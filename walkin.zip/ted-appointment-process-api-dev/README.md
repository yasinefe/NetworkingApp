# ted-appointment-process-api

* To run Application locally.

	Issue the following commands:-

	Open a command prompt

	mvn clean package

	java -jar target/ted-appointment-process-api-0.0.1.jar

	to use mock data - currently switching this via spring profiles (use the profile called local-config) ie

	java -jar target/ted-appointment-process-api-0.0.1.jar --spring.profiles.active=local-config
	
	to specify a different listening port
	
	java -jar target/ted-appointment-process-api-0.0.1.jar --server.port=xxxx
	
##Running for integration test users
java -jar target/ted-appointment-process-api-0.0.1.jar --server.port=xxxx  --spring.profiles.active=integration-test

# Logging

Logs can be monitored on Splunk. Details : [Splunk Logging](https://digital-confluence.systems.uk.hsbc/confluence/display/SDTed/Splunk+Logging+Integration)

##Example querying WalkIns Asynchronously by locationId
```
http://localhost:8090/walkins?locationId=400106
```

##Example querying a WalkIn Asynchronously by appointmentId
```
http://localhost:8090/walkins/{id}
```

##Example returning the Status Counts by locationId
```
http://localhost:8090/walkins/statusCounts?locationId=400106
```

##Example updating a WalkIn Status Asynchronously
Url. POST
```
http://localhost:8090/walkins/{id}
```
Header
```
{"Content-Type" : "application/json"}
```

Body
```
{"appointmentStatus" : "IN_MEETING"}
```

##Example getting product categories
Url. GET
```
http://localhost:8090/productCategories
```

##Example reloading the mock data on the server
```
http://localhost:8090/reset
```

##Example creating a WalkIn
Url. POST
```
http://localhost:8090/walkins
```
Header
```
{"Content-Type" : "application/json"}
```

Body
```
{
    "appointmentStatus": "CHECKED_IN",
    "duration": 90,
    "locationId": 400106,
    "topicId": "Current Account",
    "topicCategoryId": "Review",
    "topicSubCategoryId": "Subcategory",
    "attendee": {
      "firstName": "John",
      "lastName": "Smith",
      "email": "john.smith@email.com",
      "phoneNumber": "07957445933",
      "mobileNumber": "020 4444 4444",
      "gender": "Male"
    },
    "conductor": {
      "employeeId": "44443232",
      "fullName": "Edna Nashville"
    },
    "comments": "No comments",
    "proofOfId": false
  }
```

##PCF Dev Url
```
https://ted-appointment-pro.cf.wgdc-drn-01.cloud.uk.hsbc
```

##References

http://docs.spring.io/spring-framework/docs/5.0.0.BUILD-SNAPSHOT/spring-framework-reference/html/web-reactive.html

https://spring.io/blog/2016/07/20/notes-on-reactive-programming-part-iii-a-simple-http-server-application

https://spring.io/blog/2016/09/22/new-in-spring-5-functional-web-framework

https://dzone.com/articles/spring-5-reactive-microservices-1

## Password Encryption

To encrypt the password use following url:

```
https://propertyfileencryptor.cf.wgdc-drn-01.cloud.uk.hsbc/api/encryption/digital-ted/dev/property?prop=<password>
```