
curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Authorization: Bearer NDQwOTM2ODQ+0LGexqg0ArUajZMU94l0zm/C6nwc8TZWORwuAUWr8t0+MTUxMTQzMjQ1OA==" -H "X-BRANCH-ID: 404519" -d '{
    "query": "mutation CreateWalkInMutation($input_0:CreateWalkInInput!){createWalkIn(input:$input_0){clientMutationId walkIn {attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments} walkInStats {totalForToday} walkInSummary {count appointmentStatus}}}",
    "variables": {
      "input_0": {
        "gender": "MALE",
        "firstName": "John",
        "lastName": "Smith",
        "topicId": "Existing Product",
        "topicCategoryId": "Payments",
        "topicSubCategoryId": "Bill Payment",
        "proofOfId": false,
        "comments": "This is a test",
        "clientMutationId": "10"
      }
    }
   }' "https://ted-tablet-exp-dev.cf.wgdc-drn-01.cloud.uk.hsbc/graphql/"

 curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Authorization: Bearer NDQwOTM2ODQ+0LGexqg0ArUajZMU94l0zm/C6nwc8TZWORwuAUWr8t0+MTUxMTQzMjQ1OA==" -H "X-BRANCH-ID: 404519" -d '{
     "query": "mutation CreateWalkInMutation($input_0:CreateWalkInInput!){createWalkIn(input:$input_0){clientMutationId walkIn {attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments} walkInStats {totalForToday} walkInSummary {count appointmentStatus}}}",
     "variables": {
       "input_0": {
         "gender": "MALE",
         "firstName": "Jack",
         "lastName": "Smith",
         "topicId": "Existing Product",
         "topicCategoryId": "Savings",
         "topicSubCategoryId": "Close Saver",
         "proofOfId": false,
         "comments": "This is a test",
         "clientMutationId": "10"
       }
     }
    }' "https://ted-tablet-exp-dev.cf.wgdc-drn-01.cloud.uk.hsbc/graphql/"

 curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Authorization: Bearer NDQwOTM2ODQ+0LGexqg0ArUajZMU94l0zm/C6nwc8TZWORwuAUWr8t0+MTUxMTQzMjQ1OA==" -H "X-BRANCH-ID: 404519" -d '{
     "query": "mutation CreateWalkInMutation($input_0:CreateWalkInInput!){createWalkIn(input:$input_0){clientMutationId walkIn {attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments} walkInStats {totalForToday} walkInSummary {count appointmentStatus}}}",
     "variables": {
       "input_0": {
         "gender": "MALE",
         "firstName": "John",
         "lastName": "Smith",
         "topicId": "Existing Product",
         "topicCategoryId": "Savings",
         "topicSubCategoryId": "Renew Saver",
         "proofOfId": false,
         "comments": "This is a test",
         "clientMutationId": "10"
       }
     }
    }' "https://ted-tablet-exp-dev.cf.wgdc-drn-01.cloud.uk.hsbc/graphql/"

 curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Authorization: Bearer NDQwOTM2ODQ+0LGexqg0ArUajZMU94l0zm/C6nwc8TZWORwuAUWr8t0+MTUxMTQzMjQ1OA==" -H "X-BRANCH-ID: 404519" -d '{
       "query": "mutation CreateWalkInMutation($input_0:CreateWalkInInput!){createWalkIn(input:$input_0){clientMutationId walkIn {attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments} walkInStats {totalForToday} walkInSummary {count appointmentStatus}}}",
       "variables": {
         "input_0": {
           "gender": "MALE",
           "firstName": "John",
           "lastName": "Smith",
           "topicId": "Existing Product",
           "topicCategoryId": "Premier",
           "topicSubCategoryId": "Upgrade to Premier",
           "proofOfId": false,
           "comments": "This is a test",
           "clientMutationId": "10"
         }
       }
      }' "https://ted-tablet-exp-dev.cf.wgdc-drn-01.cloud.uk.hsbc/graphql/"

 curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Authorization: Bearer NDQwOTM2ODQ+0LGexqg0ArUajZMU94l0zm/C6nwc8TZWORwuAUWr8t0+MTUxMTQzMjQ1OA==" -H "X-BRANCH-ID: 404519" -d '{
       "query": "mutation CreateWalkInMutation($input_0:CreateWalkInInput!){createWalkIn(input:$input_0){clientMutationId walkIn {attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments} walkInStats {totalForToday} walkInSummary {count appointmentStatus}}}",
       "variables": {
         "input_0": {
           "gender": "MALE",
           "firstName": "Jane",
           "lastName": "Smith",
           "topicId": "New Product",
           "topicCategoryId": "Current",
           "topicSubCategoryId": "Open Account",
           "proofOfId": false,
           "comments": "This is a test",
           "clientMutationId": "10"
         }
       }
      }' "https://ted-tablet-exp-dev.cf.wgdc-drn-01.cloud.uk.hsbc/graphql/"

 curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Authorization: Bearer NDQwOTM2ODQ+0LGexqg0ArUajZMU94l0zm/C6nwc8TZWORwuAUWr8t0+MTUxMTQzMjQ1OA==" -H "X-BRANCH-ID: 404519" -d '{
        "query": "mutation CreateWalkInMutation($input_0:CreateWalkInInput!){createWalkIn(input:$input_0){clientMutationId walkIn {attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments} walkInStats {totalForToday} walkInSummary {count appointmentStatus}}}",
        "variables": {
          "input_0": {
            "gender": "MALE",
            "firstName": "Jerry",
            "lastName": "Smith",
            "topicId": "New Product",
            "topicCategoryId": "Premier",
            "topicSubCategoryId": "Open Premier Acc",
            "proofOfId": false,
            "comments": "This is a test",
            "clientMutationId": "10"
          }
        }
       }' "https://ted-tablet-exp-dev.cf.wgdc-drn-01.cloud.uk.hsbc/graphql/"

 curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Authorization: Bearer NDQwOTM2ODQ+0LGexqg0ArUajZMU94l0zm/C6nwc8TZWORwuAUWr8t0+MTUxMTQzMjQ1OA==" -H "X-BRANCH-ID: 404519" -d '{
         "query": "mutation CreateWalkInMutation($input_0:CreateWalkInInput!){createWalkIn(input:$input_0){clientMutationId walkIn {attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments} walkInStats {totalForToday} walkInSummary {count appointmentStatus}}}",
         "variables": {
           "input_0": {
             "gender": "MALE",
             "firstName": "Jerry",
             "lastName": "Smith",
             "topicId": "New Product",
             "topicCategoryId": "Unsecured Lending",
             "topicSubCategoryId": "Lending Review",
             "proofOfId": false,
             "comments": "This is a test",
             "clientMutationId": "10"
           }
         }
        }' "https://ted-tablet-exp-dev.cf.wgdc-drn-01.cloud.uk.hsbc/graphql/"
