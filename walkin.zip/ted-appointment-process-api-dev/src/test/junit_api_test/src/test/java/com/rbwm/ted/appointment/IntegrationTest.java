package com.rbwm.ted.appointment;

import com.jayway.restassured.response.Response;
import com.rbwm.ted.appointment.config.ConfigProvider;
import com.typesafe.config.Config;
import org.junit.Before;
import org.junit.Test;

import static com.jayway.restassured.RestAssured.*;
import static com.jayway.restassured.http.ContentType.JSON;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class IntegrationTest {
    private Config config;
    private String host = System.getenv("FULL_HOST_URL");

    @Before
    public void setUp() throws Exception {
        config = ConfigProvider.config();
        if (host == null || host.isEmpty()) {
            host = config.getString("baseUri");
        }
        baseURI = host;
        basePath = config.getString("basePath");
    }

    @Test
    public void testHealth() throws Exception {
        Response response = given()
                .accept(JSON)
                .when()
                .get(config.getString("healthPath"))
                .then()
                .extract().response();

        assertThat(response.getStatusCode(), is(SC_OK));
        assertThat(response.jsonPath().get("status"), is("UP"));
    }
}
