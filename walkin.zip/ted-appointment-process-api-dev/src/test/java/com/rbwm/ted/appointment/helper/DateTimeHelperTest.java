package com.rbwm.ted.appointment.helper;

import org.junit.Test;

import java.time.*;

import static org.junit.Assert.*;


/**
 * Created by 44052007 on 01/02/2018.
 */
public class DateTimeHelperTest {

    private ZonedDateTime yesterday23pm = LocalDateTime.of(2018, 1, 24, 23, 0, 0, 0).atZone(ZoneId.of("UTC"));
    private ZonedDateTime today1am = LocalDateTime.of(2018, 1, 25, 1, 0, 0, 0).atZone(ZoneId.of("UTC"));

    private ClockProvider clockYesterday23pm = new ClockProvider(Clock.fixed(yesterday23pm.toInstant(), ZoneId.of("UTC")));
    private ClockProvider clockToday1am = new ClockProvider(Clock.fixed(today1am.toInstant(), ZoneId.of("UTC")));

    private DateTimeHelper dateTimeHelper;


    // |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
    // 8   9   10  11  12  13  14  15  16  17  18  19  20  21  22  23  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18  19  20  21  22  23  0
    //
    //                                                        24/01    |--------------------------------- 25/01/2018 Europe London ------------------------------------|
    //
    //                         Clock Samples       (yesterday23pm) *       * (today1am)
    //
    // |-------------------------- 24/01/2018 America Los Angeles -------------------------------------| 25/01
    //
    // 0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18  19  20  21  22  23  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16
    // |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|



    @Test
    public void shouldReturnNow() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        assertEquals(Long.valueOf(yesterday23pm.toInstant().toEpochMilli()), dateTimeHelper.now.get());
    }

    @Test
    public void shouldReturnLocalDateOfWhenClockYesterday23pm() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        LocalDate localDateInLondon = dateTimeHelper.localDateOf.apply(yesterday23pm.toInstant().toEpochMilli(), "Europe/London");
        assertEquals(LocalDate.of(2018, 1, 24), localDateInLondon);
        LocalDate localDateInLosAngeles = dateTimeHelper.localDateOf.apply(yesterday23pm.toInstant().toEpochMilli(), "America/Los_Angeles");
        assertEquals(LocalDate.of(2018, 1, 24), localDateInLosAngeles);
    }

    @Test
    public void shouldReturnLocalDateOfWhenClockToday1am() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockToday1am);
        LocalDate localDateInLondon = dateTimeHelper.localDateOf.apply(today1am.toInstant().toEpochMilli(), "Europe/London");
        assertEquals(LocalDate.of(2018, 1, 25), localDateInLondon);
        LocalDate localDateInLosAngeles = dateTimeHelper.localDateOf.apply(today1am.toInstant().toEpochMilli(), "America/Los_Angeles");
        assertEquals(LocalDate.of(2018, 1, 24), localDateInLosAngeles);
    }

    @Test
    public void isTodayShouldReturnTrueGivenTimestampAndTimezoneIsInToday() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        assertTrue(dateTimeHelper.isToday.apply(LocalDateTime.of(2018, 1, 24, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "Europe/London"));
        assertTrue(dateTimeHelper.isToday.apply(LocalDateTime.of(2018, 1, 24, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "America/Los_Angeles"));
    }

    @Test
    public void isTodayShouldReturnFalseIfGivenTimestampAndTimezoneIsNotInToday() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockToday1am);
        // For London it is 25 but in Los Angeles it is still 24
        assertFalse(dateTimeHelper.isToday.apply(LocalDateTime.of(2018, 1, 24, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "Europe/London"));
        assertTrue(dateTimeHelper.isToday.apply(LocalDateTime.of(2018, 1, 24, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "America/Los_Angeles"));
    }

    @Test
    public void isYesterdayShouldReturnTrueGivenTimestampAndTimezoneIsInYesterday() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        assertTrue(dateTimeHelper.isYesterday.apply(LocalDateTime.of(2018, 1, 23, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "Europe/London"));
        assertTrue(dateTimeHelper.isYesterday.apply(LocalDateTime.of(2018, 1, 23, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "America/Los_Angeles"));
    }

    @Test
    public void isYesterdayShouldReturnFalseIfGivenTimestampAndTimezoneIsNotInYesterday() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockToday1am);
        // For London it is 25 so yesterday is 24 but in Los Angeles it is still 24 so yesterday is 23
        assertFalse(dateTimeHelper.isYesterday.apply(LocalDateTime.of(2018, 1, 23, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "Europe/London"));
        assertTrue(dateTimeHelper.isYesterday.apply(LocalDateTime.of(2018, 1, 23, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "America/Los_Angeles"));
    }

    @Test
    public void isYesterdayShouldReturnTrueIfGivenTimestampAndTimezoneIsInSaturdaySkipSundaysCase() throws Exception {
        ZonedDateTime monday1am = LocalDateTime.of(2018, 1, 22, 15, 0, 0, 0).atZone(ZoneId.of("UTC"));

        ClockProvider clockMonday1am = new ClockProvider(Clock.fixed(monday1am.toInstant(), ZoneId.of("UTC")));

        dateTimeHelper = new DateTimeHelper(clockMonday1am);
        assertTrue(dateTimeHelper.isYesterday.apply(LocalDateTime.of(2018, 1, 20, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "Europe/London"));
        assertTrue(dateTimeHelper.isYesterday.apply(LocalDateTime.of(2018, 1, 20, 13, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(), "America/Los_Angeles"));
    }

    @Test
    public void shouldReturnEpocPlusMinutes() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        LocalDateTime minutesAfter = LocalDateTime.of(2018, 1, 24, 23, 3, 0, 0);
        assertEquals(minutesAfter, dateTimeHelper.epochPlusMinutes.apply(yesterday23pm.toInstant().toEpochMilli(), 3));
    }

    @Test
    public void shouldReturnFalseEpocPlusMinutesBeforeNow() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        ZonedDateTime before2Mins = LocalDateTime.of(2018, 1, 24, 22, 58, 0, 0).atZone(ZoneId.of("UTC"));
        assertFalse(dateTimeHelper.isEpochPlusMinutesAfterNow.apply(before2Mins.toInstant().toEpochMilli(), 1));
    }

    @Test
    public void shouldReturnFalseEpocPlusMinutesAfterNow() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        ZonedDateTime before2Mins = LocalDateTime.of(2018, 1, 24, 22, 58, 0, 0).atZone(ZoneId.of("UTC"));
        assertTrue(dateTimeHelper.isEpochPlusMinutesAfterNow.apply(before2Mins.toInstant().toEpochMilli(), 3));
    }

    @Test
    public void shouldReturnEpochOfDaysBefore() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        ZonedDateTime twoDaysBefore = LocalDateTime.of(2018, 1, 22, 23, 0, 0, 0).atZone(ZoneId.of("UTC"));
        assertEquals(Long.valueOf(twoDaysBefore.toInstant().toEpochMilli()), dateTimeHelper.epocOfDaysBefore.apply(2));
    }

    @Test
    public void shouldReturnHourInTimeZone() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockYesterday23pm);
        assertEquals("23:00", dateTimeHelper.getHourInTimeZone.apply("Europe/London"));
        assertEquals("15:00", dateTimeHelper.getHourInTimeZone.apply("America/Los_Angeles"));
    }

    @Test
    public void shouldReturnTrueIfNowIsOver() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockToday1am);
        ZonedDateTime tenMinsEarlier = LocalDateTime.of(2018, 1, 25, 0, 50, 0, 0).atZone(ZoneId.of("UTC"));
        assertTrue(dateTimeHelper.nowIsOverOf.apply(tenMinsEarlier.toInstant().toEpochMilli(), 5));
    }

    @Test
    public void shouldReturnFalseIfNowIsNotOver() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockToday1am);
        ZonedDateTime tenMinsAfter = LocalDateTime.of(2018, 1, 25, 1, 10, 0, 0).atZone(ZoneId.of("UTC"));
        assertFalse(dateTimeHelper.nowIsOverOf.apply(tenMinsAfter.toInstant().toEpochMilli(), 5));
    }

    @Test
    public void shouldFormatDateTimeInISO() throws Exception {
        dateTimeHelper = new DateTimeHelper(clockToday1am);
        ZonedDateTime tenMinsAfter = LocalDateTime.of(2018, 1, 25, 1, 10, 15, 0).atZone(ZoneId.of("UTC"));
        assertEquals("2018-01-24T17:10:15.000-0800", dateTimeHelper.toIsoFormat.apply(tenMinsAfter.toInstant().toEpochMilli(), "America/Los_Angeles"));
        assertEquals("2018-01-25T01:10:15.000+0000", dateTimeHelper.toIsoFormat.apply(tenMinsAfter.toInstant().toEpochMilli(), "Europe/London"));
    }
}