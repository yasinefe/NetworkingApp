/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 02/10/2017.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CryptConfiguration.class, CryptConfigurationTest.Config.class})
@TestPropertySource(
        properties = {
                "test.crypto.key=ENC(CQZzVJsggr2IFvzhPyIwcxYZDxb9)",
                "test.regular.property=TEST"
        }
)
public class CryptConfigurationTest {

    @Autowired
    private Environment environment;

    @Test
    public void testRegularKeyWorks() throws Exception {
        assertEquals("TEST", environment.getProperty("test.regular.property"));
    }

    @Test
    public void testEncryptedKeyIsDecrypted() {
        assertEquals("testCryptoKey", environment.getProperty("test.crypto.key"));
    }

    @Configuration
    public static class Config {

        @Bean
        public EnvironmentStringPBEConfig environmentVariablesConfiguration() {
            EnvironmentStringPBEConfig environmentStringPBEConfig = new EnvironmentStringPBEConfig();
            environmentStringPBEConfig.setAlgorithm("PBEWITHSHA1ANDRC4_128");
            environmentStringPBEConfig.setPassword("password");
            return environmentStringPBEConfig;
        }
    }

}