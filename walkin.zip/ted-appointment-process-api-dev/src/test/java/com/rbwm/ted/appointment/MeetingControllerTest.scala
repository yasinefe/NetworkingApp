/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import com.rbwm.ted.appointment.model.Appointment.{Employee, Person}
import com.rbwm.ted.appointment.model._
import org.mockito.Mockito._
import org.springframework.http.HttpStatus
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import reactor.core.publisher.{Flux, Mono}

/**
  * Created by 44052007 on 02/05/2018.
  */
class MeetingControllerTest extends ControllerTest {

  def meetingResponse =
    """
      {
        "status": "IN_MEETING",
        "group": "IN_MEETING",
        "meetingId": "meetingId",
        "topicId": "topicId",
        "topicName": "topicName",
        "topicCategoryId": "topicCategoryId",
        "topicCategoryName": "topicCategoryName",
        "topicSubCategoryId": "topicSubCategoryId",
        "topicSubCategoryName": "topicSubCategoryName",
        "conductor": {
          "employeeId": "employeeId",
          "fullName": "fullName"
        },
        "bookedFor": "2018-05-01T12:20:45.000+0100",
        "checkedInAt": "2018-05-01T12:20:45.000+0100",
        "startedAt": "2018-05-01T12:20:45.000+0100",
        "endedAt": "2018-05-01T12:20:45.000+0100",
        "duration": 15,
        "isNew": true,
        "isOverdue": true,
        "isOverdueCritical": true,
        "isOverrun": true,
        "isOverrunCritical": true,
        "attendee": {
          "firstName": "firstName",
          "lastName": "lastName",
          "email": "email",
          "phoneNumber": "pnoneNumber",
          "mobileNumber": "mobileNumber",
          "gender": "gender"
        },
        "comments": "comments",
        "proofOfId": true,
        "countryCode": "GBR",
        "endedBy": "USER",
        "timezone": "Europe/London"
      }
    """.stripMargin

  def meetingsResponse = "[" + meetingResponse + "]"


  val person = new Person("firstName", "lastName", "email", "pnoneNumber", "mobileNumber", "gender")
  val employee = new Employee("employeeId", "fullName")
  val meeting = new Meeting(MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING, "meetingId", "topicId", "topicName",
    "topicCategoryId", "topicCategoryName", "topicSubCategoryId", "topicSubCategoryName", employee, "2018-05-01T12:20:45.000+0100",
    "2018-05-01T12:20:45.000+0100", "2018-05-01T12:20:45.000+0100", "2018-05-01T12:20:45.000+0100", 15, true, true, true,
    true, true, person, "comments", true, "GBR", ModifierType.USER, "Europe/London")

  val meetings = new java.util.ArrayList[Meeting]
  meetings.add(meeting)

  it should " return all meetings " in {
    when(meetingService.getMeetings("400123", null, null)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return meetings filtered by meeting status " in {
    when(meetingService.getMeetings("400123", MeetingStatus.IN_MEETING, null)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123?meetingStatus=IN_MEETING", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return meetings filtered by meeting group " in {
    when(meetingService.getMeetings("400123", null, MeetingGroup.IN_MEETING)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123?meetingGroup=IN_MEETING", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return meeting " in {
    when(meetingService.getMeeting("meetingId")).thenReturn(Mono.just(meeting))
    doGetAsync("/meetings/meetingId", HttpStatus.OK)
      .andExpect(content.json(meetingResponse))
  }

  it should " create meeting " in {
    val meetingInput = new MeetingInput("400123", Gender.FEMALE, "firstName", "lastName", "topicId", "topicCategoryId", "topicSubCategoryId", true, "comments");
    when(meetingService.createMeeting(meetingInput)).thenReturn(Mono.just(meeting))

    def request =
      """
      {
        "branchId": "400123",
        "firstName": "firstName",
        "lastName": "lastName",
        "gender": "FEMALE",
        "topicId": "topicId",
        "topicCategoryId": "topicCategoryId",
        "topicSubCategoryId": "topicSubCategoryId",
        "comments": "comments",
        "proofOfId": true
      }
      """.stripMargin

    doPostAsync("/meetings", HttpStatus.OK, request)
      .andExpect(content.json(meetingResponse))
  }

  it should " update meeting status " in {
    when(meetingService.updateMeetingStatus("meetingId", MeetingStatus.IN_MEETING)).thenReturn(Mono.just(meeting))

    def request =
      """
      {
        "meetingStatus": "IN_MEETING"
      }
      """.stripMargin

    doPutAsync("/meetings/meetingId", HttpStatus.OK, request)
      .andExpect(content.json(meetingResponse))
  }

  it should " return meeting stats " in {
    def statsResponse =
      """
      {
        "waitingTime": {
          "count": 1,
          "sum": 2
        },
        "waitingTimeLastWorkingDay": {
           "count": 3,
           "sum": 4
        },
        "meetingLength": {
           "count": 5,
           "sum": 6
        },
        "inNextHour": 7
      }
      """.stripMargin

    when(meetingStatsService.getMeetingStats("400123")).thenReturn(Mono.just(new MeetingStats(new StatData(1, 2L), new StatData(3, 4L), new StatData(5, 6L), 7)))
    doGetAsync("/meetings/stats/branchId/400123", HttpStatus.OK)
      .andExpect(content.json(statsResponse))
  }

}
