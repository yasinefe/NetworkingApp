/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by 43578876 on 21/04/2017.
 */
public class ServerExceptionTest {


    @Test
    public void getError() throws Exception {
        Exceptions.ServerException exception = new Exceptions.NotFoundException(ErrorCode.WALKIN_NOT_FOUND,"1234");
        assertEquals(new Error(302,"Walkin not found for id: 1234"),exception.getError());
    }

}