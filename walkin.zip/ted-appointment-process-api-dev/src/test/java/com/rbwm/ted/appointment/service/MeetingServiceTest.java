/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.api.MeetingServiceApi;
import com.rbwm.ted.appointment.api.WalkInServiceApi;
import com.rbwm.ted.appointment.config.WalkInConfig;
import com.rbwm.ted.appointment.helper.ClockProvider;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import com.rbwm.ted.appointment.input.WalkInInput;
import com.rbwm.ted.appointment.model.Appointment.Employee;
import com.rbwm.ted.appointment.model.Appointment.Person;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.model.*;
import com.rbwm.ted.appointment.repository.WalkInRepository;
import org.junit.Before;
import org.junit.Test;
import reactor.core.publisher.Flux;

import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import static com.rbwm.ted.appointment.model.ModifierType.USER;
import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Flux.fromIterable;
import static reactor.core.publisher.Mono.just;

/**
 * Created by 44052007 on 01/05/2018.
 */
public class MeetingServiceTest {

    private ZonedDateTime time = LocalDateTime.of(2018, 5, 1, 11, 23, 45, 175).atZone(ZoneId.of("UTC"));
    private ClockProvider clockProvider = new ClockProvider(Clock.fixed(time.toInstant(), ZoneId.of("UTC")));
    private DateTimeHelper dateTimeHelper = new DateTimeHelper(clockProvider);
    private WalkInServiceApi mockWalkInService = mock(WalkInServiceApi.class);
    private WalkInConfig mockWalkInConfig = mock(WalkInConfig.class);
    private WalkInRepository mockWalkInRepository = mock(WalkInRepository.class);

    private MeetingServiceApi meetingServiceApi = new MeetingService(mockWalkInService, dateTimeHelper, mockWalkInConfig, mockWalkInRepository);

    private WalkIn checkedInWalkIn;
    private Meeting checkedInMeeting;
    private Meeting inMeetingMeeting;
    private Meeting completedMeeting;
    private Meeting cancelledMeeting;
    private Meeting overdueMeeting;
    private Meeting newMeeting;
    private Meeting oldMeeting;
    private Meeting criticalOverdueMeeting;
    private Meeting overRunMeeting;
    private Meeting criticalOverRunMeeting;

    @Before
    public void setUp() throws Exception {
        when(mockWalkInConfig.getOverdueOffset()).thenReturn(5);
        when(mockWalkInConfig.getNewOffset()).thenReturn(10);
        when(mockWalkInConfig.getCriticalOverDueOffset()).thenReturn(15);
        when(mockWalkInConfig.getCriticalOverRunOffset()).thenReturn(10);

        checkedInWalkIn = createWalkIn("1234001", AppointmentStatus.CHECKED_IN, minsBefore(7),
                minsAfter(2), null, null, null);
        checkedInMeeting = createMeeting("1234001", MeetingStatus.CHECKED_IN, MeetingGroup.CHECKED_IN,
                minsBefore(7), minsAfter(2), null, null, null, true, false,
                false, false, false);

        WalkIn inMeetingWalkIn = createWalkIn("1234002", AppointmentStatus.IN_MEETING, minsBefore(16),
                minsBefore(11), minsBefore(11), null, null);
        inMeetingMeeting = createMeeting("1234002", MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING,
                minsBefore(16), minsBefore(11), minsBefore(11), null, null, false,
                false, false, false, false);

        WalkIn completedWalkIn = createWalkIn("1234003", AppointmentStatus.COMPLETED, minsBefore(30),
                minsBefore(25), minsBefore(25), minsBefore(10), USER);
        completedMeeting = createMeeting("1234003", MeetingStatus.COMPLETED, MeetingGroup.COMPLETED,
                minsBefore(30), minsBefore(25), minsBefore(25), minsBefore(10), USER, false,
                false, false, false, false);

        WalkIn cancelledWalkIn = createWalkIn("1234004", AppointmentStatus.CANCELLED, minsBefore(30),
                minsBefore(25), null, minsBefore(28), USER);
        cancelledMeeting = createMeeting("1234004", MeetingStatus.CANCELLED, MeetingGroup.COMPLETED,
                minsBefore(30), minsBefore(25), null, minsBefore(28), USER, false,
                false, false, false, false);


        WalkIn overdueWalkIn = createWalkIn("1234005", AppointmentStatus.CHECKED_IN, minsBefore(15),
                minsBefore(10), null, null, null);
        overdueMeeting = createMeeting("1234005", MeetingStatus.CHECKED_IN, MeetingGroup.CHECKED_IN,
                minsBefore(15), minsBefore(10), null, null, null, false,
                true, false, false, false);


        WalkIn criticalOverdueWalkIn = createWalkIn("1234006", AppointmentStatus.CHECKED_IN, minsBefore(21),
                minsBefore(16), null, null, null);
        criticalOverdueMeeting = createMeeting("1234006", MeetingStatus.CHECKED_IN, MeetingGroup.CHECKED_IN,
                minsBefore(21), minsBefore(16), null, null, null, false,
                true, true, false, false);

        WalkIn newWalkIn = createWalkIn("1234007", AppointmentStatus.CHECKED_IN, minsBefore(8),
                minsBefore(3), null, null, null);
        newMeeting = createMeeting("1234007", MeetingStatus.CHECKED_IN, MeetingGroup.CHECKED_IN,
                minsBefore(8), minsBefore(3), null, null, null, true,
                false, false, false, false);


        WalkIn oldWalkIn = createWalkIn("1234008", AppointmentStatus.CHECKED_IN, minsBefore(11),
                minsBefore(6), null, null, null);
        oldMeeting = createMeeting("1234008", MeetingStatus.CHECKED_IN, MeetingGroup.CHECKED_IN,
                minsBefore(11), minsBefore(6), null, null, null, false,
                true, false, false, false);

        WalkIn overRunWalkIn = createWalkIn("1234009", AppointmentStatus.IN_MEETING, minsBefore(21),
                minsBefore(16), minsBefore(16), null, null);
        overRunMeeting = createMeeting("1234009", MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING,
                minsBefore(21), minsBefore(16), minsBefore(16), null, null, false,
                false, false, true, false);

        WalkIn criticalOverRunWalkIn = createWalkIn("1234010", AppointmentStatus.IN_MEETING, minsBefore(36),
                minsBefore(31), minsBefore(31), null, null);
        criticalOverRunMeeting = createMeeting("1234010", MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING,
                minsBefore(36), minsBefore(31), minsBefore(31), null, null, false,
                false, false, true, true);

        Flux<WalkIn> walkInFlux = fromIterable(asList(checkedInWalkIn, inMeetingWalkIn, completedWalkIn, cancelledWalkIn,
                overdueWalkIn, criticalOverdueWalkIn, newWalkIn, oldWalkIn, overRunWalkIn, criticalOverRunWalkIn));

        when(mockWalkInRepository.findByBranchId("400706")).thenReturn(walkInFlux);
        when(mockWalkInRepository.findById("1234001")).thenReturn(just(checkedInWalkIn));
    }

    @Test
    public void shouldReturnAllMeetingsConvertedFromWalkIns() throws Exception {
        List<Meeting> actualMeetings = meetingServiceApi.getMeetings("400706", null, null).collectList().block();
        List<Meeting> expectedMeetings = asList(checkedInMeeting, inMeetingMeeting, completedMeeting, cancelledMeeting,
                overdueMeeting, criticalOverdueMeeting, newMeeting, oldMeeting, overRunMeeting, criticalOverRunMeeting);

        assertEquals(expectedMeetings, actualMeetings);
    }

    @Test
    public void shouldReturnMeetingsFilteredByMeetingStatus() throws Exception {
        List<Meeting> actualMeetings = meetingServiceApi.getMeetings("400706", MeetingStatus.IN_MEETING, null).collectList().block();
        List<Meeting> expectedMeetings = asList(inMeetingMeeting, overRunMeeting, criticalOverRunMeeting);

        assertEquals(expectedMeetings, actualMeetings);
    }

    @Test
    public void shouldReturnMeetingsFilteredByMeetingGroup() throws Exception {
        List<Meeting> actualMeetings = meetingServiceApi.getMeetings("400706", null, MeetingGroup.CHECKED_IN).collectList().block();
        List<Meeting> expectedMeetings = asList(checkedInMeeting, overdueMeeting, criticalOverdueMeeting, newMeeting, oldMeeting);

        assertEquals(expectedMeetings, actualMeetings);
    }

    @Test
    public void shouldReturnMeeting() throws Exception {
        Meeting actualMeeting = meetingServiceApi.getMeeting("1234001").block();
        assertEquals(checkedInMeeting, actualMeeting);
    }

    @Test
    public void shouldReturnOverdueWalkInProgressPassedCheckedIn() {
        //Given
        WalkIn inMeetingOverdueWalkIn = createWalkIn("1234010", AppointmentStatus.IN_MEETING,
                minsAfter(0), minsAfter(0), minsAfter(7), null, null);
        WalkIn completedCriticallyOverdueWalkIn = createWalkIn("1234011", AppointmentStatus.COMPLETED,
                minsAfter(0), minsAfter(0), minsAfter(16), minsAfter(16), USER);
        given(mockWalkInRepository.findByBranchId("400672")).willReturn(Flux.just(inMeetingOverdueWalkIn, completedCriticallyOverdueWalkIn));

        //When
        List<Meeting> actual = meetingServiceApi.getMeetings("400672", null, null).collectList().block();

        //Then
        Meeting expectedMeeting1 = createMeeting("1234010", MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING,
                minsAfter(0), minsAfter(0), minsAfter(7), null, null, true,
                true, false, false, false);
        Meeting expectedMeeting2 = createMeeting("1234011", MeetingStatus.COMPLETED, MeetingGroup.COMPLETED,
                minsAfter(0), minsAfter(0), minsAfter(16), minsAfter(16), USER, true,
                true, true, false, false);
        List<Meeting> expected = asList(expectedMeeting1, expectedMeeting2);

        assertEquals(expected, actual);
    }

    @Test
    public void shouldReturnOverdueForWalkInCancelledAfterOverdueOffset() {
        //Given
        WalkIn cancelledOverdueWalkIn = createWalkIn("1234010", AppointmentStatus.CANCELLED,
                minsAfter(0), minsAfter(0), null, minsAfter(6), USER);
        WalkIn cancelledCriticallyOverdueWalkIn = createWalkIn("1234011", AppointmentStatus.CANCELLED,
                minsAfter(0), minsAfter(0), null, minsAfter(16), USER);
        given(mockWalkInRepository.findByBranchId("400672")).willReturn(Flux.just(cancelledOverdueWalkIn, cancelledCriticallyOverdueWalkIn));

        //When
        List<Meeting> actual = meetingServiceApi.getMeetings("400672", null, null).collectList().block();

        //Then
        Meeting expectedMeeting1 = createMeeting("1234010", MeetingStatus.CANCELLED, MeetingGroup.COMPLETED,
                minsAfter(0), minsAfter(0), null, minsAfter(6), USER, true,
                true, false, false, false);
        Meeting expectedMeeting2 = createMeeting("1234011", MeetingStatus.CANCELLED, MeetingGroup.COMPLETED,
                minsAfter(0), minsAfter(0), null, minsAfter(16), USER, true,
                true, true, false, false);
        List<Meeting> expected = asList(expectedMeeting1, expectedMeeting2);

        assertEquals(expected, actual);
    }

    @Test
    public void shouldReturnOverrunWalkInsProgressedPassedInMeeting() {
        //Given
        WalkIn completedOverRunWalkIn = createWalkIn("1234010", AppointmentStatus.COMPLETED, minsBefore(36),
                minsBefore(30), minsBefore(30), minsBefore(14), USER);
        WalkIn completedCriticalOverRunWalkIn = createWalkIn("1234011", AppointmentStatus.COMPLETED, minsBefore(36),
                minsBefore(30), minsBefore(30), minsBefore(4), USER);
        given(mockWalkInRepository.findByBranchId("400672")).willReturn(Flux.just(completedOverRunWalkIn, completedCriticalOverRunWalkIn));

        //When
        List<Meeting> actual = meetingServiceApi.getMeetings("400672", null, null).collectList().block();

        //Then
        Meeting expectedMeeting1 = createMeeting("1234010", MeetingStatus.COMPLETED, MeetingGroup.COMPLETED,
                minsBefore(36), minsBefore(30), minsBefore(30), minsBefore(14), USER, false,
                false, false, true, false);
        Meeting expectedMeeting2 = createMeeting("1234011", MeetingStatus.COMPLETED, MeetingGroup.COMPLETED,
                minsBefore(36), minsBefore(30), minsBefore(30), minsBefore(4), USER, false,
                false, false, true, true);
        List<Meeting> expected = asList(expectedMeeting1, expectedMeeting2);

        assertEquals(expected, actual);
    }

    @Test
    public void shouldCreateMeeting() throws Exception {
        Person attendee = new Person("firstName", "lastName", null, null, null, "FEMALE");
        WalkInInput walkInInput = new WalkInInput(null, AppointmentStatus.CHECKED_IN, 15, "400706", "topicId", "topicCategoryId", "topicSubCategoryId", "comments", true, attendee, null);
        when(mockWalkInService.insert(walkInInput)).thenReturn(just(checkedInWalkIn));

        MeetingInput meetingInput = new MeetingInput("400706", Gender.FEMALE, "firstName", "lastName",
                "topicId", "topicCategoryId", "topicSubCategoryId", true, "comments");
        Meeting actualMeeting = meetingServiceApi.createMeeting(meetingInput).block();

        assertEquals(checkedInMeeting, actualMeeting);
    }

    @Test
    public void shouldCreateMeetingWithoutOptionalFields() throws Exception {
        Person attendee = new Person("firstName", "lastName", null, null, null, null);
        WalkInInput walkInInput = new WalkInInput(null, AppointmentStatus.CHECKED_IN, 15, "400706", "topicId", "topicCategoryId", null, null, true, attendee, null);
        when(mockWalkInService.insert(walkInInput)).thenReturn(just(checkedInWalkIn));

        MeetingInput meetingInput = new MeetingInput("400706", null, "firstName", "lastName",
                "topicId", "topicCategoryId", null, true, null);
        Meeting actualMeeting = meetingServiceApi.createMeeting(meetingInput).block();

        assertEquals(checkedInMeeting, actualMeeting);
    }

    @Test
    public void shouldUpdateMeetingStatus() throws Exception {
        when(mockWalkInService.updateStatus("1234001", AppointmentStatus.IN_MEETING)).thenReturn(just(checkedInWalkIn));

        Meeting actualMeeting = meetingServiceApi.updateMeetingStatus("1234001", MeetingStatus.IN_MEETING).block();
        assertEquals(checkedInMeeting, actualMeeting);
    }

    private Long minsBefore(int min) {
        return minsAfter(-1 * min);
    }

    private Long minsAfter(int min) {
        return time.toInstant().plus(min, ChronoUnit.MINUTES).toEpochMilli();
    }

    private WalkIn createWalkIn(String appointmentId, AppointmentStatus appointmentStatus, Long created, Long dateTime, Long startedAt, Long endedAt, ModifierType endedBy) {
        Person person = new Person("firstName", "lastName", "email", "pnoneNumber",
                "mobileNumber", "FEMALE");
        Employee employee = new Employee("employeeId", "fullName");
        return new WalkIn(appointmentId, appointmentStatus, 15, null, "400706",
                "topicId", "topicCategoryId", "topicSubCategoryId", "comments",
                true, person, employee, created, dateTime, dateTime, startedAt, "Europe/London", "GBR", endedAt,
                endedBy);
    }

    private Meeting createMeeting(String meetingId, MeetingStatus meetingStatus, MeetingGroup meetingGroup, Long checkedInAt,
                                  Long bookedFor, Long startedAt, Long endedAt, ModifierType endedBy,
                                  Boolean isNew, Boolean isOverDue, Boolean isOverDueCritical, Boolean isOverRun,
                                  Boolean isOverRunCritical) {
        Person person = new Person("firstName", "lastName", "email", "pnoneNumber",
                "mobileNumber", "FEMALE");
        Employee employee = new Employee("employeeId", "fullName");
        return new Meeting(meetingStatus, meetingGroup, meetingId, "topicId", "topicId",
                "topicCategoryId", "topicCategoryId", "topicSubCategoryId",
                "topicSubCategoryId", employee, formatDate(bookedFor), formatDate(checkedInAt),
                formatDate(startedAt), formatDate(endedAt), 15, isNew, isOverDue, isOverDueCritical, isOverRun,
                isOverRunCritical, person, "comments", true, "GBR", endedBy, "Europe/London");
    }

    private String formatDate(Long datetime) {
        if (datetime == null) {
            return null;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Europe/London"));
        return simpleDateFormat.format(new Date(datetime));
    }
}