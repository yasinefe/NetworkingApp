/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import com.rbwm.ted.appointment.api.BranchServiceApi
import com.rbwm.ted.appointment.filter.{CorrelationIdFilter, LoggingFilter}
import com.rbwm.ted.appointment.model.Branch.{Address, BranchDetails}
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer
import com.rbwm.ted.telemetry.logging.RequestLogging
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertEquals
import org.junit.runner.RunWith
import org.mockito.Mockito._
import org.scalatest.junit.JUnitRunner
import org.scalatest.mockito.MockitoSugar
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.{HttpHeaders, HttpStatus}
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.test.context.{ContextConfiguration, TestContextManager, TestPropertySource}
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import org.springframework.test.web.servlet.setup.{MockMvcBuilders, StandaloneMockMvcBuilder}
import reactor.core.publisher.{Flux}

import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
/**
  * Created by 44027117 on 11/05/2017.
  */
@RunWith(classOf[JUnitRunner])
@TestPropertySource(properties = Array[String]{"spring.config.location = classpath:config/ted-appointment-process-api.yaml"})
@SpringBootTest(classes = Array(classOf[ConfigMock]))
class CorrelationIdTest extends FlatSpec
  with Matchers
  with MockitoSugar
  with BeforeAndAfter
  with RestTestPack {

  var mvc: MockMvc = _
  var branchService: BranchServiceApi = _
  var testLoggingFilter: TestLoggingFilter = new TestLoggingFilter

  before {
    new TestContextManager(this.getClass).prepareTestInstance(this)
    branchService = mock[BranchServiceApi]

    val controller = new BranchController(branchService)
    val mvcBuilder: StandaloneMockMvcBuilder = MockMvcBuilders.standaloneSetup(controller).addFilters(new CorrelationIdFilter, testLoggingFilter)
    mvc = mvcBuilder.build()
  }

  val address = new Address("68 Whitehall Waterfront", "2 RiverSide Way", "Leeds", "LS14EE", "West Yorkshire", "GB")
  val canaryWharf = new BranchDetails("1234", "GB123456", 11.11, 22.22, "Europe/London", "Canary Wharf", address)

  def branchListResponse = """
        [
          {
            "branchId": "1234",
            "longitude": 11.11,
            "latitude": 22.22,
            "timezone": "Europe/London",
            "name": "Canary Wharf",
            "address": {
              "addressLine1": "68 Whitehall Waterfront",
              "addressLine2": "2 RiverSide Way",
              "city": "Leeds",
              "postcode": "LS14EE",
              "county": "West Yorkshire",
              "countryCode": "GB"
            }
          }
        ]
      """

  it should " return all branches by country code" in {
    val branchDetailsList = new java.util.ArrayList[BranchDetails]
    branchDetailsList.add(canaryWharf)

    val fluxBranches = Flux.fromIterable(branchDetailsList)
    when(branchService.findByCountryCode("GB", null)).thenReturn(fluxBranches)

    doGetAsync("/branches/countryCode/GB", HttpStatus.OK)
      .andExpect(content.json(branchListResponse))

    val correlationId = CorrelationIdContainer.getId
    assertNotNull(correlationId)
    assertEquals(testLoggingFilter.requestLogging.key,  "CorrelationId")
    assertEquals(testLoggingFilter.requestLogging.value,  correlationId)

    val httpHeaders = new HttpHeaders()
    httpHeaders.add("X-CORRELATION-ID", correlationId)
    doGetAsync("/branches/countryCode/GB", HttpStatus.OK, httpHeaders)
      .andExpect(content.json(branchListResponse))

    val newCorrelationId = CorrelationIdContainer.getId

    assertEquals(correlationId, newCorrelationId)
    assertEquals(testLoggingFilter.requestLogging.key,  "CorrelationId")
    assertEquals(testLoggingFilter.requestLogging.value,  newCorrelationId)

  }

  class TestLoggingFilter extends LoggingFilter() {

    var requestLogging: TestRequestLogging = _

    override def getRequestLogging: RequestLogging = {
      requestLogging = new TestRequestLogging
      requestLogging
    }
  }

  class TestRequestLogging() extends RequestLogging {

    var key: String = _
    var value: String = _

    override def withKeyValue(key: String, value: String): RequestLogging = {
      super.withKeyValue(key, value)
      this.key = key
      this.value = value
      this
    }
  }
}
