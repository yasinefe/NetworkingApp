/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.repository;

import com.rbwm.ted.appointment.config.MongoConfig;
import com.rbwm.ted.appointment.config.WalkInConfig;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.helper.ClockProvider;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import com.rbwm.ted.appointment.model.Appointment.Employee;
import com.rbwm.ted.appointment.model.Appointment.Person;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.service.WalkInFilters;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

import static com.rbwm.ted.appointment.model.AppointmentStatus.CHECKED_IN;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by 43578876 on 04/04/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class WalkInRepositoryTest {

    private static final Instant instant = LocalDateTime.of(2018, 1, 24, 23, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant();
    private static final Instant yesterdayInstant = LocalDateTime.of(2018, 1, 23, 23, 0, 0, 0).atZone(ZoneId.of("UTC")).toInstant();
    private static final int OVERDUE_OFFSET = 15;
    private static final String BRANCH_ID = "1234";
    private static final String APPOINTMENT_ID = "12334";
    private static final String WALKINS_COLLECTION = "walkIns";

    @Mock
    private ReactiveMongoTemplate mongoTemplate;

    @Mock
    private MongoConfig mongoConfig;

    @Mock
    private WalkInConfig walkInConfig;

    private DateTimeHelper dateTimeHelper = new DateTimeHelper(new ClockProvider(Clock.fixed(instant, ZoneId.systemDefault())));

    private WalkInRepository walkInRepository;

    private Person person = new Person("John", "Smith", "john.smith@email.com", "07957445933",
            "020 4444 4444", "Male");
    private Employee staff = new Employee("44443232", "Edna Nashville");

    private WalkIn walkIn = new WalkIn(APPOINTMENT_ID, CHECKED_IN, 90, null, "400706",
            "Current Account", "Review", "Subcategory", "No comments", false, person,
            staff, instant.toEpochMilli(), instant.toEpochMilli(), instant.toEpochMilli(), instant.toEpochMilli(), "Europe/London",
            "GBR", instant.toEpochMilli(), null);

    private WalkIn yesterdayWalkIn = new WalkIn(APPOINTMENT_ID, CHECKED_IN, 90, null, "400706",
            "Current Account", "Review", "Subcategory", "No comments", false, person,
            staff, yesterdayInstant.toEpochMilli(), yesterdayInstant.toEpochMilli(), yesterdayInstant.toEpochMilli(), yesterdayInstant.toEpochMilli(),
            "Europe/London", "GBR", instant.toEpochMilli(), null);

    private WalkIn walkInWithOverdue = new WalkIn(APPOINTMENT_ID, CHECKED_IN, 90, 15, "400706",
            "Current Account", "Review", "Subcategory", "No comments", false, person,
            staff, instant.toEpochMilli(), instant.toEpochMilli(), instant.toEpochMilli(), instant.toEpochMilli(), "Europe/London",
            "GBR", instant.toEpochMilli(), null);

    private WalkIn yesterdayWalkInWithOverdue = new WalkIn(APPOINTMENT_ID, CHECKED_IN, 90, 15, "400706",
            "Current Account", "Review", "Subcategory", "No comments", false, person,
            staff, yesterdayInstant.toEpochMilli(), yesterdayInstant.toEpochMilli(), yesterdayInstant.toEpochMilli(), yesterdayInstant.toEpochMilli(),
            "Europe/London", "GBR", instant.toEpochMilli(), null);

    @Before
    public void setUp() throws Exception {
        when(walkInConfig.getOverdueOffset()).thenReturn(OVERDUE_OFFSET);
        when(mongoConfig.getWalkInsCollection()).thenReturn(WALKINS_COLLECTION);
        WalkInFilters walkInFilters = new WalkInFilters(dateTimeHelper);
        walkInRepository = new WalkInRepository(mongoTemplate, mongoConfig, walkInConfig, dateTimeHelper, walkInFilters);
    }

    @Test
    public void shouldFindWalkInsByLocationId() {
        Criteria criteria = Criteria
                .where("branchId").is(BRANCH_ID)
                .andOperator(Criteria
                        .where("dateTime").gte(dateTimeHelper.epocOfDaysBefore.apply(1)));

        when(mongoTemplate.find(Query.query(criteria), WalkIn.class, WALKINS_COLLECTION)).thenReturn(Flux.just(walkIn, yesterdayWalkIn));

        Flux<WalkIn> walkIns = walkInRepository.findByBranchId(BRANCH_ID);
        assertEquals(asList(walkInWithOverdue), walkIns.collectList().block());
    }

    @Test
    public void shouldFindYesterdayWalkInsByLocationId() {
        Criteria criteria = Criteria
                .where("branchId").is(BRANCH_ID)
                .andOperator(Criteria
                        .where("dateTime").gte(dateTimeHelper.epocOfDaysBefore.apply(3)));

        when(mongoTemplate.find(Query.query(criteria), WalkIn.class, WALKINS_COLLECTION)).thenReturn(Flux.just(walkIn, yesterdayWalkIn));

        Flux<WalkIn> walkIns = walkInRepository.findYesterdayByBranchId(BRANCH_ID);
        assertEquals(asList(yesterdayWalkInWithOverdue), walkIns.collectList().block());
    }

    @Test
    public void shouldFindWalkInById() {
        when(mongoTemplate.findById(APPOINTMENT_ID, WalkIn.class, WALKINS_COLLECTION)).thenReturn(Mono.just(walkIn));

        Mono<WalkIn> walkIn = walkInRepository.findById(APPOINTMENT_ID);
        assertEquals(walkInWithOverdue, walkIn.block());
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void shouldThrowExceptionWhenWalkInNotFound() {
        when(mongoTemplate.findById(APPOINTMENT_ID, WalkIn.class, WALKINS_COLLECTION)).thenReturn(Mono.empty());

        walkInRepository.findById(APPOINTMENT_ID).block();
    }

    @Test
    public void shouldSaveWalkIn() {
        Mono<WalkIn> monoWalkIn = Mono.just(walkIn);
        when(mongoTemplate.save(monoWalkIn, WALKINS_COLLECTION)).thenReturn(monoWalkIn);

        Mono<WalkIn> savedWalkIn = walkInRepository.save(monoWalkIn);
        assertEquals(walkInWithOverdue, savedWalkIn.block());
    }

    @Test
    public void shouldInsertWalkIn() {
        when(mongoTemplate.insert(walkIn, WALKINS_COLLECTION)).thenReturn(Mono.just(walkIn));

        Mono<WalkIn> insertedWalkIn = walkInRepository.insert(Mono.just(walkIn));
        assertEquals(walkInWithOverdue, insertedWalkIn.block());
    }

    @Test
    public void shouldFindByAppointmentStatus() {
        Query query = Query.query(Criteria.where("appointmentStatus").is(CHECKED_IN.getVal()));
        when(mongoTemplate.find(query, WalkIn.class, WALKINS_COLLECTION)).thenReturn(Flux.just(walkIn));

        Flux<WalkIn> walkIns = walkInRepository.findByAppointmentStatus(CHECKED_IN);
        assertEquals(singletonList(walkInWithOverdue), walkIns.collectList().block());
    }

}