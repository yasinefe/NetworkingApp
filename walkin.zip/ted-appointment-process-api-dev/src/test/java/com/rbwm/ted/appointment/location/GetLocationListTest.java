/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.location;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.LocationConfiguration;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by 44027117 on 22/02/2017.
 */
public class GetLocationListTest {

    private GetLocationList getLocationList;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private LocationConfiguration locationConfiguration = new LocationConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(locationConfiguration, "locationsHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(locationConfiguration, "locationsListUri", "/locations");
        ReflectionTestUtils.setField(locationConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getLocationList = new GetLocationList(locationConfiguration, new ResponseHandler());
    }

    @Test
    public void testGetAppointments() throws Exception {
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource("mock-data/get-location-list-response.json");
        String fileContent = new String(Files.readAllBytes(Paths.get(path.toURI())));

        stubFor(get(urlPathEqualTo("/locations"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(fileContent)));

        List<Map<String, Object>> locationList = getLocationList.getLocationList();
        assertTrue(locationList != null);
        assertEquals(2, locationList.size());
    }

}
