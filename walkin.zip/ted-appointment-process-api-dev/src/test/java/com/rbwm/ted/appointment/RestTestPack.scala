/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.{request => _, _}
import org.springframework.test.web.servlet.result.MockMvcResultHandlers
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._

/**
  * Created by 43578876 on 20/04/2017.
  */
trait RestTestPack {

  var mvc: MockMvc

  def doGetAsync(url: String, httpStatus : HttpStatus, headers: HttpHeaders = new HttpHeaders) = {

    val mvcResult = mvc.perform(get(url)
      .contentType(MediaType.APPLICATION_JSON).headers(headers))
      .andExpect(request().asyncStarted())
      .andReturn()

    mvc.perform(asyncDispatch(mvcResult))
      .andExpect(status().is(httpStatus.value()))

  }

  def doPostAsync(url: String, httpStatus : HttpStatus, body: String) = {

    val mvcResult = mvc.perform(post(url)
      .contentType(MediaType.APPLICATION_JSON)
      .content(body))
      .andExpect(request().asyncStarted())
      .andReturn()

    mvc.perform(asyncDispatch(mvcResult))
      .andDo(MockMvcResultHandlers.log())
      .andExpect(status().is(httpStatus.value()))
  }

  def doPutAsync(url: String, httpStatus : HttpStatus, body: String) = {

    val mvcResult = mvc.perform(put(url)
      .contentType(MediaType.APPLICATION_JSON)
      .content(body))
      .andExpect(request().asyncStarted())
      .andReturn()

    mvc.perform(asyncDispatch(mvcResult))
      .andDo(MockMvcResultHandlers.log())
      .andExpect(status().is(httpStatus.value()))
  }
}
