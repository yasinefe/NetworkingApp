/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.model.Branch;
import com.rbwm.ted.appointment.model.Branch.BranchDetails;
import com.rbwm.ted.appointment.model.Branch.LocationMacAddress;
import com.rbwm.ted.appointment.repository.BranchRepository;
import com.rbwm.ted.appointment.repository.LocationMacAddressRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import reactor.core.publisher.Mono;

import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Flux.fromIterable;

/**
 * Created by 43578876 on 20/04/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class BranchServiceTest {

    private BranchService branchService;

    @Mock
    private BranchRepository branchRepository;

    @Mock
    private LocationMacAddressRepository locationMacAddressRepository;

    private BranchDetails holborn =  new BranchDetails("400706", "GBLNKEN1", 1234.54, 4567.56, "Europe/London", "Holborn Branch",
            new Branch.Address("Holborn Street", "Holborn Road", "London", "HOL BORN", "City Center", "GBR"));
    private BranchDetails moorgate = new BranchDetails("400701", "GBLNCLS5", 1233.54, 43367.56, "Europe/London", "Moorgate Branch",
            new Branch.Address("Moorgate Street", "Moorgate Road", "London", "MOOR GATE", "City Center", "GBR"));

    private String macAddress = "ff:ff:rd:ss";
    private String locationCode = "GBLNKEN1WA001001";

    private LocationMacAddress locationMacAddress = new LocationMacAddress("1234",macAddress,locationCode,"Random Branch Location","Holborn Branch", "GBR", null);

    @Before
    public void setUp() {
        branchService = new BranchService(branchRepository, locationMacAddressRepository);
    }

    @Test
    public void findByCountryCode() throws Exception {
        List<BranchDetails> branches = asList(holborn, moorgate);

        when(branchRepository.findByCountryCode("GB")).thenReturn(fromIterable(branches));
        assertEquals(branches, branchService.findByCountryCode("GB", null).collectList().block());
    }

    @Test
    public void findByCountryCodeIgnoreEmptyKeyword() throws Exception {
        List<BranchDetails> branches = asList(holborn, moorgate);

        when(branchRepository.findByCountryCode("GB")).thenReturn(fromIterable(branches));
        assertEquals(branches, branchService.findByCountryCode("GB", "").collectList().block());
    }

    @Test
    public void findByCountryCodeAndFilterOnBranchIdByKeyword() throws Exception {
        List<BranchDetails> branches = asList(holborn, moorgate);

        when(branchRepository.findByCountryCode("GB")).thenReturn(fromIterable(branches));
        assertEquals(singletonList(holborn), branchService.findByCountryCode("GB", "400706").collectList().block());
    }

    @Test
    public void findByCountryCodeAndFilterOnNameByKeyword() throws Exception {
        List<BranchDetails> branches = asList(holborn, moorgate);

        when(branchRepository.findByCountryCode("GB")).thenReturn(fromIterable(branches));
        assertEquals(singletonList(holborn), branchService.findByCountryCode("GB", "Holborn B").collectList().block());
    }

    @Test
    public void findByCountryCodeAndFilterOnPostcodeByKeyword() throws Exception {
        List<BranchDetails> branches = asList(holborn, moorgate);

        when(branchRepository.findByCountryCode("GB")).thenReturn(fromIterable(branches));
        assertEquals(singletonList(holborn), branchService.findByCountryCode("GB", "HOL B").collectList().block());
    }

    @Test
    public void testExtractCramerId() {
        assertEquals("GBLNKEN1", BranchService.extractCramerId.apply(locationMacAddress));
    }

    @Test
    public void findBranchByMacAddress() throws Exception {

        Mono<BranchDetails> justHolborn = Mono.just(holborn);

        Mono<String> justCramerId = Mono.just("GBLNKEN1");

        when(locationMacAddressRepository.findByMacAddress(macAddress)).thenReturn(Mono.just(locationMacAddress));

        //TODO THIS DOESN'T WORK
        //when(branchRepository.findByCramerId(justCramerId)).thenReturn(justHolborn);
        when(branchRepository.findByCramerId(any(Mono.class))).thenReturn(justHolborn);

        assertEquals(holborn, branchService.findBranchByMacAddress(macAddress).block());

        //TODO this DOESN'T WORK YET
        //verify(branchRepository).findByCramerId(justCramerId);
    }

    @Test
    public void findBranchByBranchId() throws Exception {

        Mono<BranchDetails> justHolborn = Mono.just(holborn);

        String branchId = "400809";

        when(branchRepository.findById(branchId)).thenReturn(justHolborn);

        assertEquals(holborn, branchService.findBranchByBranchId(branchId).block());

    }
}