/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.repository;

import com.rbwm.ted.appointment.config.MongoConfig;
import com.rbwm.ted.appointment.model.Appointment.ProductCategory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import reactor.core.publisher.Flux;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by 44052007 on 01/02/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProductCategoryRepositoryTest {

    private static final String PRODUCT_CATEGORY_COLLECTION = "productCategories";
    private static final String COUNTRY_CODE = "GBR";

    @Mock
    private ReactiveMongoTemplate mongoTemplate;

    @Mock
    private MongoConfig mongoConfig;

    private ProductCategoryRepository productCategoryRepository;

    private ProductCategory productCategory = new ProductCategory("name", COUNTRY_CODE, emptyList());

    @Before
    public void setUp() {
        when(mongoConfig.getProductCategoriesCollection()).thenReturn(PRODUCT_CATEGORY_COLLECTION);
        productCategoryRepository = new ProductCategoryRepository(mongoTemplate, mongoConfig);
    }

    @Test
    public void shouldFindAll() throws Exception {
        when(mongoTemplate.findAll(ProductCategory.class, PRODUCT_CATEGORY_COLLECTION)).thenReturn(Flux.just(productCategory));

        Flux<ProductCategory> productCategoryFlux = productCategoryRepository.findAll();

        assertEquals(asList(productCategory), productCategoryFlux.collectList().block());
    }

    @Test
    public void shouldFindByCountry() throws Exception {
        Criteria criteria = Criteria.where("countryCode").is(COUNTRY_CODE);

        when(mongoTemplate.find(Query.query(criteria), ProductCategory.class, PRODUCT_CATEGORY_COLLECTION))
                .thenReturn(Flux.just(productCategory));

        Flux<ProductCategory> productCategoryFlux = productCategoryRepository.findByCountry(COUNTRY_CODE);

        assertEquals(asList(productCategory), productCategoryFlux.collectList().block());
    }

}