/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.model;

import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.model.Appointment.WalkInStats;
import com.rbwm.ted.appointment.helper.ClockProvider;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

/**
 * Created by 44027117 on 14/03/2017.
 */
public class AppointmentTest {

    private Long now = new DateTimeHelper(new ClockProvider()).now.get();

    @Test
    public void calculateAverageTimeForToday() throws Exception {
        WalkIn walkInStartedIn1Min = createWalkIn(now, minsAfter(now, 1));
        WalkIn walkInStartedIn3Mins = createWalkIn(now, minsAfter(now, 3));

        WalkInStats walkInStats = new WalkInStats(Arrays.asList(walkInStartedIn1Min, walkInStartedIn3Mins), Collections.emptyList(), now);
        assertEquals(new Integer(2), walkInStats.total);
        assertEquals(new Integer(2), walkInStats.averageWaitingTime);
        assertEquals(new Integer(0), walkInStats.averageWaitingTimeLastBusinessDay);
    }

    @Test
    public void calculateAverageTimeForYesterday() throws Exception {
        Long yesterday = new DateTimeHelper(new ClockProvider()).now.get() - TimeUnit.DAYS.toMillis(1);
        WalkIn walkInStartedIn1Min = createWalkIn(yesterday, minsAfter(yesterday, 1));
        WalkIn walkInStartedIn3Mins = createWalkIn(yesterday, minsAfter(yesterday, 3));

        WalkInStats walkInStats = new WalkInStats(Collections.emptyList(), Arrays.asList(walkInStartedIn1Min, walkInStartedIn3Mins), yesterday);
        assertEquals(new Integer(0), walkInStats.total);
        assertEquals(new Integer(0), walkInStats.averageWaitingTime);
        assertEquals(new Integer(2), walkInStats.averageWaitingTimeLastBusinessDay);
    }

    @Test
    public void calculateAverageTimeForWithNotStartedWalkIns() throws Exception {
        WalkIn walkInStartedIn4Min = createWalkIn(now, minsAfter(now, 4));
        WalkIn walkInStartedIn1Min = createWalkIn(now, minsAfter(now, 1));
        WalkIn walkInNotStarted = createWalkIn(minsAfter(now, -3), null);

        WalkInStats walkInStats = new WalkInStats(Arrays.asList(walkInStartedIn4Min, walkInStartedIn1Min, walkInNotStarted), Collections.emptyList(), now);
        assertEquals(new Integer(3), walkInStats.total);
        assertEquals(new Integer(3), walkInStats.averageWaitingTime); // average : 8 / 3 = 2.6666...
        assertEquals(new Integer(0), walkInStats.averageWaitingTimeLastBusinessDay);
    }

    private Long minsAfter(Long now, int mins) {
        return now + 60000 * mins;
    }

    private WalkIn createWalkIn(Long now, Long startedAt) {
        return new WalkIn("", null, null, null, null,
                null, null, null, null, false, null,
                null, now, now, now, startedAt, null, null, null, null);
    }
}
