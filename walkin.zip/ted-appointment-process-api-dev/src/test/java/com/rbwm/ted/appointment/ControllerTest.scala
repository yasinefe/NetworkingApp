/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import com.rbwm.ted.appointment.api.{MeetingServiceApi, MeetingStatsServiceApi}
import com.rbwm.ted.appointment.repository.{BranchRepository, LocationMacAddressRepository, ProductCategoryRepository, WalkInRepository}
import com.rbwm.ted.appointment.service.{BranchService, LocationService, ProductCategoryService, WalkInService}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.mockito.MockitoSugar
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.{TestContextManager, TestPropertySource}
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.setup.MockMvcBuilders
import org.springframework.web.context.WebApplicationContext

/**
  * Created by 44027117 on 06/03/2017.
  */
@RunWith(classOf[JUnitRunner])
@TestPropertySource(properties = Array[String]{"spring.config.location = classpath:config/ted-appointment-process-api.yaml"})
@SpringBootTest(classes = Array(classOf[Application], classOf[ConfigMock]))
abstract class ControllerTest extends FlatSpec
  with Matchers
  with MockitoSugar
  with BeforeAndAfter
  with RestTestPack {

  var mvc: MockMvc = _

  @Autowired
  val webApplicationContext: WebApplicationContext = null
  @Autowired
  val walkInService: WalkInService = null
  @Autowired
  val productCategoryService: ProductCategoryService = null
  @Autowired
  val branchService: BranchService = null
  @Autowired
  val locationService: LocationService = null
  @Autowired
  val meetingController: MeetingController = null

  var walkInRepository: WalkInRepository = _
  var productCategoryRepository: ProductCategoryRepository = _
  var branchRepository: BranchRepository = _
  var locationMacAddressRepository: LocationMacAddressRepository = _
  var meetingService: MeetingServiceApi = _
  var meetingStatsService: MeetingStatsServiceApi = _

  before {
    new TestContextManager(this.getClass).prepareTestInstance(this)
    mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build()
    walkInRepository = mock[WalkInRepository]
    productCategoryRepository = mock[ProductCategoryRepository]
    branchRepository = mock[BranchRepository]
    locationMacAddressRepository = mock[LocationMacAddressRepository]
    meetingService = mock[MeetingServiceApi]
    meetingStatsService = mock[MeetingStatsServiceApi]

    ReflectionTestUtils.setField(walkInService, "walkInRepository", walkInRepository)
    ReflectionTestUtils.setField(walkInService, "branchRepository", branchRepository)
    ReflectionTestUtils.setField(productCategoryService, "productCategoryRepository", productCategoryRepository)
    ReflectionTestUtils.setField(branchService, "branchRepository", branchRepository)
    ReflectionTestUtils.setField(branchService, "locationMacAddressRepository", locationMacAddressRepository)
    ReflectionTestUtils.setField(locationService, "locationMacAddressRepository", locationMacAddressRepository)
    ReflectionTestUtils.setField(meetingController, "meetingService", meetingService)
    ReflectionTestUtils.setField(meetingController, "meetingStatsService", meetingStatsService)
  }
}
