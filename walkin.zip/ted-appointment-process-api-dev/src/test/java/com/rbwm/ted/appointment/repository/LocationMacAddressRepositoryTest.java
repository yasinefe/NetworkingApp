/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.repository;

import com.mongodb.client.result.UpdateResult;
import com.rbwm.ted.appointment.config.MongoConfig;
import com.rbwm.ted.appointment.error.ErrorCode;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.error.Exceptions.NotFoundException;
import com.rbwm.ted.appointment.model.Branch.LocationMacAddress;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by 43578876 on 20/04/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class LocationMacAddressRepositoryTest {

    private static final String MAC_ADDRESS = "ed:rf:fd:ss";
    private static final String LOCATION_COLLECTION = "locations";
    private static final String LOCATION_CODE = "GBRSXJ12";

    private LocationMacAddressRepository locationMacAddressRepository;

    @Mock
    private ReactiveMongoTemplate mongoTemplate;

    @Mock
    private MongoConfig mongoConfig;

    private LocationMacAddress locationMacAddress = new LocationMacAddress("locationMacAddressId",
            MAC_ADDRESS, LOCATION_CODE, "locationDescription", "branchName",
            "countryCode", 1L);

    @Before
    public void setUp() {
        when(mongoConfig.getLocationMacAddressCollection()).thenReturn(LOCATION_COLLECTION);
        locationMacAddressRepository = new LocationMacAddressRepository(mongoTemplate, mongoConfig);
    }

    @Test
    public void shouldFindByMacAddress() throws Exception {
        Criteria criteria = Criteria.where("accessPointMacAddress").is(MAC_ADDRESS);

        when(mongoTemplate.findOne(Query.query(criteria), LocationMacAddress.class, LOCATION_COLLECTION))
                .thenReturn(Mono.just(locationMacAddress));

        Mono<LocationMacAddress> locationMacAddressMono = locationMacAddressRepository.findByMacAddress(MAC_ADDRESS);

        assertEquals(locationMacAddress, locationMacAddressMono.block());
    }

    @Test(expected = NotFoundException.class)
    public void shouldThrowExceptionWhenMacAddressIsNotFound() {
        Criteria criteria = Criteria.where("accessPointMacAddress").is(MAC_ADDRESS);

        when(mongoTemplate.findOne(Query.query(criteria), LocationMacAddress.class, LOCATION_COLLECTION))
                .thenReturn(Mono.empty());

        Exceptions.ServerException exception = new NotFoundException(ErrorCode.MAC_ADDRESS_NOT_FOUND, MAC_ADDRESS);

        Mono<LocationMacAddress> locationMacAddressMono = locationMacAddressRepository.findByMacAddress(MAC_ADDRESS);

        try {
            locationMacAddressMono.block();
        } catch (NotFoundException e) {
            assertEquals(exception ,e);
            assertEquals(exception.toString() ,e.toString());
            assertEquals(exception.hashCode() ,e.hashCode());
            assertEquals(HttpStatus.NOT_FOUND, e.getHttpStatus());
            throw e;
        }
    }

    @Test
    public void shouldUpdateLocationMacAddress() throws Exception {
        UpdateResult updateResult = mock(UpdateResult.class);

        Update update = Update.update("accessPointMacAddress", locationMacAddress.accessPointMacAddress)
                .set("locationDescription", locationMacAddress.locationDescription)
                .set("branchName", locationMacAddress.branchName)
                .set("countryCode", locationMacAddress.countryCode)
                .set("updated", locationMacAddress.updated);
        Criteria criteria = Criteria.where("locationCode").is(LOCATION_CODE);

        when(mongoTemplate.upsert(Query.query(criteria), update, LocationMacAddress.class, LOCATION_COLLECTION))
                .thenReturn(Mono.just(updateResult));

        Mono<UpdateResult> updateResultMono = locationMacAddressRepository.update(locationMacAddress);

        assertEquals(updateResult, updateResultMono.block());
    }
}