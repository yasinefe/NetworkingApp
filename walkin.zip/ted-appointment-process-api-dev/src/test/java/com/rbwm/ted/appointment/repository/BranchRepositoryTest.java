/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.repository;

import com.rbwm.ted.appointment.config.MongoConfig;
import com.rbwm.ted.appointment.error.ErrorCode;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.model.Branch.Address;
import com.rbwm.ted.appointment.model.Branch.BranchDetails;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by 43578876 on 20/04/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class BranchRepositoryTest {

    private static final String BRANCHES_COLLECTION = "branches";
    private static final String CRAMER_ID = "GBSFCTY5";
    private static final String BRANCH_ID = "400126";
    private static final String COUNTRY_CODE = "GBR";

    @Mock
    private ReactiveMongoTemplate mongoTemplate;

    @Mock
    private MongoConfig mongoConfig;

    private BranchRepository branchRepository;

    private Address address = new Address("addressLine1", "addressLine2", "city",
            "postCode", "county", COUNTRY_CODE);
    private BranchDetails branchDetails = new BranchDetails(BRANCH_ID, CRAMER_ID, 0d, 0d, "Europe/London",
            "branchName", address);

    @Before
    public void setUp() {
        when(mongoConfig.getBranchesCollection()).thenReturn(BRANCHES_COLLECTION);
        branchRepository = new BranchRepository(mongoTemplate, mongoConfig);
    }

    @Test
    public void shouldFindByCramerId() throws Exception {
        Criteria criteria = Criteria.where("cramerId").is(CRAMER_ID);

        when(mongoTemplate.findOne(Query.query(criteria), BranchDetails.class, BRANCHES_COLLECTION))
                .thenReturn(Mono.just(branchDetails));

        Mono<BranchDetails> branch = branchRepository.findByCramerId(Mono.just(CRAMER_ID));

        assertEquals(branchDetails, branch.block());
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void shouldThrowExceptionWhenCramerIdIsNotFound() throws Exception {
        Criteria criteria = Criteria.where("cramerId").is(CRAMER_ID);

        when(mongoTemplate.findOne(Query.query(criteria), BranchDetails.class, BRANCHES_COLLECTION))
                .thenReturn(Mono.empty());

        Mono<?> ret = branchRepository.findByCramerId(Mono.just(CRAMER_ID));

        Exceptions.ServerException exception = new Exceptions.NotFoundException(ErrorCode.BRANCH_NOT_FOUND_CRAMER_ID, CRAMER_ID);

        try {
            ret.block();
        } catch (Exceptions.NotFoundException e) {
            assertEquals(exception, e);
            assertEquals(HttpStatus.NOT_FOUND, e.getHttpStatus());
            assertEquals("Branch not found for cramerId : " + CRAMER_ID, e.getError().message);
            throw e;
        }
    }

    @Test
    public void shouldFindById() throws Exception {
        Criteria criteria = Criteria.where("branchId").is(BRANCH_ID);

        when(mongoTemplate.findOne(Query.query(criteria), BranchDetails.class, BRANCHES_COLLECTION))
                .thenReturn(Mono.just(branchDetails));

        Mono<BranchDetails> branch = branchRepository.findById(BRANCH_ID);

        assertEquals(branchDetails, branch.block());
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void shouldThrowExceptionWhenBranchIsNotFound() throws Exception {
        Criteria criteria = Criteria.where("branchId").is(BRANCH_ID);

        when(mongoTemplate.findOne(Query.query(criteria), BranchDetails.class, BRANCHES_COLLECTION))
                .thenReturn(Mono.empty());

        Mono<?> ret = branchRepository.findById(BRANCH_ID);

        Exceptions.ServerException exception = new Exceptions.NotFoundException(ErrorCode.BRANCH_NOT_FOUND_BRANCH_ID, BRANCH_ID);

        try {
            ret.block();
        } catch (Exceptions.NotFoundException e) {
            assertEquals(exception, e);
            assertEquals(HttpStatus.NOT_FOUND, e.getHttpStatus());
            assertEquals("Branch not found for branchId : " + BRANCH_ID, e.getError().message);
            throw e;
        }
    }

    @Test
    public void shouldFindByCountryCode() throws Exception {
        Criteria criteria = Criteria.where("address.countryCode").is(COUNTRY_CODE);

        when(mongoTemplate.find(Query.query(criteria), BranchDetails.class, BRANCHES_COLLECTION))
                .thenReturn(Flux.just(branchDetails));

        Flux<BranchDetails> branches = branchRepository.findByCountryCode(COUNTRY_CODE);

        assertEquals(asList(branchDetails), branches.collectList().block());
    }

}