package com.rbwm.ted.appointment.config;

import com.rbwm.ted.appointment.api.LocationServiceApi;
import com.rbwm.ted.appointment.api.WalkInServiceApi;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.config.CronTask;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * Created by 44052007 on 21/03/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class ScheduleConfigTest {

    @InjectMocks
    private ScheduleConfig scheduleConfig;

    @Mock
    private LocationServiceApi locationServiceApi;

    @Mock
    private WalkInServiceApi walkInServiceApi;

    private ScheduledTaskRegistrar scheduledTaskRegistrar = new ScheduledTaskRegistrar();

    @Test
    public void cronTaskShouldBeScheduledToTriggerCronTasks() throws Exception {
        String cronExpression = "0 0 23 * * *";
        setField(scheduleConfig, "locationUpdateCronExpression", cronExpression);
        setField(scheduleConfig, "walkInEndBatchCronExpression", cronExpression);

        scheduleConfig.configureTasks(scheduledTaskRegistrar);

        CronTask cronTask1 = scheduledTaskRegistrar.getCronTaskList().get(0);
        assertEquals(cronExpression, cronTask1.getExpression());
        cronTask1.getRunnable().run();

        CronTask cronTask2 = scheduledTaskRegistrar.getCronTaskList().get(1);
        assertEquals(cronExpression, cronTask2.getExpression());
        cronTask2.getRunnable().run();

        verify(locationServiceApi).updateLocations();
        verify(walkInServiceApi).endWalkIns();
    }
}