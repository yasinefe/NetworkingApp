/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import com.rbwm.ted.appointment.model.Appointment.ProductCategory
import org.mockito.Mockito._
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import reactor.core.publisher.Flux

/**
  * Created by 43578876 on 21/02/2017.
  */
class ProductCategoryControllerTest extends ControllerTest with RestTestPack {

  val thirdLevelProductCategories = new java.util.ArrayList[ProductCategory]
  thirdLevelProductCategories.add(new ProductCategory("third-level-category", "GBR", null))
  val secondLevelProductCategories = new java.util.ArrayList[ProductCategory]
  secondLevelProductCategories.add(new ProductCategory("second-level-category", "GBR", thirdLevelProductCategories))
  val productCategory = new ProductCategory("first-level-category", "GBR", secondLevelProductCategories)
  val productCategories = new java.util.ArrayList[ProductCategory]
  productCategories.add(productCategory)

  it should " return a list of categories " in {

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)
    headers.add(Headers.COUNTRY_CODE_HEADER, "GBR")

    when(productCategoryRepository.findByCountry("GBR")).thenReturn(Flux.fromIterable(productCategories))

    val response =
      """
      |  [
      |    {
      |      "name": "first-level-category",
      |      "countryCode": "GBR",
      |      "productCategories": [
      |        {
      |          "name": "second-level-category",
      |          "countryCode": "GBR",
      |          "productCategories": [
      |            {
      |              "name": "third-level-category"
      |            }
      |          ]
      |        }
      |      ]
      |    }
      |  ]
      """.stripMargin


    doGetAsync("/productCategories", HttpStatus.OK, headers)
      .andExpect(content.json(response))
  }

}
