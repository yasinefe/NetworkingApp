/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.audit.AuditContext;
import com.rbwm.ted.appointment.audit.AuditProcessor;
import com.rbwm.ted.appointment.config.WalkInConfig;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.helper.ClockProvider;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import com.rbwm.ted.appointment.model.Appointment;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.model.Appointment.WalkInStats;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import com.rbwm.ted.appointment.repository.BranchRepository;
import com.rbwm.ted.appointment.repository.WalkInRepository;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.rbwm.ted.appointment.audit.AuditContext.ENTITY_TYPE_WALKIN;
import static com.rbwm.ted.appointment.audit.AuditContext.OPERATION_WALKIN_CHANGE_STATUS;
import static com.rbwm.ted.appointment.model.AppointmentStatus.*;
import static com.rbwm.ted.appointment.model.ModifierType.SYSTEM;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.*;
import static reactor.core.publisher.Mono.just;

/**
 * Created by 44052007 on 04/04/2017.
 */
public class WalkInServiceTest {

    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    private static final String BRANCH_ID = "12342";

    private WalkInRepository mockWalkInRepository = mock(WalkInRepository.class);
    private WalkInConfig mockWalkInConfig = mock(WalkInConfig.class);
    private BranchRepository mockBranchRepository = mock(BranchRepository.class);
    private AuditProcessor mockAuditProcessor = mock(AuditProcessor.class);
    private ZonedDateTime time = LocalDateTime.of(2018, 3, 21, 11, 23, 45, 175).atZone(ZoneId.of("UTC"));
    private ClockProvider clockProvider = new ClockProvider(Clock.fixed(time.toInstant(), ZoneId.of("UTC")));
    private DateTimeHelper dateTimeHelper = new DateTimeHelper(clockProvider);
    private WalkInService walkInService = new WalkInService(mockWalkInRepository, mockWalkInConfig,
            new WalkInFilters(dateTimeHelper), dateTimeHelper, mockBranchRepository, mockAuditProcessor);

    @Test
    public void testGetStatusCountsReturnsInitialCountsWhenThereIsNoAppointment() throws Exception {
        mockWalkInRepository();

        Map<String, Long> statusCounts = walkInService.getStatusCounts(BRANCH_ID).block();

        assertThat(statusCounts).isEqualTo(new HashMap<String, Long>() {{
            put(CANCELLED.getVal(), 0L);
            put(IN_MEETING.getVal(), 0L);
            put(CHECKED_IN.getVal(), 0L);
            put(OVERDUE.getVal(), 0L);
            put(COMPLETED.getVal(), 0L);
        }});
    }

    @Test
    public void testGetStatusCountsReturnsCorrectCountsForEachAppointmentStatus() throws Exception {
        WalkIn cancelledWalkIn1 = createWalkIn(CANCELLED);
        WalkIn cancelledWalkIn2 = createWalkIn(CANCELLED);
        WalkIn cancelledWalkIn3 = createWalkIn(CANCELLED);
        WalkIn inMeetingWalkIn = createWalkIn(IN_MEETING);
        WalkIn checkedInWalkIn = createWalkIn(CHECKED_IN);
        WalkIn completedWalkIn = createWalkIn(COMPLETED);
        mockWalkInRepository(cancelledWalkIn1, cancelledWalkIn2, cancelledWalkIn3, inMeetingWalkIn, checkedInWalkIn, completedWalkIn);

        Map<String, Long> statusCounts = walkInService.getStatusCounts(BRANCH_ID).block();

        assertThat(statusCounts).isEqualTo(new HashMap<String, Long>() {{
            put(CANCELLED.getVal(), 3L);
            put(IN_MEETING.getVal(), 1L);
            put(CHECKED_IN.getVal(), 1L);
            put(OVERDUE.getVal(), 0L);
            put(COMPLETED.getVal(), 1L);
        }});
    }

    @Test
    public void testGetStatusCountsReturnsCorrectCountsForOverdue() throws Exception {
        WalkIn checkedInWalkIn = createWalkIn(CHECKED_IN);
        WalkIn overdueWalkIn = createWalkIn(CHECKED_IN, minsBefore(20));
        mockWalkInRepository(checkedInWalkIn, overdueWalkIn);

        Map<String, Long> statusCounts = walkInService.getStatusCounts(BRANCH_ID).block();

        assertThat(statusCounts).isEqualTo(new HashMap<String, Long>() {{
            put(CANCELLED.getVal(), 0L);
            put(IN_MEETING.getVal(), 0L);
            put(CHECKED_IN.getVal(), 2L);
            put(OVERDUE.getVal(), 1L);
            put(COMPLETED.getVal(), 0L);
        }});
    }

    @Test
    public void testGetStatusCountsReturnsCorrectCountsAfterFilteringWalkInsForToday() throws Exception {
        WalkIn cancelledInWalkIn = createWalkIn(CANCELLED);
        WalkIn checkedInWalkIn = createWalkIn(CHECKED_IN);
        WalkIn inMeeting = createWalkIn(IN_MEETING);
        mockWalkInRepository(cancelledInWalkIn, checkedInWalkIn, inMeeting);

        Map<String, Long> statusCounts = walkInService.getStatusCounts(BRANCH_ID).block();

        assertThat(statusCounts).isEqualTo(new HashMap<String, Long>() {{
            put(CANCELLED.getVal(), 1L);
            put(IN_MEETING.getVal(), 1L);
            put(CHECKED_IN.getVal(), 1L);
            put(OVERDUE.getVal(), 0L);
            put(COMPLETED.getVal(), 0L);
        }});
    }

    @Test
    public void testGetTotalCount() throws Exception {
        WalkIn cancelledWalkIn1 = createWalkIn(CANCELLED);
        WalkIn cancelledWalkIn2 = createWalkIn(CANCELLED);
        WalkIn overdue = createWalkIn(OVERDUE);
        WalkIn inMeetingWalkIn = createWalkIn(IN_MEETING);
        WalkIn checkedInWalkIn = createWalkIn(CHECKED_IN);

        WalkIn[] walkIns = new WalkIn[5];
        walkIns[0] = cancelledWalkIn1;
        walkIns[1] = cancelledWalkIn2;
        walkIns[2] = overdue;
        walkIns[3] = inMeetingWalkIn;
        walkIns[4] = checkedInWalkIn;

        when(mockWalkInRepository.findByBranchId(BRANCH_ID)).thenReturn(Flux.fromArray(walkIns));
        when(mockWalkInRepository.findYesterdayByBranchId(BRANCH_ID)).thenReturn(Flux.empty());

        WalkInStats walkInStats = walkInService.getStats(BRANCH_ID).block();
        assertEquals(new Integer(3), walkInStats.total);
    }

    @Test
    public void testFindByLocationIdFiltersWalkIns() throws Exception {
        WalkIn checkedInWalkIn = createWalkIn(CHECKED_IN);
        WalkIn checkedInWalkInNotStarted = createWalkIn(CHECKED_IN, minsBefore(61));
        WalkIn inMeeting = createWalkIn(IN_MEETING);
        WalkIn inMeetingAndOverRunning = createWalkIn(IN_MEETING, minsBefore(70), minsBefore(65));
        mockWalkInRepository(checkedInWalkIn, checkedInWalkInNotStarted, inMeeting, inMeetingAndOverRunning);

        List<WalkIn> walkIns = walkInService.findByBranchId(BRANCH_ID).collectList().block();

        assertThat(walkIns).hasSize(4);
    }

    @Test
    public void testWalkInsAreSortedByDate() throws Exception {
        Long dateTime5MinsAfter = minsAfter(5);
        Long dateTime5MinsBefore = minsBefore(5);

        WalkIn walkIn5MinsAfter = createWalkIn(CHECKED_IN, dateTime5MinsAfter);
        WalkIn walkIn5MinsBefore = createWalkIn(CHECKED_IN, dateTime5MinsBefore);

        mockWalkInRepository(walkIn5MinsAfter, walkIn5MinsBefore);

        List<WalkIn> walkInList = walkInService.findByBranchId(BRANCH_ID).collectList().block();

        assertEquals(2, walkInList.size());
        assertEquals(dateTime5MinsBefore, walkInList.get(0).dateTime);
        assertEquals(dateTime5MinsAfter, walkInList.get(1).dateTime);
    }

    @Test
    public void shouldSetStartedDateWhenWalkInStatusUpdatedToInMeeting() throws Exception {
        WalkIn walkIn = createWalkIn(CHECKED_IN, minsBefore(15), minsBefore(10));
        Mono<WalkIn> walkInMono = just(walkIn);

        when(mockWalkInRepository.findById(walkIn.appointmentId)).thenReturn(walkInMono);
        when(mockWalkInRepository.save(argThat(new ArgumentMatcher<Mono<WalkIn>>(){
            @Override
            public boolean matches(Object arg) {
                Mono<WalkIn> walkInMono = (Mono<WalkIn>)arg;
                return walkInMono.block().startedAt != null;
            }
        }))).thenReturn(walkInMono);

        assertNotNull(walkInService.updateStatus(walkIn.appointmentId, IN_MEETING));
    }

    @Test
    public void shouldSetEndedDateWhenWalkInStatusUpdatedToCompleted() throws Exception {
        WalkIn walkIn = createWalkIn(IN_MEETING, minsBefore(15), minsBefore(10));
        Mono<WalkIn> walkInMono = just(walkIn);

        when(mockWalkInRepository.findById(walkIn.appointmentId)).thenReturn(walkInMono);
        when(mockWalkInRepository.save(argThat(new ArgumentMatcher<Mono<WalkIn>>(){
            @Override
            public boolean matches(Object arg) {
                Mono<WalkIn> walkInMono = (Mono<WalkIn>)arg;
                return walkInMono.block().endedAt != null;
            }
        }))).thenReturn(walkInMono);

        assertNotNull(walkInService.updateStatus(walkIn.appointmentId, COMPLETED));
    }

    @Test(expected = Exceptions.ConflictException.class)
    public void shouldThrowConflictExceptionWhenPreviousStatusDoesNotMatch() throws Exception {
        WalkIn walkIn = createWalkIn(IN_MEETING, minsBefore(15), minsBefore(10));
        Mono<WalkIn> walkInMono = just(walkIn);
        when(mockWalkInRepository.findById(walkIn.appointmentId)).thenReturn(walkInMono);
        when(mockWalkInRepository.save(argThat(new ArgumentMatcher<Mono<WalkIn>>(){
            @Override
            public boolean matches(Object arg) {
                Mono<WalkIn> walkInMono = (Mono<WalkIn>)arg;
                walkInMono.block();
                return true;
            }
        }))).thenReturn(walkInMono);
        walkInService.updateStatus(walkIn.appointmentId, CANCELLED).block();
    }

    @Test
    public void endWalkInsShouldCancelCheckedInWalkInsIfTimeIsInBatchProcessPeriod() throws Exception {
        when(mockWalkInConfig.getWalkInEndAfter()).thenReturn("11:00");

        WalkIn walkInForLondon = createWalkIn(CHECKED_IN, "Europe/London");
        WalkIn walkInForLosAngeles = createWalkIn(CHECKED_IN, "America/Los_Angeles");

        when(mockWalkInRepository.findByAppointmentStatus(CHECKED_IN)).thenReturn(Flux.fromIterable(Arrays.asList(walkInForLondon, walkInForLosAngeles)));
        when(mockWalkInRepository.findByAppointmentStatus(IN_MEETING)).thenReturn(Flux.empty());

        when(mockWalkInRepository.save(any())).thenReturn(Mono.just(walkInForLondon));

        walkInService.endWalkIns();

        verify(mockWalkInRepository, times(1)).save(argThat(new ArgumentMatcher<Mono<WalkIn>>(){
            @Override
            public boolean matches(Object o) {
                Mono<WalkIn> walkInMono = (Mono<WalkIn>)o;
                WalkIn walkIn = walkInMono.block();
                assertEquals("Europe/London", walkIn.timezone);
                assertEquals(CANCELLED, walkIn.appointmentStatus);
                assertEquals(SYSTEM, walkIn.endedBy);
                assertEquals(dateTimeHelper.now.get(), walkIn.endedAt);
                assertEquals(dateTimeHelper.now.get(), walkIn.updated);
                return true;
            }
        }));

        Map<String, Object> variables = new HashMap<>();
        Map<String, Object> input = new HashMap<>();
        input.put("appointmentId", walkInForLondon.appointmentId);
        input.put("appointmentStatus", CANCELLED.getVal());
        variables.put("input", input);

        AuditContext auditContext = new AuditContext(walkInForLondon.countryCode, walkInForLondon.branchId, SYSTEM.name(), SYSTEM.name(),
                SYSTEM.name(), variables, walkInForLondon.appointmentId, OPERATION_WALKIN_CHANGE_STATUS, ENTITY_TYPE_WALKIN);

        verify(mockAuditProcessor).sendEvent(auditContext);
    }

    @Test
    public void endWalkInsShouldCompleteInMeetingWalkInsIfTimeIsInBatchProcessPeriod() throws Exception {
        when(mockWalkInConfig.getWalkInEndAfter()).thenReturn("11:00");

        WalkIn walkInForLondon = createWalkIn(IN_MEETING, "Europe/London");
        WalkIn walkInForLosAngeles = createWalkIn(IN_MEETING, "America/Los_Angeles");

        when(mockWalkInRepository.findByAppointmentStatus(IN_MEETING)).thenReturn(Flux.fromIterable(Arrays.asList(walkInForLondon, walkInForLosAngeles)));
        when(mockWalkInRepository.findByAppointmentStatus(CHECKED_IN)).thenReturn(Flux.empty());

        when(mockWalkInRepository.save(any())).thenReturn(Mono.just(walkInForLondon));

        walkInService.endWalkIns();

        verify(mockWalkInRepository, times(1)).save(argThat(new ArgumentMatcher<Mono<WalkIn>>(){
            @Override
            public boolean matches(Object o) {
                Mono<WalkIn> walkInMono = (Mono<WalkIn>)o;
                WalkIn walkIn = walkInMono.block();
                assertEquals("Europe/London", walkIn.timezone);
                assertEquals(COMPLETED, walkIn.appointmentStatus);
                assertEquals(dateTimeHelper.now.get(), walkIn.endedAt);
                assertEquals(dateTimeHelper.now.get(), walkIn.updated);
                assertEquals(SYSTEM, walkIn.endedBy);
                return true;
            }
        }));
        Map<String, Object> variables = new HashMap<>();
        Map<String, Object> input = new HashMap<>();
        input.put("appointmentId", walkInForLondon.appointmentId);
        input.put("appointmentStatus", COMPLETED.getVal());
        variables.put("input", input);

        AuditContext auditContext = new AuditContext(walkInForLondon.countryCode, walkInForLondon.branchId, SYSTEM.name(), SYSTEM.name(),
                SYSTEM.name(), variables, walkInForLondon.appointmentId, OPERATION_WALKIN_CHANGE_STATUS, ENTITY_TYPE_WALKIN);

        verify(mockAuditProcessor).sendEvent(auditContext);
    }

    private Long minsBefore(int min) {
        return minsAfter(-1 * min);
    }

    private Long minsAfter(int min) {
        return time.toInstant().plus(min, ChronoUnit.MINUTES).toEpochMilli();
    }

    private void mockWalkInRepository(WalkIn... walkins) {
        when(mockWalkInRepository.findByBranchId(BRANCH_ID)).thenReturn(Flux.fromArray(walkins));
    }

    private Appointment.WalkIn createWalkIn(AppointmentStatus appointmentStatus) {
        return createWalkIn(appointmentStatus, dateTimeHelper.now.get());
    }

    private Appointment.WalkIn createWalkIn(AppointmentStatus appointmentStatus, Long dateTime) {
        return createWalkIn(appointmentStatus, dateTime, null);
    }

    private Appointment.WalkIn createWalkIn(AppointmentStatus appointmentStatus, Long dateTime, Long startedAt) {
        return createWalkIn(appointmentStatus, dateTime, startedAt, "Europe/London");
    }

    private Appointment.WalkIn createWalkIn(AppointmentStatus appointmentStatus, String timezone) {
        return createWalkIn(appointmentStatus, dateTimeHelper.now.get(), null, timezone);
    }

    private Appointment.WalkIn createWalkIn(AppointmentStatus appointmentStatus, Long dateTime, Long startedAt, String timezone) {
        return new Appointment.WalkIn("12334", appointmentStatus, 90, 10, "400706",
                null, null, null, null, false, null, null,
                dateTime, dateTime, null, startedAt, timezone, "GBR", null, null);
    }
}