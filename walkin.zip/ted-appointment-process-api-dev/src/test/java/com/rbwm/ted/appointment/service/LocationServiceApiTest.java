package com.rbwm.ted.appointment.service;

import com.mongodb.client.result.UpdateResult;
import com.rbwm.ted.appointment.location.GetLocationList;
import com.rbwm.ted.appointment.model.Branch.LocationMacAddress;
import com.rbwm.ted.appointment.repository.LocationMacAddressRepository;
import com.rbwm.ted.appointment.helper.ClockProvider;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by 44093684 on 17/11/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class LocationServiceApiTest {

    @Mock
    Mono<UpdateResult> updateResultMono;

    @Mock
    private LocationMacAddressRepository locationMacAddressRepository;

    @Mock
    private GetLocationList getLocationList;

    private LocationService locationService;

    @Before
    public void setUp() {
        locationService = new LocationService(locationMacAddressRepository, getLocationList, new DateTimeHelper(new ClockProvider()));

        UpdateResult updateResult = mock(UpdateResult.class);
        when(updateResultMono.block()).thenReturn(updateResult);
    }

    @Test
    public void testUpdateLocations() {
        //Given
        Map<String, Object> macAddress1 = new HashMap<>();
        macAddress1.put("macAddress", "GBLNSWK2WA001M11");
        macAddress1.put("deviceName", "GBILFOR2WA001000");
        macAddress1.put("fullLocation", "BR London > GBLNSWK2/GB4016 > Mezzanine");
        macAddress1.put("mapLocation", "GBLNSWK2 - BRANCH 1");
        macAddress1.put("countryCode", "GBR");
        when(getLocationList.getLocationList()).thenReturn(Collections.singletonList(macAddress1));
        when(locationMacAddressRepository.update(any(LocationMacAddress.class))).thenReturn(updateResultMono);

        //When
        locationService.updateLocations();

        //Then
        ArgumentCaptor<LocationMacAddress> argument = ArgumentCaptor.forClass(LocationMacAddress.class);
        verify(locationMacAddressRepository).update(argument.capture());
        LocationMacAddress macAddress = argument.getValue();

        List<String> expected = asList(null, "GBLNSWK2WA001M11", "GBILFOR2WA001000",
                "BR London > GBLNSWK2/GB4016 > Mezzanine", "GBLNSWK2 - BRANCH 1", "GBR");
        List<String> actual = asList(macAddress.locationMacAddressId, macAddress.accessPointMacAddress,
                macAddress.locationCode, macAddress.locationDescription,
                macAddress.branchName, macAddress.countryCode);
        assertEquals(expected, actual);
    }

}
