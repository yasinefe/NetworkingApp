/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import com.rbwm.ted.appointment.error.ErrorCode
import com.rbwm.ted.appointment.error.Exceptions.NotFoundException
import com.rbwm.ted.appointment.model.Appointment.WalkIn
import com.rbwm.ted.appointment.repository.WalkInRepository
import org.mockito.Mockito._
import org.springframework.dao.DataAccessResourceFailureException
import org.springframework.data.mongodb.core.query.Query
import org.springframework.http.{HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._

class ErrorHandlingTest extends ControllerTest {


  it should " return error code and message when walkIn not found " in {

    val response =
      """
        {
          "error": {
            "code": 302,
            "message": "Walkin not found for id: 1234567"
          }
        }
      """.stripMargin

    when(walkInRepository.findById("1234567")).thenThrow(new NotFoundException(ErrorCode.WALKIN_NOT_FOUND, "1234567"))

    doGetAsync("/walkins/1234567", HttpStatus.NOT_FOUND)
      .andExpect(content.json(response))
  }

  it should " return error code and message when mongo db connection problem " in {
    val response =
      """
        {
          "error": {
            "code": 301,
            "message": "Unable to connect mongo db : message"
          }
        }
      """.stripMargin

    when(walkInRepository.findByBranchId("400706")).thenThrow(new DataAccessResourceFailureException("message"))

    doGetAsync("/walkins/statusCounts?branchId=400706", HttpStatus.INTERNAL_SERVER_ERROR)
      .andExpect(content.json(response))
  }


  it should " return error code and message when runtime exception occured " in {

    val response =
      """
        {
          "error": {
            "code": 501,
            "message": "Unexpected error : message"
          }
        }
      """.stripMargin

    when(walkInRepository.findByBranchId("400706")).thenThrow(new RuntimeException("message"))

    doGetAsync("/walkins/statusCounts?branchId=400706", HttpStatus.INTERNAL_SERVER_ERROR)
      .andExpect(content.json(response))
  }

  def doGetAsync(url: String, httpStatus : HttpStatus) = {
    mvc.perform(get(url)
      .contentType(MediaType.APPLICATION_JSON))
      .andExpect(status().is(httpStatus.value()))
  }

}
