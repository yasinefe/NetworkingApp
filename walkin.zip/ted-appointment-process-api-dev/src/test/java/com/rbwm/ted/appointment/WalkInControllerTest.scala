/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import java.time.{LocalDateTime, ZoneId}

import com.rbwm.ted.appointment.error.ErrorCode.CONFLICT_ON_WALKIN_STATUS_UPDATE
import com.rbwm.ted.appointment.error.Exceptions
import com.rbwm.ted.appointment.model.Appointment.WalkIn
import com.rbwm.ted.appointment.model.AppointmentStatus.{CANCELLED, CHECKED_IN, IN_MEETING}
import com.rbwm.ted.appointment.model.Branch.BranchDetails
import com.rbwm.ted.appointment.model.{Appointment, AppointmentStatus, Branch}
import org.mockito.Matchers.any
import org.mockito.Mockito._
import org.springframework.http.{HttpStatus, MediaType}
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import org.springframework.test.web.servlet.result.MockMvcResultHandlers
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import reactor.core.publisher.{Flux, Mono}

/**
  * Created by 43578876 on 21/02/2017.
  */
class WalkInControllerTest extends ControllerTest {

  val walkins = new java.util.HashMap[String, WalkIn]
  val person: Appointment.Person = new Appointment.Person("John", "Smith", "john.smith@email.com", "07957445933", "020 4444 4444", "Male")
  val staff: Appointment.Employee = new Appointment.Employee("44443232", "Edna Nashville")

  val now: Long = LocalDateTime.now.atZone(ZoneId.systemDefault).toInstant.toEpochMilli
  val minute: Long = 60000
  walkins.put("ddd12333", new WalkIn("12334", CHECKED_IN, 90, 5, "400706", "Current Account", "Review", "Subcategory", "No comments", false, person, staff, now - 5 * minute, now - 5 * minute, now - 5 * minute, null, "Europe/London", "GBR", null, null))
  walkins.put("ddd33444", new WalkIn("33444", IN_MEETING, 60, 5, "400706", "Current Account", "Review", "Subcategory", "No comments", false, person, staff, now, now, now, now + 5 * minute, "Europe/London", "GBR", null, null))

  it should " return a list of walkins asynchronously " in {

    val response =
      """
        |[
        |  {
        |    "appointmentId": "12334",
        |    "appointmentStatus": "CHECKED_IN",
        |    "duration": 90,
        |    "overdueOffset": 5,
        |    "branchId": "400706",
        |    "topicId": "Current Account",
        |    "topicCategoryId": "Review",
        |    "topicSubCategoryId": "Subcategory",
        |    "attendee": {
        |      "firstName": "John",
        |      "lastName": "Smith",
        |      "email": "john.smith@email.com",
        |      "phoneNumber": "07957445933",
        |      "mobileNumber": "020 4444 4444",
        |      "gender": "Male"
        |    },
        |    "conductor": {
        |      "employeeId": "44443232",
        |      "fullName": "Edna Nashville"
        |    },
        |    "comments": "No comments",
        |    "proofOfId": false,
        |    "timezone": "Europe/London",
        |    "countryCode": "GBR"
        |  },
        |  {
        |    "appointmentId": "33444",
        |    "appointmentStatus": "IN_MEETING",
        |    "duration": 60,
        |    "overdueOffset": 5,
        |    "branchId": "400706",
        |    "topicId": "Current Account",
        |    "topicCategoryId": "Review",
        |    "topicSubCategoryId": "Subcategory",
        |    "attendee": {
        |      "firstName": "John",
        |      "lastName": "Smith",
        |      "email": "john.smith@email.com",
        |      "phoneNumber": "07957445933",
        |      "mobileNumber": "020 4444 4444",
        |      "gender": "Male"
        |    },
        |    "conductor": {
        |      "employeeId": "44443232",
        |      "fullName": "Edna Nashville"
        |    },
        |    "comments": "No comments",
        |    "proofOfId": false,
        |    "timezone": "Europe/London",
        |    "countryCode": "GBR"
        |  }
        |]
      """.stripMargin



    when(walkInRepository.findByBranchId("400706")).thenReturn(Flux.fromIterable(walkins.values))

    doGetAsync("/walkins?branchId=400706",HttpStatus.OK)
      .andExpect(content.json(response))
  }

  it should " update a walkin asynchronously " in {
    val walkIn = walkins.get("ddd12333")
    val walkInMono = Mono.just(walkIn)
    when(walkInRepository.findById("58bd380c0303220b704c9b80")).thenReturn(walkInMono)
    val walkInUpdated = new Appointment.WalkIn(walkIn.appointmentId, AppointmentStatus.COMPLETED, walkIn.duration, walkIn.overdueOffset,
      walkIn.branchId, walkIn.topicId, walkIn.topicCategoryId, walkIn.topicSubCategoryId, walkIn.comments,
      walkIn.proofOfId, walkIn.attendee, walkIn.conductor, walkIn.created, walkIn.dateTime, 12345L, 12345L, walkIn.timezone,
      walkIn.countryCode, 12345L, null)
    when(walkInRepository.save(any(classOf[Mono[WalkIn]]))).thenReturn(Mono.just(walkInUpdated))

    val request =
      """
        |{"appointmentStatus" : "IN_MEETING"}
      """.stripMargin

    val response =
      """
        |{
        |  "appointmentId": "12334",
        |  "appointmentStatus": "COMPLETED",
        |  "duration": 90,
        |  "overdueOffset": 5,
        |  "branchId": "400706",
        |  "topicId": "Current Account",
        |  "topicCategoryId": "Review",
        |  "topicSubCategoryId": "Subcategory",
        |  "comments": "No comments",
        |  "proofOfId": false,
        |  "attendee": {
        |    "firstName": "John",
        |    "lastName": "Smith",
        |    "email": "john.smith@email.com",
        |    "phoneNumber": "07957445933",
        |    "mobileNumber": "020 4444 4444",
        |    "gender": "Male"
        |  },
        |  "conductor": {
        |    "employeeId": "44443232",
        |    "fullName": "Edna Nashville"
        |  },
        |  "timezone": "Europe/London",
        |  "countryCode": "GBR"
        |}
      """.stripMargin

    doPostAsync("/walkins/58bd380c0303220b704c9b80", HttpStatus.OK, request)
      .andExpect(content.json(response))

  }

  it should " throw conflict error when previous walkin status does not match " in {

    val walkIn = Mono.just(walkins.get("ddd33444"))
    when(walkInRepository.findById("33444")).thenReturn(walkIn)
    when(walkInRepository.save(any(classOf[Mono[WalkIn]]))).thenThrow(new Exceptions.ConflictException(CONFLICT_ON_WALKIN_STATUS_UPDATE, IN_MEETING, CANCELLED))

    val request =
      """
        |{"appointmentStatus" : "CANCELLED"}
      """.stripMargin

    val response =
      """
        |{
        |  "error": {
        |    "code": 409,
        |    "message": "Walkin status can not be updated from IN_MEETING to CANCELLED"
        |  }
        |}
      """.stripMargin

    mvc.perform(post("/walkins/33444")
      .contentType(MediaType.APPLICATION_JSON)
      .content(request))
      .andDo(MockMvcResultHandlers.print())
      .andExpect(status().is(HttpStatus.CONFLICT.value()))
      .andExpect(content.json(response))

  }

  it should " return a count for each status filtering by today, not ended, specific location and not cancelled " in {

    val response =
      """
        {"CANCELLED":0,"IN_MEETING":1,"CHECKED_IN":1, "OVERDUE": 1}
      """.stripMargin

    when(walkInRepository.findByBranchId("400706")).thenReturn(Flux.fromIterable(walkins.values))

    doGetAsync("/walkins/statusCounts?branchId=400706",HttpStatus.OK)
      .andExpect(content.json(response))
  }

  it should " return a total count of WalkIn for today and specific location " in {
    when(walkInRepository.findByBranchId("400706")).thenReturn(Flux.fromIterable(walkins.values))
    when(walkInRepository.findYesterdayByBranchId("400706")).thenReturn(Flux.fromIterable(walkins.values))

    val response =
      """
        {"total":2,"averageWaitingTime":5,"averageWaitingTimeLastBusinessDay":5}
      """.stripMargin

    doGetAsync("/walkins/stats?branchId=400706", HttpStatus.OK)
      .andExpect(content.json(response))
  }

  it should " create a walkin asynchronously " in {
    val walkIn = walkins.get("ddd12333")
    val branch: BranchDetails = new Branch.BranchDetails("400706", "GBLNKEN1", 1234.54, 4567.56, "Europe/London", "Holborn Branch",
      new Branch.Address("Holborn Street", "Holborn Road", "London", "HOL BORN", "City Center", "GBR"))

    when(branchRepository.findById("400706")).thenReturn(Mono.just(branch))
    when(walkInRepository.insert(any[Mono[WalkIn]]())).thenReturn(Mono.just(walkIn))

    val request =
      """
        |{
        |  "appointmentId": "12334",
        |  "appointmentStatus": "CHECKED_IN",
        |  "duration": 90,
        |  "branchId": "400706",
        |  "topicId": "Current Account",
        |  "topicCategoryId": "Review",
        |  "topicSubCategoryId": "Subcategory",
        |  "comments": "No comments",
        |  "proofOfId": false,
        |  "attendee": {
        |    "firstName": "John",
        |    "lastName": "Smith",
        |    "email": "john.smith@email.com",
        |    "phoneNumber": "07957445933",
        |    "mobileNumber": "020 4444 4444",
        |    "gender": "Male"
        |  },
        |  "conductor": {
        |    "employeeId": "44443232",
        |    "fullName": "Edna Nashville"
        |  }
        |}
      """.stripMargin

    val response =
      """
        |{
        |  "appointmentId": "12334",
        |  "appointmentStatus": "CHECKED_IN",
        |  "duration": 90,
        |  "overdueOffset": 5,
        |  "branchId": "400706",
        |  "topicId": "Current Account",
        |  "topicCategoryId": "Review",
        |  "topicSubCategoryId": "Subcategory",
        |  "comments": "No comments",
        |  "proofOfId": false,
        |  "attendee": {
        |    "firstName": "John",
        |    "lastName": "Smith",
        |    "email": "john.smith@email.com",
        |    "phoneNumber": "07957445933",
        |    "mobileNumber": "020 4444 4444",
        |    "gender": "Male"
        |  },
        |  "conductor": {
        |    "employeeId": "44443232",
        |    "fullName": "Edna Nashville"
        |  },
        |  "timezone": "Europe/London",
        |  "countryCode": "GBR"
        |}
      """.stripMargin

    doPostAsync("/walkins", HttpStatus.CREATED, request)
      .andExpect(content.json(response))

  }

  it should " return a walkin asynchronously " in {
    val walkIn = Mono.just(walkins.get("ddd12333"))
    when(walkInRepository.findById("12334")).thenReturn(walkIn)

    val response =
      """
        |{
        |  "appointmentId": "12334",
        |  "appointmentStatus": "CHECKED_IN",
        |  "duration": 90,
        |  "overdueOffset": 5,
        |  "branchId": "400706",
        |  "topicId": "Current Account",
        |  "topicCategoryId": "Review",
        |  "topicSubCategoryId": "Subcategory",
        |  "attendee": {
        |    "firstName": "John",
        |    "lastName": "Smith",
        |    "email": "john.smith@email.com",
        |    "phoneNumber": "07957445933",
        |    "mobileNumber": "020 4444 4444",
        |    "gender": "Male"
        |  },
        |  "conductor": {
        |    "employeeId": "44443232",
        |    "fullName": "Edna Nashville"
        |  },
        |  "comments": "No comments",
        |  "proofOfId": false,
        |  "timezone": "Europe/London",
        |  "countryCode": "GBR"
        |}
      """.stripMargin

    doGetAsync("/walkins/12334", HttpStatus.OK)
      .andExpect(content.json(response))
  }

  it should " return a walkins list " in {

    val response =
      """{
        |  "walkins" : [
        |     {
        |       "appointmentId": "12334",
        |       "appointmentStatus": "CHECKED_IN",
        |       "duration": 90,
        |       "overdueOffset": 5,
        |       "branchId": "400706",
        |       "topicId": "Current Account",
        |       "topicCategoryId": "Review",
        |       "topicSubCategoryId": "Subcategory",
        |       "attendee": {
        |         "firstName": "John",
        |         "lastName": "Smith",
        |         "email": "john.smith@email.com",
        |         "phoneNumber": "07957445933",
        |         "mobileNumber": "020 4444 4444",
        |         "gender": "Male"
        |       },
        |       "conductor": {
        |         "employeeId": "44443232",
        |         "fullName": "Edna Nashville"
        |       },
        |       "comments": "No comments",
        |       "proofOfId": false,
        |       "timezone": "Europe/London",
        |       "countryCode": "GBR"
        |     },
        |     {
        |       "appointmentId": "33444",
        |       "appointmentStatus": "IN_MEETING",
        |       "duration": 60,
        |       "overdueOffset": 5,
        |       "branchId": "400706",
        |       "topicId": "Current Account",
        |       "topicCategoryId": "Review",
        |       "topicSubCategoryId": "Subcategory",
        |       "attendee": {
        |         "firstName": "John",
        |         "lastName": "Smith",
        |         "email": "john.smith@email.com",
        |         "phoneNumber": "07957445933",
        |         "mobileNumber": "020 4444 4444",
        |         "gender": "Male"
        |       },
        |       "conductor": {
        |         "employeeId": "44443232",
        |         "fullName": "Edna Nashville"
        |       },
        |       "comments": "No comments",
        |       "proofOfId": false,
        |       "timezone": "Europe/London",
        |       "countryCode": "GBR"
        |     }
        |   ],
        |   "statusCounts" : {"CANCELLED":0,"IN_MEETING":1,"CHECKED_IN":1, "OVERDUE": 1}
        |}
      """.stripMargin

    when(walkInRepository.findByBranchId("400706")).thenReturn(Flux.fromIterable(walkins.values))

    doGetAsync("/walkins/list?branchId=400706",HttpStatus.OK)
      .andExpect(content.json(response))
  }

}
