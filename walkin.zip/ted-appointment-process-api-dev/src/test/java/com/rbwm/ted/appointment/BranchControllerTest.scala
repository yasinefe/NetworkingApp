/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import com.rbwm.ted.appointment.model.Branch.{Address, BranchDetails, LocationMacAddress}
import org.mockito.Matchers
import org.mockito.Mockito._
import org.springframework.http.HttpStatus
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import reactor.core.publisher.Mono.just
import reactor.core.publisher.{Flux, Mono}

/**
  * Created by 44027117 on 20/04/2017.
  */
class BranchControllerTest  extends ControllerTest with RestTestPack{

  val macAddress = "34:fd:0g:ff"
  val address = new Address("68 Whitehall Waterfront", "2 RiverSide Way", "Leeds", "LS14EE", "West Yorkshire", "GB")
  val canaryWharf = new BranchDetails("1234", "GB123456", 11.11, 22.22, "Europe/London", "Canary Wharf", address)
  val locationMacAddress = new LocationMacAddress("locationMacAddressId", macAddress, "GB123456XYZ", "locationDescription", "branchName", "countryCode", 1234L)

  def branchListResponse = """
        [
          {
            "branchId": "1234",
            "longitude": 11.11,
            "latitude": 22.22,
            "timezone": "Europe/London",
            "name": "Canary Wharf",
            "address": {
              "addressLine1": "68 Whitehall Waterfront",
              "addressLine2": "2 RiverSide Way",
              "city": "Leeds",
              "postcode": "LS14EE",
              "county": "West Yorkshire",
              "countryCode": "GB"
            }
          },
          {
            "branchId": "5678",
            "longitude": 33.33,
            "latitude": 44.44,
            "timezone": "Europe/London",
            "name": "London Bridge",
            "address": {
              "addressLine1": "68 Whitehall Waterfront",
              "addressLine2": "2 RiverSide Way",
              "city": "Leeds",
              "postcode": "LS14EE",
              "county": "West Yorkshire",
              "countryCode": "GB"
            }
          }
        ]
      """

  it should " return all the branches " in {

    val branchDetailsList = new java.util.ArrayList[BranchDetails]
    branchDetailsList.add(canaryWharf)
    branchDetailsList.add(new BranchDetails("5678", "GB123459", 33.33, 44.44, "Europe/London", "London Bridge", address))

    val fluxBranches = Flux.fromIterable(branchDetailsList)
    when(branchRepository.findByCountryCode("GB")).thenReturn(fluxBranches)

    doGetAsync("/branches/countryCode/GB", HttpStatus.OK)
      .andExpect(content.json(branchListResponse))
  }

  it should " return all the branches with search parameter " in {
    val branchDetailsList = new java.util.ArrayList[BranchDetails]
    branchDetailsList.add(canaryWharf)
    branchDetailsList.add(new BranchDetails("5678", "GB123459", 33.33, 44.44, "Europe/London", "London Bridge", address))

    val fluxBranches = Flux.fromIterable(branchDetailsList)
    when(branchRepository.findByCountryCode("GB")).thenReturn(fluxBranches)

    def branchListResponse = """
      [
        {
          "branchId": "1234",
          "longitude": 11.11,
          "latitude": 22.22,
          "name": "Canary Wharf",
          "address": {
            "addressLine1": "68 Whitehall Waterfront",
            "addressLine2": "2 RiverSide Way",
            "city": "Leeds",
            "postcode": "LS14EE",
            "county": "West Yorkshire",
            "countryCode": "GB"
          }
        }
      ]
    """.stripMargin

    doGetAsync("/branches/countryCode/GB?search=Canary", HttpStatus.OK)
      .andExpect(content.json(branchListResponse))
  }


  it should " return a branch for a valid mac address " + macAddress + " that exists in the lookup table" in {
    when(locationMacAddressRepository.findByMacAddress(macAddress)).thenReturn(just(locationMacAddress))
    when(branchRepository.findByCramerId(Matchers.any())).thenReturn(just(canaryWharf))

    val response =
      """
      {
      "branchId": "1234",
      "longitude": 11.11,
      "latitude": 22.22,
      "timezone": "Europe/London",
      "name": "Canary Wharf",
      "address": {
        "addressLine1": "68 Whitehall Waterfront",
        "addressLine2": "2 RiverSide Way",
        "city": "Leeds",
        "postcode": "LS14EE",
        "county": "West Yorkshire",
        "countryCode": "GB"
        }
      }
        """

    doGetAsync("/branches/macAddress/" + macAddress, HttpStatus.OK)
        .andExpect(content.json(response))
  }

  val branchId = "1234"
  it should " return a branch for a valid branchId " + branchId + " that exists in the database" in {

    when(branchRepository.findById(branchId)).thenReturn(just(canaryWharf))

    val response =
      """
      {
      "branchId": "1234",
      "longitude": 11.11,
      "latitude": 22.22,
      "timezone": "Europe/London",
      "name": "Canary Wharf",
      "address": {
        "addressLine1": "68 Whitehall Waterfront",
        "addressLine2": "2 RiverSide Way",
        "city": "Leeds",
        "postcode": "LS14EE",
        "county": "West Yorkshire",
        "countryCode": "GB"
        }
      }
      """

    doGetAsync("/branches/branchId/" + branchId, HttpStatus.OK)
      .andExpect(content.json(response))
  }
}
