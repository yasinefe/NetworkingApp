/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

/**
 * Created by 44052007 on 10/04/2017.
 */
public enum ErrorCode {

    NO_CONNECTION_TO_MONGO_DB(301,"Unable to connect mongo db : {0}"),
    WALKIN_NOT_FOUND(302,"Walkin not found for id: {0}"),
    MAC_ADDRESS_NOT_FOUND(303,"Mac Address not found for: {0}"),
    BRANCH_NOT_FOUND_CRAMER_ID(304,"Branch not found for cramerId : {0}"),
    BRANCH_NOT_FOUND_BRANCH_ID(305,"Branch not found for branchId : {0}"),
    UNEXPECTED_ERROR(501,"Unexpected error : {0}"),
    CONFLICT_ON_WALKIN_STATUS_UPDATE(409,"Walkin status can not be updated from {0} to {1}");

    private int code;
    private String description;


    ErrorCode(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
