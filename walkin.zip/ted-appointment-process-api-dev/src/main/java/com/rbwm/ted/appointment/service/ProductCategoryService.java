/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.api.ProductCategoryServiceApi;
import com.rbwm.ted.appointment.model.Appointment.ProductCategory;
import com.rbwm.ted.appointment.repository.ProductCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.util.function.Function;

/**
 * Created by 43578876 on 20/02/2017.
 */
@Service
public class ProductCategoryService implements ProductCategoryServiceApi {

    private final ProductCategoryRepository productCategoryRepository;

    @Autowired
    public ProductCategoryService(ProductCategoryRepository productCategoryRepository) {
        this.productCategoryRepository = productCategoryRepository;
    }

    @Override
    public Flux<ProductCategory> findAll() {
        return productCategoryRepository.findAll();
    }

    @Override
    public Flux<ProductCategory> findByCountry(String countryCode) {
        return productCategoryRepository.findByCountry(countryCode);
    }

}
