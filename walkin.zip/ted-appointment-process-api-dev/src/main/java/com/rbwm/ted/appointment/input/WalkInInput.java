/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.input;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rbwm.ted.appointment.model.Appointment.Employee;
import com.rbwm.ted.appointment.model.Appointment.Person;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import lombok.EqualsAndHashCode;

/**
 * Created by 44027117 on 16/03/2017.
 */
@EqualsAndHashCode
public class WalkInInput {

    public final String appointmentId;
    public final AppointmentStatus appointmentStatus;
    public final Integer duration;
    public final String branchId;
    public final String topicId;
    public final String topicCategoryId;
    public final String topicSubCategoryId;
    public final Person attendee;
    public final Employee conductor;
    public final String comments;
    public final Boolean proofOfId;

    @JsonCreator
    public WalkInInput(@JsonProperty("appointmentId") final String appointmentId,
                  @JsonProperty("appointmentStatus") final AppointmentStatus appointmentStatus,
                  @JsonProperty("duration") final Integer duration,
                  @JsonProperty("branchId") final String branchId,
                  @JsonProperty("topicId") final String topicId,
                  @JsonProperty("topicCategoryId") final String topicCategoryId,
                  @JsonProperty("topicSubCategoryId") final String topicSubCategoryId,
                  @JsonProperty("comments") final String comments,
                  @JsonProperty("proofOfId") final Boolean proofOfId,
                  @JsonProperty("attendee") final Person attendee,
                  @JsonProperty("conductor") final Employee conductor
    ) {
        this.appointmentId = appointmentId;
        this.appointmentStatus = appointmentStatus;
        this.duration = duration;
        this.branchId = branchId;
        this.topicId = topicId;
        this.topicCategoryId = topicCategoryId;
        this.topicSubCategoryId = topicSubCategoryId;
        this.comments = comments;
        this.proofOfId = proofOfId;
        this.attendee = attendee;
        this.conductor = conductor;
    }
}
