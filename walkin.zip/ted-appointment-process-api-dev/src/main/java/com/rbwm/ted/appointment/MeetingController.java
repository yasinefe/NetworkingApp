/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.rbwm.ted.appointment.api.MeetingServiceApi;
import com.rbwm.ted.appointment.api.MeetingStatsServiceApi;
import com.rbwm.ted.appointment.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Created by 43578876 on 20/02/2017.
 */
@RestController
@RequestMapping("/meetings")
public class MeetingController {

    private final MeetingServiceApi meetingService;
    private final MeetingStatsServiceApi meetingStatsService;

    @Autowired
    public MeetingController(MeetingServiceApi meetingService, MeetingStatsServiceApi meetingStatsService) {
        this.meetingService = meetingService;
        this.meetingStatsService = meetingStatsService;
    }

    @RequestMapping(value = "/branchId/{branchId}", method = RequestMethod.GET)
    public CompletableFuture<List<Meeting>> getMeetings(@PathVariable("branchId") String branchId,
                                                        @RequestParam(value = "meetingStatus", required = false) MeetingStatus meetingStatus,
                                                        @RequestParam(value = "meetingGroup", required = false) MeetingGroup meetingGroup) {
        return meetingService.getMeetings(branchId, meetingStatus, meetingGroup).collectList().toFuture();
    }

    @RequestMapping(value = "/{meetingId}", method = RequestMethod.GET)
    public CompletableFuture<Meeting> getMeeting(@PathVariable("meetingId") String meetingId) {
        return meetingService.getMeeting(meetingId).toFuture();
    }

    @RequestMapping(method = RequestMethod.POST)
    public CompletableFuture<Meeting> createMeeting(@RequestBody MeetingInput meetingInput) {
        return meetingService.createMeeting(meetingInput).toFuture();
    }

    @RequestMapping(value = "/{meetingId}", method = RequestMethod.PUT)
    public CompletableFuture<Meeting> updateMeetingStatus(@PathVariable("meetingId") String meetingId, @RequestBody MeetingStatus meetingStatus) {
        return meetingService.updateMeetingStatus(meetingId, meetingStatus).toFuture();
    }

    @RequestMapping(value = "/stats/branchId/{branchId}", method = RequestMethod.GET)
    public CompletableFuture<MeetingStats> getMeetingStats(@PathVariable("branchId") String branchId) {
        return meetingStatsService.getMeetingStats(branchId).toFuture();
    }

}
