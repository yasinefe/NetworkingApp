/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.api.MeetingServiceApi;
import com.rbwm.ted.appointment.api.WalkInServiceApi;
import com.rbwm.ted.appointment.config.WalkInConfig;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import com.rbwm.ted.appointment.input.WalkInInput;
import com.rbwm.ted.appointment.model.*;
import com.rbwm.ted.appointment.model.Appointment.Person;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.repository.WalkInRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static java.time.Duration.ofMillis;
import static java.time.Duration.ofMinutes;

/**
 * Created by 44052007 on 30/04/2018.
 */
@Service
public class MeetingService implements MeetingServiceApi {

    private final static int DEFAULT_WALKIN_DURATION = 15;

    private final WalkInServiceApi walkinServiceApi;
    private final DateTimeHelper dateTimeHelper;
    private final WalkInConfig walkInConfig;
    private final WalkInRepository walkInRepository;

    @Autowired
    public MeetingService(WalkInServiceApi walkinServiceApi, DateTimeHelper dateTimeHelper, WalkInConfig walkInConfig,
                          WalkInRepository walkInRepository) {
        this.walkinServiceApi = walkinServiceApi;
        this.dateTimeHelper = dateTimeHelper;
        this.walkInConfig = walkInConfig;
        this.walkInRepository = walkInRepository;
    }

    @Override
    public Flux<Meeting> getMeetings(String branchId, MeetingStatus meetingStatus, MeetingGroup meetingGroup) {
        return walkInRepository.findByBranchId(branchId)
                .map(this::convertToMeeting)
                .filter(meeting -> meetingStatus == null || meetingStatus.equals(meeting.status))
                .filter(meeting -> meetingGroup == null || meetingGroup.equals(meeting.group));
    }

    @Override
    public Mono<Meeting> getMeeting(String meetingId) {
        return walkInRepository.findById(meetingId).map(this::convertToMeeting);
    }

    @Override
    public Mono<Meeting> createMeeting(MeetingInput meetingInput) {
        Person attendee = new Person(meetingInput.firstName, meetingInput.lastName, null, null, null,
                meetingInput.gender != null ? meetingInput.gender.name() : null);
        return walkinServiceApi.insert(new WalkInInput(null,
                AppointmentStatus.CHECKED_IN,
                DEFAULT_WALKIN_DURATION,
                meetingInput.branchId,
                meetingInput.topicId,
                meetingInput.topicCategoryId,
                meetingInput.topicSubCategoryId,
                meetingInput.comments,
                meetingInput.proofOfId,
                attendee,
                null)).map(this::convertToMeeting);
    }

    @Override
    public Mono<Meeting> updateMeetingStatus(String meetingId, MeetingStatus meetingStatus) {
        return walkinServiceApi.updateStatus(meetingId, AppointmentStatus.valueOf(meetingStatus.name()))
                .map(this::convertToMeeting);
    }

    private Meeting convertToMeeting(WalkIn walkIn) {
        MeetingStatus meetingStatus = getMeetingStatus(walkIn);
        return new Meeting(meetingStatus, getMeetingGroup(walkIn), walkIn.appointmentId, walkIn.topicId,
                walkIn.topicId, walkIn.topicCategoryId, walkIn.topicCategoryId, walkIn.topicSubCategoryId,
                walkIn.topicSubCategoryId, walkIn.conductor, formatDateTime(walkIn.dateTime, walkIn.timezone),
                formatDateTime(walkIn.created, walkIn.timezone), formatDateTime(walkIn.startedAt, walkIn.timezone),
                formatDateTime(walkIn.endedAt, walkIn.timezone), walkIn.duration, isNew(walkIn),
                isOverDue(walkIn, meetingStatus, walkInConfig.getOverdueOffset()),
                isOverDue(walkIn, meetingStatus, walkInConfig.getCriticalOverDueOffset()),
                isOverRun(walkIn, meetingStatus, walkIn.duration),
                isOverRun(walkIn, meetingStatus, walkIn.duration + walkInConfig.getCriticalOverRunOffset()), walkIn.attendee,
                walkIn.comments, walkIn.proofOfId, walkIn.countryCode, walkIn.endedBy, walkIn.timezone);
    }

    private MeetingStatus getMeetingStatus(WalkIn walkIn) {
        return MeetingStatus.valueOf(walkIn.appointmentStatus.name());
    }

    private MeetingGroup getMeetingGroup(WalkIn walkIn) {
        if (walkIn.appointmentStatus == AppointmentStatus.CANCELLED) {
            return MeetingGroup.COMPLETED;
        } else {
            return MeetingGroup.valueOf(walkIn.appointmentStatus.name());
        }
    }

    private String formatDateTime(Long dateTime, String timezone) {
        return dateTime != null ? dateTimeHelper.toIsoFormat.apply(dateTime, timezone) : null;
    }

    // It is true if meeting has been created in last X mins.
    private Boolean isNew(WalkIn walkIn) {
        return !dateTimeHelper.nowIsOverOf.apply(walkIn.created, walkInConfig.getNewOffset());
    }

    // It is true if meeting has at least been checked in and datetime is in past, it should have been started at datetime.
    private Boolean isOverDue(WalkIn walkIn, MeetingStatus meetingStatus, long offset) {
        switch (meetingStatus) {
            case CHECKED_IN:
                return isElapsedTimeOverDuration(walkIn.dateTime, dateTimeHelper.now.get(), offset);
            case IN_MEETING:
            case COMPLETED:
                return isElapsedTimeOverDuration(walkIn.dateTime, walkIn.startedAt, offset);
            case CANCELLED:
                return isElapsedTimeOverDuration(walkIn.dateTime, walkIn.endedAt, offset);
            default:
                return false;
        }
    }

    // It is true if meeting takes X minutes longer then duration
    private Boolean isOverRun(WalkIn walkIn, MeetingStatus meetingStatus, long offset) {
        switch (meetingStatus) {
            case IN_MEETING:
                return isElapsedTimeOverDuration(walkIn.startedAt, dateTimeHelper.now.get(), offset);
            case COMPLETED:
                return isElapsedTimeOverDuration(walkIn.startedAt, walkIn.endedAt, offset);
            default:
                return false;
        }
    }

    private Boolean isElapsedTimeOverDuration(Long beginningTime, Long endingTime, long duration) {
        return beginningTime != null && endingTime != null && ofMillis(endingTime - beginningTime).compareTo(ofMinutes(duration)) > 0;
    }

}
