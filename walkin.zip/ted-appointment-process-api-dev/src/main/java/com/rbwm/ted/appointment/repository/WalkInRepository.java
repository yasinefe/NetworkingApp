/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.repository;

import com.rbwm.ted.appointment.config.MongoConfig;
import com.rbwm.ted.appointment.config.WalkInConfig;
import com.rbwm.ted.appointment.error.Exceptions.NotFoundException;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import com.rbwm.ted.appointment.service.WalkInFilters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

import static com.rbwm.ted.appointment.error.ErrorCode.WALKIN_NOT_FOUND;

/**
 * Created by 44052007 on 03/04/2017.
 */
@Repository
public class WalkInRepository {

    public final BiFunction<WalkIn, Integer, WalkIn> builderOverdueOffset = (w, overdue) -> new WalkIn(w.appointmentId,
            w.appointmentStatus, w.duration, overdue, w.branchId, w.topicId, w.topicCategoryId,
            w.topicSubCategoryId, w.comments, w.proofOfId, w.attendee, w.conductor, w.created, w.dateTime,
            w.updated, w.startedAt, w.timezone, w.countryCode, w.endedAt, w.endedBy);

    private final Function<String, Mono<WalkIn>> appointmentNotFound = (appointmentId) ->
            Mono.error(new NotFoundException(WALKIN_NOT_FOUND, appointmentId));

    private interface WalkInDecorator extends Function<WalkIn, WalkIn>{}
    private final WalkInDecorator addOverdueOffset;

    private final Function<String, Criteria> locationCriteria;

    private final Supplier<Criteria> todayCriteria;
    private final Supplier<Criteria> yesterdayCriteria;

    private final Function<String, Criteria> todayWalkInsCriteria;
    private final Function<String, Criteria> yesterdayWalkInsCriteria;

    private final String walkInsCollection;
    private final ReactiveMongoTemplate mongoTemplate;
    private final WalkInFilters walkInFilters;

    @Autowired
    public WalkInRepository(ReactiveMongoTemplate mongoTemplate, MongoConfig mongoConfig, WalkInConfig walkInConfig,
                            DateTimeHelper dateTimeHelper, WalkInFilters walkInFilters) {
        this.mongoTemplate = mongoTemplate;
        this.walkInsCollection = mongoConfig.getWalkInsCollection();
        this.walkInFilters = walkInFilters;

        this.addOverdueOffset = walkIn -> builderOverdueOffset.apply(walkIn, walkInConfig.getOverdueOffset());

        this.locationCriteria = branchId -> Criteria.where("branchId").is(branchId);
        this.todayCriteria = () -> Criteria.where("dateTime").gte(dateTimeHelper.epocOfDaysBefore.apply(1));
        this.yesterdayCriteria = () -> Criteria.where("dateTime").gte(dateTimeHelper.epocOfDaysBefore.apply(3));
        this.todayWalkInsCriteria =  branchId -> locationCriteria.apply(branchId).andOperator(todayCriteria.get());
        this.yesterdayWalkInsCriteria = branchId -> locationCriteria.apply(branchId).andOperator(yesterdayCriteria.get());
    }

    public Flux<WalkIn> findByBranchId(String branchId) {
        return mongoTemplate.find(Query.query(todayWalkInsCriteria.apply(branchId)), WalkIn.class, walkInsCollection)
                .filter(walkInFilters.isInToday)
                .map(addOverdueOffset);
    }

    public Flux<WalkIn> findYesterdayByBranchId(String locationId) {
        return mongoTemplate.find(Query.query(yesterdayWalkInsCriteria.apply(locationId)), WalkIn.class, walkInsCollection)
                .filter(walkInFilters.isInYesterday)
                .map(addOverdueOffset);
    }

    public Mono<WalkIn> findById(String appointmentId) {
        return mongoTemplate
                .findById(appointmentId, WalkIn.class, walkInsCollection)
                .otherwiseIfEmpty(appointmentNotFound.apply(appointmentId))
                .map(addOverdueOffset);
    }

    public Mono<WalkIn> save(Mono<WalkIn> walkIn) {
        return mongoTemplate.save(walkIn, walkInsCollection)
                .map(addOverdueOffset);
    }

    public Mono<WalkIn> insert(Mono<WalkIn> walkInMono) {
        return walkInMono.then(walkIn -> mongoTemplate.insert(walkIn, walkInsCollection))
                .map(addOverdueOffset);
    }

    public Flux<WalkIn> findByAppointmentStatus(AppointmentStatus appointmentStatus) {
        Query query = Query.query(Criteria.where("appointmentStatus").is(appointmentStatus.getVal()));
        return mongoTemplate.find(query, WalkIn.class, walkInsCollection).map(addOverdueOffset);
    }


}
