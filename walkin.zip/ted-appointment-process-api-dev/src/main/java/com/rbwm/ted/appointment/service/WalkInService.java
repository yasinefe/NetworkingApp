/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.api.WalkInServiceApi;
import com.rbwm.ted.appointment.audit.AuditContext;
import com.rbwm.ted.appointment.audit.AuditProcessor;
import com.rbwm.ted.appointment.config.WalkInConfig;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import com.rbwm.ted.appointment.input.WalkInInput;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.model.Appointment.WalkInList;
import com.rbwm.ted.appointment.model.Appointment.WalkInStats;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import com.rbwm.ted.appointment.model.Branch.BranchDetails;
import com.rbwm.ted.appointment.model.ModifierType;
import com.rbwm.ted.appointment.repository.BranchRepository;
import com.rbwm.ted.appointment.repository.WalkInRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;

import static com.rbwm.ted.appointment.audit.AuditContext.ENTITY_TYPE_WALKIN;
import static com.rbwm.ted.appointment.audit.AuditContext.OPERATION_WALKIN_CHANGE_STATUS;
import static com.rbwm.ted.appointment.error.ErrorCode.CONFLICT_ON_WALKIN_STATUS_UPDATE;
import static com.rbwm.ted.appointment.model.AppointmentStatus.*;
import static com.rbwm.ted.appointment.model.ModifierType.SYSTEM;
import static com.rbwm.ted.appointment.model.ModifierType.USER;

/**
 * Created by 43578876 on 20/02/2017.
 */
@Component
public class WalkInService implements WalkInServiceApi {

    private static final Logger log = LoggerFactory.getLogger(WalkInService.class);

    private final WalkInRepository walkInRepository;
    private final BranchRepository branchRepository;
    private final AuditProcessor auditProcessor;
    private final WalkInFilters walkInFilters;
    private final Integer walkInWaitingTime;
    private final DateTimeHelper dateTimeHelper;

    private final BiFunction<WalkIn, AppointmentStatus, Long> startedAt;
    private final BiFunction<WalkIn, AppointmentStatus, Long> endedAt;
    private final BiFunction<WalkIn, AppointmentStatus, ModifierType> endedBy;
    private final BiFunction<WalkIn, AppointmentStatus, WalkIn> builderStatus;
    private final Function<AppointmentStatus, Function<WalkIn, WalkIn>> statusUpdater;
    private final BiFunction<WalkInInput, Integer, WalkIn> createWalkin;
    private final BiFunction<WalkIn, BranchDetails, WalkIn> builderTimezoneAndCountryCode;

    private final Comparator comparatorByDateTime = Comparator.comparingLong(a -> (((WalkIn)a).dateTime));

    private final Predicate<WalkIn> isItInBatchProcessPeriod;
    private final Function<WalkIn, WalkIn> cancelBySystem;
    private final Function<WalkIn, WalkIn> completeBySystem;

    @Autowired
    public WalkInService(WalkInRepository walkInRepository, WalkInConfig walkInConfig, WalkInFilters walkInFilters,
                         DateTimeHelper dateTimeHelper, BranchRepository branchRepository, AuditProcessor auditProcessor) {
        this.walkInRepository = walkInRepository;
        this.walkInWaitingTime = walkInConfig.getWalkInWaitingTime();
        this.walkInFilters = walkInFilters;
        this.dateTimeHelper = dateTimeHelper;
        this.branchRepository = branchRepository;
        this.auditProcessor = auditProcessor;

        startedAt = (w, s) -> s.equals(AppointmentStatus.IN_MEETING) ? dateTimeHelper.now.get() : w.startedAt;
        endedAt = (w, s) -> s.equals(AppointmentStatus.COMPLETED) || s.equals(AppointmentStatus.CANCELLED) ? dateTimeHelper.now.get() : w.endedAt;
        endedBy = (w, s) -> s.equals(AppointmentStatus.COMPLETED) || s.equals(AppointmentStatus.CANCELLED) ? USER : w.endedBy;

        builderStatus = (w, status) -> new WalkIn(w.appointmentId,
                status, w.duration, w.overdueOffset, w.branchId, w.topicId, w.topicCategoryId,
                w.topicSubCategoryId, w.comments, w.proofOfId, w.attendee, w.conductor, w.created, w.dateTime, dateTimeHelper.now.get(),
                startedAt.apply(w, status), w.timezone, w.countryCode, endedAt.apply(w, status), endedBy.apply(w, status));

        statusUpdater = status -> walkIn -> builderStatus.apply(walkIn, status);

        createWalkin = (w, waitingTime) ->
                new WalkIn(w.appointmentId, w.appointmentStatus, w.duration, null, w.branchId, w.topicId, w.topicCategoryId,
                        w.topicSubCategoryId, w.comments, w.proofOfId, w.attendee, w.conductor, dateTimeHelper.now.get(),
                        dateTimeHelper.now.get() + TimeUnit.MINUTES.toMillis(waitingTime), dateTimeHelper.now.get(),
                        null, null, null, null, null);

        builderTimezoneAndCountryCode = (w, branchDetails) -> new WalkIn(w.appointmentId, w.appointmentStatus, w.duration, w.overdueOffset,
                w.branchId, w.topicId, w.topicCategoryId, w.topicSubCategoryId, w.comments, w.proofOfId, w.attendee,
                w.conductor, w.created, w.dateTime, w.updated, w.startedAt, branchDetails.timezone, branchDetails.address.countryCode,
                w.endedAt, w.endedBy);

        isItInBatchProcessPeriod = walkIn -> dateTimeHelper.getHourInTimeZone.apply(walkIn.timezone).compareTo(walkInConfig.getWalkInEndAfter()) > 0;

        cancelBySystem = w -> new WalkIn(w.appointmentId, CANCELLED, w.duration, w.overdueOffset,
                w.branchId, w.topicId, w.topicCategoryId, w.topicSubCategoryId, w.comments, w.proofOfId, w.attendee,
                w.conductor, w.created, w.dateTime, dateTimeHelper.now.get(), w.startedAt, w.timezone, w.countryCode,
                dateTimeHelper.now.get(), SYSTEM);

        completeBySystem = w -> new WalkIn(w.appointmentId, COMPLETED, w.duration, w.overdueOffset,
                w.branchId, w.topicId, w.topicCategoryId, w.topicSubCategoryId, w.comments, w.proofOfId, w.attendee,
                w.conductor, w.created, w.dateTime, dateTimeHelper.now.get(), w.startedAt, w.timezone, w.countryCode,
                dateTimeHelper.now.get(), SYSTEM);
    }

    @Override
    public Flux<WalkIn> findByBranchId(String branchId) {
        Flux<WalkIn> walkIns = walkInRepository.findByBranchId(branchId).sort(comparatorByDateTime);
        return walkIns.filter(walkInFilters.isNotCancelled);
    }

    @Override
    public Mono<WalkInList> getWalkinList(String branchId) {
        Flux<WalkIn> walkIns = walkInRepository.findByBranchId(branchId).sort(comparatorByDateTime);
        Flux<WalkIn> filteredWalkIns = walkIns.filter(walkInFilters.isNotCancelled);

        return Flux.zip(
                filteredWalkIns.collectList(),
                getStatusCounts(walkIns))
                .map(pair -> new WalkInList(pair.getT1(),pair.getT2()))
                .next();
    }

    @Override
    public Mono<WalkIn> findById(String appointmentId) {
        return walkInRepository.findById(appointmentId);
    }

    @Override
    public Mono<WalkIn> updateStatus(String appointmentId, AppointmentStatus appointmentStatus) {
        Mono<WalkIn> walkIn = walkInRepository.findById(appointmentId)
                .map(retrievedWalkIn -> {
                    if (retrievedWalkIn.appointmentStatus.equals(appointmentStatus.getPreviousStatus())) {
                        return statusUpdater.apply(appointmentStatus).apply(retrievedWalkIn);
                    } else {
                        throw new Exceptions.ConflictException(CONFLICT_ON_WALKIN_STATUS_UPDATE, retrievedWalkIn.appointmentStatus, appointmentStatus);
                    }
                });

        return walkInRepository.save(walkIn);
    }

    @Override
    public Mono<WalkIn> insert(WalkInInput walkInInput) {
        Mono<WalkIn> walkInMono = branchRepository.findById(String.valueOf(walkInInput.branchId))
                .map(branchDetails -> builderTimezoneAndCountryCode.apply(createWalkin.apply(walkInInput, walkInWaitingTime), branchDetails));
        return walkInRepository.insert(walkInMono);
    }

    @Override
    public Mono<Map<String, Long>> getStatusCounts(String locationId) {
       return getStatusCounts(walkInRepository.findByBranchId(locationId));
    }

    private Mono<Map<String, Long>> getStatusCounts(Flux<WalkIn> walkIns) {
        Map<String, Long> initialCounts = new HashMap<>();
        Arrays.stream(AppointmentStatus.values()).forEach(e ->  initialCounts.put(e.getVal(), 0L));
        return walkIns.map(flagStatus).reduce(initialCounts, summaryCounts);
    }

    @Override
    public Mono<WalkInStats> getStats(String branchId) {
        Flux<WalkIn> todayWalkIns = walkInRepository.findByBranchId(branchId).filter(walkInFilters.isNotCancelled);
        Flux<WalkIn> yesterdayWalkIns = walkInRepository.findYesterdayByBranchId(branchId).filter(walkInFilters.isNotCancelled);
        return Flux.zip(
                todayWalkIns.collectList(),
                yesterdayWalkIns.collectList())
                .map(pair -> new WalkInStats(pair.getT1(),pair.getT2(), dateTimeHelper.now.get()))
                .next();
    }

    private BiFunction<Map<String, Long>, Map<String, Long>, Map<String, Long>> summaryCounts = (a, b) -> {
        Map<String, Long> summary = new HashMap<>();
        Arrays.stream(AppointmentStatus.values())
                .forEach(e -> summary.put(e.getVal(), a.get(e.getVal()) + b.getOrDefault(e.getVal(), 0L)));
        return summary;
    };

    private Function<WalkIn, Map<String, Long>> flagStatus = walkIn -> {
            Map<String, Long> mapStatus = new HashMap<>();
            mapStatus.put(walkIn.appointmentStatus.getVal(), 1L);
            if (isOverdue(walkIn)) {
                mapStatus.put(AppointmentStatus.OVERDUE.getVal(), 1L);
            }
            return mapStatus;
        };

    private boolean isOverdue(WalkIn walkIn) {
        if (walkIn.appointmentStatus.equals(CHECKED_IN)) {
            long overdueTime = walkIn.dateTime + TimeUnit.MINUTES.toMillis(walkIn.overdueOffset);
            long now = dateTimeHelper.now.get();
            return now > overdueTime;
        }
        return false;
    }

    public void endWalkIns() {
        log.info("Scheduled batch process to end walk-ins has been started");
        cancelCheckedInWalkIns();
        log.info("Cancelled CHECKED_IN walk-ins");
        completeInMeetingWalkIns();
        log.info("Completed IN-MEETING walk-ins");
    }

    private void cancelCheckedInWalkIns() {
        Flux<WalkIn> checkedInWalkIns = walkInRepository.findByAppointmentStatus(CHECKED_IN);
        checkedInWalkIns.toStream()
                .filter(isItInBatchProcessPeriod)
                .map(cancelBySystem)
                .forEach(walkIn -> {
                    createAudit(walkIn);
                    walkInRepository.save(Mono.just(walkIn)).block();
                });
    }

    private void completeInMeetingWalkIns() {
        Flux<WalkIn> checkedInWalkIns = walkInRepository.findByAppointmentStatus(IN_MEETING);
        checkedInWalkIns.toStream()
                .filter(isItInBatchProcessPeriod)
                .map(completeBySystem)
                .forEach(walkIn -> {
                    createAudit(walkIn);
                    walkInRepository.save(Mono.just(walkIn)).block();
                });
    }

    private void createAudit(WalkIn walkIn) {
        Map<String, Object> variables = new HashMap<>();
        Map<String, Object> input = new HashMap<>();
        input.put("appointmentId", walkIn.appointmentId);
        input.put("appointmentStatus", walkIn.appointmentStatus.getVal());
        variables.put("input", input);
        AuditContext auditContext = new AuditContext(walkIn.countryCode, walkIn.branchId, SYSTEM.name(), SYSTEM.name(),
                SYSTEM.name(), variables, walkIn.appointmentId, OPERATION_WALKIN_CHANGE_STATUS, ENTITY_TYPE_WALKIN);
        auditProcessor.sendEvent(auditContext);
    }
}
