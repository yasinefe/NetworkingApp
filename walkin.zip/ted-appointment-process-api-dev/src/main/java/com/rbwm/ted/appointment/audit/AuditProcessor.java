/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.audit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.rbwm.ted.rest.api.CRUDRest;
import com.rbwm.ted.appointment.config.AuditConfiguration;
import com.rbwm.ted.appointment.error.ErrorCode;
import com.rbwm.ted.appointment.error.Exceptions.UnexpectedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * Created by 44027117 on 10/04/2017.
 */
@Component
public class AuditProcessor {

    private final CRUDRest crudRest;
    private final ObjectMapper objectMapper;
    private final AuditConfiguration auditConfiguration;
    private static final String FEATURE_PREFIX = "CREATE-AUDIT";

    @Autowired
    public AuditProcessor(ObjectMapper objectMapper, AuditConfiguration auditConfiguration) {
        this.objectMapper = objectMapper;
        this.auditConfiguration = auditConfiguration;
        this.crudRest = auditConfiguration.auditCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    @Async
    public void sendEvent(AuditContext auditContext) {
        try {
            crudRest.doPost(auditConfiguration.getAuditUri(), objectMapper.writeValueAsString(auditContext));
        } catch (JsonProcessingException e) {
            throw new UnexpectedException(ErrorCode.UNEXPECTED_ERROR, "Error converting the audit event data to JSON formats");
        }
    }

}
