/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.api.MeetingStatsServiceApi;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.model.MeetingStats;
import com.rbwm.ted.appointment.model.StatData;
import com.rbwm.ted.appointment.repository.WalkInRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.LongSummaryStatistics;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.rbwm.ted.appointment.model.AppointmentStatus.CANCELLED;
import static com.rbwm.ted.appointment.model.AppointmentStatus.COMPLETED;

/**
 * Created by 44052007 on 21/05/2018.
 */
@Service
public class MeetingStatsService implements MeetingStatsServiceApi {

    private final WalkInRepository walkInRepository;
    private final DateTimeHelper dateTimeHelper;

    @Autowired
    public MeetingStatsService(WalkInRepository walkInRepository, DateTimeHelper dateTimeHelper) {
        this.walkInRepository = walkInRepository;
        this.dateTimeHelper = dateTimeHelper;
    }

    @Override
    public Mono<MeetingStats> getMeetingStats(String branchId) {
        Flux<WalkIn> todayWalkIns = walkInRepository.findByBranchId(branchId);
        Flux<WalkIn> yesterdayWalkIns = walkInRepository.findYesterdayByBranchId(branchId);

        return Flux.zip(todayWalkIns.collectList(), yesterdayWalkIns.collectList())
                .map(pair -> getMeetingStats(pair.getT1(), pair.getT2()))
                .next();
    }

    private MeetingStats getMeetingStats(List<WalkIn> todayWalkIns, List<WalkIn> yesterdayWalkIns) {
        LongSummaryStatistics todayWaitingTimeStats = summarizeWaitingTime(todayWalkIns);
        LongSummaryStatistics yesterdayWaitingTimeStats = summarizeWaitingTime(yesterdayWalkIns);
        LongSummaryStatistics todayMeetingLengthTimeStats = summarizeMeetingLengthTime(yesterdayWalkIns);

        return new MeetingStats(
                new StatData((int) todayWaitingTimeStats.getCount(), todayWaitingTimeStats.getSum()),
                new StatData((int) yesterdayWaitingTimeStats.getCount(), yesterdayWaitingTimeStats.getSum()),
                new StatData((int) todayMeetingLengthTimeStats.getCount(), todayMeetingLengthTimeStats.getSum()),
                getCountInNextHour(todayWalkIns));
    }

    private LongSummaryStatistics summarizeWaitingTime(List<WalkIn> walkIns) {
        return walkIns.stream()
                .collect(Collectors.summarizingLong(this::waitingTime));
    }

    private Long waitingTime(WalkIn walkIn){
        if (walkIn.startedAt != null) {
            return walkIn.startedAt - walkIn.created;
        } else if (walkIn.endedAt != null) {
            return walkIn.endedAt - walkIn.created;
        } else {
            return dateTimeHelper.now.get() - walkIn.created;
        }
    }

    private LongSummaryStatistics summarizeMeetingLengthTime(List<WalkIn> walkIns) {
        return walkIns.stream()
                .filter(walkIn -> COMPLETED.equals(walkIn.appointmentStatus))
                .filter(this::hasStartedAndEndedTime)
                .collect(Collectors.summarizingLong(this::meetingLengthTime));
    }

    private boolean hasStartedAndEndedTime(WalkIn walkIn) {
        return walkIn.startedAt != null && walkIn.endedAt != null;
    }

    private Long meetingLengthTime(WalkIn walkIn) {
        return walkIn.endedAt - walkIn.startedAt;
    }

    private Integer getCountInNextHour(List<WalkIn> walkIns) {
        Long count = walkIns.stream()
                .filter(walkIn -> !CANCELLED.equals(walkIn.appointmentStatus))
                .filter(this::inNextHour)
                .count();
        return count.intValue();
    }

    private Boolean inNextHour(WalkIn walkIn) {
        Long now = dateTimeHelper.now.get();
        return walkIn.dateTime != null && walkIn.dateTime > now && walkIn.dateTime <= now + TimeUnit.HOURS.toMillis(1);
    }

}
