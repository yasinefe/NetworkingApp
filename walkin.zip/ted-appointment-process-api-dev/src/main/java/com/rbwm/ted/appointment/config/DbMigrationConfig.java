/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.mongobee.Mongobee;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.rbwm.ted.appointment.repository.changelogs.DatabaseChangeLog;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

/**
 * Created by 44052007 on 30/03/2017.
 */
@Configuration
public class DbMigrationConfig {

    @Bean
    public Mongobee mongobee(MongoConfig mongoConfig,
                             MongoTemplate mongoTemplate,
                             ObjectMapper objectMapper,
                             @Qualifier("defaultMongoClient") MongoClient mongoClient) {
        DatabaseChangeLog.setMongoTemplate(mongoTemplate);
        DatabaseChangeLog.setProductCategoriesCollectionName(mongoConfig.getProductCategoriesCollection());
        DatabaseChangeLog.setBranchesCollectionName(mongoConfig.getBranchesCollection());
        DatabaseChangeLog.setLocationMacAddressesCollectionName(mongoConfig.getLocationMacAddressCollection());
        DatabaseChangeLog.setWalkInsCollectionName(mongoConfig.getWalkInsCollection());
        DatabaseChangeLog.setObjectMapper(objectMapper);

        Mongobee mongobee = new Mongobee(mongoClient);
        mongobee.setDbName(mongoConfig.getDatabaseName());
        mongobee.setChangeLogsScanPackage(DatabaseChangeLog.class.getPackage().getName());
        mongobee.setEnabled(mongoConfig.getApplyChangeSet());

        return mongobee;
    }

    @Bean
    public MongoClient defaultMongoClient(MongoConfig mongoConfig){
        return new MongoClient(new MongoClientURI(mongoConfig.getConnectionUri()));
    }

    @Bean
    public MongoDbFactory mongoDbFactory(@Qualifier("defaultMongoClient") MongoClient mongoClient, MongoConfig mongoConfig) {
        return new SimpleMongoDbFactory(mongoClient, mongoConfig.getDatabaseName());
    }

    @Bean
    public MongoTemplate mongoTemplate(MongoDbFactory mongoDbFactory) {
        return new MongoTemplate(mongoDbFactory);
    }

}