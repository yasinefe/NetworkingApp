/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Created by 44027117 on 16/03/2017.
 */
@Component
public class DateTimeHelper {

    private final static String ISO_DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

    public final Supplier<Long> now;
    public final BiFunction<Long, String, LocalDate> localDateOf;
    public final BiFunction<Long, String, Boolean> isToday;
    public final BiFunction<Long, String, Boolean> isYesterday;
    public final BiFunction<Long, Integer, LocalDateTime> epochPlusMinutes;
    public final BiFunction<Long, Integer, Boolean> isEpochPlusMinutesAfterNow;
    public final Function<Integer, Long> epocOfDaysBefore;
    public final Function<String, String> getHourInTimeZone;
    public final BiFunction<Long, Integer, Boolean> nowIsOverOf;
    public final BiFunction<Long, String, String> toIsoFormat;

    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm");

    @Autowired
    public DateTimeHelper(ClockProvider clockProvider) {
        now = () -> clockProvider.getUTCInstant().toEpochMilli();

        localDateOf = (utcTime, timezone) -> Instant.ofEpochMilli(utcTime).atZone(ZoneId.of(timezone)).toLocalDate();

        isToday = (utcTime, timezone) -> localDateOf.apply(utcTime, timezone).equals(LocalDate.now(clockProvider.getClock(timezone)));

        isYesterday = (utcTime, timezone) -> {
            LocalDate yesterday = LocalDate.now(clockProvider.getClock(timezone)).minus(1, ChronoUnit.DAYS);
            if (yesterday.getDayOfWeek() == DayOfWeek.SUNDAY) {
                yesterday = yesterday.minus(1, ChronoUnit.DAYS);
            }
            return localDateOf.apply(utcTime, timezone).equals(yesterday);
        };

        epochPlusMinutes = (datetime, minutes) ->
                LocalDateTime.ofInstant(Instant.ofEpochMilli(datetime), ZoneId.systemDefault()).plusMinutes(minutes);

        isEpochPlusMinutesAfterNow = (datetime, minutes) ->
                epochPlusMinutes.apply(datetime, minutes).isAfter(LocalDateTime.now(clockProvider.getClock()));

        epocOfDaysBefore = days -> now.get() - TimeUnit.DAYS.toMillis(days);

        getHourInTimeZone = timezone -> {
            LocalDateTime localDate = Instant.ofEpochMilli(now.get()).atZone(ZoneId.of(timezone)).toLocalDateTime();
            return dateTimeFormatter.format(localDate);
        };

        nowIsOverOf = (datetime, minutes) -> now.get() > Instant.ofEpochMilli(datetime).plus(minutes, ChronoUnit.MINUTES).toEpochMilli();
        toIsoFormat = (datetime, timezone) -> {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ISO_DATE_PATTERN);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone(timezone));
            return simpleDateFormat.format(new Date(datetime));
        };
    }


}
