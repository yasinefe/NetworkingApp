/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.rbwm.ted.appointment.api.ProductCategoryServiceApi;
import com.rbwm.ted.appointment.model.Appointment.ProductCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import static com.rbwm.ted.appointment.Headers.COUNTRY_CODE_HEADER;

/**
 * Created by 43578876 on 20/02/2017.
 */
@RestController
public class ProductCategoryController {

    private final ProductCategoryServiceApi productCategoryServiceApi;

    @Autowired
    public ProductCategoryController(ProductCategoryServiceApi productCategoryServiceApi) {
        this.productCategoryServiceApi = productCategoryServiceApi;
    }

    @RequestMapping(value = "/productCategories", method = RequestMethod.GET)
    public CompletableFuture<List<ProductCategory>> getProductCategories(
            @RequestHeader(value = COUNTRY_CODE_HEADER, required = false, defaultValue = "GBR") String countryCode) {
        return productCategoryServiceApi.findByCountry(countryCode).collectList().toFuture();
    }
}
