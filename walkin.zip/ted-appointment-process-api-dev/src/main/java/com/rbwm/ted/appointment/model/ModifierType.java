package com.rbwm.ted.appointment.model;

/**
 * Created by 44052007 on 16/03/2018.
 */
public enum ModifierType {

    USER, SYSTEM

}
