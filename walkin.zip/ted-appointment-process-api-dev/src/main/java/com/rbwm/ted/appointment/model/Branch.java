/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Created by 44027117 on 20/04/2017.
 */
public interface Branch {

    class Address {
        public final String addressLine1;
        public final String addressLine2;
        public final String city;
        public final String postcode;
        public final String county;
        public final String countryCode;

        @JsonCreator
        public Address(@JsonProperty("addressLine1") String addressLine1,
                       @JsonProperty("addressLine2") String addressLine2,
                       @JsonProperty("city") String city,
                       @JsonProperty("postcode") String postcode,
                       @JsonProperty("county") String county,
                       @JsonProperty("countryCode") String countryCode) {
            this.addressLine1 = addressLine1;
            this.addressLine2 = addressLine2;
            this.city = city;
            this.postcode = postcode;
            this.county = county;
            this.countryCode = countryCode;
        }
    }

    @Document
    class BranchDetails {
        
        public final String branchId;
        public final String cramerId;
        public final Double longitude;
        public final Double latitude;
        public final String timezone;
        public final String name;
        public final Address address;

        @JsonCreator
        public BranchDetails(@JsonProperty("branchId") String branchId,
                             @JsonProperty("cramerId") String cramerId,
                             @JsonProperty("longitude") Double longitude,
                             @JsonProperty("latitude") Double latitude,
                             @JsonProperty("timezone") String timezone,
                             @JsonProperty("name") String name,
                             @JsonProperty("address") Address address
        ) {
            this.branchId = branchId;
            this.cramerId = cramerId;
            this.longitude = longitude;
            this.latitude = latitude;
            this.timezone = timezone;
            this.name = name;
            this.address = address;
        }
    }

    @Document
    class LocationMacAddress{

        @Id
        public final String locationMacAddressId;
        public final String accessPointMacAddress;
        public final String locationCode;
        public final String locationDescription;
        public final String branchName;
        public final String countryCode;
        public final Long updated;

        @JsonCreator
        public LocationMacAddress(@JsonProperty("locationMacAddressId") String locationMacAddressId,
                                  @JsonProperty("accessPointMacAddress") String accessPointMacAddress,
                                  @JsonProperty("locationCode") String locationCode,
                                  @JsonProperty("locationDescription") String locationDescription,
                                  @JsonProperty("branchName") String branchName,
                                  @JsonProperty("countryCode") String countryCode,
                                  @JsonProperty("updated") Long updated) {
            this.locationMacAddressId = locationMacAddressId;
            this.accessPointMacAddress = accessPointMacAddress;
            this.locationCode = locationCode;
            this.locationDescription = locationDescription;
            this.branchName = branchName;
            this.countryCode = countryCode;
            this.updated = updated;
        }

    }
}