/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.model;

import com.rbwm.ted.appointment.model.Appointment.Employee;
import com.rbwm.ted.appointment.model.Appointment.Person;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * Created by 44052007 on 30/04/2018.
 */
@EqualsAndHashCode
@ToString
public class Meeting {

    public final MeetingStatus status;
    public final MeetingGroup group;
    public final String meetingId;
    public final String topicId;
    public final String topicName;
    public final String topicCategoryId;
    public final String topicCategoryName;
    public final String topicSubCategoryId;
    public final String topicSubCategoryName;
    public final Employee conductor;
    public final String bookedFor;
    public final String checkedInAt;
    public final String startedAt;
    public final String endedAt;
    public final Integer duration;
    public final Boolean isNew;
    public final Boolean isOverdue;
    public final Boolean isOverdueCritical;
    public final Boolean isOverrun;
    public final Boolean isOverrunCritical;
    public final Person attendee;
    public final String comments;
    public final Boolean proofOfId;
    public final String countryCode;
    public final ModifierType endedBy;
    public final String timezone;

    public Meeting(MeetingStatus status,
                   MeetingGroup group,
                   String meetingId,
                   String topicId,
                   String topicName,
                   String topicCategoryId,
                   String topicCategoryName,
                   String topicSubCategoryId,
                   String topicSubCategoryName,
                   Employee conductor,
                   String bookedFor,
                   String checkedInAt,
                   String startedAt,
                   String endedAt,
                   Integer duration,
                   Boolean isNew,
                   Boolean isOverdue,
                   Boolean isOverdueCritical,
                   Boolean isOverrun,
                   Boolean isOverrunCritical,
                   Person attendee,
                   String comments,
                   Boolean proofOfId,
                   String countryCode,
                   ModifierType endedBy,
                   String timezone) {
        this.status = status;
        this.group = group;
        this.meetingId = meetingId;
        this.topicId = topicId;
        this.topicName = topicName;
        this.topicCategoryId = topicCategoryId;
        this.topicCategoryName = topicCategoryName;
        this.topicSubCategoryId = topicSubCategoryId;
        this.topicSubCategoryName = topicSubCategoryName;
        this.conductor = conductor;
        this.bookedFor = bookedFor;
        this.checkedInAt = checkedInAt;
        this.startedAt = startedAt;
        this.endedAt = endedAt;
        this.duration = duration;
        this.isNew = isNew;
        this.isOverdue = isOverdue;
        this.isOverdueCritical = isOverdueCritical;
        this.isOverrun = isOverrun;
        this.isOverrunCritical = isOverrunCritical;
        this.attendee = attendee;
        this.comments = comments;
        this.proofOfId = proofOfId;
        this.countryCode = countryCode;
        this.endedBy = endedBy;
        this.timezone = timezone;
    }
}
