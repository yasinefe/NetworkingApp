/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.api.LocationServiceApi;
import com.rbwm.ted.appointment.helper.DateTimeHelper;
import com.rbwm.ted.appointment.location.GetLocationList;
import com.rbwm.ted.appointment.model.Branch.LocationMacAddress;
import com.rbwm.ted.appointment.repository.LocationMacAddressRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by 44052007 on 10/08/2017.
 */
@Service
public class LocationService implements LocationServiceApi {

    private static final Logger log = LoggerFactory.getLogger(LocationService.class);

    private final LocationMacAddressRepository locationMacAddressRepository;
    private final GetLocationList getLocationList;
    private final DateTimeHelper dateTimeHelper;

    @Autowired
    public LocationService(LocationMacAddressRepository locationMacAddressRepository, GetLocationList getLocationList, DateTimeHelper dateTimeHelper) {
        this.locationMacAddressRepository = locationMacAddressRepository;
        this.getLocationList = getLocationList;
        this.dateTimeHelper = dateTimeHelper;
    }

    public void updateLocations() {
        log.info("Scheduled location updater has started");
        List<Map<String, Object>> locations = getLocationList.getLocationList();
        log.info("All locations are retrieved (total: " + locations.size() + ") and mongo db is being updated");
        locations.forEach(location -> {
            LocationMacAddress locationMacAddress = new LocationMacAddress(null,
                    (String) location.get("macAddress"),
                    (String) location.get("deviceName"),
                    (String) location.get("fullLocation"),
                    (String) location.get("mapLocation"),
                    (String) location.get("countryCode"),
                    dateTimeHelper.now.get()
            );
            locationMacAddressRepository.update(locationMacAddress).block();
        });
        log.info("Scheduled location updater has done");
    }

}
