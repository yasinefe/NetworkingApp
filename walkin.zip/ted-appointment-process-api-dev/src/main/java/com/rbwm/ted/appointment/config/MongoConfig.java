/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.ReactiveMongoDatabaseFactory;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.SimpleReactiveMongoDatabaseFactory;

/**
 * Created by 43578876 on 21/02/2017.
 */
@Configuration
public class MongoConfig {

    @Value("${ted.walkin.mongo.hostname}")
    private String mongoHostname;

    @Value("${ted.walkin.mongo.port}")
    private String mongoPort;

    @Value("${ted.walkin.mongo.database}")
    private String mongoDb;

    @Value("${ted.walkin.mongo.collection.walkins}")
    private String walkInsCollection;

    @Value("${ted.walkin.mongo.collection.productCategories}")
    private String productCategoriesCollection;

    @Value("${ted.walkin.mongo.collection.branches}")
    private String branchesCollection;

    @Value("${ted.walkin.mongo.collection.locationMacAddress}")
    private String locationMacAddressCollection;

    @Value("${ted.walkin.mongo.userName}")
    private String userName;

    @Value("${ted.walkin.mongo.password}")
    private String password;

    @Value("${ted.walkin.mongo.apply.changeset}")
    private Boolean applyChangeSet;

    @Bean
    public MongoClient mongoClient() {
        return MongoClients.create(getConnectionUri());
    }

    public String getConnectionUri() {
        return "mongodb://" + userName + ":"  + password + "@" + mongoHostname + ":" + mongoPort + "/" + getDatabaseName();
    }

    public String getDatabaseName() {
        return mongoDb;
    }

    public Boolean getApplyChangeSet() {
        return applyChangeSet;
    }

    @Bean
    public ReactiveMongoDatabaseFactory reactiveMongoDbFactory(MongoClient mongoClient) {
        return new SimpleReactiveMongoDatabaseFactory(mongoClient, getDatabaseName());
    }

    @Bean
    public ReactiveMongoTemplate reactiveMongoTemplate(ReactiveMongoDatabaseFactory mongoDbFactory) {
        return new ReactiveMongoTemplate(mongoDbFactory);
    }

    public String getWalkInsCollection() {
        return walkInsCollection;
    }

    public String getProductCategoriesCollection() {
        return productCategoriesCollection;
    }

    public String getBranchesCollection() { return branchesCollection;}

    public String getLocationMacAddressCollection() {
        return locationMacAddressCollection;
    }
}
