/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.rbwm.ted.appointment.api.WalkInServiceApi;
import com.rbwm.ted.appointment.input.WalkInInput;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.model.Appointment.WalkInList;
import com.rbwm.ted.appointment.model.Appointment.WalkInStats;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Created by 43578876 on 20/02/2017.
 */
@RestController
public class WalkInController {

    private final WalkInServiceApi walkinServiceApi;

    @Autowired
    public WalkInController(WalkInServiceApi walkinServiceApi) {
        this.walkinServiceApi = walkinServiceApi;
    }

    @RequestMapping(value = "/walkins", method = RequestMethod.GET)
    public CompletableFuture<List<WalkIn>> getWalkIns(@RequestParam String branchId) {
        return walkinServiceApi.findByBranchId(branchId).collectList().toFuture();
    }

    @RequestMapping(value = "/walkins/list", method = RequestMethod.GET)
    public CompletableFuture<WalkInList> getWalkInList(@RequestParam String branchId) {
        return walkinServiceApi.getWalkinList(branchId).toFuture();
    }

    @RequestMapping(value = "/walkins/{appointmentId}", method = RequestMethod.GET)
    public CompletableFuture<WalkIn> getWalkIn(@PathVariable String appointmentId) {
        return walkinServiceApi.findById(appointmentId).toFuture();
    }

    @RequestMapping(value = "/walkins/statusCounts", method = RequestMethod.GET)
    public CompletableFuture<Map<String, Long>> getCounts(@RequestParam String branchId) {
        return walkinServiceApi.getStatusCounts(branchId).toFuture();
    }

    @RequestMapping(value = "/walkins/stats", method = RequestMethod.GET)
    public CompletableFuture<WalkInStats> getStats(@RequestParam String branchId) {
        return walkinServiceApi.getStats(branchId).toFuture();
    }

    @RequestMapping(path = "/walkins/{appointmentId}", method = RequestMethod.POST)
    public CompletableFuture<WalkIn> updateStatus(@PathVariable String appointmentId, @RequestBody AppointmentStatus status) {
        return walkinServiceApi.updateStatus(appointmentId, status).toFuture();
    }

    @RequestMapping(path = "/walkins", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public CompletableFuture<WalkIn> create(@RequestBody WalkInInput walkInInput) {
        return walkinServiceApi.insert(walkInInput).toFuture();
    }
}
