/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by 44027117 on 08/03/2017.
 */
public enum AppointmentStatus {
    CHECKED_IN("CHECKED_IN"),
    IN_MEETING("IN_MEETING", CHECKED_IN),
    CANCELLED("CANCELLED", CHECKED_IN),
    OVERDUE("OVERDUE", CHECKED_IN),
    COMPLETED("COMPLETED", IN_MEETING);

    private final String val;
    private AppointmentStatus previousStatus;

    AppointmentStatus(String val) {
        this(val, null);
    }
    AppointmentStatus(String val, AppointmentStatus previousStatus) {
        this.val = val;
        this.previousStatus = previousStatus;
    }

    public String getVal() {
        return val;
    }

    public AppointmentStatus getPreviousStatus() {
        return previousStatus;
    }

    @JsonCreator
    public static AppointmentStatus fromVal(@JsonProperty("appointmentStatus") String value) {
        return AppointmentStatus.valueOf(value);
    }

    @Override
    public String toString() {
        return val;
    }
}
