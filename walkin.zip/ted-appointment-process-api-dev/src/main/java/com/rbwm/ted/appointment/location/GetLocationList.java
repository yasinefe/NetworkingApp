/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.location;

import com.hsbc.rbwm.ted.rest.api.CRUDRest;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import com.rbwm.ted.appointment.config.LocationConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 44052007 on 19/06/2017.
 */
@Component
public class GetLocationList {

    private final CRUDRest crudRest;
    private final LocationConfiguration appointmentBookingConfiguration;
    private final ResponseHandler<List<Map<String,Object>>> responseHandler;
    private static final String FEATURE_PREFIX = "GET-LOCATION-LIST";

    @Autowired
    public GetLocationList(LocationConfiguration locationConfiguration,
                           @Qualifier("restResponseHandler") ResponseHandler responseHandler) {
        this.appointmentBookingConfiguration = locationConfiguration;
        this.responseHandler = responseHandler;

        crudRest = locationConfiguration.cramerPrimeApiCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public List<Map<String,Object>> getLocationList() {
        return responseHandler.extractBody(crudRest.doGet(getUri(), new HashMap<>()));
    }

    private String getUri() {
        return appointmentBookingConfiguration.getLocationsListUri();
    }
}
