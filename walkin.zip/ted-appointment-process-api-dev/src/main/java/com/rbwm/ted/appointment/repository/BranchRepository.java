/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.repository;

import com.rbwm.ted.appointment.config.MongoConfig;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.model.Branch.BranchDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.function.Function;

import static com.rbwm.ted.appointment.error.ErrorCode.BRANCH_NOT_FOUND_BRANCH_ID;
import static com.rbwm.ted.appointment.error.ErrorCode.BRANCH_NOT_FOUND_CRAMER_ID;

/**
 * Created by 43578876 on 20/04/2017.
 */
@Component
public class BranchRepository {

    private final String branchCollection;
    private final ReactiveMongoTemplate mongoTemplate;

    @Autowired
    public BranchRepository(ReactiveMongoTemplate mongoTemplate,
                            MongoConfig mongoConfig) {
        this.branchCollection = mongoConfig.getBranchesCollection();
        this.mongoTemplate = mongoTemplate;
    }

    public Flux<BranchDetails> findByCountryCode(String countryCode) {
        return mongoTemplate.find(Query.query(criteriaFindByCountryCode.apply(countryCode)), BranchDetails.class, branchCollection);
    }

    public Mono<BranchDetails> findByCramerId(Mono<String> cramerIdMono) {
        return cramerIdMono.then(cramerId -> mongoTemplate.findOne(
                Query.query(criteriaFindByCramerId.apply(cramerId)),
                BranchDetails.class,
                branchCollection)
                .otherwiseIfEmpty(notFound.apply(cramerId)));
    }

    public Mono<BranchDetails> findById(String branchId) {
        return mongoTemplate.findOne(
                Query.query(criteriaFindByBranchId.apply(branchId)),
                BranchDetails.class,
                branchCollection)
                .otherwiseIfEmpty(branchNotFound.apply(branchId));
    }

    private static final Function<String,Criteria> criteriaFindByCramerId = cramerId -> Criteria
            .where("cramerId").is(cramerId);

    private static final Function<String,Criteria> criteriaFindByCountryCode = countryCode -> Criteria
            .where("address.countryCode").is(countryCode);

    private static final Function<String,Criteria> criteriaFindByBranchId = branchId -> Criteria
            .where("branchId").is(branchId);

    private static final Function<String, Mono<BranchDetails>> notFound = cramerId ->
            Mono.error(new Exceptions.NotFoundException(BRANCH_NOT_FOUND_CRAMER_ID, cramerId));

    private static final Function<String, Mono<BranchDetails>> branchNotFound = branchId ->
            Mono.error(new Exceptions.NotFoundException(BRANCH_NOT_FOUND_BRANCH_ID, branchId));
}
