/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.audit;

import lombok.EqualsAndHashCode;

import java.util.Map;

/**
 * Created by 44027117 on 28/04/2017.
 */
@EqualsAndHashCode
public class AuditContext {

    public static final String ENTITY_TYPE_WALKIN = "WALKIN";
    public static final String OPERATION_WALKIN_CHANGE_STATUS = "WALKIN_STATUS_CHANGE";

    public final String countryCode;
    public final String branchId;
    public final String wifiMACAddress;
    public final String machineId;
    public final String staffId;
    public final Map<String, Object> variables;
    public final String entityId;
    public final String operationName;
    public final String type;
    public final Boolean error = Boolean.FALSE;


    public AuditContext(String countryCode, String branchId, String wifiMACAddress, String machineId, String staffId,
                        Map<String, Object> variables, String entityId, String operationName, String type) {
        this.countryCode = countryCode;
        this.branchId = branchId;
        this.wifiMACAddress = wifiMACAddress;
        this.machineId = machineId;
        this.staffId = staffId;
        this.variables = variables;
        this.entityId = entityId;
        this.operationName = operationName;
        this.type = type;
    }
}
