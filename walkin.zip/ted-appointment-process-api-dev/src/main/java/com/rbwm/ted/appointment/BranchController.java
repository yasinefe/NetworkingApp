/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.rbwm.ted.appointment.api.BranchServiceApi;
import com.rbwm.ted.appointment.model.Branch.BranchDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Created by 44027117 on 20/04/2017.
 */
@RestController
public class BranchController {

    private final BranchServiceApi branchService;

    @Autowired
    public BranchController(BranchServiceApi branchService) {
        this.branchService = branchService;
    }

    @RequestMapping(value = "/branches/macAddress/{mac}", method = RequestMethod.GET)
    public CompletableFuture<BranchDetails> getBranchByMacAddress(@PathVariable String mac) {
        return branchService.findBranchByMacAddress(mac).toFuture();
    }

    @RequestMapping(value = "/branches/branchId/{branchId}", method = RequestMethod.GET)
    public CompletableFuture<BranchDetails> getBranchByBranchId(@PathVariable String branchId) {
        return branchService.findBranchByBranchId(branchId).toFuture();
    }

    @RequestMapping(value = "/branches/countryCode/{countryCode}", method = RequestMethod.GET)
    public CompletableFuture<List<BranchDetails>> getBranches(@PathVariable String countryCode,
                                                              @RequestParam(value = "search", required = false) String search) {
        return branchService.findByCountryCode(countryCode, search).collectList().toFuture();
    }
}
