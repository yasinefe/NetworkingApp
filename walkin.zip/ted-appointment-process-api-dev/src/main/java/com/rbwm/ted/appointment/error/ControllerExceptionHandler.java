/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import com.rbwm.ted.appointment.error.Exceptions.NoConnectionException;
import com.rbwm.ted.appointment.error.Exceptions.ServerException;
import com.rbwm.ted.appointment.error.Exceptions.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.web.DefaultErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.RequestAttributes;

import java.util.HashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.error.ErrorCode.NO_CONNECTION_TO_MONGO_DB;
import static com.rbwm.ted.appointment.error.ErrorCode.UNEXPECTED_ERROR;

/**
 * Created by 44052007 on 06/04/2017.
 */
@ControllerAdvice
@Configuration
public class ControllerExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ControllerExceptionHandler.class);

    @ExceptionHandler(ServerException.class)
    public ResponseEntity serverException(ServerException exception){
        log.error(exception.getMessage());
        return ResponseEntity.status(exception.getHttpStatus()).body(createError(exception.getError()));
    }

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity serverException(DataAccessException exception){
        NoConnectionException mongoDbException = new NoConnectionException(NO_CONNECTION_TO_MONGO_DB, exception.getMessage());
        log.error(mongoDbException.getMessage(), exception);
        return serverException(mongoDbException);
    }

    @ExceptionHandler(Throwable.class)
    public ResponseEntity throwable(Throwable exception){
        UnexpectedException unexpectedException = new UnexpectedException(UNEXPECTED_ERROR, exception.getMessage());
        log.error(unexpectedException.getMessage(), exception);
        return serverException(unexpectedException);
    }

    @Bean
    public ErrorAttributes errorAttributes() {
        return new DefaultErrorAttributes() {
            @Override
            public Map<String, Object> getErrorAttributes(RequestAttributes requestAttributes, boolean includeStackTrace) {
                Map<String, Object> errorAttributes = super.getErrorAttributes(requestAttributes, includeStackTrace);
                UnexpectedException unexpectedException = new UnexpectedException(UNEXPECTED_ERROR, (String)errorAttributes.get("message"));
                log.error(unexpectedException.getMessage());
                return createError(unexpectedException.getError());
            }
        };
    }

    private Map<String, Object> createError(final Object error) {
        Map<String, Object> newErrorAttributes = new HashMap<>();
        newErrorAttributes.put("error", error);
        return newErrorAttributes;
    }

}
