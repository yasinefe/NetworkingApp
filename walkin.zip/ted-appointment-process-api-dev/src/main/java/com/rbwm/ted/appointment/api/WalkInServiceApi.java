/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.api;

import com.rbwm.ted.appointment.input.WalkInInput;
import com.rbwm.ted.appointment.model.Appointment.WalkIn;
import com.rbwm.ted.appointment.model.Appointment.WalkInList;
import com.rbwm.ted.appointment.model.Appointment.WalkInStats;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * Created by 43578876 on 20/02/2017.
 */
public interface WalkInServiceApi {

    Flux<WalkIn> findByBranchId(String branchId);

    Mono<WalkInList> getWalkinList(String branchId);

    /**
     * Returns a @Mono stats of WalkIns for today. yesterday and the specific locationId
     * @param branchId
     * @return
     */
    Mono<WalkInStats> getStats(String branchId);

    Mono<WalkIn> updateStatus(String appointmentId, AppointmentStatus appointmentStatus);

    /**
     * Returns a @Mono Map of counts for each status filtering by today, specific location and not ended.
     * Also excluding cancelled.
     * @param branchId
     * @return
     */
    Mono<Map<String, Long>> getStatusCounts(String branchId);

    Mono<WalkIn> insert(WalkInInput walkInInput);

    Mono<WalkIn> findById(String appointmentId);

    void endWalkIns();
}
