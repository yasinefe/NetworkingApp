/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import com.rbwm.ted.appointment.api.LocationServiceApi;
import com.rbwm.ted.appointment.api.WalkInServiceApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.CronTask;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

/**
 * Created by 44052007 on 10/08/2017.
 */
@Component
public class ScheduleConfig implements SchedulingConfigurer {

    private final LocationServiceApi locationServiceApi;
    private final WalkInServiceApi walkInServiceApi;

    @Value("${ted.locations.update.cron.expression}")
    private String locationUpdateCronExpression;

    @Value("${ted.walkin.end.batch.cron.expression}")
    private String walkInEndBatchCronExpression;

    @Autowired
    public ScheduleConfig(LocationServiceApi locationServiceApi, WalkInServiceApi  walkInServiceApi) {
        this.locationServiceApi = locationServiceApi;
        this.walkInServiceApi = walkInServiceApi;
    }

    @Override
    public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
        scheduledTaskRegistrar.addCronTask(new CronTask(locationServiceApi::updateLocations, locationUpdateCronExpression));
        scheduledTaskRegistrar.addCronTask(new CronTask(walkInServiceApi::endWalkIns, walkInEndBatchCronExpression));
    }
}
