/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.service;

import com.rbwm.ted.appointment.api.BranchServiceApi;
import com.rbwm.ted.appointment.model.Branch.BranchDetails;
import com.rbwm.ted.appointment.model.Branch.LocationMacAddress;
import com.rbwm.ted.appointment.repository.BranchRepository;
import com.rbwm.ted.appointment.repository.LocationMacAddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.function.Function;
import java.util.function.Predicate;

import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * Created by 43578876 on 20/04/2017.
 */
@Component
public class BranchService implements BranchServiceApi {

    private final BranchRepository branchRepository;
    private final LocationMacAddressRepository locationMacAddressRepository;

    @Autowired
    public BranchService(BranchRepository branchRepository,
                         LocationMacAddressRepository locationMacAddressRepository) {
        this.branchRepository = branchRepository;
        this.locationMacAddressRepository = locationMacAddressRepository;
    }

    @Override
    public Flux<BranchDetails> findByCountryCode(String countryCode, String keyword) {
        Predicate<BranchDetails> filterByKeyword = branchDetails -> isEmpty(keyword)
                || branchDetails.branchId.toLowerCase().startsWith(keyword.toLowerCase())
                || branchDetails.name.toLowerCase().startsWith(keyword.toLowerCase())
                || branchDetails.address.postcode.toLowerCase().startsWith(keyword.toLowerCase());

        return branchRepository.findByCountryCode(countryCode).filter(filterByKeyword);
    }

    @Override
    public Mono<BranchDetails> findBranchByMacAddress(String macAddress) {
        Mono<LocationMacAddress> location = locationMacAddressRepository.findByMacAddress(macAddress);
        return  branchRepository.findByCramerId(location.map(extractCramerId));
    }

    @Override
    public Mono<BranchDetails> findBranchByBranchId(String branchId) {
        return branchRepository.findById(branchId);
    }
    /*
     * CramerId appears to be the first 8 characters of the locationCode stored against the mac address
     */
    static Function<LocationMacAddress,String> extractCramerId = location ->
            location.locationCode.substring(0,8);
}
