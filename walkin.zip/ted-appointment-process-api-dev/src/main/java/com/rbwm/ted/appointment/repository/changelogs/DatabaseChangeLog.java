/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.repository.changelogs;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.google.common.io.Files;
import com.mongodb.client.result.UpdateResult;
import com.rbwm.ted.appointment.model.Appointment.ProductCategory;
import com.rbwm.ted.appointment.model.Branch;
import com.rbwm.ted.appointment.model.Branch.BranchDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * Created by 44052007 on 30/03/2017.
 */
@ChangeLog(order = "001")
public class DatabaseChangeLog {

    private static final Logger log = LoggerFactory.getLogger(DatabaseChangeLog.class);

    private static MongoTemplate mongoTemplate;
    private static String productCategoriesCollectionName;
    private static ObjectMapper objectMapper;
    private static String branchesCollectionName;
    private static String locationMacAddressesCollectionName;
    private static String walkInsCollectionName;

    public static void setMongoTemplate(MongoTemplate mongoTemplate) {
        DatabaseChangeLog.mongoTemplate = mongoTemplate;
    }

    public static void setProductCategoriesCollectionName(String productCategoriesCollectionName) {
        DatabaseChangeLog.productCategoriesCollectionName = productCategoriesCollectionName;
    }

    public static void setObjectMapper(ObjectMapper objectMapper) {
        DatabaseChangeLog.objectMapper = objectMapper;
    }

    public static void setBranchesCollectionName(String branchesCollectionName) {
        DatabaseChangeLog.branchesCollectionName = branchesCollectionName;
    }

    public static void setLocationMacAddressesCollectionName(String locationMacAddressesCollectionName) {
        DatabaseChangeLog.locationMacAddressesCollectionName = locationMacAddressesCollectionName;
    }

    public static void setWalkInsCollectionName(String walkInsCollectionName) {
        DatabaseChangeLog.walkInsCollectionName = walkInsCollectionName;
    }

    @ChangeSet(order = "001", id = "initialProductCategories", author = "appointment-process-api")
    public void initialProductCategories() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        readJSONAndInsert("data/productCategories.json", ProductCategory.class, productCategoriesCollectionName);
    }

    @ChangeSet(order = "002", id = "initialBranches", author = "appointment-process-api")
    public void initialBranches() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        readJSONAndInsert("data/branches.json", BranchDetails.class, branchesCollectionName);
    }

    @ChangeSet(order = "003", id = "pilotLocationMacAddresses", author = "appointment-process-api")
    public void initialLocationMacAddresses() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        readJSONAndInsert("data/macAddressesPilot.json", Branch.LocationMacAddress.class, locationMacAddressesCollectionName);
    }

    @ChangeSet(order = "004", id = "updateBranchWithCramerIdV1", author = "appointment-process-api")
    public void updateBranchWithCramerIdV1() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        List<String> lines = Files.readLines(new File(DatabaseChangeLog.class.getClassLoader().getResource("data/branchCramerIdMap-v1.csv").getPath()), Charset.forName("UTF-8"));
        ExecutorService executorService = Executors.newFixedThreadPool(10);

        lines.forEach(line -> executorService.execute(() -> {
            String[] splittedLine = line.split(",");
            UpdateResult updateResult = mongoTemplate.updateFirst(Query.query(Criteria.where("branchId").is(splittedLine[1])),
                    Update.update("cramerId", splittedLine[0]),
                    branchesCollectionName);
            if (updateResult.getModifiedCount() == 0) {
                log.warn(splittedLine[1] + " branch id is not found in db");
            }
        }));

        executorService.shutdown();
    }

    @ChangeSet(order = "005", id = "productCategoriesV2", author = "appointment-process-api")
    public void productCategoriesV2() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        mongoTemplate.remove(new Query(), productCategoriesCollectionName);
        readJSONAndInsert("data/productCategoriesV2.json", ProductCategory.class, productCategoriesCollectionName);
    }

    @ChangeSet(order = "006", id = "updateBranchesWithCountryCodeGBR", author = "appointment-process-api")
    public void updateBranchesWithCountryCodeGBR() throws URISyntaxException, IOException {
        mongoTemplate.updateMulti(null, Update.update("address.countryCode", "GBR"), branchesCollectionName);
    }

    @ChangeSet(order = "007", id = "initialBranchesUSAForPilot", author = "appointment-process-api")
    public void initialBranchesUSAForPilot() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        readJSONAndInsert("data/branchesUSAforPilot.json", BranchDetails.class, branchesCollectionName);
    }

    @ChangeSet(order = "008", id = "updateLocationMacAddressForGBR", author = "appointment-process-api")
    public void updateLocationMacAddressForGBR() throws URISyntaxException, IOException {
        mongoTemplate.updateMulti(null, Update.update("countryCode", "GBR"), locationMacAddressesCollectionName);
    }

    @ChangeSet(order = "009", id = "productCategoriesV3", author = "appointment-process-api")
    public void productCategoriesV3() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        mongoTemplate.remove(new Query(), productCategoriesCollectionName);
        readJSONAndInsert("data/productCategoriesV3.json", ProductCategory.class, productCategoriesCollectionName);
    }

    @ChangeSet(order = "010", id = "productCategories-GBR-V4", author = "appointment-process-api")
    public void productCategoriesV4() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        mongoTemplate.remove(new Query(), productCategoriesCollectionName);
        readJSONAndInsert("data/productCategories-GBR-V4.json", ProductCategory.class, productCategoriesCollectionName);
    }

    @ChangeSet(order = "011", id = "productCategories-USA-V5", author = "appointment-process-api")
    public void productCategoriesV5() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        readJSONAndInsert("data/productCategories-USA-V5.json", ProductCategory.class, productCategoriesCollectionName);
    }

    @ChangeSet(order = "012", id = "branchesUSAforPilotV2", author = "appointment-process-api")
    public void updateBranchesUSAforPilotV2() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        mongoTemplate.remove(Query.query(Criteria.where("address.countryCode").is("USA")), branchesCollectionName);
        readJSONAndInsert("data/branchesUSAforPilotV2.json", BranchDetails.class, branchesCollectionName);
    }

    @ChangeSet(order = "013", id = "setTimezoneAndCountryCodeForWalkIns", author = "appointment-process-api")
    public void setTimezoneAndCountryCodeForWalkIns() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        setTimeZoneAndCountryCode("GBR", "Europe/London");
        setTimeZoneAndCountryCode("USA", "America/Los_Angeles");
    }

    @ChangeSet(order = "014", id = "productCategories-GBR-V5", author = "appointment-process-api")
    public void productCategoriesGBRV5() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        mongoTemplate.remove(new Query(Criteria.where("countryCode").is("GBR")), productCategoriesCollectionName);
        readJSONAndInsert("data/productCategories-GBR-V5.json", ProductCategory.class, productCategoriesCollectionName);
    }

    @ChangeSet(order = "015", id = "productCategories-USA-V6", author = "appointment-process-api")
    public void productCategoriesUSAV6() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        mongoTemplate.remove(new Query(Criteria.where("countryCode").is("USA")), productCategoriesCollectionName);
        readJSONAndInsert("data/productCategories-USA-V6.json", ProductCategory.class, productCategoriesCollectionName);
    }

    @ChangeSet(order = "016", id = "branchesUSAforPilotV3", author = "appointment-process-api")
    public void updateBranchesUSAforPilotV3() throws URISyntaxException, IOException, ExecutionException, InterruptedException {
        mongoTemplate.remove(Query.query(Criteria.where("address.countryCode").is("USA")), branchesCollectionName);
        readJSONAndInsert("data/branchesUSAforPilotV3.json", BranchDetails.class, branchesCollectionName);
    }

    private void setTimeZoneAndCountryCode(String countryCode, String timezone) throws ExecutionException, InterruptedException {
        List<BranchDetails> branches = mongoTemplate.find(Query.query(Criteria.where("address.countryCode").is(countryCode)),
                BranchDetails.class, branchesCollectionName);

        // One of the branch has 402225N which is not number
        List<Integer> locationIds = branches.stream().map(branchDetails -> {
            try {
                return Integer.valueOf(branchDetails.branchId);
            } catch (NumberFormatException e) {
                return 0;
            }
        }).collect(Collectors.toList());

        mongoTemplate.updateMulti(
                Query.query(Criteria.where("locationId").in(locationIds)),
                Update.update("timezone", timezone).set("countryCode", countryCode),
                walkInsCollectionName);
    }

    private <T> void readJSONAndInsert(String fileName, Class<T> clazz, String collectionName)
            throws IOException, URISyntaxException {
        InputStream in = DatabaseChangeLog.class.getClassLoader().getResourceAsStream(fileName);
        List<T> objects = objectMapper.readValue(in, new TypeReference<List<T>>() {});
        mongoTemplate.insert(objects, collectionName);
    }

}
