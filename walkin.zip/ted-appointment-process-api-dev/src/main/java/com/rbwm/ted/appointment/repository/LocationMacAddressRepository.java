/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.repository;

import com.mongodb.client.result.UpdateResult;
import com.rbwm.ted.appointment.config.MongoConfig;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.model.Branch.LocationMacAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.function.Function;

import static com.rbwm.ted.appointment.error.ErrorCode.MAC_ADDRESS_NOT_FOUND;

/**
 * Created by 43578876 on 20/04/2017.
 */
@Component
public class LocationMacAddressRepository {

    private final String locationMacAddressCollection;
    private final ReactiveMongoTemplate mongoTemplate;

    @Autowired
    public LocationMacAddressRepository(ReactiveMongoTemplate mongoTemplate,
                                        MongoConfig mongoConfig) {
        this.mongoTemplate = mongoTemplate;
        this.locationMacAddressCollection = mongoConfig.getLocationMacAddressCollection();
    }

    public Mono<LocationMacAddress> findByMacAddress(String macAddress) {
        return mongoTemplate.findOne(
                Query.query(findMacAddress.apply(macAddress)),
                LocationMacAddress.class,
                locationMacAddressCollection)
                .otherwiseIfEmpty(notFound.apply(macAddress));
    }

    public Mono<UpdateResult> update(LocationMacAddress location) {
        Update update = Update.update("accessPointMacAddress", location.accessPointMacAddress)
                .set("locationDescription", location.locationDescription)
                .set("branchName", location.branchName)
                .set("countryCode", location.countryCode)
                .set("updated", location.updated);
        return mongoTemplate.upsert(Query.query(findLocationCode.apply(location.locationCode)),
                update,
                LocationMacAddress.class,
                locationMacAddressCollection);
    }

    private static final Function<String,Criteria> findLocationCode = locationCode -> Criteria
            .where("locationCode").is(locationCode);

    private static final Function<String,Criteria> findMacAddress = mac -> Criteria
            .where("accessPointMacAddress").is(mac);

    private static final Function<String, Mono<LocationMacAddress>> notFound = macAddress ->
            Mono.error(new Exceptions.NotFoundException(MAC_ADDRESS_NOT_FOUND, macAddress));

}
