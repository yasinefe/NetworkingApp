/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import com.hsbc.rbwm.ted.rest.api.CRUDRestBuilder;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.hsbc.rbwm.ted.rest.http.HttpErrorHandler;
import com.hsbc.rbwm.ted.rest.http.HttpErrorResponseBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * Created by 44052007 on 20/06/2017.
 */
@Configuration
public class LocationConfiguration {

    public static final String APPLICATION_PREFIX = "APA";

    @Value("${ted.locations.hostname}")
    private String locationsHostname;

    @Value("${ted.locations.list.uri}")
    private String locationsListUri;

    @Autowired
    @Qualifier(value = "restAsyncClientRestTemplate")
    private AsyncClientRestTemplate asyncClientRestTemplate;

    public String getLocationsListUri() {
        return locationsListUri;
    }

    public CRUDRestBuilder cramerPrimeApiCRUDRestBuilder(String featurePrefix) {
        ErrorResponse errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix(APPLICATION_PREFIX)
                        .withFeatureErrorCodePrefix(featurePrefix)
                        .build();

        return new CRUDRestBuilder()
                .withClientRestTemplate(asyncClientRestTemplate)
                .withErrorHandler(new HttpErrorHandler(errorsResponse))
                .withHostname(locationsHostname);
    }

}
