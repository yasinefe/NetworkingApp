/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Created by 44052007 on 03/04/2017.
 */
@Configuration
public class WalkInConfig {

    @Value("${ted.walkin.overdue.offset}")
    private Integer overdueOffset;

    @Value("${ted.walkin.time.waiting}")
    private Integer walkInWaitingTime;

    @Value("${ted.walkin.end.after}")
    private String walkInEndAfter;

    @Value("${ted.walkin.new.offset}")
    private Integer newOffset;

    @Value("${ted.walkin.critical.overdue.offset}")
    private Integer criticalOverDueOffset;

    @Value("${ted.walkin.critical.overrun.offset}")
    private Integer criticalOverRunOffset;

    public Integer getOverdueOffset() {
        return overdueOffset;
    }

    public Integer getWalkInWaitingTime() {return walkInWaitingTime;}

    public String getWalkInEndAfter() {
        return walkInEndAfter;
    }

    public Integer getNewOffset() {
        return newOffset;
    }

    public Integer getCriticalOverDueOffset() {
        return criticalOverDueOffset;
    }

    public Integer getCriticalOverRunOffset() {
        return criticalOverRunOffset;
    }
}
