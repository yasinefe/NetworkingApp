/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.ToLongBiFunction;

import static java.util.stream.Collectors.averagingLong;

/**
 * Created by 43578876 on 21/02/2017.
 */
public interface Appointment {

    @EqualsAndHashCode
    @ToString
    class Person {
        public final String firstName;
        public final String lastName;
        public final String email;
        public final String phoneNumber;
        public final String mobileNumber;
        public final String gender;

        @JsonCreator
        public Person(@JsonProperty("firstName") final String firstName,
                      @JsonProperty("lastName") final String lastName,
                      @JsonProperty("email") final String email,
                      @JsonProperty("phoneNumber") final String phoneNumber,
                      @JsonProperty("mobileNumber") final String mobileNumber,
                      @JsonProperty("gender") final String gender) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.phoneNumber = phoneNumber;
            this.mobileNumber = mobileNumber;
            this.gender = gender;
        }
    }

    @EqualsAndHashCode
    @ToString
    class Employee {
        public final String employeeId;
        public final String fullName;

        @JsonCreator
        public Employee(@JsonProperty("employeeId") String employeeId,
                        @JsonProperty("fullName") String fullName) {
            this.employeeId = employeeId;
            this.fullName = fullName;
        }
    }

    @Document
    @EqualsAndHashCode
    class WalkIn {
        @Id
        public final String appointmentId;
        public final AppointmentStatus appointmentStatus;
        public final Long dateTime;
        public final Integer duration;
        public final Integer overdueOffset;
        public final String branchId;
        public final String topicId;
        public final String topicCategoryId;
        public final String topicSubCategoryId;
        public final Person attendee;
        public final Employee conductor;
        public final String comments;
        public final Boolean proofOfId;
        public final Long created;
        public final Long updated;
        public final Long startedAt;
        public final String timezone;
        public final String countryCode;
        public final Long endedAt;
        public final ModifierType endedBy;

        @JsonCreator
        public WalkIn(@JsonProperty("appointmentId") final String appointmentId,
                      @JsonProperty("appointmentStatus") final AppointmentStatus appointmentStatus,
                      @JsonProperty("duration") final Integer duration,
                      @JsonProperty("overdueOffset") final Integer overdueOffset,
                      @JsonProperty("branchId") final String branchId,
                      @JsonProperty("topicId") final String topicId,
                      @JsonProperty("topicCategoryId") final String topicCategoryId,
                      @JsonProperty("topicSubCategoryId") final String topicSubCategoryId,
                      @JsonProperty("comments") final String comments,
                      @JsonProperty("proofOfId") final Boolean proofOfId,
                      @JsonProperty("attendee") final Person attendee,
                      @JsonProperty("conductor") final Employee conductor,
                      @JsonProperty("created") final Long created,
                      @JsonProperty("dateTime") final Long dateTime,
                      @JsonProperty("updated") final Long updated,
                      @JsonProperty("startedAt") final Long startedAt,
                      @JsonProperty("timezone") final String timezone,
                      @JsonProperty("countryCode") final String countryCode,
                      @JsonProperty("endedAt") final Long endedAt,
                      @JsonProperty("endedBy") final ModifierType endedBy
                      ) {
            this.appointmentId = appointmentId;
            this.appointmentStatus = appointmentStatus;
            this.dateTime = dateTime;
            this.duration = duration;
            this.overdueOffset = overdueOffset;
            this.branchId = branchId;
            this.topicId = topicId;
            this.topicCategoryId = topicCategoryId;
            this.topicSubCategoryId = topicSubCategoryId;
            this.attendee = attendee;
            this.conductor= conductor;
            this.comments = comments;
            this.proofOfId = proofOfId;
            this.created = created;
            this.updated = updated;
            this.startedAt = startedAt;
            this.timezone = timezone;
            this.countryCode = countryCode;
            this.endedAt = endedAt;
            this.endedBy = endedBy;
        }

    }

    class WalkInList {
        public final List<WalkIn> walkins;
        public final Map<String, Long> statusCounts;

        public WalkInList(List<WalkIn> walkins, Map<String, Long> statusCounts) {
            this.walkins = walkins;
            this.statusCounts = statusCounts;
        }
    }

    class WalkInStats {
        public final Integer total;
        public final Integer averageWaitingTime;
        public final Integer averageWaitingTimeLastBusinessDay;

        public final static Function<Double, Integer> toMinute = millis -> (int) Math.round(millis / TimeUnit.MINUTES.toMillis(1));

        public WalkInStats(List<WalkIn> walkIns, List<WalkIn> yesterdayWalkIns, Long now) {
            this.total = walkIns.size();
            averageWaitingTime = toMinute.apply(averageWaitingTimeFunction.apply(walkIns, now));
            averageWaitingTimeLastBusinessDay = toMinute.apply(averageWaitingTimeFunction.apply(yesterdayWalkIns, now));
        }

        private static ToLongBiFunction<WalkIn, Long> waitingTime = (walkIn, now) -> {
            if (walkIn.startedAt != null && walkIn.startedAt > walkIn.created) {
                return walkIn.startedAt - walkIn.created;
            } else {
                return now - walkIn.created;
            }
        };

        private static BiFunction<List<WalkIn>, Long, Double> averageWaitingTimeFunction = (walkIns, now) -> walkIns.stream()
                .collect(averagingLong(walkIn -> waitingTime.applyAsLong(walkIn, now)));
    }

    @Document
    class ProductCategory {

        public final String name;
        public final String countryCode;
        public final List<ProductCategory> productCategories;

        @JsonCreator
        public ProductCategory(@JsonProperty("name") final String name,
                               @JsonProperty("countryCode") final String countryCode,
                               @JsonProperty("productCategories") List<ProductCategory> productCategories) {
            this.name = name;
            this.countryCode = countryCode;
            this.productCategories = productCategories;
        }
    }
}
