/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import io.restassured.RestAssured._
import org.apache.http.HttpStatus
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers._
import scala.util.parsing.json.JSON

class WalkInListIT extends Base {

  test("Retrieve walk-ins by location") {

    val expectedResponseString =
      """
        |[
        |  {
        |    "appointmentId": "58ecbce7c3c5b73c945c2665",
        |    "appointmentStatus": "CHECKED_IN",
        |    "duration": 15,
        |    "overdueOffset": 10,
        |    "locationId": 400106,
        |    "topicId": "First",
        |    "topicCategoryId": "Second",
        |    "topicSubCategoryId": "Third",
        |    "comments": "Nothing to see here, move along...",
        |    "proofOfId": false,
        |    "attendee": {
        |      "firstName": "Sammy",
        |      "lastName": "Charles",
        |      "email": "sammy.charles@email.com",
        |      "phoneNumber": "07777777777",
        |      "mobileNumber": "02000000000",
        |      "gender": "FEMALE"
        |    },
        |    "conductor": {
        |      "employeeId": "44443232",
        |      "fullName": "Ms Edna Nashville"
        |    },
        |    "created": 1491909863179,
        |    "dateTime": 1491909863182,
        |    "updated": 1491909863182,
        |    "startedAt": null
        |  },
        |  {
        |    "appointmentId": "58ecbd09c3c5b73c9ef96c4e",
        |    "appointmentStatus": "CHECKED_IN",
        |    "duration": 15,
        |    "overdueOffset": 10,
        |    "locationId": 400106,
        |    "topicId": "First",
        |    "topicCategoryId": "Second",
        |    "topicSubCategoryId": "Third",
        |    "comments": "Nothing to see here, move along...",
        |    "proofOfId": false,
        |    "attendee": {
        |      "firstName": "Sammy",
        |      "lastName": "Charles",
        |      "email": "sammy.charles@email.com",
        |      "phoneNumber": "07777777777",
        |      "mobileNumber": "02000000000",
        |      "gender": "FEMALE"
        |    },
        |    "conductor": {
        |      "employeeId": "44443232",
        |      "fullName": "Ms Edna Nashville"
        |    },
        |    "created": 1491909897464,
        |    "dateTime": 1491909897467,
        |    "updated": 1491909897467,
        |    "startedAt": null
        |  },
        |  {
        |    "appointmentId": "58ecc0b2c3c5b743e58a5a68",
        |    "appointmentStatus": "CHECKED_IN",
        |    "duration": 15,
        |    "overdueOffset": 10,
        |    "locationId": 400106,
        |    "topicId": "First",
        |    "topicCategoryId": "Second",
        |    "topicSubCategoryId": "Third",
        |    "comments": "Nothing to see here, move along...",
        |    "proofOfId": false,
        |    "attendee": {
        |      "firstName": "Sammy",
        |      "lastName": "Charles",
        |      "email": "sammy.charles@email.com",
        |      "phoneNumber": "07777777777",
        |      "mobileNumber": "02000000000",
        |      "gender": "FEMALE"
        |    },
        |    "conductor": {
        |      "employeeId": "44443232",
        |      "fullName": "Ms Edna Nashville"
        |    },
        |    "created": 1491910834496,
        |    "dateTime": 1491910834498,
        |    "updated": 1491910834498,
        |    "startedAt": null
        |  },
        |  {
        |    "appointmentId": "58ecd587c3c5b74afd8f5e9b",
        |    "appointmentStatus": "CHECKED_IN",
        |    "duration": 15,
        |    "overdueOffset": 10,
        |    "locationId": 400106,
        |    "topicId": "First",
        |    "topicCategoryId": "Second",
        |    "topicSubCategoryId": "Third",
        |    "comments": "Nothing to see here, move along...",
        |    "proofOfId": false,
        |    "attendee": {
        |      "firstName": "Sammy",
        |      "lastName": "Charles",
        |      "email": "sammy.charles@email.com",
        |      "phoneNumber": "07777777777",
        |      "mobileNumber": "02000000000",
        |      "gender": "FEMALE"
        |    },
        |    "conductor": {
        |      "employeeId": "44443232",
        |      "fullName": "Ms Edna Nashville"
        |    },
        |    "created": 1491916167032,
        |    "dateTime": 1491916167035,
        |    "updated": 1491916167035,
        |    "startedAt": null
        |  },
        |  {
        |    "appointmentId": "58ecd649c3c5b74b2f928a35",
        |    "appointmentStatus": "CHECKED_IN",
        |    "duration": 15,
        |    "overdueOffset": 10,
        |    "locationId": 400106,
        |    "topicId": "First",
        |    "topicCategoryId": "Second",
        |    "topicSubCategoryId": "Third",
        |    "comments": "Nothing to see here, move along...",
        |    "proofOfId": false,
        |    "attendee": {
        |      "firstName": "Sammy",
        |      "lastName": "Charles",
        |      "email": "sammy.charles@email.com",
        |      "phoneNumber": "07777777777",
        |      "mobileNumber": "02000000000",
        |      "gender": "FEMALE"
        |    },
        |    "conductor": {
        |      "employeeId": "44443232",
        |      "fullName": "Ms Edna Nashville"
        |    },
        |    "created": 1491916361462,
        |    "dateTime": 1491916361465,
        |    "updated": 1491916361465,
        |    "startedAt": null
        |  }
        |]
      """.stripMargin

    val locationId = "400106"
    val actualResponseObject =
      given
        .queryParam("locationId",locationId).
      when
        .get("/walkins").
      then
        .extract.response

    val actualResponse = JSON.parseFull(actualResponseObject.body.asString)
    val expectedResponse = JSON.parseFull(expectedResponseString)
    assertThat(actualResponseObject.statusCode, equalTo(HttpStatus.SC_OK))
    assertThat(actualResponse, equalTo(expectedResponse))
  }

}