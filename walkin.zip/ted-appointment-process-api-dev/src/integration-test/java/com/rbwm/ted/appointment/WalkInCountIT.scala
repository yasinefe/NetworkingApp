/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import io.restassured.RestAssured._
import org.apache.http.HttpStatus
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers._
import scala.util.parsing.json.JSON

class WalkInCountIT extends Base {

  test("Retrieve walk-ins count by location") {

    val expectedResponseString =
      """
        {
        "CANCELLED":0,
        "IN_MEETING":0,
        "CHECKED_IN":5,
        "OVERDUE":5
        }
      """

    val locationId = "400106"
    val actualResponseObject =
      given
        .queryParam("locationId",locationId).
      when
        .get("/walkins/statusCounts").
      then
        .extract.response

    val actualResponse = JSON.parseFull(actualResponseObject.body.asString)
    val expectedResponse = JSON.parseFull(expectedResponseString)
    assertThat(actualResponseObject.statusCode, equalTo(HttpStatus.SC_OK))
    assertThat(actualResponse, equalTo(expectedResponse))
  }

}