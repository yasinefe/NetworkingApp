/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import io.restassured.RestAssured._
import org.apache.http.HttpStatus
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers._
import scala.util.parsing.json.JSON

class GetProductCategoriesIT extends Base {

  test("Retrieve product categories") {

    val expectedResponseString =
      """
        [{
        	"name": "Existing Product",
        	"productCategories": [{
        		"name": "Payments",
        		"productCategories": [{
        			"name": "Bill Payment",
        			"productCategories": null
        		}, {
        			"name": "Fund Transfer (over 10K)",
        			"productCategories": null
        		}, {
        			"name": "Priority / Int payment",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Current",
        		"productCategories": [{
        			"name": "Close Account",
        			"productCategories": null
        		}, {
        			"name": "Convert to Joint Account",
        			"productCategories": null
        		}, {
        			"name": "Individual Review",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Savings",
        		"productCategories": [{
        			"name": "Close Saver",
        			"productCategories": null
        		}, {
        			"name": "Renew Saver",
        			"productCategories": null
        		}, {
        			"name": "Savings Review / Inhibit",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Premier",
        		"productCategories": [{
        			"name": "Upgrade to Premier",
        			"productCategories": null
        		}, {
        			"name": "PRM / PRO introduction",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Mortgage",
        		"productCategories": [{
        			"name": "Remortgage Quote / DIP",
        			"productCategories": null
        		}, {
        			"name": "Buy to Let Quote / DIP",
        			"productCategories": null
        		}, {
        			"name": "Document Check",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Unsecured Lending",
        		"productCategories": [{
        			"name": "Consolidate Credit card",
        			"productCategories": null
        		}, {
        			"name": "Consolidate Loan",
        			"productCategories": null
        		}, {
        			"name": "Lending Review",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Insurance",
        		"productCategories": [{
        			"name": "Adjust Home insurance",
        			"productCategories": null
        		}, {
        			"name": "Adjust Life insure",
        			"productCategories": null
        		}, {
        			"name": "Help making claim",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Bereavement",
        		"productCategories": [{
        			"name": "Initial notification",
        			"productCategories": null
        		}, {
        			"name": "Submit Documentation",
        			"productCategories": null
        		}, {
        			"name": "Executor Acc",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Print / Internet",
        		"productCategories": [{
        			"name": "Statement",
        			"productCategories": null
        		}, {
        			"name": "Cover / Visa Letter",
        			"productCategories": null
        		}, {
        			"name": "Set / Reset Internet Banking",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Other",
        		"productCategories": [{
        			"name": "Fraud",
        			"productCategories": null
        		}, {
        			"name": "Customer details update",
        			"productCategories": null
        		}, {
        			"name": "Business Acc Query",
        			"productCategories": null
        		}, {
        			"name": "Third party access",
        			"productCategories": null
        		}]
        	}]
        }, {
        	"name": "New Product",
        	"productCategories": [{
        		"name": "Current",
        		"productCategories": [{
        			"name": "Open Account",
        			"productCategories": null
        		}, {
        			"name": "Open Secondary Acc",
        			"productCategories": null
        		}, {
        			"name": "Open Joint Acc",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Savings",
        		"productCategories": [{
        			"name": "Open Saver",
        			"productCategories": null
        		}, {
        			"name": "Savings Review",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Premier",
        		"productCategories": [{
        			"name": "Open Premier Acc",
        			"productCategories": null
        		}, {
        			"name": "Open International Acc",
        			"productCategories": null
        		}, {
        			"name": "PRM / PRO introduction",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Mortgage",
        		"productCategories": [{
        			"name": "First time Quote / DIP",
        			"productCategories": null
        		}, {
        			"name": "Remortgage Quote / DIP",
        			"productCategories": null
        		}, {
        			"name": "Buy to Let Quote / DIP",
        			"productCategories": null
        		}, {
        			"name": "Document Check",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Unsecured Lending",
        		"productCategories": [{
        			"name": "Apply Credit card / Loan",
        			"productCategories": null
        		}, {
        			"name": "Complete Credit card / Loan",
        			"productCategories": null
        		}, {
        			"name": "Lending Review",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Insurance",
        		"productCategories": [{
        			"name": "Apply Home insure",
        			"productCategories": null
        		}, {
        			"name": "Apply Life insure",
        			"productCategories": null
        		}, {
        			"name": "Help making claim",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Other",
        		"productCategories": [{
        			"name": "Fraud",
        			"productCategories": null
        		}, {
        			"name": "Open Business Acc",
        			"productCategories": null
        		}]
        	}]
        }, {
        	"name": "Not a Customer",
        	"productCategories": [{
        		"name": "Current",
        		"productCategories": [{
        			"name": "Open Account",
        			"productCategories": null
        		}, {
        			"name": "Open Secondary Acc",
        			"productCategories": null
        		}, {
        			"name": "Open Joint Acc",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Savings",
        		"productCategories": [{
        			"name": "Open Saver",
        			"productCategories": null
        		}, {
        			"name": "Savings Review",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Premier",
        		"productCategories": [{
        			"name": "Open Premier Acc",
        			"productCategories": null
        		}, {
        			"name": "Open International Acc",
        			"productCategories": null
        		}, {
        			"name": "PRM / PRO introduction",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Mortgage",
        		"productCategories": [{
        			"name": "First time Quote / DIP",
        			"productCategories": null
        		}, {
        			"name": "Remortgage Quote / DIP",
        			"productCategories": null
        		}, {
        			"name": "Buy to Let Quote / DIP",
        			"productCategories": null
        		}, {
        			"name": "Document Check",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Unsecured Lending",
        		"productCategories": [{
        			"name": "Apply Credit card / Loan",
        			"productCategories": null
        		}, {
        			"name": "Complete Credit card / Loan",
        			"productCategories": null
        		}, {
        			"name": "Lending Review",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Insurance",
        		"productCategories": [{
        			"name": "Apply Home insure",
        			"productCategories": null
        		}, {
        			"name": "Apply Life insure",
        			"productCategories": null
        		}, {
        			"name": "Help making claim",
        			"productCategories": null
        		}]
        	}, {
        		"name": "Other",
        		"productCategories": [{
        			"name": "Fraud",
        			"productCategories": null
        		}, {
        			"name": "Open Business Acc",
        			"productCategories": null
        		}]
        	}]
        }]
      """

    val actualResponseObject =
      when
        .get("/productCategories").
      then
        .extract.response

    val actualResponse = JSON.parseFull(actualResponseObject.body.asString)
    val expectedResponse = JSON.parseFull(expectedResponseString)
    assertThat(actualResponseObject.statusCode, equalTo(HttpStatus.SC_OK))
    assertThat(actualResponse, equalTo(expectedResponse))
  }

}