/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import io.restassured.RestAssured._
import io.restassured.http.ContentType
import org.apache.http.HttpStatus

class CreateWalkInIT extends Base {

  test("Create a new walkin appointment") {

    val request =
      """
        {
            "appointmentStatus": "CHECKED_IN",
            "duration": 15,
            "locationId": 400106,
            "topicId": "First",
            "topicCategoryId": "Second",
            "topicSubCategoryId": "Third",
            "attendee": {
              "firstName": "Sammy",
              "lastName": "Charles",
              "email": "sammy.charles@email.com",
              "phoneNumber": "07777777777",
              "mobileNumber": "02000000000",
              "gender": "FEMALE"
            },
            "conductor": {
              "employeeId": "44443232",
              "fullName": "Ms Edna Nashville"
            },
            "comments": "Nothing to see here, move along...",
            "proofOfId": false
          }
      """

    given
      .contentType(ContentType.JSON)
      .body(request).
    when
      .post("/walkins").
    then
      .assertThat().statusCode(HttpStatus.SC_CREATED)
  }

}