/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import io.restassured.RestAssured._
import org.apache.http.HttpStatus
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers._
import scala.util.parsing.json.JSON

class RetrieveWalkInIT extends Base {

  test("Retrieve a walkin appointment by appointment id") {

    val expectedResponseString =
      """
        {
        	"appointmentId": "59008326f84523a0a4416cf9",
        	"appointmentStatus": "CHECKED_IN",
        	"duration": 15,
        	"overdueOffset": 10,
        	"locationId": 400706,
        	"topicId": "Current Account",
        	"topicCategoryId": "Review",
        	"topicSubCategoryId": "Interest",
        	"comments": "This is a test note",
        	"proofOfId": false,
        	"attendee": {
        		"firstName": "Peter",
        		"lastName": "Jones",
        		"email": "peter.jones@email.com",
        		"phoneNumber": "07957445933",
        		"mobileNumber": "020 3232 5544",
        		"gender": "Male"
        	},
        	"conductor": {
        		"employeeId": "44443232",
        		"fullName": "Edna Nashville"
        	},
        	"created": 1491490571749,
        	"dateTime": 1493729908000,
        	"updated": 1491490571749,
        	"startedAt": null
        }
      """

    val walkinId = "59008326f84523a0a4416cf9"
    val actualResponseObject =
      given
        .pathParam("walkinId",walkinId).
      when
        .get("/walkins/{walkinId}").
      then
        .extract.response

    val actualResponse = JSON.parseFull(actualResponseObject.body.asString)
    val expectedResponse = JSON.parseFull(expectedResponseString)
    assertThat(actualResponseObject.statusCode, equalTo(HttpStatus.SC_OK))
    assertThat(actualResponse, equalTo(expectedResponse))
  }

}