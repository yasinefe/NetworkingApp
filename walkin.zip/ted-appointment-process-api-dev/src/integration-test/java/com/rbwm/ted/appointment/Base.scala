/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import io.restassured.RestAssured
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.{BeforeAndAfter, FunSuite}

@RunWith(classOf[JUnitRunner])
abstract class Base extends FunSuite with BeforeAndAfter {

  private val processApi = new ProcessApi()

  before {
    val base = processApi.getBaseUrl()
    val port = processApi.getPort()
    if ((base == processApi.defaultBase) && port == processApi.defaultPort) {
      processApi.startLocalServer()
    }
    RestAssured.baseURI = base
    RestAssured.port = port
  }

  after {
    if (processApi.process != null) {
      processApi.stopLocalServer()
    }
    RestAssured.reset()
  }

}