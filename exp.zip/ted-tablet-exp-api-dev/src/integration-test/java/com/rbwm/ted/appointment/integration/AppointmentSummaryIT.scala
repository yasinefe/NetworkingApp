/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class AppointmentSummaryIT extends Base {

  test("Retrieve appointment summary") {

    val request =
      """
      {
        "query": "{ted{appointmentSummary (locationId:\"400706\", appointmentStatus:[CHECKED_IN,COMPLETED,IN_MEETING,NEXT_DAY,NOSHOW,OVERDUE,OVERRUN,UPCOMING]) {count,appointmentStatus}}}",
        "variables": {
          },
        "operationName": null
      }
      """

    val expectedResponse =
      """
        {
          "data": {
            "ted": {
              "appointmentSummary": [
                {
                  "count": 3,
                  "appointmentStatus": "CHECKED_IN"
                },
                {
                  "count": 2,
                  "appointmentStatus": "COMPLETED"
                },
                {
                  "count": 2,
                  "appointmentStatus": "IN_MEETING"
                },
                {
                  "count": 12,
                  "appointmentStatus": "NEXT_DAY"
                },
                {
                  "count": 1,
                  "appointmentStatus": "NOSHOW"
                },
                {
                  "count": 2,
                  "appointmentStatus": "OVERDUE"
                },
                {
                  "count": 1,
                  "appointmentStatus": "OVERRUN"
                },
                {
                  "count": 6,
                  "appointmentStatus": "UPCOMING"
                }
              ]
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

}
