/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import org.apache.http.HttpStatus
import org.hamcrest.MatcherAssert._
import org.hamcrest.Matchers._

/**
  * Created by 44027117 on 11/04/2017.
  */
class CancelWalkInsIT extends Base {

  test("Cancel a walkIn created") {
    val creationRequest =
      """
        {
        	"query": "mutation CreateWalkInMutation($input:CreateWalkInInput!){createWalkIn(input:$input){clientMutationId walkIn {appointmentId, attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments, locationId}}}",
        	"variables": {
        		"input": {
        			"gender": "MALE",
        			"firstName": "Javier",
        			"lastName": "Torres",
        			"topicId": "First",
        			"topicCategoryId": "Second",
        			"topicSubCategoryId": "Third",
        			"proofOfId": true,
        			"comments": "Nothing to see here, move along...",
        			"locationId": 400106,
        			"clientMutationId": "10"
        		}
        	}
        }
      """

    val walkInCreated = doPostWithAuth(creationRequest)
    val walkInCreatedJson = toResponseMap(walkInCreated.body.asString)
    val appointmentId = walkInCreatedJson.get.apply("data").apply("createWalkIn").apply("walkIn").apply("appointmentId")

    val cancelRequest =
      """
        {
          "query": "mutation ChangeStatusWalkInMutation($input:ChangeStatusWalkInInput!){changeStatusWalkIn(input:$input){clientMutationId walkIn {id, appointmentId, appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": """" + appointmentId + """",
              "appointmentStatus": "CANCELLED",
              "clientMutationId": "10"
            }
          }
        }
      """

    val cancelResponse = doPostWithAuth(cancelRequest)
    val cancelResponseJson = toResponseMap(cancelResponse.body.asString)

    assertThat(cancelResponse.statusCode(), equalTo(HttpStatus.SC_OK))
    assertThat("CANCELLED", equalTo(cancelResponseJson.get.apply("data").apply("changeStatusWalkIn").apply("walkIn").apply("appointmentStatus")))
  }
}
