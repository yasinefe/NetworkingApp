/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import java.io.{BufferedReader, InputStreamReader}
import org.scalatest._

class ExperienceApi extends FunSuite {

  var process: Process = _

  private val command = "java -jar target/ted-tablet-exp-api-1.0.12-0-0.jar --spring.profiles.active=mct"

  val defaultBase = "http://localhost"
  val defaultPort = 8080

  def getBaseUrl(): String = {
    var base = defaultBase
    val args = sys.env.getOrElse("MAVEN_CMD_LINE_ARGS", "")
    if (!args.isEmpty) {
      args.split(" ").foreach { string =>
        val index = string.indexOf("=") + 1
        if (string.contains("experience.server.base")) {
          base = string.substring(index)
        }
      }
    }
    base
  }

  def getPort(): Int = {
    var port = defaultPort
    val args = sys.env.getOrElse("MAVEN_CMD_LINE_ARGS", "")
    if (!args.isEmpty) {
      args.split(" ").foreach { string =>
        val index = string.indexOf("=") + 1
        if (string.contains("experience.server.port")) {
          port = string.substring(index).toInt
        }
      }
    }
    port
  }

  def start() {
    process = Runtime.getRuntime.exec(command)
    val reader = new BufferedReader(new InputStreamReader(process.getInputStream))
    var run = true
    while (run) {
      val line = reader.readLine()
      if (line.contains("Started Application")) {
        run = false
      }
      if (line.contains("Failed to start")) {
        fail("Experience API failed to start, is the process already running?")
      }
    }

  }

  def stop() {
    process.destroy()
  }

}
