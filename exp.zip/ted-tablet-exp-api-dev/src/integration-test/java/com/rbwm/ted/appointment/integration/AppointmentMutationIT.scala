/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class AppointmentMutationIT extends Base {

  test("Check in an Upcoming appointment") {

    val request =
      """
      {
        "query": "mutation ChangeStatusMutation($input:ChangeStatusInput!){changeStatus(input:$input){clientMutationId, appointment {id,appointmentId, appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": "XEF1546",
              "appointmentStatus": "CHECKED_IN",
              "clientMutationId": "1"
            }
          }
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "changeStatus": {
              "clientMutationId": "1",
              "appointment": {
                "id": "YXBwb2ludG1lbnQ6WEVGMTU0Ng==",
                "appointmentId": "XEF1546",
                "appointmentStatus": "CHECKED_IN"
              }
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

  test("Start a Checked In appointment") {

    val request =
      """
      {
        "query": "mutation ChangeStatusMutation($input:ChangeStatusInput!){changeStatus(input:$input){clientMutationId, appointment {id,appointmentId, appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": "XEF1532",
              "appointmentStatus": "IN_MEETING",
              "clientMutationId": "1"
            }
          }
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "changeStatus": {
              "clientMutationId": "1",
              "appointment": {
                "id": "YXBwb2ludG1lbnQ6WEVGMTUzMg==",
                "appointmentId": "XEF1532",
                "appointmentStatus": "IN_MEETING"
              }
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

  test("End an In meeting appointment") {

    val request =
      """
      {
        "query": "mutation ChangeStatusMutation($input:ChangeStatusInput!){changeStatus(input:$input){clientMutationId, appointment {id,appointmentId, appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": "XEF1530",
              "appointmentStatus": "COMPLETED",
              "clientMutationId": "1"
            }
          }
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "changeStatus": {
              "clientMutationId": "1",
              "appointment": {
                "id": "YXBwb2ludG1lbnQ6WEVGMTUzMA==",
                "appointmentId": "XEF1530",
                "appointmentStatus": "COMPLETED"
              }
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

  test("Recover an Expired appointment") {

    val request =
      """
      {
        "query": "mutation ChangeStatusMutation($input:ChangeStatusInput!){changeStatus(input:$input){clientMutationId, appointment {id,appointmentId, appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": "XEF1511",
              "appointmentStatus": "CHECKED_IN",
              "clientMutationId": "1"
            }
          }
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "changeStatus": {
              "clientMutationId": "1",
              "appointment": {
                "id": "YXBwb2ludG1lbnQ6WEVGMTUxMQ==",
                "appointmentId": "XEF1511",
                "appointmentStatus": "CHECKED_IN"
              }
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

}
