/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class WalkInsMutationIT extends Base {

  test("Start a walk ins") {

    val request =
      """
        {
        	"query": "mutation ChangeStatusWalkInMutation($input:ChangeStatusWalkInInput!){changeStatusWalkIn(input:$input){clientMutationId walkIn {id, appointmentId, appointmentStatus}}}",
        	"variables": {
        		"input": {
        			"appointmentId": "58c1747ec419ef03b84ded58",
        			"appointmentStatus": "IN_MEETING",
        			"clientMutationId": "10"
        		}
        	}
        }
      """

    val expectedResponse =
      """
        {
        	"data": {
        		"changeStatusWalkIn": {
        			"clientMutationId": "10",
        			"walkIn": {
        				"id": "YXBwb2ludG1lbnQ6NThjMTc0N2VjNDE5ZWYwM2I4NGRlZDU4",
        				"appointmentId": "58c1747ec419ef03b84ded58",
        				"appointmentStatus": "IN_MEETING"
        			}
        		}
        	}
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }
}