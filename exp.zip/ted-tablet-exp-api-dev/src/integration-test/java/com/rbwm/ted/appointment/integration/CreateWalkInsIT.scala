/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class CreateWalkInsIT extends Base {

  test("Create a new walk in appointment") {
    val request =
      """
        {
        	"query": "mutation CreateWalkInMutation($input:CreateWalkInInput!){createWalkIn(input:$input){clientMutationId walkIn {gender, firstName, lastName, topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments, locationId}}}",
        	"variables": {
        		"input": {
        			"gender": "FEMALE",
        			"firstName": "Grace",
        			"lastName": "Charles",
        			"topicId": "First",
        			"topicCategoryId": "Second",
        			"topicSubCategoryId": "Third",
        			"proofOfId": true,
        			"comments": "Nothing to see here, move along...",
        			"locationId": 400106,
        			"clientMutationId": "10"
        		}
        	}
        }
      """

    val expectedResponse =
      """
        {
        	"data": {
        		"createWalkIn": {
        			"clientMutationId": "10",
        			"walkIn": {
        				"gender": "FEMALE",
        				"firstName": "Grace",
        				"lastName": "Charles",
        				"topicId": "First",
        				"topicCategoryId": "Second",
        				"topicSubCategoryId": "Third",
        				"proofOfId": true,
        				"comments": "Nothing to see here, move along...",
        				"locationId": "400106"
        			}
        		}
        	}
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }
}