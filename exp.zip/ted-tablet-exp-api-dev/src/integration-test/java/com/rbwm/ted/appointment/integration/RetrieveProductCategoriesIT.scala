/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class RetrieveProductCategoriesIT extends Base {

  test("Retrieve product categories") {

    val request =
      """
        {
        	"query": "{ted{productCategories {name productCategories {name productCategories {name}}}}}",
        	"variables": {}
        }
      """

    val expectedResponse =
      """
        {
        	"data": {
        		"ted": {
        			"productCategories": [{
        				"name": "Existing Product",
        				"productCategories": [{
        					"name": "Payments",
        					"productCategories": [{
        						"name": "Bill Payment"
        					}, {
        						"name": "Fund Transfer (over 10K)"
        					}, {
        						"name": "Priority / Int payment"
        					}]
        				}, {
        					"name": "Current",
        					"productCategories": [{
        						"name": "Close Account"
        					}, {
        						"name": "Convert to Joint Account"
        					}, {
        						"name": "Individual Review"
        					}]
        				}, {
        					"name": "Savings",
        					"productCategories": [{
        						"name": "Close Saver"
        					}, {
        						"name": "Renew Saver"
        					}, {
        						"name": "Savings Review / Inhibit"
        					}]
        				}, {
        					"name": "Premier",
        					"productCategories": [{
        						"name": "Upgrade to Premier"
        					}, {
        						"name": "PRM / PRO introduction"
        					}]
        				}, {
        					"name": "Mortgage",
        					"productCategories": [{
        						"name": "Remortgage Quote / DIP"
        					}, {
        						"name": "Buy to Let Quote / DIP"
        					}, {
        						"name": "Document Check"
        					}]
        				}, {
        					"name": "Unsecured Lending",
        					"productCategories": [{
        						"name": "Consolidate Credit card"
        					}, {
        						"name": "Consolidate Loan"
        					}, {
        						"name": "Lending Review"
        					}]
        				}, {
        					"name": "Insurance",
        					"productCategories": [{
        						"name": "Adjust Home insurance"
        					}, {
        						"name": "Adjust Life insure"
        					}, {
        						"name": "Help making claim"
        					}]
        				}, {
        					"name": "Bereavement",
        					"productCategories": [{
        						"name": "Initial notification"
        					}, {
        						"name": "Submit Documentation"
        					}, {
        						"name": "Executor Acc"
        					}]
        				}, {
        					"name": "Print / Internet",
        					"productCategories": [{
        						"name": "Statement"
        					}, {
        						"name": "Cover / Visa Letter"
        					}, {
        						"name": "Set / Reset Internet Banking"
        					}]
        				}, {
        					"name": "Other",
        					"productCategories": [{
        						"name": "Fraud"
        					}, {
        						"name": "Customer details update"
        					}, {
        						"name": "Business Acc Query"
        					}, {
        						"name": "Third party access"
        					}]
        				}]
        			}, {
        				"name": "New Product",
        				"productCategories": [{
        					"name": "Current",
        					"productCategories": [{
        						"name": "Open Account"
        					}, {
        						"name": "Open Secondary Acc"
        					}, {
        						"name": "Open Joint Acc"
        					}]
        				}, {
        					"name": "Savings",
        					"productCategories": [{
        						"name": "Open Saver"
        					}, {
        						"name": "Savings Review"
        					}]
        				}, {
        					"name": "Premier",
        					"productCategories": [{
        						"name": "Open Premier Acc"
        					}, {
        						"name": "Open International Acc"
        					}, {
        						"name": "PRM / PRO introduction"
        					}]
        				}, {
        					"name": "Mortgage",
        					"productCategories": [{
        						"name": "First time Quote / DIP"
        					}, {
        						"name": "Remortgage Quote / DIP"
        					}, {
        						"name": "Buy to Let Quote / DIP"
        					}, {
        						"name": "Document Check"
        					}]
        				}, {
        					"name": "Unsecured Lending",
        					"productCategories": [{
        						"name": "Apply Credit card / Loan"
        					}, {
        						"name": "Complete Credit card / Loan"
        					}, {
        						"name": "Lending Review"
        					}]
        				}, {
        					"name": "Insurance",
        					"productCategories": [{
        						"name": "Apply Home insure"
        					}, {
        						"name": "Apply Life insure"
        					}, {
        						"name": "Help making claim"
        					}]
        				}, {
        					"name": "Other",
        					"productCategories": [{
        						"name": "Fraud"
        					}, {
        						"name": "Open Business Acc"
        					}]
        				}]
        			}, {
        				"name": "Not a Customer",
        				"productCategories": [{
        					"name": "Current",
        					"productCategories": [{
        						"name": "Open Account"
        					}, {
        						"name": "Open Secondary Acc"
        					}, {
        						"name": "Open Joint Acc"
        					}]
        				}, {
        					"name": "Savings",
        					"productCategories": [{
        						"name": "Open Saver"
        					}, {
        						"name": "Savings Review"
        					}]
        				}, {
        					"name": "Premier",
        					"productCategories": [{
        						"name": "Open Premier Acc"
        					}, {
        						"name": "Open International Acc"
        					}, {
        						"name": "PRM / PRO introduction"
        					}]
        				}, {
        					"name": "Mortgage",
        					"productCategories": [{
        						"name": "First time Quote / DIP"
        					}, {
        						"name": "Remortgage Quote / DIP"
        					}, {
        						"name": "Buy to Let Quote / DIP"
        					}, {
        						"name": "Document Check"
        					}]
        				}, {
        					"name": "Unsecured Lending",
        					"productCategories": [{
        						"name": "Apply Credit card / Loan"
        					}, {
        						"name": "Complete Credit card / Loan"
        					}, {
        						"name": "Lending Review"
        					}]
        				}, {
        					"name": "Insurance",
        					"productCategories": [{
        						"name": "Apply Home insure"
        					}, {
        						"name": "Apply Life insure"
        					}, {
        						"name": "Help making claim"
        					}]
        				}, {
        					"name": "Other",
        					"productCategories": [{
        						"name": "Fraud"
        					}, {
        						"name": "Open Business Acc"
        					}]
        				}]
        			}]
        		}
        	}
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

}
