/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class RetrieveAppointmentsIT extends Base {

  test("Retrieve Upcoming appointments") {
    val request =
      """
        {
          "query": "{ted{appointments (locationId:\"404628\", appointmentStatus:UPCOMING) {appointmentId appointmentStatus locationId dateTime duration noShowDuration topicId topicCategoryId timezone attendee{firstName lastName email} conductor{fullName employeeId} }}}",
          "variables": {
            }
          }
      """

    val expectedResponse =
      """
        {
          "data": {
            "ted": {
              "appointments": [
                {
                  "appointmentId": "XEF1546",
                  "appointmentStatus": "UPCOMING",
                  "locationId": "404519",
                  "dateTime": 1477387800000,
                  "duration": "60",
                  "noShowDuration": "20",
                  "topicId": "Account Maintenance Review",
                  "topicCategoryId": "Review of Current Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Giles",
                    "lastName": "Peterson",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MR BARNEY GUMBLE",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1556",
                  "appointmentStatus": "UPCOMING",
                  "locationId": "404519",
                  "dateTime": 1477389600000,
                  "duration": "60",
                  "noShowDuration": "20",
                  "topicId": "Current Account",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Donald",
                    "lastName": "Byrd",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MR HOMER SIMPSON",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1589",
                  "appointmentStatus": "UPCOMING",
                  "locationId": "404519",
                  "dateTime": 1477395000000,
                  "duration": "60",
                  "noShowDuration": "20",
                  "topicId": "Current Account",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "John",
                    "lastName": "Smithville",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MS EDNA KRABAPPEL",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1690",
                  "appointmentStatus": "UPCOMING",
                  "locationId": "404519",
                  "dateTime": 1477396800000,
                  "duration": "45",
                  "noShowDuration": "20",
                  "topicId": "Current Account",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Peter",
                    "lastName": "Tongue",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MR NED FLANDERS",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1691",
                  "appointmentStatus": "UPCOMING",
                  "locationId": "404519",
                  "dateTime": 1477398600000,
                  "duration": "45",
                  "noShowDuration": "20",
                  "topicId": "Current Account",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Bob",
                    "lastName": "Jones",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MS MARGE SIMPSON",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1692",
                  "appointmentStatus": "UPCOMING",
                  "locationId": "404519",
                  "dateTime": 1477400400000,
                  "duration": "60",
                  "noShowDuration": "20",
                  "topicId": "Current Account",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "James",
                    "lastName": "Brown",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MOE SZYSLAK",
                    "employeeId": "01747754"
                  }
                }
              ]
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

  test("Retrieve Checked In appointments") {

    val request =
      """
      {
        "query": "{ted{appointments (locationId:\"404628\", appointmentStatus:CHECKED_IN) {appointmentId appointmentStatus locationId dateTime duration criticalOverdueOffset topicId topicCategoryId timezone attendee{firstName lastName email} conductor{fullName employeeId} }}}",
        "variables": {
          }
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "ted": {
              "appointments": [
                {
                  "appointmentId": "XEF1532",
                  "appointmentStatus": "CHECKED_IN",
                  "locationId": "404519",
                  "dateTime": 1477378800000,
                  "duration": "75",
                  "criticalOverdueOffset": "10",
                  "topicId": "Mortgages",
                  "topicCategoryId": "Purchase a Property",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Jonathan",
                    "lastName": "Talbot",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MR APU NAHASAPEEMAPETILON",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1538",
                  "appointmentStatus": "CHECKED_IN",
                  "locationId": "404519",
                  "dateTime": 1477382400000,
                  "duration": "60",
                  "criticalOverdueOffset": "10",
                  "topicId": "ISA",
                  "topicCategoryId": "Choose an investment",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Mary",
                    "lastName": "Smalltown",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MS EDNA KRABAPPEL",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1544",
                  "appointmentStatus": "CHECKED_IN",
                  "locationId": "404519",
                  "dateTime": 1477386000000,
                  "duration": "60",
                  "criticalOverdueOffset": "10",
                  "topicId": "Current Account",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Raymond",
                    "lastName": "Smith",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MR MOE SZYSLAK",
                    "employeeId": "01747754"
                  }
                }
              ]
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

  test("Retrieve In Meeting appointments") {

    val request =
      """
      {
        "query": "{ted{appointments (locationId:\"404628\", appointmentStatus:IN_MEETING) {appointmentId appointmentStatus locationId dateTime duration overRunOffset topicId topicCategoryId timezone attendee{firstName lastName email} conductor{fullName employeeId} }}}",
        "variables": {
          }
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "ted": {
              "appointments": [
                {
                  "appointmentId": "XEF1530",
                  "appointmentStatus": "IN_MEETING",
                  "locationId": "404519",
                  "dateTime": 1477378800000,
                  "duration": "75",
                  "overRunOffset": "10",
                  "topicId": "Mortgages",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "James",
                    "lastName": "Green",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MR HOMER SIMPSON",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1531",
                  "appointmentStatus": "IN_MEETING",
                  "locationId": "404519",
                  "dateTime": 1477378800000,
                  "duration": "240",
                  "overRunOffset": "10",
                  "topicId": "Mortgages",
                  "topicCategoryId": "Review of Current Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Tim",
                    "lastName": "Smith",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MR NED FLANDERS",
                    "employeeId": "01747754"
                  }
                }
              ]
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

  test("Retrieve Completed appointments") {

    val request =
      """
      {
        "query": "{ted{appointments (locationId:\"404628\", appointmentStatus:COMPLETED) {appointmentId appointmentStatus locationId dateTime duration isNoShow topicId topicCategoryId timezone attendee{firstName lastName email} conductor{fullName employeeId} }}}",
        "variables": {
          }
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "ted": {
              "appointments": [
                {
                  "appointmentId": "XEF1529",
                  "appointmentStatus": "COMPLETED",
                  "locationId": "404519",
                  "dateTime": 1477378800000,
                  "duration": "30",
                  "isNoShow": false,
                  "topicId": "Mortgages",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Mike",
                    "lastName": "Smith",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MS EDNA KRABAPPEL",
                    "employeeId": "01747754"
                  }
                },
                {
                  "appointmentId": "XEF1511",
                  "appointmentStatus": "UPCOMING",
                  "locationId": "404519",
                  "dateTime": 1477377000000,
                  "duration": "60",
                  "isNoShow": true,
                  "topicId": "Current Account",
                  "topicCategoryId": "Open a new Account",
                  "timezone": "GMT-3",
                  "attendee": {
                    "firstName": "Malcolm",
                    "lastName": "Smithville",
                    "email": null
                  },
                  "conductor": {
                    "fullName": "MS EDNA KRABAPPEL",
                    "employeeId": "01747754"
                  }
                }
              ]
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

}