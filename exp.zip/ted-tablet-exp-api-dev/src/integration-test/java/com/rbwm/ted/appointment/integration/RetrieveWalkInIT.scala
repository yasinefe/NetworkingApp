/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class RetrieveWalkInIT extends Base {

  test("Retrieve walk-in by appointment id") {

    val request =
      """
        {
        	"query": "{ted{walkIn(appointmentId: \"59008326f84523a0a4416cf9\") {appointmentId appointmentStatus locationId dateTime duration topicId topicCategoryId timezone attendee{firstName lastName gender} conductor{fullName employeeId} }}}",
        	"variables": {}
        }
      """

    val expectedResponse =
      """
        {
        	"data": {
        		"ted": {
        			"walkIn": {
        				"appointmentId": "59008326f84523a0a4416cf9",
        				"appointmentStatus": "CHECKED_IN",
        				"locationId": 400706,
        				"dateTime": 1493729908000,
        				"duration": "15.0",
        				"topicId": "Current Account",
        				"topicCategoryId": "Review",
        				"timezone": null,
        				"attendee": {
        					"firstName": "Peter",
        					"lastName": "Jones",
        					"gender": "Male"
        				},
        				"conductor": {
        					"fullName": "Edna Nashville",
        					"employeeId": "44443232"
        				}
        			}
        		}
        	}
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }
}