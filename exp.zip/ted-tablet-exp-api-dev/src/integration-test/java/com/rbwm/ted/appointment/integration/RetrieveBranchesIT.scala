/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class RetrieveBranchesIT extends Base {

  test("Retrieve branches by lat and long") {

    val request =
      """
        {
          "query": "{ted{branches (longitude: 1234, latitude: 1234) {name, branchId, latitude, longitude address{addressLine1, city, postCode, county} }}}",
          "variables": {}
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "ted": {
              "branches": [
                {
                  "name": "Baker Street",
                  "branchId": "400106",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "90 Baker Street",
                    "city": "",
                    "postCode": "W1U 6AX",
                    "county": "London"
                  }
                },
                {
                  "name": "Baker Street Relationship Management Centre",
                  "branchId": "407750",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "88 Baker Street",
                    "city": "",
                    "postCode": "W1U 6AX",
                    "county": "London"
                  }
                },
                {
                  "name": "Balham",
                  "branchId": "400107",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "117 Balham High Road",
                    "city": "Balham",
                    "postCode": "SW12 9AS",
                    "county": "London"
                  }
                },
                {
                  "name": "Belgravia",
                  "branchId": "400113",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "The Peak, 333 Vauxhall Bridge Road",
                    "city": "Victoria",
                    "postCode": "SW1V 1EJ",
                    "county": "London"
                  }
                },
                {
                  "name": "Bethnal Green",
                  "branchId": "400118",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "465 Bethnal Green Road",
                    "city": "Bethnal Green",
                    "postCode": "E2 9QW",
                    "county": "London"
                  }
                }
              ]
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }

  test("Retrieve all branches") {

    val request =
      """
        {
          "query": "{ted{branches {name, branchId, latitude, longitude address{addressLine1, city, postCode, county} }}}",
          "variables": {}
        }
      """

    val expectedResponse =
      """
        {
          "data": {
            "ted": {
              "branches": [
                {
                  "name": "Baker Street",
                  "branchId": "400106",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "90 Baker Street",
                    "city": "",
                    "postCode": "W1U 6AX",
                    "county": "London"
                  }
                },
                {
                  "name": "Baker Street Relationship Management Centre",
                  "branchId": "407750",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "88 Baker Street",
                    "city": "",
                    "postCode": "W1U 6AX",
                    "county": "London"
                  }
                },
                {
                  "name": "Balham",
                  "branchId": "400107",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "117 Balham High Road",
                    "city": "Balham",
                    "postCode": "SW12 9AS",
                    "county": "London"
                  }
                },
                {
                  "name": "Belgravia",
                  "branchId": "400113",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "The Peak, 333 Vauxhall Bridge Road",
                    "city": "Victoria",
                    "postCode": "SW1V 1EJ",
                    "county": "London"
                  }
                },
                {
                  "name": "Bethnal Green",
                  "branchId": "400118",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "465 Bethnal Green Road",
                    "city": "Bethnal Green",
                    "postCode": "E2 9QW",
                    "county": "London"
                  }
                },
                {
                  "name": "Brixton",
                  "branchId": "400122",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "512 Brixton Road",
                    "city": "Brixton",
                    "postCode": "SW9 8ER",
                    "county": "London"
                  }
                },
                {
                  "name": "Brompton Road",
                  "branchId": "400124",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "237 Brompton Road",
                    "city": "Chelsea",
                    "postCode": "SW3 2ER",
                    "county": "London"
                  }
                },
                {
                  "name": "Camden Town",
                  "branchId": "400203",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "176 Camden High Street",
                    "city": "Camden",
                    "postCode": "NW1 8QL",
                    "county": "London"
                  }
                },
                {
                  "name": "Canary Wharf Relationship Management Centre",
                  "branchId": "400246",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "8 Canada Square",
                    "city": "Canary Wharf",
                    "postCode": "E14 5HQ",
                    "county": "London"
                  }
                },
                {
                  "name": "Canary Wharf, Canada Place",
                  "branchId": "400244",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "Retail Unit 8Canada Place",
                    "city": "Canary Wharf",
                    "postCode": "E14 5AH",
                    "county": "London"
                  }
                },
                {
                  "name": "Canary Wharf, Jubilee Place",
                  "branchId": "400245",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "45 Bank StreetJubilee Place",
                    "city": "Canary Wharf",
                    "postCode": "E14 5NY",
                    "county": "London"
                  }
                },
                {
                  "name": "Catford",
                  "branchId": "400205",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "149 Rushey Green",
                    "city": "Catford",
                    "postCode": "SE6 4BQ",
                    "county": "London"
                  }
                },
                {
                  "name": "Chingford",
                  "branchId": "400240",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "46 Old Church Road",
                    "city": "Chingford",
                    "postCode": "E4 8DB",
                    "county": "London"
                  }
                },
                {
                  "name": "Chiswick",
                  "branchId": "400213",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "281 Chiswick High Road",
                    "city": "Chiswick",
                    "postCode": "W4 4HJ",
                    "county": "London"
                  }
                },
                {
                  "name": "City of London",
                  "branchId": "400530",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "60 Queen Victoria Street",
                    "city": "",
                    "postCode": "EC4N 4TR",
                    "county": "London"
                  }
                },
                {
                  "name": "City of London",
                  "branchId": "401160",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "60 Queen Victoria Street",
                    "city": "",
                    "postCode": "EC4N 4TR",
                    "county": "London"
                  }
                },
                {
                  "name": "Clapham Junction",
                  "branchId": "400216",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "240 Lavender Hill",
                    "city": "Battersea",
                    "postCode": "SW11 1LH",
                    "county": "London"
                  }
                },
                {
                  "name": "Covent Garden",
                  "branchId": "400409",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "16 King Street",
                    "city": "Covent Garden",
                    "postCode": "WC2E 8JF",
                    "county": "London"
                  }
                },
                {
                  "name": "Ealing Broadway",
                  "branchId": "400226",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "46 The Broadway",
                    "city": "Ealing",
                    "postCode": "W5 5JR",
                    "county": "London"
                  }
                },
                {
                  "name": "East Ham",
                  "branchId": "400234",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "118 High Street North",
                    "city": "East Ham",
                    "postCode": "E6 2HX",
                    "county": "London"
                  }
                },
                {
                  "name": "Edgware Road",
                  "branchId": "400126",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "171  Edgware Road",
                    "city": "",
                    "postCode": "W2 2HR",
                    "county": "London"
                  }
                },
                {
                  "name": "Eltham",
                  "branchId": "400239",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "111 Eltham High Street",
                    "city": "Eltham",
                    "postCode": "SE9 1TD",
                    "county": "London"
                  }
                },
                {
                  "name": "Fenchurch Street",
                  "branchId": "400104",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "60 Fenchurch Street",
                    "city": "",
                    "postCode": "EC3M 4BA",
                    "county": "London"
                  }
                },
                {
                  "name": "Finchley, Church End",
                  "branchId": "400301",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "18 Ballards LaneChurch End",
                    "city": "Finchley",
                    "postCode": "N3 2BH",
                    "county": "London"
                  }
                },
                {
                  "name": "Finsbury Park",
                  "branchId": "400303",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "312 Seven Sisters Road",
                    "city": "Finsbury Park",
                    "postCode": "N4 2AW",
                    "county": "London"
                  }
                },
                {
                  "name": "Fulham Broadway",
                  "branchId": "400714",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "593 - 599 Fulham Road",
                    "city": "Fulham",
                    "postCode": "SW6 5UA",
                    "county": "London"
                  }
                },
                {
                  "name": "Gerrard Street",
                  "branchId": "400340",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "17 Gerrard Street",
                    "city": "",
                    "postCode": "W1D 6HB",
                    "county": "London"
                  }
                },
                {
                  "name": "Gloucester Road",
                  "branchId": "400619",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "95 Gloucester Road",
                    "city": "South Kensington",
                    "postCode": "SW7 4SX",
                    "county": "London"
                  }
                },
                {
                  "name": "Golders Green",
                  "branchId": "400311",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "897 Finchley Road",
                    "city": "Golders Green",
                    "postCode": "NW11 7NX",
                    "county": "London"
                  }
                },
                {
                  "name": "Greenwich",
                  "branchId": "400316",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "275 Greenwich High Road",
                    "city": "Greenwich",
                    "postCode": "SE10 8NF",
                    "county": "London"
                  }
                },
                {
                  "name": "Hackney",
                  "branchId": "400319",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "283 Mare Street",
                    "city": "Hackney",
                    "postCode": "E8 1PJ",
                    "county": "London"
                  }
                },
                {
                  "name": "Hammersmith",
                  "branchId": "400321",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "21 King's MallKing Street",
                    "city": "Hammersmith",
                    "postCode": "W6 0QF",
                    "county": "London"
                  }
                },
                {
                  "name": "Hampstead High Street",
                  "branchId": "400336",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "12 Hampstead High Street",
                    "city": "Hampstead",
                    "postCode": "NW3 1PY",
                    "county": "London"
                  }
                },
                {
                  "name": "Hampstead, Finchley Road",
                  "branchId": "400302",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "122 Finchley Road",
                    "city": "Hampstead",
                    "postCode": "NW3 5JD",
                    "county": "London"
                  }
                },
                {
                  "name": "Hendon Central",
                  "branchId": "400326",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "1 Central Circus",
                    "city": "Hendon",
                    "postCode": "NW4 3JU",
                    "county": "London"
                  }
                },
                {
                  "name": "High Holborn",
                  "branchId": "400327",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "210 High Holborn",
                    "city": "",
                    "postCode": "WC1V 7BZ",
                    "county": "London"
                  }
                },
                {
                  "name": "Holborn Circus",
                  "branchId": "400328",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "31 Holborn",
                    "city": "",
                    "postCode": "EC1N 2HR",
                    "county": "London"
                  }
                },
                {
                  "name": "Holborn Circus",
                  "branchId": "401158",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "31 Holborn",
                    "city": "",
                    "postCode": "EC1N 2HR",
                    "county": "London"
                  }
                },
                {
                  "name": "Islington, Angel Branch and Commercial Office",
                  "branchId": "400333",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "Lion House25 Islington High Street",
                    "city": "Islington",
                    "postCode": "N1 9LJ",
                    "county": "London"
                  }
                },
                {
                  "name": "Kensington High Street",
                  "branchId": "400401",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "92 Kensington High Street",
                    "city": "Kensington",
                    "postCode": "W8 4SH",
                    "county": "London"
                  }
                },
                {
                  "name": "Kilburn",
                  "branchId": "400404",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "50-52 Kilburn High Road",
                    "city": "Kilburn",
                    "postCode": "NW6 4HJ",
                    "county": "London"
                  }
                },
                {
                  "name": "Kings Cross",
                  "branchId": "400407",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "31 Euston Road",
                    "city": "Kings Cross",
                    "postCode": "NW1 2ST",
                    "county": "London"
                  }
                },
                {
                  "name": "Kings Road",
                  "branchId": "400615",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "76-78 Kings Road",
                    "city": "Chelsea",
                    "postCode": "SW3 4TZ",
                    "county": "London"
                  }
                },
                {
                  "name": "Kingsbury",
                  "branchId": "400406",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "544 Kingsbury Road",
                    "city": "Kingsbury",
                    "postCode": "NW9 9EE",
                    "county": "London"
                  }
                },
                {
                  "name": "Knightsbridge Premier Centre",
                  "branchId": "400410",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "102 Brompton Road",
                    "city": "Knightsbridge",
                    "postCode": "SW3 1JJ",
                    "county": "London"
                  }
                },
                {
                  "name": "Lewisham",
                  "branchId": "400415",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "85 Lewisham High Street",
                    "city": "Lewisham",
                    "postCode": "SE13 6BE",
                    "county": "London"
                  }
                },
                {
                  "name": "London Bridge",
                  "branchId": "400621",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "28 Borough High Street",
                    "city": "Southwark",
                    "postCode": "SE1 1YB",
                    "county": "London"
                  }
                },
                {
                  "name": "London Bridge Relationship Management Centre",
                  "branchId": "407752",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "Second Floor, 28 Borough High Street",
                    "city": "Southwark",
                    "postCode": "SE1 1YB",
                    "county": "London"
                  }
                },
                {
                  "name": "Mayfair Relationship Management Centre",
                  "branchId": "407751",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "35 Park Lane",
                    "city": "",
                    "postCode": "W1K 1RB",
                    "county": "London"
                  }
                },
                {
                  "name": "Muswell Hill",
                  "branchId": "400437",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "88 The Broadway",
                    "city": "Muswell Hill",
                    "postCode": "N10 3RX",
                    "county": "London"
                  }
                },
                {
                  "name": "New Bond Street",
                  "branchId": "400501",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "129 New Bond Street",
                    "city": "New Bond Street",
                    "postCode": "W1S 1EA",
                    "county": "London"
                  }
                },
                {
                  "name": "North Finchley",
                  "branchId": "400507",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "789 High Road",
                    "city": "North Finchley",
                    "postCode": "N12 8JX",
                    "county": "London"
                  }
                },
                {
                  "name": "Oxford Circus",
                  "branchId": "400516",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "196 Oxford Street",
                    "city": "",
                    "postCode": "W1D 1NT",
                    "county": "London"
                  }
                },
                {
                  "name": "Paddington",
                  "branchId": "400519",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "2 Craven Road",
                    "city": "Paddington",
                    "postCode": "W2 3PY",
                    "county": "London"
                  }
                },
                {
                  "name": "Pall Mall",
                  "branchId": "400520",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "69 Pall Mall",
                    "city": "St James's",
                    "postCode": "SW1Y 5EY",
                    "county": "London"
                  }
                },
                {
                  "name": "Palmers Green",
                  "branchId": "400521",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "1 Aldermans Hill",
                    "city": "Palmers Green",
                    "postCode": "N13 4YE",
                    "county": "London"
                  }
                },
                {
                  "name": "Park Royal",
                  "branchId": "400523",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "69 Park Royal Road",
                    "city": "Park Royal",
                    "postCode": "NW10 7JR",
                    "county": "London"
                  }
                },
                {
                  "name": "Peckham",
                  "branchId": "400525",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "47 Rye Lane",
                    "city": "Peckham",
                    "postCode": "SE15 5ET",
                    "county": "London"
                  }
                },
                {
                  "name": "Putney",
                  "branchId": "400531",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "172 Upper Richmond Road",
                    "city": "Putney",
                    "postCode": "SW15 2SH",
                    "county": "London"
                  }
                },
                {
                  "name": "Russell Square",
                  "branchId": "400607",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "1 Woburn Place",
                    "city": "Russell Square",
                    "postCode": "WC1H 0LQ",
                    "county": "London"
                  }
                },
                {
                  "name": "South Woodford",
                  "branchId": "400623",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "20-21 Electric Parade, George Lane",
                    "city": "South Woodford",
                    "postCode": "E18 2LX",
                    "county": "London"
                  }
                },
                {
                  "name": "Southgate",
                  "branchId": "400618",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "17 The Broadway",
                    "city": "Southgate",
                    "postCode": "N14 6PP",
                    "county": "London"
                  }
                },
                {
                  "name": "Stratford",
                  "branchId": "400630",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "59-61 The MallStratford Centre",
                    "city": "Stratford",
                    "postCode": "E15 1XF",
                    "county": "London"
                  }
                },
                {
                  "name": "Streatham Hill",
                  "branchId": "400632",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "103 Streatham Hill",
                    "city": "Streatham",
                    "postCode": "SW2 4UE",
                    "county": "London"
                  }
                },
                {
                  "name": "Surrey Quays",
                  "branchId": "400641",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "Surrey Quays Shopping Centre",
                    "city": "Redriff Road",
                    "postCode": "SE16 7LL",
                    "county": "London"
                  }
                },
                {
                  "name": "Tooting Broadway",
                  "branchId": "400704",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "56 Tooting Broadway",
                    "city": "Tooting",
                    "postCode": "SW17 0RN",
                    "county": "London"
                  }
                },
                {
                  "name": "Tottenham Court Road",
                  "branchId": "400707",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "39 Tottenham Court Road",
                    "city": "",
                    "postCode": "W1T 2AR",
                    "county": "London"
                  }
                },
                {
                  "name": "Walthamstow",
                  "branchId": "400715",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "192 Hoe Street",
                    "city": "Walthamstow",
                    "postCode": "E17 4QN",
                    "county": "London"
                  }
                },
                {
                  "name": "Wandsworth",
                  "branchId": "400717",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "73 Wandsworth High Street",
                    "city": "Wandsworth",
                    "postCode": "SW18 2PT",
                    "county": "London"
                  }
                },
                {
                  "name": "Westfield Stratford City",
                  "branchId": "404365",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "Leyton Road",
                    "city": "Stratford",
                    "postCode": "E15 1AA",
                    "county": "London"
                  }
                },
                {
                  "name": "Whitechapel",
                  "branchId": "400233",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "75 Whitechapel Road",
                    "city": "Whitechapel",
                    "postCode": "E1 1DU",
                    "county": "London"
                  }
                },
                {
                  "name": "Wimbledon",
                  "branchId": "400730",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "5 Wimbledon Hill Road",
                    "city": "Wimbledon",
                    "postCode": "SW19 7NF",
                    "county": "London"
                  }
                },
                {
                  "name": "Wood Green",
                  "branchId": "400733",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "2 CheapsideHigh Road",
                    "city": "Wood Green",
                    "postCode": "N22 6HJ",
                    "county": "London"
                  }
                },
                {
                  "name": "Woolwich",
                  "branchId": "400735",
                  "latitude": "0.0",
                  "longitude": "0.0",
                  "address": {
                    "addressLine1": "15 Wellington Street",
                    "city": "Woolwich",
                    "postCode": "SE18 6PH",
                    "county": "London"
                  }
                }
              ]
            }
          }
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }
}
