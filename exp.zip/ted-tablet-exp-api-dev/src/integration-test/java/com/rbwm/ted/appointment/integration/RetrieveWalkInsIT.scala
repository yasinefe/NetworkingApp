/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

class RetrieveWalkInsIT extends Base {

  test("Retrieve walk ins") {
    val request =
      """
        {
          "query": "{ted{walkIns (locationId:\"400106\")  {appointmentId appointmentStatus locationId dateTime duration topicId topicCategoryId attendee{firstName lastName email} conductor{fullName employeeId} }}}",
          "variables": {}
        }
      """

    val expectedResponse =
      """
        {
        	"data": {
        		"ted": {
        			"walkIns": [{
        				"appointmentId": "58bece99c419ef40440654b8",
        				"appointmentStatus": "UPCOMING",
        				"locationId": "400106.0",
        				"dateTime": 1486894200000,
        				"duration": "90.0",
        				"topicId": "Current Account",
        				"topicCategoryId": "Review",
        				"attendee": {
        					"firstName": "John",
        					"lastName": "Smith",
        					"email": "john.smith@email.com"
        				},
        				"conductor": {
        					"fullName": "Edna Nashville",
        					"employeeId": "44443232"
        				}
        			}, {
        				"appointmentId": "58bece99c419ef40440654b9",
        				"appointmentStatus": "UPCOMING",
        				"locationId": "400106.0",
        				"dateTime": 1486894200000,
        				"duration": "90.0",
        				"topicId": "Mortgages",
        				"topicCategoryId": "Remortgage A Property",
        				"attendee": {
        					"firstName": "Peter",
        					"lastName": "Jones",
        					"email": "john.smith@email.com"
        				},
        				"conductor": {
        					"fullName": "Deborah Smithville",
        					"employeeId": "44443232"
        				}
        			}]
        		}
        	}
        }
      """

    val actualResponse = doPostWithAuth(request)
    doAssert(expectedResponse, actualResponse)
  }
}