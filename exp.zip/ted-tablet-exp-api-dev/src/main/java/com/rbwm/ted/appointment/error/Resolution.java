/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

/**
 * Created by 44052007 on 29/06/2017.
 */
@JsonInclude(NON_NULL)
public class Resolution {
    public final String code;
    public final String message;
    public final String description;
    public final String label;
    public final String link;

    @JsonCreator
    public Resolution(@JsonProperty("code") String code,
                      @JsonProperty("message") String message,
                      @JsonProperty("description") String description,
                      @JsonProperty("label") String label,
                      @JsonProperty("link") String link) {
        this.code = code;
        this.message = message;
        this.description = description;
        this.label = label;
        this.link = link;
    }

}
