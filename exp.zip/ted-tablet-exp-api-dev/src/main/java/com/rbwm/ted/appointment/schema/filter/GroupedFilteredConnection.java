/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.filter;

import com.rbwm.ted.appointment.schema.model.GroupedNode;
import com.rbwm.ted.appointment.schema.sort.ObjectFieldComparator;
import com.rbwm.ted.appointment.schema.sort.Sort;
import graphql.relay.Connection;
import graphql.relay.Edge;
import graphql.schema.DataFetchingEnvironment;
import reactor.core.publisher.Mono;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static com.rbwm.ted.appointment.schema.sort.SortFields.SORT_KEY;
import static com.rbwm.ted.appointment.schema.sort.SortFields.SORT_ORDER;
import static com.rbwm.ted.appointment.schema.sort.SortOrder.ASC;
import static com.rbwm.ted.appointment.schema.sort.SortOrder.valueOf;

/**
 * Created by 44093684 on 05/02/2018.
 */
public class GroupedFilteredConnection<T extends GroupedNode> extends FilteredConnection<T> {

    public GroupedFilteredConnection(List<T> data) {
        super(data);
    }

    public static <T extends GroupedNode> CompletableFuture<Connection<T>> mapGroupedConnectionFromMono(Mono<List<T>> monoData,
                                                                                                        DataFetchingEnvironment env) {

        return monoData
                .map(data -> new GroupedFilteredConnection<>(data).get(env))
                .toFuture();
    }

    @Override
    public Connection<T> get(DataFetchingEnvironment environment) {
        Connection<T> groupConnection = super.get(environment);
        applySort(groupConnection.getEdges(), environment);
        return groupConnection;
    }

    private void applySort(List<Edge<T>> edges, DataFetchingEnvironment environment) {
        List<LinkedHashMap<String, Object>> sortArguments = environment.getArgument("groupSort");
        if (sortArguments == null || sortArguments.isEmpty()) {
            return;
        }

        List<Sort> sorts = sortArguments.stream()
                .map(sortArgument -> new Sort((String) sortArgument.get(SORT_KEY.value), valueOf((String) sortArgument.getOrDefault(SORT_ORDER.value, ASC.name()))))
                .collect(Collectors.toList());


        Comparator<Comparable> comparator = new ObjectFieldComparator<>(sorts);

        edges.forEach(edge -> {
            GroupedNode<Comparable> groupedNode = edge.getNode();
            groupedNode.getGroup().sort(comparator);
        });
    }
}
