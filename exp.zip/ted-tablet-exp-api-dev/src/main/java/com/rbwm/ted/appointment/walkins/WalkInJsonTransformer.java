/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

import static com.rbwm.ted.appointment.model.AppointmentFields.*;
import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.relay;

/**
 * Created by 43578876 on 03/04/2017.
 */
public final class WalkInJsonTransformer {

    private WalkInJsonTransformer() {}

    private static final BiFunction<Map<String, Object>, String, Long> toLong = (walkIn, key) -> (walkIn.get(key) != null) ?
            new Double(String.valueOf(walkIn.get(key))).longValue() : null;

    public static final Function<Map<String, Object>, Map<String, Object>> transform = walkIn -> {
        walkIn.put("id", relay.toGlobalId("walkIn", walkIn.get(APPOINTMENT_ID.val()).toString()));
        walkIn.put(DATE_TIME.val(), toLong.apply(walkIn, DATE_TIME.val()));
        walkIn.put(STARTED_AT.val(), toLong.apply(walkIn, STARTED_AT.val()));
        walkIn.put(DURATION.val(), toLong.apply(walkIn, DURATION.val()));
        walkIn.put(OVERDUE_OFFSET.val(), toLong.apply(walkIn, OVERDUE_OFFSET.val()));
        walkIn.put(TOPIC_NAME.val(), walkIn.get(TOPIC_ID.val()));
        walkIn.put(TOPIC_CATEGORY_NAME.val(), walkIn.get(TOPIC_CATEGORY_ID.val()));
        walkIn.put(TOPIC_SUB_CATEGORY_NAME.val(), walkIn.get(TOPIC_SUB_CATEGORY_ID.val()));
        walkIn.put(ENDED_AT.val(), toLong.apply(walkIn, ENDED_AT.val()));
        return walkIn;
    };


}
