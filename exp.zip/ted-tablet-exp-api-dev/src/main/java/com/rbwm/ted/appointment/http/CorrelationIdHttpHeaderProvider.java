/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.http;

import com.hsbc.rbwm.ted.rest.api.HttpHeaderProvider;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.springframework.http.HttpHeaders;

import java.util.List;
import java.util.Map;

import static com.rbwm.ted.telemetry.correlation.CorrelationIdGenerator.CORRELATION_ID_HEADER;
import static java.util.Collections.singletonList;

/**
 * Created by 44052007 on 13/07/2017.
 */
public class CorrelationIdHttpHeaderProvider implements HttpHeaderProvider {

    public Map<String, List<String>> getHttpHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.put(CORRELATION_ID_HEADER, singletonList(CorrelationIdContainer.getId()));
        return httpHeaders;
    }

}
