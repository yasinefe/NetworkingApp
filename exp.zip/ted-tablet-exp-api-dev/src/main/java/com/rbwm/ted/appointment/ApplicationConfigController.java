/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.rbwm.ted.appointment.api.ContentMetadataServiceApi;
import com.rbwm.ted.appointment.error.Error;
import com.rbwm.ted.appointment.error.ErrorHandler;
import com.rbwm.ted.appointment.error.Resolution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by 44027117 on 09/05/2017.
 */
@Controller
@RequestMapping(value = "/config")
public class ApplicationConfigController {

    private final ErrorHandler errorHandler;
    private final MessageSource messageSource;
    private final ContentMetadataServiceApi contentMetadataServiceApi;


    @Autowired
    public ApplicationConfigController(ErrorHandler errorHandler, MessageSource messageSource, ContentMetadataServiceApi contentMetadataServiceApi) {
        this.errorHandler = errorHandler;
        this.messageSource = messageSource;
        this.contentMetadataServiceApi = contentMetadataServiceApi;
    }

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public Mono<Map<String, Object>> config(Locale locale) {
        List<Resolution> resolutions = errorHandler.getResolutions().stream()
                .map(resolution -> localize(resolution, locale)).collect(Collectors.toList());
        return contentMetadataServiceApi.getContentMetadata().map(metadata ->
                new HashMap<String, Object>() {{
                    put("errorList", errorHandler.getErrors().stream()
                            .collect(Collectors.toMap(error -> error.code, error -> localize(error, locale, resolutions))));
                    put("helpMetadata", metadata);
                }});
    }

    private Error localize(Error error, Locale locale, List<Resolution> resolutions) {
        Error localisedError = new Error(error.code, getLocalMessage(error.message, locale),
                error.level, error.httpStatus, error.resolutionCodes);
        localisedError.populateResolutions(resolutions);
        return localisedError;
    }

    private Resolution localize(Resolution resolution, Locale locale) {
        return new Resolution(resolution.code,
                getLocalMessage(resolution.message, locale),
                getLocalMessage(resolution.description, locale),
                getLocalMessage(resolution.label, locale),
                resolution.link);
    }

    private String getLocalMessage(String key, Locale locale) {
        return messageSource.getMessage(key, null, key, locale);
    }

}
