/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import com.hsbc.rbwm.ted.rest.api.ClientRestTemplate;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRestBuilder;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.http.HttpErrorHandler;
import com.hsbc.rbwm.ted.rest.http.HttpErrorResponseBuilder;
import com.rbwm.ted.appointment.http.CorrelationIdHttpHeaderProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Created by 44052007 on 29/11/2017.
 */
@Configuration
public class LoginConfiguration {

    @Value("${ted.login.hostname}")
    private String loginHostname;

    @Value("${ted.login.uri}")
    private String loginUri;

    @Autowired
    private ClientRestTemplate asyncClientRestTemplate;

    public ReactiveCRUDRestBuilder loginCRUDRestBuilder(String featurePrefix) {
        ErrorResponse errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix(HttpConfiguration.APPLICATION_PREFIX)
                        .withFeatureErrorCodePrefix(featurePrefix)
                        .build();

        return new ReactiveCRUDRestBuilder()
                .withClientRestTemplate(asyncClientRestTemplate)
                .withErrorHandler(new HttpErrorHandler(errorsResponse))
                .addHttpHeaderProvider(new CorrelationIdHttpHeaderProvider())
                .withHostname(loginHostname);
    }

    public String getLoginUri() {
        return loginUri;
    }

}
