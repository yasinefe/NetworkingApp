/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.api.MeetingServiceApi;
import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.model.MeetingStatus;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.resolveId;

/**
 * Created by 44052007 on 16/05/2018.
 */
@Component
public class MeetingUpdater {

    public final DataFetcher<CompletableFuture> changeStatus;
    public final DataFetcher<CompletableFuture> checkIn;

    @Autowired
    public MeetingUpdater(MeetingServiceApi meetingServiceApi) {
        changeStatus = env -> {
            Map<String, Object> input = env.getArgument("input");
            String meetingId = resolveId.apply((String)input.get("id"));
            MeetingStatus meetingStatus = MeetingStatus.valueOf((String) input.get("meetingStatus"));

            return meetingServiceApi.changeMeetingStatus(meetingId, meetingStatus).map(meeting -> {
                Map<String, Object> result = new LinkedHashMap<>();
                result.put("clientMutationId", input.get("clientMutationId"));
                result.put("meeting", meeting);

                audit(env, meetingId, AuditableAction.MEETING_CHANGE_STATUS);

                return result;
            }).toFuture();
        };

        checkIn = env -> {
            Map<String, Object> input = env.getArgument("input");
            String meetingId = resolveId.apply((String)input.get("id"));
            Boolean proofOfId = (Boolean) input.get("proofOfId");

            return meetingServiceApi.checkInMeeting(meetingId, proofOfId).map(meeting -> {
                Map<String, Object> result = new LinkedHashMap<>();
                result.put("clientMutationId", input.get("clientMutationId"));
                result.put("meeting", meeting);

                audit(env, meetingId, AuditableAction.MEETING_CHECK_IN);

                return result;
            }).toFuture();
        };
    }

    private void audit(DataFetchingEnvironment env, String entityId, AuditableAction auditableAction) {
        GraphQLContext graphQLContext = env.getContext();
        graphQLContext.getDataFetcherAudit()
                .withAuditAction(auditableAction)
                .withEntityId(entityId);
    }

}
