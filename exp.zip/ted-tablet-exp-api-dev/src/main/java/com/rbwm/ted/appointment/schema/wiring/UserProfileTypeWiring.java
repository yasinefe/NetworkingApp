/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.wiring;

import com.rbwm.ted.appointment.schema.fetcher.AuthorisationDataFetcher;
import com.rbwm.ted.appointment.schema.fetcher.BranchesDataFetcher;
import com.rbwm.ted.appointment.schema.fetcher.RootDataFetcher;
import com.rbwm.ted.appointment.schema.fetcher.UserProfileDataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;

/**
 * Created by 44052007 on 17/01/2018.
 */
@Component
public class UserProfileTypeWiring extends AbstractTypeWiring {

    @Autowired
    public UserProfileTypeWiring(RootDataFetcher rootDataFetcher,
                                 BranchesDataFetcher branchesDataFetcher,
                                 AuthorisationDataFetcher authorisationDataFetcher,
                                 UserProfileDataFetcher userProfileDataFetcher) {
        addTypeWiring(newTypeWiring("UserProfile")
                .dataFetcher("id", env -> rootDataFetcher.nodeIdBuilder.apply("UserProfile", env))
                .dataFetcher("branch", branchesDataFetcher.branchFetcherBySourceId)
                .dataFetcher("authorisation", authorisationDataFetcher.authorisationFetcher)
                .dataFetcher("trackings", userProfileDataFetcher.getUserTrackingsFetcher));
    }

}


