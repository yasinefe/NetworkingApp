/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.meetings;

import com.rbwm.ted.appointment.model.Gender;
import lombok.EqualsAndHashCode;

/**
 * Created by 44052007 on 17/05/2018.
 */
@EqualsAndHashCode
public class MeetingInput {

    public final String branchId;
    public final Gender gender;
    public final String firstName;
    public final String lastName;
    public final String topicId;
    public final String topicCategoryId;
    public final String topicSubCategoryId;
    public final Boolean proofOfId;
    public final String comments;

    public MeetingInput(String branchId, Gender gender, String firstName, String lastName, String topicId,
                        String topicCategoryId, String topicSubCategoryId, Boolean proofOfId, String comments) {
        this.branchId = branchId;
        this.gender = gender;
        this.firstName = firstName;
        this.lastName = lastName;
        this.topicId = topicId;
        this.topicCategoryId = topicCategoryId;
        this.topicSubCategoryId = topicSubCategoryId;
        this.proofOfId = proofOfId;
        this.comments = comments;
    }
}
