/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.api.AppointmentBookingServiceApi;
import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.LinkedHashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.audit.AuditableAction.APPOINTMENT_CHECK_IN;
import static com.rbwm.ted.appointment.audit.AuditableAction.APPOINTMENT_STATUS_CHANGE;
import static com.rbwm.ted.appointment.model.AppointmentFields.*;
import static com.rbwm.ted.appointment.model.AppointmentStatus.CHECKED_IN;

/**
 * Created by 43578876 on 10/11/2016.
 */
@Component
public class AppointmentDataUpdater {

    public final DataFetcher updateAppointmentStatus;
    public final DataFetcher checkIn;

    @Autowired
    public AppointmentDataUpdater(AppointmentBookingServiceApi appointmentBookingService) {

        updateAppointmentStatus = env -> {
            Map<String, Object> input = env.getArgument("input");
            GraphQLContext graphQLContext = env.getContext();

            String appointmentId = (String) input.get(APPOINTMENT_ID.val());
            AppointmentStatus appointmentStatus = AppointmentStatus.valueOf((String) input.get(APPOINTMENT_STATUS.val()));

            return appointmentBookingService.updateAppointmentStatus(appointmentId, appointmentStatus).map(appointment -> {
                setDataFetcherAuditData(graphQLContext.getDataFetcherAudit(), appointmentId, APPOINTMENT_STATUS_CHANGE);

                Map<String, Object> result = new LinkedHashMap<>();
                result.put("clientMutationId", input.get("clientMutationId"));
                result.put(APPOINTMENT_ID.val(), appointmentId);
                return result;
            }).toFuture();
        };

        checkIn = env -> {
            Map<String, Object> input = env.getArgument("input");
            GraphQLContext graphQLContext = env.getContext();

            String appointmentId = (String) input.get(APPOINTMENT_ID.val());
            Boolean proofOfId = (Boolean) input.get(PROOF_OF_ID.val());

            Mono<Map<String, Object>> mapMono1 = appointmentBookingService.updateProofOfId(appointmentId, proofOfId);
            return mapMono1.then(appointmentBookingService.updateAppointmentStatus(appointmentId, CHECKED_IN)).map(app -> {
                setDataFetcherAuditData(graphQLContext.getDataFetcherAudit(), appointmentId, APPOINTMENT_CHECK_IN);

                Map<String, Object> result = new LinkedHashMap<>();
                result.put("clientMutationId", input.get("clientMutationId"));
                result.put(APPOINTMENT_ID.val(), appointmentId);
                return result;
            }).toFuture();
        };
    }

    private void setDataFetcherAuditData(DataFetcherAudit.Builder dataFetcherAuditBuilder, String appointmentId, AuditableAction auditableAction) {
        dataFetcherAuditBuilder.withEntityId(appointmentId);
        dataFetcherAuditBuilder.withAuditAction(auditableAction);
    }

}
