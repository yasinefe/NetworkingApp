/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rbwm.ted.appointment.authentication.AuthenticationFacade;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import static com.rbwm.ted.appointment.model.Headers.*;

/**
 * Created by 44052007 on 19/01/2018.
 */
@RestController
@RequestMapping("/report")
public class ReportingController {

    private Logger logger = LoggerFactory.getLogger(ReportingController.class);

    private final AuthenticationFacade authenticationFacade;

    private final ObjectMapper objectMapper;

    @Autowired
    public ReportingController(AuthenticationFacade authenticationFacade, ObjectMapper objectMapper) {
        this.authenticationFacade = authenticationFacade;
        this.objectMapper = objectMapper;
    }

    @RequestMapping(path = "/error", method = RequestMethod.POST)
    public void error(@RequestBody Map body,
                      @RequestHeader(value = BRANCH_ID_HEADER, required = false) String branchId,
                      @RequestHeader(value = MACHINE_ID_HEADER, required = false) String machineId,
                      @RequestHeader(value = WIFI_MAC_ADDRESS_HEADER, required = false) String wifiMACAddress,
                      @RequestHeader(value = COUNTRY_CODE_HEADER, required = false) String countryCode) throws JsonProcessingException {
        log(authenticationFacade.getAuthentication().getName(), branchId, machineId, wifiMACAddress, countryCode, CorrelationIdContainer.getId(), body);
    }

    private void log(String userId, String branchId, String machineId, String wifiMACAddress, String countryCode, String correlationId, Map body) throws JsonProcessingException {
        logger.error("ErrorType=UI UserId={} BranchId={} MachineId={} WifiMacAddress={} CountryCode={} CorrelationId={} ErrorDetail='{}'",
                userId, branchId, machineId, wifiMACAddress, countryCode, correlationId, StringUtils.replaceChars(objectMapper.writeValueAsString(body), "'", ""));
    }

}
