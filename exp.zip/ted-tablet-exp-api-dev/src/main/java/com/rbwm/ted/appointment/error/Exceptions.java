/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import com.hsbc.rbwm.ted.rest.error.ErrorCode;
import com.hsbc.rbwm.ted.rest.error.Exceptions.ServerException;

/**
 * Created by 44052007 on 10/04/2017.
 */
public class Exceptions {

    public static final ErrorCode TEE_INVALID_PARAMETER = new ErrorCode("TEE-INVALID-PARAMETER");
    public static final ErrorCode TEE_INVALID_GRAPHQL = new ErrorCode("TEE-INVALID-GRAPHQL");
    public static final ErrorCode TEE_UNEXPECTED_ERROR = new ErrorCode("TEE-UNEXPECTED-ERROR");

    private Exceptions() {}

    public static class InvalidRequestException extends ServerException {
        public InvalidRequestException(ErrorCode errorCode, Throwable rootCause, String message) {
            super(errorCode, rootCause, message);
        }
    }
}
