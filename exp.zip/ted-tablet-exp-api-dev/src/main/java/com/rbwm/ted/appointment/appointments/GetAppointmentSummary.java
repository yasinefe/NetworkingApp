/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentBookingConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.*;

/**
 * Created by 44052007 on 19/06/2017.
 */
@Component
public class GetAppointmentSummary {

    private final ReactiveCRUDRest crudRest;
    private final AppointmentBookingConfiguration appointmentBookingConfiguration;
    private final ReactiveResponseHandler<Map<String,Object>> responseHandler;
    private static final String FEATURE_PREFIX = "GET-APPOINTMENT-SUMMARY";

    @Autowired
    public GetAppointmentSummary(AppointmentBookingConfiguration appointmentBookingConfiguration,
                                 ReactiveResponseHandler<Map<String,Object>> responseHandler) {
        this.appointmentBookingConfiguration = appointmentBookingConfiguration;
        this.responseHandler = responseHandler;

        crudRest = appointmentBookingConfiguration.appointmentBookingCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<List<Map<String,Object>>> getAppointmentSummary(String branchId, Set<String> statuses) {
        return responseHandler.extractBody(crudRest.doGet(getUri(branchId), createRequestParams(statuses), String.class))
                .map(AppointmentSummaryTransformer.transform);
    }

    private Map<String, List<String>> createRequestParams(Set<String> status) {
        Map<String, List<String>> requestParams = new HashMap<>();
        requestParams.put("status", new ArrayList(status));
        return requestParams;
    }

    private String getUri(String branchId) {
        return appointmentBookingConfiguration.getAppointmentsListUri() + "/summary/branch/" + branchId;
    }
}
