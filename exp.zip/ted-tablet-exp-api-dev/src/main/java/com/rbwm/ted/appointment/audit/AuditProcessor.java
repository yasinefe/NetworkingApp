/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.audit;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.AuditConfiguration;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Created by 44027117 on 10/04/2017.
 */
@Service
public class AuditProcessor {

    private final ReactiveCRUDRest crudRest;
    private final AuditConfiguration auditConfiguration;
    private static final String FEATURE_PREFIX = "CREATE-AUDIT";

    @Autowired
    public AuditProcessor(AuditConfiguration auditConfiguration) {
        this.auditConfiguration = auditConfiguration;
        this.crudRest = auditConfiguration.auditCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    @Async
    public void sendEvent(AuditContext auditContext) {
        CorrelationIdContainer.setId(auditContext.correlationId);
        crudRest.doPost(auditConfiguration.getAuditUri(), auditContext, String.class).block();
    }

}
