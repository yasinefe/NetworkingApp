/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.filter;

import com.rbwm.ted.appointment.schema.sort.ObjectFieldComparator;
import com.rbwm.ted.appointment.schema.sort.Sort;
import graphql.GraphQLException;
import graphql.Scalars;
import graphql.relay.Connection;
import graphql.relay.Relay;
import graphql.relay.SimpleListConnection;
import graphql.schema.*;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Mono;

import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static com.rbwm.ted.appointment.schema.sort.SortFields.*;
import static com.rbwm.ted.appointment.schema.sort.SortOrder.ASC;
import static com.rbwm.ted.appointment.schema.sort.SortOrder.valueOf;
import static java.util.stream.Collectors.toList;

/**
 * Created by 44052007 on 17/10/2017.
 */
public class FilteredConnection<T> implements DataFetcher<Connection<T>> {

    private static final String NOT_EQUAL = "_not";
    private static final String CONTAINS = "_contains";
    private static final String NOT_CONTAINS = "_not_contains";
    private static final String STARTS_WITH = "_starts_with";
    private static final String NOT_STARTS_WITH = "_not_starts_with";

    private List<T> data;

    public FilteredConnection(List<T> data) {
        this.data = data;
    }

    public static <T> CompletableFuture<Connection<T>> mapConnectionFromMono(Mono<List<T>> monoData,
                                                                             DataFetchingEnvironment env) {

        return monoData
                .map(data -> new FilteredConnection<>(data).get(env))
                .toFuture();
    }

    @Override
    public Connection<T> get(DataFetchingEnvironment environment) {
        List<T> filteredData = applyFilters(environment);
        applySort(environment, filteredData);
        return new SimpleListConnection<>(filteredData).get(environment);
    }

    private List<T> applyFilters(DataFetchingEnvironment environment) {
        List<T> filteredData = new LinkedList<>(data);
        Map<String, Object> filter = environment.getArgument("filter");
        if (filter == null) {
            return filteredData;
        }

        GraphQLObjectType connectionType = (GraphQLObjectType) environment.getFieldType();
        GraphQLList edgeType = getWrappedType(connectionType.getFieldDefinition("edges").getType());
        GraphQLObjectType edgeObjectType = getWrappedType((GraphQLOutputType)edgeType.getWrappedType());
        GraphQLObjectType outputObjectType = getWrappedType(edgeObjectType.getFieldDefinition("node").getType());
        List<GraphQLFieldDefinition> fieldDefinitions = outputObjectType.getFieldDefinitions();


        for (GraphQLFieldDefinition graphQLFieldDefinition : fieldDefinitions) {
            GraphQLOutputType type = getType(graphQLFieldDefinition.getType());

            if (type == Scalars.GraphQLString) {
                filteredData = applyStringFilters(filteredData, graphQLFieldDefinition.getName(), filter);
            }
            if (type == Scalars.GraphQLID) {
                filteredData = applyIdFilters(filteredData, graphQLFieldDefinition.getName(), filter);
            }
            if (type == Scalars.GraphQLBoolean) {
                filteredData = applyBooleanFilters(filteredData, graphQLFieldDefinition.getName(), filter);
            }
        }

        return filteredData;
    }

    private <R> R getWrappedType(GraphQLOutputType type) {
        if (type instanceof GraphQLNonNull) {
            return (R)((GraphQLNonNull) type).getWrappedType();
        }
        return (R)type;
    }

    private void applySort(DataFetchingEnvironment environment, List<T> filteredData) {
        List<LinkedHashMap<String, Object>> sortArguments = environment.getArgument(SORT.value);
        if (sortArguments == null || sortArguments.isEmpty()) {
            return;
        }

        List<Sort> sorts = sortArguments.stream()
                .map(sortArgument -> new Sort((String) sortArgument.get(SORT_KEY.value), valueOf((String) sortArgument.getOrDefault(SORT_ORDER.value, ASC.name()))))
                .collect(Collectors.toList());

        Comparator<T> comparator = new ObjectFieldComparator<>(sorts);
        filteredData.sort(comparator);
    }

    private static GraphQLOutputType getType(GraphQLOutputType graphQLOutputType) {
        if (graphQLOutputType instanceof GraphQLModifiedType) {
            return (GraphQLOutputType) ((GraphQLModifiedType) graphQLOutputType).getWrappedType();
        }
        return graphQLOutputType;
    }

    private List<T> applyStringFilters(List<T> data, String fieldName, Map<String, Object> filter) {
        return data.stream()
                .filter(obj -> applyStringEqualFilter(obj, fieldName, (String) filter.get(fieldName)))
                .filter(obj -> applyStringNotEqualFilter(obj, fieldName, (String) filter.get(fieldName + NOT_EQUAL)))
                .filter(obj -> applyStringContainsFilter(obj, fieldName, (String) filter.get(fieldName + CONTAINS)))
                .filter(obj -> applyStringNotContainsFilter(obj, fieldName, (String) filter.get(fieldName + NOT_CONTAINS)))
                .filter(obj -> applyStringStartsWithFilter(obj, fieldName, (String) filter.get(fieldName + STARTS_WITH)))
                .filter(obj -> applyStringNotStartsWithFilter(obj, fieldName, (String) filter.get(fieldName + NOT_STARTS_WITH)))
                .collect(toList());
    }

    private List<T> applyIdFilters(List<T> data, String fieldName, Map<String, Object> filter) {
        return data.stream()
                .filter(obj -> applyIdEqualFilter(obj, fieldName, (String) filter.get(fieldName)))
                .filter(obj -> applyIdNotEqualFilter(obj, fieldName, (String) filter.get(fieldName + NOT_EQUAL)))
                .collect(toList());
    }

    private List<T> applyBooleanFilters(List<T> data, String fieldName, Map<String, Object> filter) {
        return data.stream()
                .filter(obj -> applyBooleanEqualFilter(obj, fieldName, (Boolean) filter.get(fieldName)))
                .collect(toList());
    }

    private boolean applyBooleanEqualFilter(T obj, String fieldName, Boolean value) {
        return value == null || Objects.equals(value, getFieldValue(obj, fieldName));
    }

    private boolean applyIdEqualFilter(T obj, String fieldName, String value) {
        return value == null || getFieldValue(obj, fieldName).equals(new Relay().fromGlobalId(value).getId());
    }

    private boolean applyIdNotEqualFilter(T obj, String fieldName, String value) {
        return value == null || !getFieldValue(obj, fieldName).equals(new Relay().fromGlobalId(value).getId());
    }

    private boolean applyStringEqualFilter(T obj, String fieldName, String value) {
        return value == null || Objects.equals(value, getFieldValue(obj, fieldName));
    }

    private boolean applyStringNotEqualFilter(T obj, String fieldName, String value) {
        return value == null || !Objects.equals(value, getFieldValue(obj, fieldName));
    }

    private boolean applyStringContainsFilter(T obj, String fieldName, String value) {
        return value == null || StringUtils.contains(getFieldValue(obj, fieldName), value);
    }

    private boolean applyStringNotContainsFilter(T obj, String fieldName, String value) {
        return value == null || !StringUtils.contains(getFieldValue(obj, fieldName), value);
    }

    private boolean applyStringStartsWithFilter(T obj, String fieldName, String value) {
        return value == null || StringUtils.startsWith(getFieldValue(obj, fieldName), value);
    }

    private boolean applyStringNotStartsWithFilter(T obj, String fieldName, String value) {
        return value == null || !StringUtils.startsWith(getFieldValue(obj, fieldName), value);
    }

    private <R> R getFieldValue(T obj, String fieldName) {
        try {
            Field field = obj.getClass().getField(fieldName);
            return (R) field.get(obj);
        } catch (NoSuchFieldException e) {
            throw new GraphQLException("field " + fieldName + " not found", e);
        } catch (IllegalAccessException e) {
            throw new GraphQLException("illegal access to field " + fieldName, e);
        }
    }

}
