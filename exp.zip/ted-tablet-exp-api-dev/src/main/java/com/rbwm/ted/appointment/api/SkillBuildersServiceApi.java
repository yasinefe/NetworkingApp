/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.api;

import com.rbwm.ted.appointment.schema.model.VideoGroup;
import com.rbwm.ted.appointment.schema.model.VideoSummary;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * Created by 44093684 on 22/01/2018.
 */
public interface SkillBuildersServiceApi {

    Mono<VideoSummary> getSummary(Map<String, Object> filters, String countryCode, String branchId);

    Mono<List<VideoGroup>> getVideoGroups(Map<String, Object> filters, String groupBy, String countryCode, String branchId);

}
