/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.news;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.springframework.util.StringUtils;

/**
 * Created by 44052007 on 09/02/2018.
 */
@EqualsAndHashCode
@ToString
public class NewsArticle {

    public final String title;
    public final String uri;
    public final String source;
    public final String description;
    public final Long publishedOn;
    public final Boolean mandatory;


    @JsonCreator
    public NewsArticle(@JsonProperty("title") String title,
                       @JsonProperty("link") String uri,
                       @JsonProperty("source") String source,
                       @JsonProperty("description") String description,
                       @JsonProperty("pubDate") Long publishedOn,
                       @JsonProperty("mandatory") Boolean mandatory) {
        this.title = title;
        this.uri = uri;
        this.source = StringUtils.isEmpty(source) ? "Group News" : source;
        this.description = description;
        this.publishedOn = publishedOn;
        this.mandatory = mandatory;
    }
}
