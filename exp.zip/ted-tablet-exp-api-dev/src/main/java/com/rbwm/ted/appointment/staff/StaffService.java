/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.staff;

import com.rbwm.ted.appointment.api.StaffServiceApi;
import com.rbwm.ted.appointment.schema.model.Staff;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Created by 44052007 on 15/11/2017.
 */
@Service
public class StaffService implements StaffServiceApi {

    private final GetStaff getStaff;
    private final GetAllStaff getAllStaff;

    @Autowired
    public StaffService(GetStaff getStaff, GetAllStaff getAllStaff) {
        this.getStaff = getStaff;
        this.getAllStaff = getAllStaff;
    }

    @Override
    public Mono<List<Staff>> getAllStaff(String branchId) {
        return getAllStaff.get(branchId);
    }

    @Override
    public Mono<Staff> getStaff(String employeeId) {
        return getStaff.get(employeeId);
    }
}
