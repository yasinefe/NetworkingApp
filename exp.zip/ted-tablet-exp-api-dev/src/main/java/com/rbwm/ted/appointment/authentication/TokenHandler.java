/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.authentication;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;

import static com.rbwm.ted.appointment.authentication.TokenHandler.TokenValidator.*;

/**
 * Created by 44027117 on 31/01/2017.
 */
@Component
public class TokenHandler {

    private static final String SECRET_KEY = "fdsafdasfdasfsdafsdaf"; // Pending to move somewhere else
    private static final String HMAC_ALGO = "HmacSHA256";
    private static final String TOKEN_PREFIX = "Bearer ";

    private static Logger log = LoggerFactory.getLogger(TokenHandler.class);

    public Optional<String> parseUserFromToken(String header) {

        if (TokenValidator.isTokenBearer.apply(header)) {
            final String tokenCoded = TokenValidator.extractTokenFromHeader.apply(header);
            final byte[] tokenBytes = Base64Utils.decodeFromString(tokenCoded);
            return validate(tokenBytes);
        }
        log.warn("Invalid header");
        return Optional.empty();
    }

    private Optional<String> validate(final byte[] tokenBytes) {

        byte[] userBytes = extractUser.apply(tokenBytes);

        if ( userValidate.apply(userBytes) &&
                validHash.apply(userBytes, extractHash.apply(tokenBytes))
                // && validateExpirationTime.apply(extractExpirationTime.apply(tokenBytes))
        ) {
            return Optional.of(new String(userBytes));
        } else {
            log.warn("Invalid token");
            return Optional.empty();
        }
    }

    static class TokenValidator {

        private interface ValidatorS extends Function<String, Boolean> {}
        private interface Validator extends Function<byte[], Boolean> {}

        static Function<String,String> extractTokenFromHeader = header -> header.substring(TOKEN_PREFIX.length()).trim();

        private static ValidatorS isTokenBearer = header -> header.contains(TOKEN_PREFIX);

        static Function<byte[],byte[]> extractUser = token ->  Arrays.copyOfRange(token,0,8);
        static Function<byte[],byte[]> extractHash = token ->  token.length >9 ? Arrays.copyOfRange(token, 9 , token.length - 11) : "".getBytes();
        
        private static Validator userLength = user -> user.length == 8;
        private static Validator isNumeric = userBytes -> new String(userBytes).matches("^[0-9]+$");

        static BiFunction<byte[], byte[], Boolean> validHash = (user, hash) -> Arrays.equals(createHmac(user),hash);

        static List<Validator> validators = Arrays.asList(
                userLength,
                isNumeric
        );

        static Validator userValidate = cred -> validators.stream()
                .allMatch(validator -> validator.apply(cred));

        static byte[] createHmac(byte[] content) {
            try {
                Mac hmac = Mac.getInstance(HMAC_ALGO);
                hmac.init(new SecretKeySpec(SECRET_KEY.getBytes(), HMAC_ALGO));
                return hmac.doFinal(content);

            } catch (NoSuchAlgorithmException | InvalidKeyException e) {
                log.warn("Failed generating the token hash-based [{}], [{}]", e.getMessage(), e);
                return new byte[0];
            }
        }
    }
}
