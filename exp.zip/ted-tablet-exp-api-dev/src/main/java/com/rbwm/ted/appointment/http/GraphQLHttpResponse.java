/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.http;

import com.fasterxml.jackson.annotation.JsonValue;
import com.hsbc.rbwm.ted.rest.error.ErrorCode;
import com.hsbc.rbwm.ted.rest.error.Exceptions.ServerException;
import com.hsbc.rbwm.ted.rest.error.Exceptions.UnexpectedException;
import com.rbwm.ted.appointment.error.ErrorHandler;
import com.rbwm.ted.appointment.error.ErrorLogging;
import com.rbwm.ted.appointment.error.ErrorLogging.ErrorLog;
import com.rbwm.ted.appointment.error.Exceptions.InvalidRequestException;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.*;
import org.springframework.http.HttpStatus;

import java.util.*;
import java.util.concurrent.CompletionException;
import java.util.stream.Collectors;

import static com.rbwm.ted.appointment.error.Exceptions.TEE_INVALID_GRAPHQL;
import static com.rbwm.ted.appointment.error.Exceptions.TEE_UNEXPECTED_ERROR;
import static graphql.ExecutionInput.newExecutionInput;

/**
 * Created by javierbracerotorres on 16/11/2016.
 */
public class GraphQLHttpResponse {
    private static final String ERRORS = "errors";
    private static final String DATA = "data";

    private List<ErrorCode> errors = new LinkedList<>();
    private Map<String, Object> response = new HashMap<>();
    private HttpStatus httpStatus = HttpStatus.OK;
    private ErrorHandler errorHandler;
    private ErrorLogging errorLogging;
    private ErrorLog errorLog;

    public GraphQLHttpResponse(GraphQL graphql, String query, GraphQLContext context, Map<String,
            Object> arguments, ErrorHandler errorHandler, ErrorLogging errorLogging) {
        this.errorHandler = errorHandler;
        this.errorLogging = errorLogging;
        this.errorLog = new ErrorLog()
                .add("BranchId", context.getBranchId())
                .add("MachineId", context.getMachineId())
                .add("WifiMacAddress", context.getWifiMacAddress());

        try {
            ExecutionResult result = graphql.execute(newExecutionInput().context(context).query(query).variables(arguments));
            errors = extractErrors(result);
            response = buildResponse(result, errors);
        } catch (GraphQLException e) {
            // Invalid GraphQL query
            httpStatus = HttpStatus.BAD_REQUEST;
            InvalidRequestException invalidRequestException = new InvalidRequestException(TEE_INVALID_GRAPHQL, e, e.getMessage());
            errorLogging.log(errorHandler.getError(invalidRequestException), invalidRequestException, errorLog);
            errors.add(createErrorCode(invalidRequestException));
            response.put(ERRORS, errors);
        }
    }

    private Map<String, Object> buildResponse(ExecutionResult result,
                                              List<ErrorCode> errors) {
        Map<String, Object> responseMap = new HashMap<>();
        if (!errors.isEmpty()) {
            responseMap.put(ERRORS, errors);
        }
        responseMap.put(DATA, result.getData());
        return responseMap;
    }

    private List<ErrorCode> extractErrors(ExecutionResult result) {
        return result==null || result.getErrors().isEmpty()?
                Collections.EMPTY_LIST:
                result.getErrors().stream()
                        .map(e -> mapErrors(e))
                        .collect(Collectors.toList());
    }

    private ErrorCode mapErrors(GraphQLError e) {
        if (e instanceof ExceptionWhileDataFetching) {
            ExceptionWhileDataFetching exceptionWhileDataFetching = (ExceptionWhileDataFetching) e;
            Throwable exception = exceptionWhileDataFetching.getException();

            if (exception instanceof CompletionException) {
                exception = exception.getCause();
            }
            if (exception instanceof InvalidRequestException) {
                // Invalid Request not validated by GraphQL
                httpStatus = HttpStatus.BAD_REQUEST;
            }
            if (exception instanceof ServerException) {
                ServerException serverException = (ServerException) exception;
                errorLogging.log(errorHandler.getError(serverException), serverException, errorLog);
                return createErrorCode(serverException);
            } else {
                UnexpectedException serverException = new UnexpectedException(TEE_UNEXPECTED_ERROR, exception, exception.getMessage());
                errorLogging.log(errorHandler.getError(serverException), exception, errorLog);
                return createErrorCode(serverException);
            }
        } else {
            // Example: Missing GraphQL arguments in the request
            httpStatus = HttpStatus.BAD_REQUEST;
            InvalidRequestException invalidRequestException = new InvalidRequestException(TEE_INVALID_GRAPHQL, null, e.getMessage());
            errorLogging.log(errorHandler.getError(invalidRequestException), invalidRequestException, errorLog);
            return createErrorCode(invalidRequestException);
        }
    }

    private ErrorCode createErrorCode(ServerException exception) {
        return new ErrorCode(exception.getErrorCode().code, exception.getMessage());
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    @JsonValue
    public Map<String, Object> getResponse() {
        return response;
    }

    public List<ErrorCode> getErrors() {
        return errors;
    }

}
