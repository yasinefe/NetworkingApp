/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.login;

import com.rbwm.ted.appointment.api.LoginServiceApi;
import com.rbwm.ted.appointment.user.UpdateLoginUserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

/**
 * Created by 44052007 on 29/11/2017.
 */
@Service
public class LoginService implements LoginServiceApi {

    private final UserLogin userLogin;
    private final UpdateLoginUserProfile updateLoginUserProfile;

    @Autowired
    public LoginService(UserLogin userLogin, UpdateLoginUserProfile updateLoginUserProfile) {
        this.userLogin = userLogin;
        this.updateLoginUserProfile = updateLoginUserProfile;
    }

    @Override
    public Mono<LoginResponse> login(Credentials credentials) {
        return userLogin.login(credentials).map(loginResponse -> {
            updateLoginUserProfile.update(loginResponse.user.employeeId).subscribe();
            return loginResponse;
        });
    }

}
