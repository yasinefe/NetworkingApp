/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.schema.graphql.SchemaContext;
import com.rbwm.ted.appointment.schema.model.Node;
import graphql.relay.Connection;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.StaticDataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.function.BiFunction;

import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.relay;

/**
 * Created by 44052007 on 17/01/2018.
 */
@Component
public class RootDataFetcher {

    public final DataFetcher tedFetcher;
    public final DataFetcher viewerFetcher;
    public final DataFetcher viewerIdFetcher;
    public final DataFetcher edgeCountFetcher;
    public final BiFunction<String, DataFetchingEnvironment, String> nodeIdBuilder;


    @Autowired
    public RootDataFetcher(SchemaContext schemaContext) {
        tedFetcher = new StaticDataFetcher("ted schema");
        viewerFetcher = new StaticDataFetcher("Viewer");
        viewerIdFetcher = env -> schemaContext.relay.toGlobalId("Viewer", "1");

        edgeCountFetcher = environment -> {
            Connection connection = environment.getSource();
            return connection.getEdges().size();
        };
        nodeIdBuilder = (type, env) -> {
            Node node = env.getSource();
            return relay.toGlobalId(type, node.id);
        };

    }

}
