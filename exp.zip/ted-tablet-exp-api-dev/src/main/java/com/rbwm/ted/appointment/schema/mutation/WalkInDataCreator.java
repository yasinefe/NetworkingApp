/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.api.WalkInServiceApi;
import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static com.rbwm.ted.appointment.model.AppointmentFields.APPOINTMENT_ID;
import static com.rbwm.ted.appointment.model.AppointmentFields.BRANCH_ID;
import static com.rbwm.ted.appointment.schema.graphql.GraphQLContext.branchIdExtractor;

/**
 * Created by 44027117 on 13/03/2017.
 */
@Component
public class WalkInDataCreator {

    public final DataFetcher<CompletableFuture> walkInCreater;

    @Autowired
    public WalkInDataCreator(WalkInServiceApi walkInService) {
        walkInCreater = env -> {
            Map<String, Object> input = env.getArgument("input");

            GraphQLContext graphQLContext = env.getContext();
            input.put(BRANCH_ID.val(), branchIdExtractor.apply(env));

            return walkInService.create(input).map(walkIn -> {
                setDataFetcherAuditData(graphQLContext.getDataFetcherAudit(), walkIn);

                Map<String, Object> result = new LinkedHashMap<>();
                result.put("clientMutationId", input.get("clientMutationId"));
                result.put("walkIn", walkIn);

                return result;
            }).toFuture();
        };
    }

    private void setDataFetcherAuditData(DataFetcherAudit.Builder dataFetcherAuditBuilder, Map<String, Object> walkIn) {
        dataFetcherAuditBuilder.withEntityId((String) walkIn.get(APPOINTMENT_ID.val()));
        dataFetcherAuditBuilder.withAuditAction(AuditableAction.WALKIN_CREATE);
    }
}
