/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.skillbuilders;

import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.SkillBuildersConfiguration;
import com.rbwm.ted.appointment.schema.model.VideoSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * Created by 44093684 on 22/01/2018.
 */
@Component
public class GetSummary {
    private final ReactiveCRUDRest crudRest;
    private final SkillBuildersConfiguration skillBuildersConfiguration;

    private static final String FEATURE_PREFIX = "GET-SKILLBUILDERS-SUMMARY";

    @Autowired
    public GetSummary(SkillBuildersConfiguration skillBuildersConfiguration) {
        this.skillBuildersConfiguration = skillBuildersConfiguration;
        this.crudRest = skillBuildersConfiguration.skillbuildersCrudRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<VideoSummary> get(Map<String, Object> filters, String countryCode, List<String> userIds) {
        VideoRequest request = new VideoRequest(filters, countryCode, userIds);

        return crudRest.doPost(getUrl(), request, VideoSummary.class)
                .map(ClientResponse::getBody);
    }

    private String getUrl() {
        return skillBuildersConfiguration.getSkillbuildersSummaryUri();
    }


}
