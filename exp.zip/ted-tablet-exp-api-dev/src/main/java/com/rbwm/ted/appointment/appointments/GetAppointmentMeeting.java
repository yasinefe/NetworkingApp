/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentBookingConfiguration;
import com.rbwm.ted.appointment.meetings.MeetingTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.Map;

/**
 * Created by 44052007 on 16/05/2018.
 */
@Component
public class GetAppointmentMeeting {

    private static final String FEATURE_PREFIX = "GET-APPOINTMENT-MEETING";

    protected final AppointmentBookingConfiguration appointmentBookingConfiguration;

    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<Map<String, Object>> responseHandler;

    @Autowired
    public GetAppointmentMeeting(AppointmentBookingConfiguration appointmentBookingConfiguration,
                                 ReactiveResponseHandler<Map<String, Object>> responseHandler) {
        this.appointmentBookingConfiguration = appointmentBookingConfiguration;
        this.responseHandler = responseHandler;

        crudRest = appointmentBookingConfiguration.appointmentBookingCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Map<String, Object>> getAppointment(String meetingId) {
        return responseHandler.extractBody(crudRest.doGet(getUri(meetingId), Collections.emptyMap(), String.class))
                .map(MeetingTransformer.transformAppointmentToMeeting);
    }

    private String getUri(String meetingId) {
        return appointmentBookingConfiguration.getMeetingsUri() + "/" + meetingId;
    }

}
