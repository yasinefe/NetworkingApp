/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.meetings;

import com.rbwm.ted.appointment.model.MeetingType;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.relay;

/**
 * Created by 44052007 on 30/04/2018.
 */
public final class MeetingTransformer {

    public static final String SEPARATOR = "/";

    private MeetingTransformer() {
    }

    public static final Function<List<Map<String, Object>>, List<Map<String, Object>>> transformAppointmentsToMeetings = appointments -> {
        for (Map<String, Object> appointment : appointments) {
            MeetingTransformer.transformAppointmentToMeeting.apply(appointment);
        }
        return appointments;
    };

    public static final Function<Map<String, Object>, Map<String, Object>> transformAppointmentToMeeting = appointment -> {
        appointment.put("duration", new Double(String.valueOf(appointment.get("duration"))).intValue());
        appointment.put("id", relay.toGlobalId("Meeting", MeetingType.APPOINTMENTS.name() + SEPARATOR + appointment.get("meetingId").toString()));
        appointment.put("type", MeetingType.APPOINTMENTS.name());
        return appointment;
    };

    public static final Function<List<Map<String, Object>>, List<Map<String, Object>>> transformWalkInsToMeetings = walkIns -> {
        for (Map<String, Object> walkIn : walkIns) {
            MeetingTransformer.transformWalkInToMeeting.apply(walkIn);
        }
        return walkIns;
    };

    public static final Function<Map<String, Object>, Map<String, Object>> transformWalkInToMeeting = walkIn -> {
        walkIn.put("duration", new Double(String.valueOf(walkIn.get("duration"))).intValue());
        walkIn.put("id", relay.toGlobalId("Meeting", MeetingType.WALK_INS.name() + SEPARATOR + walkIn.get("meetingId").toString()));
        walkIn.put("type", MeetingType.WALK_INS.name());
        return walkIn;
    };
}
