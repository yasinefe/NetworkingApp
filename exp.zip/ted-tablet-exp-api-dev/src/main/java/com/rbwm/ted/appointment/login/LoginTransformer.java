/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.login;

import java.util.Map;
import java.util.function.Function;

/**
 * Created by 44052007 on 17/11/2017.
 */
public final class LoginTransformer {

    private LoginTransformer() {
    }

    public static final Function<Map<String, Object>, LoginResponse> transform = (Map<String, Object> data) -> {
        Map<String, Object> userData = (Map<String, Object>) data.get("user");
        User user = new User(
                (String)userData.get("cn"),
                (String)userData.get("employeeId"),
                (String)userData.get("firstName"),
                (String)userData.get("lastName"),
                (String)userData.get("countryCode"),
                (String)userData.get("organisationCode"),
                (String)userData.get("portraitUrl")
                );
        return new LoginResponse(user, (String) data.get("token"));
    };
}
