/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.rbwm.ted.appointment.api.WalkInServiceApi;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * Created by 44027117 on 22/02/2017.
 */
@Service
public class WalkInService implements WalkInServiceApi {

    private final WalkInUpdaterStatus walkInUpdaterStatus;
    private final WalkInSummary walkInSummary;
    private final WalkInCreator walkInCreator;
    private final GetWalkIn getWalkIn;
    private final WalkInStats walkInStats;
    private final WalkInList walkInList;

    @Autowired
    public WalkInService(WalkInUpdaterStatus walkInUpdaterStatus,
                         WalkInSummary walkInSummary,
                         WalkInCreator walkInCreator,
                         GetWalkIn getWalkIn,
                         WalkInStats walkInStats,
                         WalkInList walkInList) {
        this.walkInUpdaterStatus = walkInUpdaterStatus;
        this.walkInSummary = walkInSummary;
        this.walkInCreator = walkInCreator;
        this.getWalkIn = getWalkIn;
        this.walkInStats = walkInStats;
        this.walkInList = walkInList;
    }

    @Override
    public Mono<Map<String, Object>> getWalkInList(String branchId) {
       return walkInList.getWalkIns(branchId);
    }

    @Override
    public Mono<Map<String, Object>> updateStatus(String id, AppointmentStatus appointmentStatus) {
        return walkInUpdaterStatus.updateStatus(id, appointmentStatus);
    }

    @Override
    public Mono<List<Map<String, Object>>> getStatusSummary(String branchId) {
        return walkInSummary.getSummary(branchId);
    }

    @Override
    public Mono<Map<String, Object>> create(Map<String, Object> input) {
        return walkInCreator.create(input);
    }

    @Override
    public Mono<Map<String, Object>> getWalkIn(String appointmentId) {
        return getWalkIn.getWalkIn(appointmentId);
    }

    @Override
    public Mono<Map<String, Object>> getStats(String branchId) {
        return walkInStats.getTotalForToday(branchId);
    }
}
