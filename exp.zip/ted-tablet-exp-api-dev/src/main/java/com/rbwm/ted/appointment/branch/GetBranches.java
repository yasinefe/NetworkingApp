/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.branch;

import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.rbwm.ted.appointment.schema.model.Branch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import reactor.core.publisher.Mono;

import java.util.List;

import static java.util.Collections.singletonList;

/**
 * Created by 43578876 on 21/04/2017.
 */
@Component
public class GetBranches {

    private final ReactiveCRUDRest crudRest;
    private final AppointmentConfiguration appointmentConfiguration;
    private static final String FEATURE_PREFIX = "GET-BRANCHES";

    @Autowired
    public GetBranches(AppointmentConfiguration appointmentConfiguration) {
        this.appointmentConfiguration = appointmentConfiguration;
        crudRest = appointmentConfiguration.branchCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<List<Branch>> getAllBranches(String countryCode, String keyword) {
        return crudRest.doGetForMany(getBranchListUrl(countryCode), getRequestParameter(keyword), Branch.class)
                .map(ClientResponse::getBody);
    }

    private LinkedMultiValueMap<String, String> getRequestParameter(String keyword) {
        return new LinkedMultiValueMap<String, String>(){{
                    put("search", singletonList(keyword));
                }};
    }

    private String getBranchListUrl(String countryCode) {
        return this.appointmentConfiguration.getBranchesListUri() + "/countryCode/" + countryCode;
    }
}
