/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import org.joda.time.DateTimeUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

/**
 * Created by 43578876 on 28/11/2016.
 */
@Configuration
public class DataServiceConfig {

    @Value("${ted.mock.current.datetime}")
    private Boolean mockDateTime;

    /**
     * Setting the system datetime as the same day as the day used on the mock data. 25/10/2016 09:00.
     */
    @PostConstruct
    private void setMockSystemDateTime() {
        if (mockDateTime) {
            DateTimeUtils.setCurrentMillisFixed(1477386000000L);
        }
    }
}
