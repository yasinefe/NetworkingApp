/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.skillbuilders;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 44093684 on 23/01/2018.
 */
public class VideoRequest {
    public final Map<String, Object> filter;
    public final String groupBy;

    VideoRequest(Map<String, Object> filter, String countryCode, List<String> userIds) {
        this(filter, null, countryCode, userIds);
    }

    VideoRequest(Map<String, Object> filter, String groupBy, String countryCode, List<String> userIds) {
        this.filter = new HashMap<>();
        this.filter.putAll(filter != null ? filter : Collections.emptyMap());
        this.filter.put("countryCode", countryCode);
        this.filter.put("userIds", userIds);

        this.groupBy = groupBy;
    }

}
