/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import com.rbwm.ted.appointment.user.UserProfileService;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.model.BranchFields.BRANCH_ID;
import static com.rbwm.ted.appointment.model.UserProfileFields.USER_PROFILE_FIELD;

/**
 * Created by 43578876 on 10/11/2016.
 */
@Component
public class UserProfileBranchDataUpdater {

    public final DataFetcher updateBranch;

    @Autowired
    public UserProfileBranchDataUpdater(UserProfileService userProfileService) {
        updateBranch = env -> {
            Map<String, Object> input = env.getArgument("input");
            String branchId = (String) input.get(BRANCH_ID.val());

            GraphQLContext context = env.getContext();
            return userProfileService.updateBranch(context.userId, branchId)
                    .map(userProfile -> {

                        Map<String, Object> result = new LinkedHashMap<>();
                        result.put("clientMutationId", input.get("clientMutationId"));
                        result.put(USER_PROFILE_FIELD.val(), userProfile);
                        return result;

                    }).toFuture();
        };
    }

}
