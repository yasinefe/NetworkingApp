/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.skillbuilders;

import com.rbwm.ted.appointment.api.SkillBuildersServiceApi;
import com.rbwm.ted.appointment.schema.model.VideoGroup;
import com.rbwm.ted.appointment.schema.model.VideoSummary;
import com.rbwm.ted.appointment.staff.GetAllStaff;
import com.rbwm.ted.appointment.staff.GetStaff;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by 44093684 on 22/01/2018.
 */
@Component
public class SkillbuildersService implements SkillBuildersServiceApi {

    private final GetAllStaff getAllStaff;
    private final GetSummary getSummary;
    private final GetVideos getVideos;

    @Autowired
    public SkillbuildersService(GetAllStaff getAllStaff, GetSummary getSummary, GetVideos getVideos) {
        this.getAllStaff = getAllStaff;
        this.getSummary = getSummary;
        this.getVideos = getVideos;
    }

    @Override
    public Mono<VideoSummary> getSummary(Map<String, Object> filters, String countryCode, String branchId) {
        return getEmployeeIds(branchId)
                .flatMap(userIds -> getSummary.get(filters, countryCode, userIds));
    }

    @Override
    public Mono<List<VideoGroup>> getVideoGroups(Map<String, Object> filters, String groupBy, String countryCode, String branchId) {
        return getEmployeeIds(branchId)
                .flatMap(userIds -> getVideos.get(filters, groupBy, countryCode, userIds));
    }

    private Mono<List<String>> getEmployeeIds(String branchId) {
        return getAllStaff.get(branchId)
                .map(branchStaff -> branchStaff.stream().map(staff -> staff.employeeId).collect(Collectors.toList()));
    }

}
