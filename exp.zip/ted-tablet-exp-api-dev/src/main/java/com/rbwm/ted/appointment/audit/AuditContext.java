/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.audit;

import com.rbwm.ted.appointment.http.HeaderContext;
import lombok.EqualsAndHashCode;

import java.util.Map;

/**
 * Created by 44027117 on 28/04/2017.
 */
@EqualsAndHashCode
public class AuditContext {
    public final String countryCode;
    public final String branchId;
    public final String wifiMACAddress;
    public final String machineId;
    public final String staffId;
    public final String query;
    public final Map<String, Object> variables;
    public final String correlationId;
    public final String entityId;
    public final Object entity;
    public final String operationName;
    public final String type;
    public final Boolean error;


    public AuditContext(String correlationId, HeaderContext headerContext,
                        String staffId, String query, Map<String, Object> variables, Boolean error,
                        DataFetcherAudit dataFetcherAudit) {
        this.correlationId = correlationId;
        this.countryCode = headerContext.countryCode;
        this.branchId = headerContext.branchId;
        this.wifiMACAddress = headerContext.wifiMACAddress;
        this.machineId = headerContext.machineId;
        this.staffId = staffId;
        this.query = query;
        this.variables = variables;
        this.entityId = dataFetcherAudit.entityId;
        this.entity = dataFetcherAudit.entity;
        this.operationName = dataFetcherAudit.operationName;
        this.type = dataFetcherAudit.type;
        this.error = error;
    }
}
