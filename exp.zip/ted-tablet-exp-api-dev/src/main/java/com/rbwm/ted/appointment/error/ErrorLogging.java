/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import com.rbwm.ted.appointment.authentication.AuthenticationFacadeApi;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by 44052007 on 18/05/2017.
 */
@Component
public class ErrorLogging {

    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorLogging.class);

    private final AuthenticationFacadeApi authenticationFacadeApi;

    @Autowired
    public ErrorLogging(AuthenticationFacadeApi authenticationFacadeApi) {
        this.authenticationFacadeApi = authenticationFacadeApi;
    }

    public void log(Error error, Throwable exception, ErrorLog errorLog) {
        LOGGER.error(createMessage(error, errorLog, exception), exception);
    }

    private String createMessage(Error error, ErrorLog errorLog, Throwable exception) {
        errorLog.add("HttpStatus", error.httpStatus)
            .add("CorrelationId", CorrelationIdContainer.getId())
            .add("UserId", getUserId())
            .add("ErrorCode", error.code)
            .add("ErrorMessage", error.message)
            .add("ErrorDetail", exception.getMessage());

        return errorLog.toString();
    }

    private String getUserId(){
        Authentication authentication = authenticationFacadeApi.getAuthentication();
        return authentication != null ? authentication.getName() : "";
    }

    public static class ErrorLog {
        private Map<String, String> attributes = new LinkedHashMap<>();

        public ErrorLog add(String key, Object value) {
            attributes.put(key, value != null ? value.toString() : "");
            return this;
        }

        @Override
        public String toString(){
            return attributes.entrySet().stream()
                    .map(entry -> {
                        String replaceDoubleQuotes = entry.getValue().replace('\"', '\'');
                        String wrapWithDoubleQuote = replaceDoubleQuotes.contains(" ") ? "\"" + entry.getValue() + "\"" : entry.getValue();
                        return entry.getKey() + "=" + wrapWithDoubleQuote;
                    })
                    .collect(Collectors.joining(" "));
        }
    }
}
