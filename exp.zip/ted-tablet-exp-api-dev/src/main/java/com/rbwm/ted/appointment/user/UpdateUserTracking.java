/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.user;

import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.UserProfileConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Created by 44052007 on 27/03/2018.
 */
@Component
public class UpdateUserTracking {
    private final ReactiveCRUDRest crudRest;
    private final UserProfileConfiguration userProfileConfiguration;
    private static final String FEATURE_PREFIX = "UPDATE-USER-TRACKING";

    @Autowired
    public UpdateUserTracking(UserProfileConfiguration userProfileConfiguration) {
        this.userProfileConfiguration = userProfileConfiguration;
        this.crudRest = userProfileConfiguration.userProfileCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Tracking> track(String userId, String key) {
        return crudRest.doPut(getUrlWithId(userId, key), "{}", Tracking.class)
                .map(ClientResponse::getBody);
    }

    private String getUrlWithId(String userId, String key) {
        return userProfileConfiguration.getUserTrackingUri() + "/" + userId + "/track/" + key;
    }

}
