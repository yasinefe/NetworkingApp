/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.graphql;

import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.http.HeaderContext;
import graphql.schema.DataFetchingEnvironment;
import lombok.ToString;

import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

import static com.rbwm.ted.appointment.error.Exceptions.TEE_INVALID_PARAMETER;

/**
 * Created by 44052007 on 25/04/2017.
 */
@ToString
public class GraphQLContext {

    public static final Function<DataFetchingEnvironment, String> branchIdExtractor = env -> {
        GraphQLContext graphQLContext = env.getContext();
        if (graphQLContext.getBranchId() == null) {
            throw new Exceptions.InvalidRequestException(TEE_INVALID_PARAMETER, null, "Validation error: Branch id is missing");
        }
        return graphQLContext.getBranchId();
    };

    private DataFetcherAudit.Builder dataFetcherBuilder;
    private final HeaderContext headerContext;
    private Map<String, Object> data;
    private Map<String, Object> walkinData;
    public final String userId;
    public final String correlationId;

    public GraphQLContext(HeaderContext headerContext, DataFetcherAudit.Builder dataFetcherBuilder, String userId, String correlationId) {
        this.headerContext = headerContext;
        this.dataFetcherBuilder = dataFetcherBuilder;
        this.userId = userId;
        this.correlationId = correlationId;
    }

    public String getBranchId() {
        return headerContext.branchId;
    }

    public String getWifiMacAddress() {
        return headerContext.wifiMACAddress;
    }

    public String getMachineId() {
        return headerContext.machineId;
    }

    public String getCountryCode() {
        return headerContext.countryCode;
    }
  
    public DataFetcherAudit.Builder getDataFetcherAudit() {
        return dataFetcherBuilder;
    }

    public static final BiFunction<DataFetchingEnvironment, AuditableAction, DataFetchingEnvironment> addActionType = (env, actionType) -> {
        GraphQLContext graphQLContext = env.getContext();
        graphQLContext.dataFetcherBuilder
                .withAuditAction(actionType);
        return env;
    };

    public void addData(Map<String, Object> combinedResult) {
        this.data = combinedResult;
    }

    public void addWalkinsData(Map<String, Object> result) {
        this.walkinData = result;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public Map<String, Object> getWalkinData() {
        return walkinData;
    }
}
