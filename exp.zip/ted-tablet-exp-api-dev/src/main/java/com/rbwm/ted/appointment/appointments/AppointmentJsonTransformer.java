/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.rbwm.ted.appointment.model.AppointmentFields;

import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

import static com.rbwm.ted.appointment.model.AppointmentFields.APPOINTMENT_ID;
import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.relay;

/**
 * Created by 44052007 on 20/06/2017.
 */
public final class AppointmentJsonTransformer {

    private AppointmentJsonTransformer() {
    }

    private static final BiFunction<Map<String, Object>, String, Long> toLong = (walkIn, key) -> (walkIn.get(key) != null) ?
            new Double(String.valueOf(walkIn.get(key))).longValue() : null;

    public static final Function<List<Map<String, Object>>, List<Map<String, Object>>> transformAppointments = appointments -> {
        for (Map<String, Object> appointment : appointments) {
            AppointmentJsonTransformer.transformAppointment.apply(appointment);
        }
        return appointments;
    };

    public static final Function<Map<String, Object>, Map<String, Object>> transformAppointment = appointment -> {
        appointment.put(AppointmentFields.DURATION.val(), new Double(String.valueOf(appointment.get("duration"))).intValue());
        appointment.put(AppointmentFields.DATE_TIME.val(), toLong.apply(appointment, "dateTime"));
        appointment.put(AppointmentFields.BRANCH_ID.val(), appointment.get("locationId"));
        appointment.put("id", relay.toGlobalId("appointment", appointment.get(APPOINTMENT_ID.val()).toString()));
        return appointment;
    };
}
