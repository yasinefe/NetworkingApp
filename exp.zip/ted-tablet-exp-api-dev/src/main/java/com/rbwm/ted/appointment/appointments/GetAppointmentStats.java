/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.AppointmentBookingConfiguration;
import com.rbwm.ted.appointment.meetings.MeetingStats;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Collections;

/**
 * Created by 44052007 on 16/05/2018.
 */
@Component
public class GetAppointmentStats {

    private static final String FEATURE_PREFIX = "GET-APPOINTMENT-STATS";

    protected final AppointmentBookingConfiguration appointmentBookingConfiguration;

    private final ReactiveCRUDRest crudRest;

    @Autowired
    public GetAppointmentStats(AppointmentBookingConfiguration appointmentBookingConfiguration) {
        this.appointmentBookingConfiguration = appointmentBookingConfiguration;
        crudRest = appointmentBookingConfiguration.appointmentBookingCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<MeetingStats> getAppointmentStats(String branchId) {
        return crudRest.doGet(getUri(branchId), Collections.emptyMap(), MeetingStats.class)
                .map(ClientResponse::getBody);
    }

    private String getUri(String branchId) {
        return appointmentBookingConfiguration.getMeetingsUri() + "/stats/branchId/" + branchId;
    }

}
