/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.category;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by 44027117 on 29/03/2017.
 */
@Component
public class ProductCategoryList {
    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<List<Map<String,Object>>> responseHandler;
    private final AppointmentConfiguration appointmentConfiguration;
    private static final String FEATURE_PREFIX = "GET-PRODUCT-CATEGORIES";

    @Autowired
    public ProductCategoryList(AppointmentConfiguration appointmentConfiguration,
                               ReactiveResponseHandler<List<Map<String,Object>>> responseHandler) {
        this.appointmentConfiguration = appointmentConfiguration;
        this.responseHandler = responseHandler;
        crudRest = appointmentConfiguration.productCategoryCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<List<Map<String, Object>>> getCategories(String countryCode) {
        return responseHandler.handleResponse(crudRest.doGet(
                appointmentConfiguration.getProductCategoryUri(),
                Collections.emptyMap(), getHttpHeaders(countryCode),
                String.class));
    }

    private Map<String, List<String>> getHttpHeaders(String countryCode) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("X-COUNTRY-CODE", countryCode);
        return httpHeaders;
    }
}
