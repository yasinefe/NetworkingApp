/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.rbwm.ted.appointment.audit.AuditContext;
import com.rbwm.ted.appointment.audit.AuditProcessor;
import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.authentication.AuthenticationFacadeApi;
import com.rbwm.ted.appointment.error.ErrorHandler;
import com.rbwm.ted.appointment.error.ErrorLogging;
import com.rbwm.ted.appointment.http.GraphQLHttpResponse;
import com.rbwm.ted.appointment.http.HeaderContext;
import com.rbwm.ted.appointment.schema.AppointmentSchema;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.introspection.IntrospectionQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.model.Headers.*;
import static com.rbwm.ted.appointment.validation.Validator.validateNotNull;

/**
 * Created by 43578876 on 28/10/2016.
 */
@Controller
public class AppointmentGraphQLController {

    private final GraphQL graphql;
    private final AuditProcessor auditProcessor;
    private final ErrorHandler errorHandler;
    private final ErrorLogging errorLogging;
    private final AuthenticationFacadeApi authenticationFacadeApi;

    @Autowired
    public AppointmentGraphQLController(AppointmentSchema schema, ErrorHandler errorHandler,
                                        AuditProcessor auditProcessor, ErrorLogging errorLogging,
                                        AuthenticationFacadeApi authenticationFacadeApi) {
        this.graphql = GraphQL.newGraphQL(schema.getSchema()).build();
        this.errorHandler = errorHandler;
        this.auditProcessor = auditProcessor;
        this.errorLogging = errorLogging;
        this.authenticationFacadeApi = authenticationFacadeApi;
    }

    @RequestMapping(value = "/about", method = RequestMethod.GET)
    @ResponseBody
    public AboutInfo test() {
        return new AboutInfo("appointments-experience-api",0.11);
    }

    @RequestMapping(value = "/schema.json", method = RequestMethod.GET)
    @ResponseBody
    public Map<String,Object> getSchema() {
        Map<String, Object> result = new LinkedHashMap<>();
        ExecutionResult executionResult =  graphql.execute(IntrospectionQuery.INTROSPECTION_QUERY);
        result.put("data", executionResult.getData());
        return result;
    }

    @RequestMapping(value = "/graphql", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<?> executeOperation(@RequestBody Map<String,Object> body,
                                              @RequestHeader(value = BRANCH_ID_HEADER, required = false) String branchId,
                                              @RequestHeader(value = MACHINE_ID_HEADER, required = false) String machineId,
                                              @RequestHeader(value = WIFI_MAC_ADDRESS_HEADER, required = false) String wifiMACAddress,
                                              @RequestHeader(value = COUNTRY_CODE_HEADER, required = false, defaultValue = "GBR") String countryCode) {
        validateNotNull("query", body.get("query"));
        validateNotNull("variables", body.get("variables"));

        String query = (String) body.get("query");
        Map<String, Object> variables = (Map<String, Object>) body.get("variables");

        HeaderContext headerContext = new HeaderContext(branchId, wifiMACAddress, machineId, countryCode);
        DataFetcherAudit.Builder dataFetcherAudit = new DataFetcherAudit.Builder();

        String correlationId = CorrelationIdContainer.getId();
        GraphQLHttpResponse response = new GraphQLHttpResponse(graphql,
                query, new GraphQLContext(headerContext, dataFetcherAudit, authenticationFacadeApi.getAuthentication().getName(), correlationId), variables, errorHandler, errorLogging);

        auditProcessor.sendEvent(new AuditContext(
                correlationId,
                headerContext,
                SecurityContextHolder.getContext().getAuthentication().getName(),
                query,
                variables,
                !response.getErrors().isEmpty(),
                dataFetcherAudit.build()
        ));

        return new ResponseEntity<>(response, response.getHttpStatus());
    }
}
