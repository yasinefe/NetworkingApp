/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.category;

import com.rbwm.ted.appointment.api.ProductCategoryServiceApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * Created by 44027117 on 29/03/2017.
 */
@Service
public class ProductCategoryService implements ProductCategoryServiceApi {

    private final ProductCategoryList productCategoryList;

    @Autowired
    public ProductCategoryService(ProductCategoryList productCategoryList) {
        this.productCategoryList = productCategoryList;
    }

    @Override
    public Mono<List<Map<String, Object>>> getCategories(String countryCode) {
        return productCategoryList.getCategories(countryCode);
    }
}
