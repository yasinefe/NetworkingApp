/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.api.WalkInServiceApi;
import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static com.rbwm.ted.appointment.model.AppointmentFields.APPOINTMENT_ID;
import static com.rbwm.ted.appointment.model.AppointmentFields.APPOINTMENT_STATUS;

/**
 * Created by 44027117 on 24/02/2017.
 */
@Component
public class WalkInDataUpdater {

    public final DataFetcher<CompletableFuture> updateStatus;

    @Autowired
    public WalkInDataUpdater(WalkInServiceApi walkInService) {
        updateStatus = env -> {
            Map<String, Object> input = env.getArgument("input");
            String appointmentId = (String) input.get(APPOINTMENT_ID.val());
            AppointmentStatus appointmentStatus = AppointmentStatus.valueOf((String) input.get(APPOINTMENT_STATUS.val()));

            return walkInService.updateStatus(appointmentId, appointmentStatus).map(walkIn -> {
                Map<String, Object> result = new LinkedHashMap<>();
                result.put("clientMutationId", input.get("clientMutationId"));
                result.put("walkIn", walkIn);

                audit(env, appointmentId);
                return result;
            }).toFuture();
        };
    }

    private void audit(DataFetchingEnvironment env, String entityId) {
        GraphQLContext graphQLContext = env.getContext();
        graphQLContext.getDataFetcherAudit()
                .withAuditAction(AuditableAction.WALKIN_STATUS_CHANGE)
                .withEntityId(entityId);
    }
}
