/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.google.gson.Gson;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.rbwm.ted.appointment.model.AppointmentFields;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 44027117 on 16/03/2017.
 */
@Component
public class WalkInCreator {
    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<Map<String,Object>> responseHandler;
    private final AppointmentConfiguration appointmentConfiguration;
    private static final String FEATURE_PREFIX = "CREATE-WALKIN";

    private final static int DEFAULT_WALKIN_DURATION = 15;

    @Autowired
    public WalkInCreator(AppointmentConfiguration appointmentConfiguration,
                         ReactiveResponseHandler<Map<String,Object>> responseHandler) {
        this.appointmentConfiguration = appointmentConfiguration;
        this.responseHandler = responseHandler;
        crudRest = appointmentConfiguration.walkInCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Map<String, Object>> create(Map<String, Object> input) {
        return responseHandler.handleResponse(
                    crudRest.doPost(appointmentConfiguration.getWalkInGetUri(), new Gson().toJson(transform(input)), String.class)
                ).map(WalkInJsonTransformer.transform);
    }

    private Map<String, Object> transform(Map<String, Object> input) {
        Map<String, Object> attendee = new HashMap<>();
        attendee.put("firstName", input.get("firstName"));
        attendee.put("lastName", input.get("lastName"));
        attendee.put("gender", input.get("gender"));
        input.put(AppointmentFields.ATTENDEE.val(), attendee);
        input.put(AppointmentFields.APPOINTMENT_STATUS.val(), AppointmentStatus.CHECKED_IN.getCode());
        input.put(AppointmentFields.DURATION.val(), DEFAULT_WALKIN_DURATION);
        return input;
    }
}
