package com.rbwm.ted.appointment.api;

import com.rbwm.ted.appointment.meetings.MeetingInput;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import com.rbwm.ted.appointment.model.MeetingType;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * Created by 44052007 on 26/04/2018.
 */
public interface MeetingServiceApi {

    Mono<List<Map<String, Object>>> getMeetings(String branchId, MeetingStatus meetingStatus, MeetingGroupType meetingGroupType, MeetingType meetingType);

    Mono<List<Map<String, Object>>> getNextWorkingDayMeetings(String branchId, MeetingStatus meetingStatus, MeetingGroupType meetingGroupType);

    Mono<Map<String, Object>> getMeeting(String meetingId);

    Mono<Map<String, Object>> changeMeetingStatus(String meetingId, MeetingStatus meetingStatus);

    Mono<Map<String, Object>> checkInMeeting(String meetingId, Boolean proofOfId);

    Mono<Map<String, Object>> createMeeting(MeetingInput meetingInput);

    Mono<Map<String, Object>> getMeetingStats(String branchId);
}
