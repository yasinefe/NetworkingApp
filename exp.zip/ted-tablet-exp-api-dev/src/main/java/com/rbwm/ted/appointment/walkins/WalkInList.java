/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.rbwm.ted.appointment.http.QueryParams.singleQueryParam;
import static com.rbwm.ted.appointment.model.AppointmentFields.*;

/**
 * Created by 44027117 on 22/02/2017.
 */
@Component
public class WalkInList {

    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<Map<String,Object>> responseHandler;
    private final AppointmentConfiguration appointmentConfiguration;
    private static final String FEATURE_PREFIX = "GET-WALKIN-LIST";

    private final Comparator<Map<String, Object>> byStatus = Comparator.comparing(a -> ((String) a.get(APPOINTMENT_STATUS.val())));
    private final Comparator<Map<String, Object>> byDateTime = Comparator.comparing(a  -> ((Long) a.get(DATE_TIME.val())));

    @Autowired
    public WalkInList(AppointmentConfiguration appointmentConfiguration,
                      ReactiveResponseHandler<Map<String,Object>> responseHandler) {
        this.appointmentConfiguration = appointmentConfiguration;
        this.responseHandler = responseHandler;
        crudRest = appointmentConfiguration.walkInCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Map<String,Object>> getWalkIns(final String branchId) {
        return responseHandler.handleResponse(
                crudRest.doGet(appointmentConfiguration.getWalkInListUri(),
                        singleQueryParam.apply(BRANCH_ID.val(), branchId),
                        String.class)).map(walkInResponse -> {

            List<Map<String, Object>> walkInList = ((List<Map<String, Object>>) walkInResponse.get("walkins"))
                    .stream()
                    .map(WalkInJsonTransformer.transform)
                    .sorted(byStatus.thenComparing(byDateTime))
                    .collect(Collectors.toList());

            List<Map<String, Object>> walkinSummary = WalkInSummaryTransformer.transform.apply((Map<String, Object>) walkInResponse.get("statusCounts"));

            return new HashMap<String, Object>() {{
                put("list", walkInList);
                put("summary", walkinSummary);
            }};
        });
    }
}
