/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;


import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.rbwm.ted.appointment.meetings.MeetingTransformer;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Collections.singletonList;

/**
 * Created by 44027117 on 31/03/2017.
 */
@Component
public class GetWalkIns {

    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<List<Map<String,Object>>> responseHandler;
    private final AppointmentConfiguration appointmentConfiguration;
    private static final String FEATURE_PREFIX = "GET-WALKINS";


    @Autowired
    public GetWalkIns(AppointmentConfiguration appointmentConfiguration,
                      ReactiveResponseHandler<List<Map<String,Object>>> responseHandler) {
        this.appointmentConfiguration = appointmentConfiguration;
        this.responseHandler = responseHandler;
        crudRest = appointmentConfiguration.walkInCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<List<Map<String, Object>>> getWalkIns(String branchId, MeetingStatus meetingStatus, MeetingGroupType meetingGroup) {
        return responseHandler.extractBody(crudRest.doGet(getUri(branchId), getRequestParameters(meetingStatus, meetingGroup), String.class))
                .map(MeetingTransformer.transformWalkInsToMeetings);
    }

    private Map<String, List<String>> getRequestParameters(MeetingStatus meetingStatus, MeetingGroupType meetingGroup) {
        Map<String, List<String>> params = new HashMap<>();
        if (meetingStatus != null) {
            params.put("meetingStatus", singletonList(meetingStatus.name()));
        }
        if (meetingGroup != null) {
            params.put("meetingGroup", singletonList(meetingGroup.name()));
        }
        return params;
    }

    private String getUri(String branchId) {
        return appointmentConfiguration.getWalkInsMeetingsUri() + "/branchId/" + branchId;
    }
}
