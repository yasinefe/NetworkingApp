/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.model;

/**
 * Created by 43578876 on 17/11/2016.
 */
public enum AppointmentFields implements Fields {

    APPOINTMENT("appointment"),
    APPOINTMENT_ID("appointmentId"),
    APPOINTMENT_STATUS("appointmentStatus"),
    BRANCH_ID("branchId"),
    TOPIC_ID("topicId"),
    TOPIC_NAME("topicName"),
    TOPIC_CATEGORY_ID("topicCategoryId"),
    TOPIC_CATEGORY_NAME("topicCategoryName"),
    TOPIC_SUB_CATEGORY_ID("topicSubCategoryId"),
    TOPIC_SUB_CATEGORY_NAME("topicSubCategoryName"),
    DATE_TIME("dateTime"),
    DURATION("duration"),
    OVERDUE_OFFSET("overdueOffset"),
    ATTENDEE("attendee"),
    COUNT("count"),
    CRITICAL_OVERDUE_OFFSET("criticalOverdueOffset"),
    FIRST_NAME("firstName"),
    LAST_NAME("lastName"),
    IS_NOSHOW("isNoShow"),
    GENDER("gender"),
    COMMENTS("comments"),
    PROOF_OF_ID("proofOfId"),
    STARTED_AT("startedAt"),
    CHECKLIST("checklist"),
    ENDED_AT("endedAt");

    private final String value;

    AppointmentFields(String value) {
        this.value=value;
    }

    @Override
    public String val() {
        return value;
    }

}
