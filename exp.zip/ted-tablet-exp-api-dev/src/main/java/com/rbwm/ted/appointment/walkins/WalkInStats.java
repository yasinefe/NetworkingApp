/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.function.Function;

import static com.rbwm.ted.appointment.http.QueryParams.singleQueryParam;
import static com.rbwm.ted.appointment.model.AppointmentFields.BRANCH_ID;

/**
 * Created by 44027117 on 05/05/2017.
 */
@Component
public class WalkInStats {
    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<Map<String,Object>> responseHandler;
    private final AppointmentConfiguration appointmentConfiguration;
    private static final String FEATURE_PREFIX = "GET-WALKIN-STATS";

    private static Function<Map<String,Object>,Map<String,Object>> transform = stats -> {
        stats.put("totalForToday", new Double(String.valueOf(stats.get("total"))).intValue());
        stats.put("averageWaitingTime", new Double(String.valueOf(stats.get("averageWaitingTime"))).intValue());
        stats.put("averageWaitingTimeLastBusinessDay", new Double(String.valueOf(stats.get("averageWaitingTimeLastBusinessDay"))).intValue());
        return stats;
    };

    @Autowired
    public WalkInStats(AppointmentConfiguration appointmentConfiguration,
                       ReactiveResponseHandler<Map<String,Object>> responseHandler) {
        this.appointmentConfiguration = appointmentConfiguration;
        this.responseHandler = responseHandler;
        crudRest = appointmentConfiguration.walkInCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Map<String, Object>> getTotalForToday(final String branchId) {
        return responseHandler.handleResponse(
                        crudRest.doGet(appointmentConfiguration.getWalkInStatsUri(), singleQueryParam.apply(BRANCH_ID.val(), branchId), String.class))
                .map(transform);
    }
}
