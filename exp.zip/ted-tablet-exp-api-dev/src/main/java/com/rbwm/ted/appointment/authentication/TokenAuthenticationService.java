/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.authentication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by 44027117 on 27/01/2017.
 */
@Service
public class TokenAuthenticationService {
    private static final String AUTH_HEADER_NAME = "Authorization";

    private final TokenHandler tokenHandler;

    @Autowired
    public TokenAuthenticationService(final TokenHandler tokenHandler) {
        this.tokenHandler = tokenHandler;
    }

    public Authentication getAuthentication(HttpServletRequest request) {
        final String token = request.getHeader(AUTH_HEADER_NAME);
        if (token != null && tokenHandler.parseUserFromToken(token).isPresent()) {
            String userId = tokenHandler.parseUserFromToken(token).get();
            return new UserAuthentication(userId);
        }
        return null;
    }
}
