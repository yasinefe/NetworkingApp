/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.rbwm.ted.appointment.api.LoginServiceApi;
import com.rbwm.ted.appointment.audit.AuditContext;
import com.rbwm.ted.appointment.audit.AuditProcessor;
import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.http.HeaderContext;
import com.rbwm.ted.appointment.login.Credentials;
import com.rbwm.ted.appointment.login.LoginResponse;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import static com.rbwm.ted.appointment.audit.AuditableAction.LOGIN;
import static com.rbwm.ted.appointment.model.Headers.*;

/**
 * Created by 44052007 on 29/11/2017.
 */
@RestController
public class LoginController {

    private final LoginServiceApi loginService;
    private final AuditProcessor auditProcessor;

    @Autowired
    public LoginController(LoginServiceApi loginService, AuditProcessor auditProcessor) {
        this.loginService = loginService;
        this.auditProcessor = auditProcessor;
    }

    @RequestMapping(path = "/login", method = RequestMethod.POST)
    public Mono<LoginResponse> doLogin(@RequestBody Credentials credentials,
                                       @RequestHeader(value = BRANCH_ID_HEADER, required = false) String branchId,
                                       @RequestHeader(value = MACHINE_ID_HEADER, required = false) String machineId,
                                       @RequestHeader(value = WIFI_MAC_ADDRESS_HEADER, required = false) String wifiMACAddress,
                                       @RequestHeader(value = COUNTRY_CODE_HEADER, required = false, defaultValue = "GBR") String countryCode) {
        return loginService.login(credentials).map(loginResponse -> {
            String correlationId = CorrelationIdContainer.getId();
            HeaderContext headerContext = new HeaderContext(branchId, wifiMACAddress, machineId, countryCode);
            DataFetcherAudit dataFetcherAudit = new DataFetcherAudit(loginResponse.user.employeeId, LOGIN.name(), LOGIN.entityType.name(), loginResponse.user);
            auditProcessor.sendEvent(new AuditContext(correlationId, headerContext, loginResponse.user.employeeId, null, null, false, dataFetcherAudit));
            return loginResponse;
        });
    }

}
