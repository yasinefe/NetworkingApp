/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.api;

import com.rbwm.ted.appointment.model.AppointmentStatus;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

/**
 * Created by 44027117 on 22/02/2017.
 */
public interface WalkInServiceApi {

    Mono<Map<String, Object>> getWalkInList(String branchId);

    Mono<Map<String, Object>> updateStatus(String id, AppointmentStatus appointmentStatus);

    Mono<List<Map<String, Object>>> getStatusSummary(String branchId);

    Mono<Map<String, Object>> create(Map<String, Object> input);

    Mono<Map<String, Object>> getWalkIn(String appointmentId);

    Mono<Map<String, Object>> getStats(String branchId);
}
