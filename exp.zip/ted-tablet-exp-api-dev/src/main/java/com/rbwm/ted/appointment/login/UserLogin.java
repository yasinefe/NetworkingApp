/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.login;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.LoginConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;

import static com.rbwm.ted.appointment.login.LoginTransformer.transform;

/**
 * Created by 44052007 on 29/11/2017.
 */
@Component
public class UserLogin {
    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<Map<String, Object>> responseHandler;
    private final LoginConfiguration loginConfiguration;
    private static final String FEATURE_PREFIX = "LOGIN-USER";

    @Autowired
    public UserLogin(LoginConfiguration loginConfiguration,
                     ReactiveResponseHandler<Map<String, Object>> responseHandler) {
        this.loginConfiguration = loginConfiguration;
        this.responseHandler = responseHandler;
        this.crudRest = loginConfiguration.loginCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<LoginResponse> login(Credentials credentials) {
        return responseHandler.handleResponse(
                crudRest.doPost(loginConfiguration.getLoginUri(), getBody(credentials), String.class)
        ).map(transform);
    }

    private String getBody(Credentials credentials) {
        return "{ \"staffId\" : \"" + credentials.staffId + "\", \"password\": \"" + credentials.password + "\"}";
    }
}
