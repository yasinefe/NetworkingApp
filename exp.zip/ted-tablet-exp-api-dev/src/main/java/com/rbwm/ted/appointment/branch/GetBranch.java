/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.branch;

import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.rbwm.ted.appointment.schema.model.Branch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import reactor.core.publisher.Mono;

/**
 * Created by 43578876 on 21/04/2017.
 */
@Component
public class GetBranch {

    private final ReactiveCRUDRest crudRest;
    private final AppointmentConfiguration appointmentConfiguration;
    private static final String FEATURE_PREFIX = "GET-BRANCH";

    @Autowired
    public GetBranch(AppointmentConfiguration appointmentConfiguration) {
        this.appointmentConfiguration = appointmentConfiguration;
        crudRest = appointmentConfiguration.branchCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Branch> getBranchByMacAddress(String macAddress) {
        return crudRest.doGet(buildBranchUrlWithMacAddress(macAddress), new LinkedMultiValueMap<>(), Branch.class)
                .map(ClientResponse::getBody);
    }

    public Mono<Branch> getBranchById(String branchId) {
        return crudRest.doGet(buildBranchUrlWithId(branchId), new LinkedMultiValueMap<>(), Branch.class)
                .map(ClientResponse::getBody);
    }

    private String buildBranchUrlWithMacAddress(String macAddress) {
        return this.appointmentConfiguration.getBranchesListUri() + "/macAddress/" + macAddress;
    }

    private String buildBranchUrlWithId(String branchId) {
        return this.appointmentConfiguration.getBranchesListUri() + "/branchId/" + branchId;
    }
}
