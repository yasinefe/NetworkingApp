/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.wiring;

import com.rbwm.ted.appointment.schema.fetcher.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;

/**
 * Created by 44052007 on 17/01/2018.
 */
@Component
public class RootTypeWiring extends AbstractTypeWiring {

    @Autowired
    public RootTypeWiring(NodeDataFetcher nodeDataFetcher,
                          RootDataFetcher rootDataFetcher, AppointmentDataFetcher appointmentDataFetcher,
                          NewsDataFetcher newsDataFetcher, ProductCategoryDataFetcher productCategoryDataFetcher,
                          WalkInDataFetcher walkInDataFetcher, BranchesDataFetcher branchesDataFetcher,
                          StaffDataFetcher staffDataFetcher, UserProfileDataFetcher userProfileDataFetcher,
                          SkillbuildersDataFetcher skillBuildersDataFetcher,
                          MeetingsDataFetcher meetingsDataFetcher) {
        addTypeWiring(newTypeWiring("Root")
                .dataFetcher("ted", rootDataFetcher.tedFetcher)
                .dataFetcher("viewer", rootDataFetcher.viewerFetcher)
                .dataFetcher("node", nodeDataFetcher.nodeFetcher));

        addTypeWiring(newTypeWiring("ted")
                .dataFetcher("appointment", appointmentDataFetcher.appointmentFetcher)
                .dataFetcher("productCategories", productCategoryDataFetcher.listFetcher)
                .dataFetcher("walkIn", walkInDataFetcher.walkInFetcher)
                .dataFetcher("walkInStats", walkInDataFetcher.statsFetcher));

        addTypeWiring(newTypeWiring("Viewer")
                .dataFetcher("id", rootDataFetcher.viewerIdFetcher)
                .dataFetcher("branches", branchesDataFetcher.branchesFetcher)
                .dataFetcher("branch", branchesDataFetcher.branchFetcher)
                .dataFetcher("branchStaff", staffDataFetcher.branchStaffFetcher)
                .dataFetcher("userProfile", userProfileDataFetcher.getUserProfile)
                .dataFetcher("meetings", meetingsDataFetcher.groupFetcher)
                .dataFetcher("skillbuilders", skillBuildersDataFetcher.viewerFetcher)
                .dataFetcher("newsArticles", newsDataFetcher.newsFeedDataFetcher)
                .dataFetcher("meetingList", meetingsDataFetcher.meetingsFetcher)
                .dataFetcher("nextWorkingDayMeetingList", meetingsDataFetcher.nextWorkingDayMeetingsFetcher)
                .dataFetcher("meetingStats", meetingsDataFetcher.meetingStatsFetcher));
    }

}
