/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import com.hsbc.rbwm.ted.rest.error.ErrorCode;
import com.hsbc.rbwm.ted.rest.error.Exceptions.ServerException;
import com.hsbc.rbwm.ted.rest.error.Exceptions.UnexpectedException;
import com.rbwm.ted.appointment.error.ErrorLogging.ErrorLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.util.HashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.error.Exceptions.TEE_UNEXPECTED_ERROR;
import static com.rbwm.ted.appointment.model.Headers.*;
import static java.util.Collections.singletonList;

/**
 * Created by 44052007 on 06/04/2017.
 */
@ControllerAdvice
@Configuration
public class ControllerExceptionHandler {

    @Autowired
    private ErrorHandler errorHandler;

    @Autowired
    private ErrorLogging errorLogging;

    @ExceptionHandler(ServerException.class)
    public ResponseEntity handle(ServerException exception, WebRequest webRequest){
        Error error = errorHandler.getError(exception);
        errorLogging.log(error, exception, createErrorLog(webRequest));
        return ResponseEntity.status(error.httpStatus).body(createError(exception));
    }

    @ExceptionHandler(UnexpectedException.class)
    public ResponseEntity handle(UnexpectedException exception, WebRequest webRequest){
        Error error = errorHandler.getError(exception);
        errorLogging.log(error, exception.getCause(), createErrorLog(webRequest));
        return ResponseEntity.status(error.httpStatus).body(createError(exception));
    }

    @Bean
    public ErrorAttributes errorAttributes() {
        return new DefaultErrorAttributes() {
            @Override
            public Map<String, Object> getErrorAttributes(WebRequest webRequest, boolean includeStackTrace) {
                Map<String, Object> errorAttributes = super.getErrorAttributes(webRequest, includeStackTrace);
                String message = (String) errorAttributes.get("message");
                UnexpectedException unexpectedException = new UnexpectedException(TEE_UNEXPECTED_ERROR, new RuntimeException(message), message);
                errorLogging.log(errorHandler.getError(unexpectedException), unexpectedException, createErrorLog(webRequest));
                return createError(unexpectedException);
            }
        };
    }

    private Map<String, Object> createError(final ServerException exception) {
        Map<String, Object> newErrorAttributes = new HashMap<>();
        newErrorAttributes.put("data", null);
        newErrorAttributes.put("errors", singletonList(new ErrorCode(exception.getErrorCode().code, exception.getMessage())));
        return newErrorAttributes;
    }

    private ErrorLog createErrorLog(WebRequest httpServletRequest) {
        return new ErrorLog().add("BranchId", httpServletRequest.getHeader(BRANCH_ID_HEADER))
                .add("MachineId", httpServletRequest.getHeader(MACHINE_ID_HEADER))
                .add("WifiMacAddress", httpServletRequest.getHeader(WIFI_MAC_ADDRESS_HEADER));
    }

}
