package com.rbwm.ted.appointment.schema.wiring;

import com.rbwm.ted.appointment.schema.fetcher.MeetingsDataFetcher;
import com.rbwm.ted.appointment.schema.fetcher.RootDataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;

/**
 * Created by 44093684 on 14/03/2018.
 */
@Component
public class MeetingTypeWiring extends AbstractTypeWiring {

    @Autowired
    public MeetingTypeWiring(RootDataFetcher rootDataFetcher, MeetingsDataFetcher meetingsDataFetcher) {

        addTypeWiring(newTypeWiring("MeetingGroupConnection")
                .dataFetcher("count", rootDataFetcher.edgeCountFetcher));
        addTypeWiring(newTypeWiring("MeetingConnection")
                .dataFetcher("count", rootDataFetcher.edgeCountFetcher)
                .dataFetcher("newCount", meetingsDataFetcher.newCountDataFetcher)
                .dataFetcher("overdueCount", meetingsDataFetcher.overdueCountDataFetcher)
                .dataFetcher("overdueCriticalCount", meetingsDataFetcher.overdueCriticalCountDataFetcher)
                .dataFetcher("overrunCount", meetingsDataFetcher.overrunCountDataFetcher)
                .dataFetcher("overrunCriticalCount", meetingsDataFetcher.overrunCriticalCountDataFetcher)
                .dataFetcher("noShowCount", meetingsDataFetcher.noShowCountDataFetcher));

    }
}
