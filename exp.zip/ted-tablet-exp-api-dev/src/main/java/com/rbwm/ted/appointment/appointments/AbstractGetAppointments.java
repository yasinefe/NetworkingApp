/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentBookingConfiguration;
import com.rbwm.ted.appointment.meetings.MeetingTransformer;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Collections.singletonList;

/**
 * Created by 44052007 on 19/06/2017.
 */
public abstract class AbstractGetAppointments {

    protected final AppointmentBookingConfiguration appointmentBookingConfiguration;

    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<List<Map<String,Object>>> responseHandler;

    public AbstractGetAppointments(AppointmentBookingConfiguration appointmentBookingConfiguration,
                                   ReactiveResponseHandler<List<Map<String,Object>>> responseHandler,
                                   String featurePrefix) {
        this.appointmentBookingConfiguration = appointmentBookingConfiguration;
        this.responseHandler = responseHandler;

        crudRest = appointmentBookingConfiguration.appointmentBookingCRUDRestBuilder(featurePrefix).build();
    }

    public Mono<List<Map<String,Object>>> getAppointments(String branchId, MeetingStatus meetingStatus, MeetingGroupType meetingGroup) {
        return responseHandler.extractBody(crudRest.doGet(getUri(branchId), getRequestParameters(meetingStatus, meetingGroup), String.class))
                .map(MeetingTransformer.transformAppointmentsToMeetings);
    }

    private Map<String, List<String>> getRequestParameters(MeetingStatus meetingStatus, MeetingGroupType meetingGroup) {
        Map<String, List<String>> params = new HashMap<>();
        if (meetingStatus != null) {
            params.put("meetingStatus", singletonList(meetingStatus.name()));
        }
        if (meetingGroup != null) {
            params.put("meetingGroup", singletonList(meetingGroup.name()));
        }
        return params;
    }

    protected abstract String getUri(String branchId);

}
