/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.api.SkillBuildersServiceApi;
import com.rbwm.ted.appointment.schema.filter.GroupedFilteredConnection;
import com.rbwm.ted.appointment.schema.model.VideoSummary;
import graphql.schema.DataFetcher;
import graphql.schema.StaticDataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Created by 44093684 on 22/01/2018.
 */
@Component
public class SkillbuildersDataFetcher {

    public final DataFetcher viewerFetcher;
    public final DataFetcher<CompletableFuture<VideoSummary>> summaryFetcher;
    public final DataFetcher<CompletableFuture> videosGroupFetcher;

    @Autowired
    public SkillbuildersDataFetcher(SkillBuildersServiceApi skillBuildersServiceApi) {

        viewerFetcher = new StaticDataFetcher("SkillbuildersViewer");

        summaryFetcher = env -> {
            Map<String, Object> filters = env.getArgument("filter");
            String countryCode = env.getArgument("countryCode");
            String branchId = env.getArgument("branchId");

            return skillBuildersServiceApi.getSummary(filters, countryCode, branchId)
                    .toFuture();
        };

        videosGroupFetcher = env -> {
            Map<String, Object> filters = env.getArgument("filter");
            String groupBy = env.getArgument("groupBy");
            String countryCode = env.getArgument("countryCode");
            String branchId = env.getArgument("branchId");

            return GroupedFilteredConnection
                    .mapGroupedConnectionFromMono(skillBuildersServiceApi.getVideoGroups(filters, groupBy, countryCode, branchId), env);
        };
    }

}
