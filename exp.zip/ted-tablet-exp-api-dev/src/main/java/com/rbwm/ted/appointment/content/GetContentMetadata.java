/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.content;

import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.ContentConfiguration;
import com.rbwm.ted.appointment.content.ContentMetadata.Metadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import reactor.core.publisher.Mono;

import java.util.function.Function;

/**
 * Created by 44052007 on 31/10/2017.
 */
@Component
public class GetContentMetadata {

    private static final String FEATURE_PREFIX = "GET-CONTENT-METADATA";

    private final ReactiveCRUDRest crudRest;
    private final ContentConfiguration contentConfiguration;
    private final Function<Metadata, Metadata> transformContentMetadata;

    @Autowired
    public GetContentMetadata(ContentConfiguration contentConfiguration) {
        this.contentConfiguration = contentConfiguration;

        crudRest = contentConfiguration.videoContentCRUDRestBuilder(FEATURE_PREFIX).build();

        transformContentMetadata = contentMetadata -> {
           contentMetadata.sections.forEach(section -> section.contents.forEach(content -> {
               if (content.content != null) {
                   content.content.addHostName(contentConfiguration.getVideoContentHostname());
               }
           }));
           return contentMetadata;
        };
    }

    public Mono<Metadata> getContentMetadata() {
        return crudRest.doGet(contentConfiguration.getVideoContentMetadataUri(), new LinkedMultiValueMap<>(), Metadata.class)
                .map(ClientResponse::getBody).map(transformContentMetadata);
    }

}
