/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.meetings;

import com.rbwm.ted.appointment.api.MeetingServiceApi;
import com.rbwm.ted.appointment.appointments.*;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import com.rbwm.ted.appointment.model.MeetingType;
import com.rbwm.ted.appointment.walkins.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static com.rbwm.ted.appointment.error.Exceptions.TEE_INVALID_PARAMETER;
import static com.rbwm.ted.appointment.model.MeetingType.APPOINTMENTS;
import static com.rbwm.ted.appointment.model.MeetingType.WALK_INS;
import static java.util.Comparator.comparing;

/**
 * Created by 44052007 on 26/04/2018.
 */
@Service
public class MeetingService implements MeetingServiceApi {

    private final GetWalkIns getWalkIns;
    private final GetAppointments getAppointments;
    private final GetWalkInMeeting getWalkInMeeting;
    private final GetAppointmentMeeting getAppointmentMeeting;
    private final GetNextWorkingDayAppointments getNextWorkingDayAppointments;
    private final CreateWalkIn createWalkIn;
    private final UpdateWalkInStatus updateWalkInStatus;
    private final UpdateAppointmentMeetingStatus updateAppointmentMeetingStatus;
    private final GetAppointmentStats getAppointmentStats;
    private final GetWalkInStats getWalkInStats;

    private final Function<List<Map<String, Object>>, List<Map<String, Object>>> sort = meetings -> {
        meetings.sort(comparing((meeting) -> (String) meeting.get("bookedFor")));
        return meetings;
    };

    @Autowired
    public MeetingService(GetWalkIns getWalkIns, GetAppointments getAppointments,
                          GetWalkInMeeting getWalkInMeeting, GetAppointmentMeeting getAppointmentMeeting,
                          GetNextWorkingDayAppointments getNextWorkingDayAppointments,
                          CreateWalkIn createWalkIn, UpdateWalkInStatus updateWalkInStatus,
                          UpdateAppointmentMeetingStatus updateAppointmentMeetingStatus,
                          GetAppointmentStats getAppointmentStats, GetWalkInStats getWalkInStats) {
        this.getWalkIns = getWalkIns;
        this.getAppointments = getAppointments;
        this.getWalkInMeeting = getWalkInMeeting;
        this.getAppointmentMeeting = getAppointmentMeeting;
        this.getNextWorkingDayAppointments = getNextWorkingDayAppointments;
        this.createWalkIn = createWalkIn;
        this.updateWalkInStatus = updateWalkInStatus;
        this.updateAppointmentMeetingStatus = updateAppointmentMeetingStatus;
        this.getAppointmentStats = getAppointmentStats;
        this.getWalkInStats = getWalkInStats;
    }

    @Override
    public Mono<List<Map<String, Object>>> getMeetings(String branchId, MeetingStatus meetingStatus, MeetingGroupType meetingGroupType, MeetingType meetingType) {
        if (APPOINTMENTS.equals(meetingType)) {
            return getAppointments.getAppointments(branchId, meetingStatus, meetingGroupType).map(sort);
        }
        if (WALK_INS.equals(meetingType)) {
            return getWalkIns.getWalkIns(branchId, meetingStatus, meetingGroupType).map(sort);
        }

        Mono<List<Map<String, Object>>> appointments = getAppointments.getAppointments(branchId, meetingStatus, meetingGroupType);
        Mono<List<Map<String, Object>>> walkIns = getWalkIns.getWalkIns(branchId, meetingStatus, meetingGroupType);

        return Mono.zip(appointments, walkIns).map(objects -> {
            List<Map<String, Object>> appointmentList = objects.getT1();
            List<Map<String, Object>> walkInList = objects.getT2();

            List<Map<String, Object>> allMeetings = new ArrayList<>();
            allMeetings.addAll(appointmentList);
            allMeetings.addAll(walkInList);

            sort.apply(allMeetings);

            return allMeetings;
        });
    }

    @Override
    public Mono<List<Map<String, Object>>> getNextWorkingDayMeetings(String branchId, MeetingStatus meetingStatus, MeetingGroupType meetingGroupType) {
        return getNextWorkingDayAppointments.getAppointments(branchId, meetingStatus, meetingGroupType).map(sort);
    }

    @Override
    public Mono<Map<String, Object>> getMeeting(String meetingId) {
        if (meetingId.startsWith(MeetingType.WALK_INS.name())) return getWalkInMeeting.getWalkIn(extractId(meetingId));
        if (meetingId.startsWith(MeetingType.APPOINTMENTS.name())) return getAppointmentMeeting.getAppointment(extractId(meetingId));
        throw new Exceptions.InvalidRequestException(TEE_INVALID_PARAMETER, null, "Meeting id must start with either WALK_INS or APPOINTMENTS");
    }

    @Override
    public Mono<Map<String, Object>> changeMeetingStatus(String meetingId, MeetingStatus meetingStatus) {
        if (meetingId.startsWith(MeetingType.WALK_INS.name())) return updateWalkInStatus.updateWalkInStatus(extractId(meetingId), meetingStatus);
        if (meetingId.startsWith(MeetingType.APPOINTMENTS.name())) return updateAppointmentMeetingStatus.updateAppointmentStatus(extractId(meetingId), meetingStatus, null);
        throw new Exceptions.InvalidRequestException(TEE_INVALID_PARAMETER, null, "Meeting id must start with either WALK_INS or APPOINTMENTS");
    }

    @Override
    public Mono<Map<String, Object>> checkInMeeting(String meetingId, Boolean proofOfId) {
        if (meetingId.startsWith(MeetingType.APPOINTMENTS.name())) return updateAppointmentMeetingStatus.updateAppointmentStatus(extractId(meetingId), MeetingStatus.CHECKED_IN, proofOfId);
        throw new Exceptions.InvalidRequestException(TEE_INVALID_PARAMETER, null, "Meeting id must start with APPOINTMENTS to check in");
    }

    @Override
    public Mono<Map<String, Object>> createMeeting(MeetingInput meetingInput) {
        return createWalkIn.createWalkIn(meetingInput);
    }

    @Override
    public Mono<Map<String, Object>> getMeetingStats(String branchId) {
        Mono<MeetingStats> walkInStatsMono = getWalkInStats.getWalkInStats(branchId);
        Mono<MeetingStats> appointmentStatsMono = getAppointmentStats.getAppointmentStats(branchId);

        return Mono.zip(walkInStatsMono, appointmentStatsMono).map(tuple -> {
            MeetingStats walkInStats = tuple.getT1();
            MeetingStats appointmentStats = tuple.getT1();

            Map<String, Object> stats = new HashMap<>();
            stats.put("averageWaitingTime", calculateAverage(walkInStats.waitingTime, appointmentStats.waitingTime));
            stats.put("averageWaitingTimeLastWorkingDay", calculateAverage(walkInStats.waitingTimeLastWorkingDay, appointmentStats.waitingTimeLastWorkingDay));
            stats.put("averageMeetingLength", calculateAverage(walkInStats.meetingLength, appointmentStats.meetingLength));
            stats.put("inNextHour", walkInStats.inNextHour + appointmentStats.inNextHour);
            return stats;
        });
    }

    private Integer calculateAverage(StatData statData1, StatData statData2) {
        Integer totalCount = statData1.count + statData2.count;

        if (totalCount == 0) {
            return null;
        } else {
            double totalSum = (statData1.sum + statData2.sum) / totalCount;
            return (int) Math.round(totalSum / TimeUnit.MINUTES.toMillis(1));
        }
    }

    private String extractId(String meetingId) {
        if (meetingId.contains(MeetingTransformer.SEPARATOR)) {
            return meetingId.substring(meetingId.indexOf(MeetingTransformer.SEPARATOR) + 1);
        }
        throw new Exceptions.InvalidRequestException(TEE_INVALID_PARAMETER, null, "Meeting id should contain meeting type and id with separator");
    }

}
