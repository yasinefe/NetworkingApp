/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.rbwm.ted.appointment.api.AppointmentBookingServiceApi;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by 44052007 on 19/06/2017.
 */
@Service
public class AppointmentBookingService implements AppointmentBookingServiceApi {

    private final GetAppointment getAppointment;
    private final GetAppointmentSummary getAppointmentSummary;
    private final UpdateAppointmentStatus updateAppointmentStatus;
    private final GetAppointmentList getAppointmentList;
    private final SetProofOfId setProofOfId;

    @Autowired
    public AppointmentBookingService(GetAppointment getAppointment,
                                     UpdateAppointmentStatus updateAppointmentStatus,
                                     GetAppointmentSummary getAppointmentSummary,
                                     GetAppointmentList getAppointmentList,
                                     SetProofOfId setProofOfId) {
        this.getAppointment = getAppointment;
        this.updateAppointmentStatus = updateAppointmentStatus;
        this.getAppointmentSummary = getAppointmentSummary;
        this.getAppointmentList = getAppointmentList;
        this.setProofOfId = setProofOfId;
    }

    @Override
    public Mono<Map<String, Object>> getAppointmentList(String branchId, AppointmentStatus status) {
        return getAppointmentList.getAppointmentList(branchId, status);
    }

    @Override
    public Mono<Map<String, Object>> getAppointment(String appointmentId) {
        return getAppointment.getAppointment(appointmentId);
    }


    @Override
    public Mono<Map<String,Object>> updateAppointmentStatus(String appointmentId, AppointmentStatus appointmentStatus) {
        return updateAppointmentStatus.updateStatus(appointmentId, appointmentStatus);
    }

    @Override
    public Mono<Map<String,Object>> updateProofOfId(String appointmentId, Boolean proofOfId) {
        return setProofOfId.setProofOfId(appointmentId, proofOfId);
    }

    @Override
    public Mono<List<Map<String, Object>>> getAppointmentSummary(String branchId, Set<String> statuses) {
        return getAppointmentSummary.getAppointmentSummary(branchId, statuses);
    }
}
