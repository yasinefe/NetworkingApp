/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.Set;

/**
 * Created by 44093684 on 23/01/2018.
 */
@EqualsAndHashCode
@ToString
public class Video {

    public final String moid;
    public final String title;
    public final Set<String> categories;
    public final Set<String> subCategories;

    public final Integer viewCount;
    public final Integer averageRating;
    public final Integer ratingCount;
    public final Integer playlistParticipationCount;

    @JsonCreator
    public Video(@JsonProperty("moid") String moid,
                 @JsonProperty("title") String title,
                 @JsonProperty("categories") Set<String> categories,
                 @JsonProperty("subCategories") Set<String> subCategories,
                 @JsonProperty("viewCount") Integer viewCount,
                 @JsonProperty("averageRating") Integer averageRating,
                 @JsonProperty("ratingCount") Integer ratingCount,
                 @JsonProperty("playlistParticipationCount") Integer playlistParticipationCount) {

        this.moid = moid;
        this.title = title;
        this.categories = categories;
        this.subCategories = subCategories;
        this.viewCount = viewCount;
        this.averageRating = averageRating;
        this.ratingCount = ratingCount;
        this.playlistParticipationCount = playlistParticipationCount;
    }


}
