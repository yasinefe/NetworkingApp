/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.api.WalkInServiceApi;
import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import static com.rbwm.ted.appointment.model.AppointmentFields.APPOINTMENT_ID;
import static com.rbwm.ted.appointment.schema.graphql.GraphQLContext.addActionType;
import static com.rbwm.ted.appointment.schema.graphql.GraphQLContext.branchIdExtractor;
import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.relay;
import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.resolveId;
import static java.util.concurrent.CompletableFuture.completedFuture;

/**
 * Created by 44027117 on 20/02/2017.
 */
@Component
public class WalkInDataFetcher {
    public final DataFetcher<CompletableFuture> mutationPayloadSummaryFetcher;
    public final DataFetcher<CompletableFuture> walkInFetcher;
    public final DataFetcher<CompletableFuture> statsFetcher;
    public final DataFetcher<CompletableFuture> statsNodeFetcher;
    public final DataFetcher<CompletableFuture> walkInNodeFetcher;
    public final DataFetcher<CompletableFuture> walkInListFetcher;
    public final DataFetcher<CompletableFuture> walkInListNodeFetcher;

    @Autowired
    public WalkInDataFetcher(WalkInServiceApi walkInService) {
        walkInListFetcher = env ->
                walkInService.getWalkInList(branchIdExtractor.apply(env))
                        .map(walkInList -> {
                            walkInList.put("id", relay.toGlobalId("walkInList", String.valueOf(branchIdExtractor.apply(env))));
                            return walkInList;
                        }).toFuture();

        walkInListNodeFetcher = env -> {
            String branchId = resolveId.apply(env.getArgument("id"));
            return walkInService.getWalkInList(branchId).map(walkInList -> {
                walkInList.put("id", relay.toGlobalId("walkInList", String.valueOf(branchIdExtractor.apply(env))));
                return walkInList;
            }).toFuture();
        };

        Function<String, Mono<Map<String, Object>>> retrieveWalkIn = walkInService::getWalkIn;

        mutationPayloadSummaryFetcher = env -> {
            GraphQLContext context = env.getContext();
            return context.getWalkinData() != null ?
                    completedFuture(context.getWalkinData().get("summary")) :
                    walkInService.getStatusSummary(branchIdExtractor.apply(env)).toFuture();
        };

        walkInFetcher = env -> {
            DataFetchingEnvironment dataFetchingEnvironment = addActionType.apply(env, AuditableAction.WALKIN_RETRIEVE);
            return walkInService.getWalkIn(dataFetchingEnvironment.getArgument(APPOINTMENT_ID.val())).toFuture();
        };

        walkInNodeFetcher = env -> retrieveWalkIn.compose(resolveId).apply(env.getArgument("id")).toFuture();

        statsFetcher = env -> walkInService.getStats(branchIdExtractor.apply(env)).map(walkInStats -> {
            walkInStats.put("id", relay.toGlobalId("walkInStats", String.valueOf(branchIdExtractor.apply(env))));
            return walkInStats;
        }).toFuture();

        statsNodeFetcher = env -> {
            String branchId = resolveId.apply(env.getArgument("id"));
            return walkInService.getStats(branchId).map(walkInStats -> {
                walkInStats.put("id", relay.toGlobalId("walkInStats", branchId));
                return walkInStats;
            }).toFuture();
        };
    }
}
