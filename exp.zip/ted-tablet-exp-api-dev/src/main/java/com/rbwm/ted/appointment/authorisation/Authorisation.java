/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.authorisation;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;

/**
 * Created by 44052007 on 04/12/2017.
 */
@EqualsAndHashCode
public class Authorisation {

    public final CrudPermission walkIn;
    public final CrudPermission appointment;
    public final CrudPermission help;
    public final CrudPermission miReport;
    public final CrudPermission skillbuilders;

    @JsonCreator
    public Authorisation(@JsonProperty("walkIn") CrudPermission walkIn,
                         @JsonProperty("appointment") CrudPermission appointment,
                         @JsonProperty("help") CrudPermission help,
                         @JsonProperty("miReport") CrudPermission miReport,
                         @JsonProperty("skillBuilder") CrudPermission skillbuilders) {
        this.walkIn = walkIn;
        this.appointment = appointment;
        this.help = help;
        this.miReport = miReport;
        this.skillbuilders = skillbuilders;
    }
}
