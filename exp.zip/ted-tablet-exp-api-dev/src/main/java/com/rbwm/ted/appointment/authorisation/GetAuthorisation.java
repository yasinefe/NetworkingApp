/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.authorisation;

import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.AuthorisationConfiguration;
import com.rbwm.ted.appointment.model.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import reactor.core.publisher.Mono;

/**
 * Created by 44052007 on 08/12/2017.
 */
@Component
public class GetAuthorisation {
    private final ReactiveCRUDRest crudRest;
    private final AuthorisationConfiguration authorisationConfiguration;
    private static final String FEATURE_PREFIX = "GET-AUTHORISATION";

    @Autowired
    public GetAuthorisation(AuthorisationConfiguration authorisationConfiguration) {
        this.authorisationConfiguration = authorisationConfiguration;
        crudRest = authorisationConfiguration.authorisationCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Authorisation> get(Role role, String userId, String branchId, String countryCode) {
        return crudRest.doGet(getUrlWithRole(role), createQueryParams(userId, branchId, countryCode), Authorisation.class)
                .map(ClientResponse::getBody);
    }

    private LinkedMultiValueMap<String, String> createQueryParams(String userId, String branchId, String countryCode) {
        LinkedMultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.add("userId", userId);
        queryParams.add("branchId", branchId);
        queryParams.add("countryCode", countryCode);
        return queryParams;
    }

    private String getUrlWithRole(Role role) {
        return authorisationConfiguration.getAuthorisationUri() + "/" + role;
    }
}
