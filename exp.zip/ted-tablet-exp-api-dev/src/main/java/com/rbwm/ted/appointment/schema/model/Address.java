/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;

/**
 * Created by 44052007 on 20/11/2017.
 */
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {

    public final String addressLine1;
    public final String addressLine2;
    public final String city;
    public final String postcode;
    public final String county;
    public final String countryCode;

    @JsonCreator
    public Address(@JsonProperty("addressLine1") String addressLine1,
                   @JsonProperty("addressLine2") String addressLine2,
                   @JsonProperty("city") String city,
                   @JsonProperty("postcode") String postcode,
                   @JsonProperty("county") String county,
                   @JsonProperty("countryCode") String countryCode) {
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.city = city;
        this.postcode = postcode;
        this.county = county;
        this.countryCode = countryCode;
    }
}
