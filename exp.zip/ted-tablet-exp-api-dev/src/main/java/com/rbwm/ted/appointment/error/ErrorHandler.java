/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.rbwm.ted.rest.error.Exceptions.ServerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import static java.lang.Thread.currentThread;

/**
 * Created by 44052007 on 07/04/2017.
 */
@Component
public class ErrorHandler {

    private final ObjectMapper objectMapper;
    private List<Error> errors;
    private List<Resolution> resolutions;

    @Autowired
    public ErrorHandler(ObjectMapper objectMapper) throws IOException {
        this.objectMapper = objectMapper;
        loadErrors();
    }

    private void loadErrors() throws IOException {
        loadResolutions();

        InputStream in = currentThread().getContextClassLoader().getResourceAsStream("errors.json");
        errors = objectMapper.readValue(in, new TypeReference<List<Error>>() {});
    }

    private void loadResolutions() throws IOException {
        InputStream in = currentThread().getContextClassLoader().getResourceAsStream("resolutions.json");
        resolutions = objectMapper.readValue(in, new TypeReference<List<Resolution>>() {});
    }

    public List<Error> getErrors() {
        return errors;
    }

    public List<Resolution> getResolutions() {
        return resolutions;
    }

    public Error getError(ServerException serverException) {
        return errors.stream()
                .filter(error -> error.code.equals(serverException.getErrorCode().code))
                .findFirst()
                .orElse(new Error(serverException.getErrorCode().code, serverException.getMessage()));
    }
}
