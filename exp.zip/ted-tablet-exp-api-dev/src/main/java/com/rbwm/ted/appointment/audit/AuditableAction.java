/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.audit;

import static com.rbwm.ted.appointment.audit.EntityType.*;

/**
 * Created by 43578876 on 18/05/2017.
 */
public enum AuditableAction {

    WALKIN_CREATE(WALKIN),
    WALKIN_RETRIEVE(WALKIN),
    WALKIN_STATUS_CHANGE(WALKIN),
    APPOINTMENT_LIST_AND_SUMMARY(APPOINTMENT),
    APPOINTMENT_RETRIEVE(APPOINTMENT),
    APPOINTMENT_STATUS_CHANGE(APPOINTMENT),
    APPOINTMENT_CHECK_IN(APPOINTMENT),
    LOGIN(USER_PROFILE),
    MEETING_LIST(MEETING),
    MEETING_NEXT_WORKING_DAY_LIST(MEETING),
    MEETING_RETRIEVE(MEETING),
    MEETING_CREATE(MEETING),
    MEETING_CHANGE_STATUS(MEETING),
    MEETING_CHECK_IN(MEETING);

    public final EntityType entityType;

    AuditableAction(EntityType entityType) {
        this.entityType = entityType;
    }
}
