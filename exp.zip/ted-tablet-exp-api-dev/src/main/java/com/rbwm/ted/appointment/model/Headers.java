/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.model;

/**
 * Created by 44052007 on 09/05/2017.
 */
public class Headers {

    private Headers(){
    }

    public static final String BRANCH_ID_HEADER = "X-BRANCH-ID";
    public static final String MACHINE_ID_HEADER = "X-MACHINE-ID";
    public static final String WIFI_MAC_ADDRESS_HEADER = "X-WIFI-MAC-ADDRESS";
    public static final String COUNTRY_CODE_HEADER = "X-COUNTRY-CODE";

}
