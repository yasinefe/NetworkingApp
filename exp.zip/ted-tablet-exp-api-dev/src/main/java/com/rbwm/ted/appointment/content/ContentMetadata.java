/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.content;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * Created by 44052007 on 31/10/2017.
 */
public interface ContentMetadata {

    @EqualsAndHashCode
    class Metadata {
        public final List<Section> sections;

        @JsonCreator
        public Metadata(@JsonProperty("sections") List<Section> sections) {
            this.sections = sections;
        }
    }

    @EqualsAndHashCode
    class Section {

        public final String id;
        public final String name;
        public final String duration;
        public final List<Content> contents;

        @JsonCreator
        public Section(@JsonProperty("id") String id,
                       @JsonProperty("name") String name,
                       @JsonProperty("duration") String duration,
                       @JsonProperty("contents") List<Content> contents) {
            this.id = id;
            this.name = name;
            this.duration = duration;
            this.contents = contents;
        }

    }

    @EqualsAndHashCode
    class Content {
        public final String id;
        public final String name;
        public final String tip;
        public final String description;
        public final Boolean disabled;
        public final Video content;

        @JsonCreator
        public Content(@JsonProperty("id") String id,
                       @JsonProperty("name") String name,
                       @JsonProperty("tip") String tip,
                       @JsonProperty("description") String description,
                       @JsonProperty("disabled") Boolean disabled,
                       @JsonProperty("content") Video content) {
            this.id = id;
            this.name = name;
            this.tip = tip;
            this.description = description;
            this.disabled = disabled;
            this.content = content;
        }

    }

    @EqualsAndHashCode
    class Video {
        public String videoUrl;

        @JsonCreator
        public Video(@JsonProperty("videoUrl") String videoUrl) {
            this.videoUrl = videoUrl;
        }

        public void addHostName(String videoContentHostname) {
            this.videoUrl = videoContentHostname + this.videoUrl;
        }
    }
}