/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.user;

import com.rbwm.ted.appointment.api.UserProfileServiceApi;
import com.rbwm.ted.appointment.authorisation.Authorisation;
import com.rbwm.ted.appointment.authorisation.GetAuthorisation;
import com.rbwm.ted.appointment.model.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Created by 44027117 on 19/04/2017.
 */
@Service
public class UserProfileService implements UserProfileServiceApi {

    private final GetUserProfile getUserProfile;
    private final UpdateBranchUserProfile updateBranchUserProfile;
    private final GetAuthorisation getAuthorisation;
    private final UpdateUserTracking updateUserTracking;
    private final GetUserTrackings getUserTrackings;

    @Autowired
    public UserProfileService(GetUserProfile getUserProfile,
                              UpdateBranchUserProfile updateBranchUserProfile,
                              GetAuthorisation getAuthorisation,
                              UpdateUserTracking updateUserTracking,
                              GetUserTrackings getUserTrackings) {
        this.getUserProfile = getUserProfile;
        this.updateBranchUserProfile = updateBranchUserProfile;
        this.getAuthorisation = getAuthorisation;
        this.updateUserTracking = updateUserTracking;
        this.getUserTrackings = getUserTrackings;
    }

    @Override
    public Mono<UserProfile> getUserProfile(String userId) {
        return getUserProfile.get(userId);
    }

    @Override
    public Mono<Tracking> track(String userId, String key) {
        return updateUserTracking.track(userId, key);
    }

    @Override
    public Mono<List<Tracking>> getTrackings(String userId) {
        return getUserTrackings.getTrackings(userId);
    }

    @Override
    public Mono<UserProfile> updateBranch(String userId, String branchId) {
        return updateBranchUserProfile.update(userId, branchId);
    }

    @Override
    public Mono<Authorisation> getAuthorisation(Role role, String userId, String branchId, String countryCode) {
        return getAuthorisation.get(role, userId, branchId, countryCode);
    }

}
