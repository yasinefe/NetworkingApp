/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.user;

import com.rbwm.ted.appointment.model.Role;

import java.util.Map;
import java.util.function.Function;

import static com.rbwm.ted.appointment.model.UserProfileFields.*;

/**
 * Created by 44027117 on 19/04/2017.
 */
public final class UserProfileTransformer {

    private UserProfileTransformer(){
    }

    private static final Function<Object, Double> convertToDouble = (value) -> new Double(String.valueOf(value));

    public static UserProfile transform(Map<String, Object> data) {
        return new UserProfile(
                (String)data.get(USER_ID.val()),
                (Boolean)data.get(FIRST_LOGIN.val()),
                convertToDouble.apply(data.get(LAST_TIME_LOGIN.val())).longValue(),
                (String)data.get(FIRST_NAME.val()),
                (String)data.get(LAST_NAME.val()),
                (String)data.get(BRANCH_ID.val()),
                Role.get((String)data.get(ROLE.val()))
        );
    }

}
