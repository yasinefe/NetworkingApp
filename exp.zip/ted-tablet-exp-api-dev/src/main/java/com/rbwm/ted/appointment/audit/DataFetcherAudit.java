/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.audit;

import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * Created by 44027117 on 18/05/2017.
 */
@EqualsAndHashCode
@ToString
public class DataFetcherAudit {
    public final String entityId;
    public final String operationName;
    public final String type;
    public final Object entity;

    public DataFetcherAudit(final String entityId, final String operationName, final String type, final Object entity) {
        this.entityId = entityId;
        this.operationName = operationName;
        this.type = type;
        this.entity = entity;
    }

    @ToString
    public static class Builder {
        private String entityId;
        private String operationName;
        private String type;
        private Object entity;

        public Builder withEntityId(String entityId) {
            this.entityId = entityId;
            return this;
        }

        public Builder withOperationName(String operationName) {
            this.operationName = operationName;
            return this;
        }

        public Builder withType(String type) {
            this.type = type;
            return this;
        }

        public Builder withEntity(Object entity) {
            this.entity = entity;
            return this;
        }

        public Builder withAuditAction(AuditableAction auditAction) {
            this.type = auditAction.entityType.name();
            this.operationName = auditAction.name();
            return this;
        }

        public DataFetcherAudit build() {
            return new DataFetcherAudit(entityId, operationName, type, entity);
        }
    }
}
