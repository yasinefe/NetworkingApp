/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.api.MeetingServiceApi;
import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.meetings.MeetingInput;
import com.rbwm.ted.appointment.model.Gender;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static com.rbwm.ted.appointment.schema.graphql.GraphQLContext.branchIdExtractor;

/**
 * Created by 44052007 on 16/05/2018.
 */
@Component
public class MeetingCreator {

    public final DataFetcher<CompletableFuture> createMeeting;

    @Autowired
    public MeetingCreator(MeetingServiceApi meetingServiceApi) {
        createMeeting = env -> {
            Map<String, Object> input = env.getArgument("input");

            MeetingInput meetingInput = new MeetingInput(
                    branchIdExtractor.apply(env),
                    Gender.getGender((String)input.get("gender")),
                    (String) input.get("firstName"),
                    (String) input.get("lastName"),
                    (String) input.get("topicId"),
                    (String) input.get("topicCategoryId"),
                    (String) input.get("topicSubCategoryId"),
                    (Boolean) input.get("proofOfId"),
                    (String) input.get("comments"));

            GraphQLContext graphQLContext = env.getContext();
            input.put("branchId", branchIdExtractor.apply(env));

            return meetingServiceApi.createMeeting(meetingInput).map(meeting -> {
                Map<String, Object> result = new LinkedHashMap<>();
                result.put("clientMutationId", input.get("clientMutationId"));
                result.put("meeting", meeting);

                setDataFetcherAuditData(graphQLContext.getDataFetcherAudit(), meeting);

                return result;
            }).toFuture();
        };
    }

    private void setDataFetcherAuditData(DataFetcherAudit.Builder dataFetcherAuditBuilder, Map<String, Object> meeting) {
        dataFetcherAuditBuilder.withEntityId((String) meeting.get("meetingId"));
        dataFetcherAuditBuilder.withEntity(meeting);
        dataFetcherAuditBuilder.withAuditAction(AuditableAction.MEETING_CREATE);
    }

}
