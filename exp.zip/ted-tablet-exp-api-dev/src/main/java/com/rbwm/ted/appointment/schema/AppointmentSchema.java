/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema;

import com.rbwm.ted.appointment.schema.graphql.SchemaContext;
import com.rbwm.ted.appointment.schema.model.Node;
import com.rbwm.ted.appointment.schema.wiring.AbstractTypeWiring;
import graphql.schema.GraphQLObjectType;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.RuntimeWiring.Builder;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.List;
import java.util.Map;

import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.relay;
import static graphql.schema.idl.RuntimeWiring.newRuntimeWiring;
import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;
import static java.lang.Thread.currentThread;

/**
 * Created by 43578876 on 28/10/2016.
 */
@Component
public class AppointmentSchema {

    private final GraphQLSchema schema;
    private final SchemaContext schemaContext;
    private final List<AbstractTypeWiring> typeWiringBaseList;

    @Autowired
    public AppointmentSchema(SchemaContext schemaContext,
                             List<AbstractTypeWiring> typeWiringBaseList) {
        this.schemaContext = schemaContext;
        this.typeWiringBaseList = typeWiringBaseList;
        this.schema = createSchema();
        setTypeResolver();
    }

    private GraphQLSchema createSchema() {
        SchemaParser schemaParser = new SchemaParser();
        SchemaGenerator schemaGenerator = new SchemaGenerator();

        File schemaFile = new File(currentThread().getContextClassLoader().getResource("static/schema.graphql").getPath());

        TypeDefinitionRegistry typeRegistry = schemaParser.parse(schemaFile);
        RuntimeWiring wiring = buildRuntimeWiring();
        return schemaGenerator.makeExecutableSchema(typeRegistry, wiring);
    }

    private RuntimeWiring buildRuntimeWiring() {
        Builder builder = newRuntimeWiring();

        builder.type(newTypeWiring("Node")
                        .typeResolver(schemaContext.getTypeResolverProxy()));

        typeWiringBaseList.forEach(typeWiringBase -> typeWiringBase.typeWirings.forEach(builder::type));

        return builder.build();
    }

    private void setTypeResolver() {
        schemaContext.getTypeResolverProxy().setTypeResolver(
                typeResolver -> {
                    if (typeResolver.getObject() instanceof Map) {
                        Map objMap = (Map) typeResolver.getObject();
                        return (GraphQLObjectType) schema.getType(relay.fromGlobalId((String) objMap.get("id")).getType());
                    }
                    if (typeResolver.getObject() instanceof Node) {
                        return (GraphQLObjectType) schema.getType(typeResolver.getObject().getClass().getSimpleName());
                    }
                    return null;
                }
        );
    }

    public GraphQLSchema getSchema() {
        return schema;
    }
}
