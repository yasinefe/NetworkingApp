package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.api.MeetingServiceApi;
import com.rbwm.ted.appointment.api.MeetingsGroupServiceApi;
import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import com.rbwm.ted.appointment.model.MeetingType;
import com.rbwm.ted.appointment.schema.filter.FilteredConnection;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.relay.Connection;
import graphql.relay.DefaultEdge;
import graphql.relay.SimpleListConnection;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static com.rbwm.ted.appointment.schema.graphql.GraphQLContext.addActionType;
import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.resolveId;

/**
 * Created by 44093684 on 14/03/2018.
 */
@Component
public class MeetingsDataFetcher {

    public final DataFetcher<CompletableFuture> groupFetcher;
    public final DataFetcher<CompletableFuture> meetingsFetcher;
    public final DataFetcher<CompletableFuture> nextWorkingDayMeetingsFetcher;
    public final DataFetcher<CompletableFuture> meetingNodeFetcher;
    public final DataFetcher<CompletableFuture> meetingStatsFetcher;

    public final DataFetcher<Integer> newCountDataFetcher;
    public final DataFetcher<Integer> overdueCountDataFetcher;
    public final DataFetcher<Integer> overdueCriticalCountDataFetcher;
    public final DataFetcher<Integer> overrunCountDataFetcher;
    public final DataFetcher<Integer> overrunCriticalCountDataFetcher;
    public final DataFetcher<Integer> noShowCountDataFetcher;

    @Autowired
    public MeetingsDataFetcher(MeetingsGroupServiceApi meetingsGroupServiceApi, MeetingServiceApi meetingServiceApi) {

        groupFetcher = env -> {
            Map<String, Object> filters = env.getArgument("filter");
            String groupBy = env.getArgument("groupBy");

            return FilteredConnection.mapConnectionFromMono(meetingsGroupServiceApi.get(filters, groupBy), env);
        };

        meetingsFetcher = env -> {
            Map<String, Object> filter = env.getArgument("filter");
            String branchId = (String)filter.get("branchId");
            MeetingStatus status = filter.containsKey("status") ? MeetingStatus.valueOf((String)filter.get("status")) : null;
            MeetingGroupType group = filter.containsKey("group") ? MeetingGroupType.valueOf((String)filter.get("group")) : null;
            MeetingType type = filter.containsKey("type") ? MeetingType.valueOf((String)filter.get("type")) : null;

            addActionType.apply(env, AuditableAction.MEETING_LIST);

            return meetingServiceApi.getMeetings(branchId, status, group, type)
                    .map(meetings -> new SimpleListConnection<>(meetings).get(env)).toFuture();
        };

        nextWorkingDayMeetingsFetcher = env -> {
            Map<String, Object> filter = env.getArgument("filter");
            String branchId = (String)filter.get("branchId");
            MeetingStatus status = filter.containsKey("status") ? MeetingStatus.valueOf((String)filter.get("status")) : null;
            MeetingGroupType group = filter.containsKey("group") ? MeetingGroupType.valueOf((String)filter.get("group")) : null;

            addActionType.apply(env, AuditableAction.MEETING_NEXT_WORKING_DAY_LIST);

            return meetingServiceApi.getNextWorkingDayMeetings(branchId, status, group)
                    .map(meetings -> new SimpleListConnection<>(meetings).get(env)).toFuture();
        };

        meetingNodeFetcher = env -> {
            String meetingId = resolveId.apply(env.getArgument("id"));

            GraphQLContext context = env.getContext();
            context.getDataFetcherAudit()
                    .withAuditAction(AuditableAction.MEETING_RETRIEVE)
                    .withEntityId(meetingId);

            return meetingServiceApi.getMeeting(meetingId).toFuture();
        };

        newCountDataFetcher = environment -> getCount(environment, "isNew");
        overdueCountDataFetcher = environment -> getCount(environment, "isOverdue");
        overdueCriticalCountDataFetcher = environment -> getCount(environment, "isOverdueCritical");
        overrunCountDataFetcher = environment -> getCount(environment, "isOverrun");
        overrunCriticalCountDataFetcher = environment -> getCount(environment, "isOverrunCritical");
        noShowCountDataFetcher = environment -> getNoShowCount(environment);

        meetingStatsFetcher = env -> meetingServiceApi.getMeetingStats(env.getArgument("branchId")).toFuture();
    }

    private Integer getNoShowCount(DataFetchingEnvironment environment) {
        Connection connection = environment.getSource();
        List<DefaultEdge<Map<String, Object>>> meetingEdges = connection.getEdges();
        return (int) meetingEdges.stream()
                .map(DefaultEdge::getNode)
                .filter(meeting -> MeetingStatus.NOSHOW.equals(meeting.get("status"))).count();
    }

    private Integer getCount(DataFetchingEnvironment environment, String filterBy) {
        Connection connection = environment.getSource();
        List<DefaultEdge<Map<String, Object>>> meetingEdges = connection.getEdges();
        return (int) meetingEdges.stream()
                .map(DefaultEdge::getNode)
                .filter(meeting -> meeting.containsKey(filterBy) && (Boolean) meeting.get(filterBy)).count();
    }

}
