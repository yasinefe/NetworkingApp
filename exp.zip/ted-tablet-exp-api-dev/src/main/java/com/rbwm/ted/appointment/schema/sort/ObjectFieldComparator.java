/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.sort;

import graphql.GraphQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * Created by 44093684 on 08/12/2017.
 */
public class ObjectFieldComparator<T> implements Comparator<T> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ObjectFieldComparator.class);

    private final List<Sort> sorts;

    public ObjectFieldComparator(List<Sort> sorts) {
        if (sorts.isEmpty()) {
            throw new IllegalArgumentException("no Sorting criteria specified");
        }

        this.sorts = sorts;
    }

    @Override
    public int compare(T o1, T o2) {
        Iterator<Sort> iterator = sorts.iterator();
        int compareResult = 0;

        while (compareResult == 0 && iterator.hasNext()) { //use next sort if result is equal.
            Sort nextSort = iterator.next();
            compareResult = compareBySort(o1, o2, nextSort);
        }

        return compareResult;
    }

    private int compareBySort(T o1, T o2, Sort sort) {
        try {
            Object value1 = o1.getClass().getDeclaredField(sort.sortKey).get(o1);
            Object value2 = o2.getClass().getDeclaredField(sort.sortKey).get(o2);

            if (value1 instanceof Comparable && value2 instanceof Comparable) {
                return handleRegularSort(sort, (Comparable) value1, (Comparable) value2);
            } else if (value1 == null || value2 == null) {
                return handleSortWithNullValues(sort, value1, value2);
            } else {
                LOGGER.warn("field '{}' is not sortable, default sort will be applied.");
                return 0;
            }

        } catch (NoSuchFieldException e) {
            throw new GraphQLException("field " + sort.sortKey + " not found", e);
        } catch (IllegalAccessException e) {
            throw new GraphQLException("illegal access to field " + sort.sortKey, e);
        }
    }

    private int handleRegularSort(Sort sort, Comparable comparable1, Comparable comparable2) {
        return SortOrder.DESC.equals(sort.sortOrder) ? comparable2.compareTo(comparable1) : comparable1.compareTo(comparable2);
    }

    private int handleSortWithNullValues(Sort sort, Object value1, Object value2) {
        int compareValue = (value1 != null) ? 1 : (value2 != null) ? -1 : 0;
        int orderModifier = SortOrder.DESC.equals(sort.sortOrder) ? -1 : 1;

        return compareValue * orderModifier;
    }

}
