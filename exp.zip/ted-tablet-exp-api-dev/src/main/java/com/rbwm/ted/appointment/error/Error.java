/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

/**
 * Created by 44052007 on 07/04/2017.
 */
// Todo This class requires to refactor to contain only code and message
@JsonInclude(NON_NULL)
public class Error {

    public final String code;
    public final String message;
    public final ErrorLevel level;
    public final int httpStatus;
    public List<String> resolutionCodes;
    public final Map<String, Object> resolutions = new LinkedHashMap<>();

    @JsonCreator
    public Error(@JsonProperty("code") String code,
                 @JsonProperty("message") String message,
                 @JsonProperty("level") ErrorLevel level,
                 @JsonProperty("httpStatus") int httpStatus,
                 @JsonProperty("resolutionCodes") List<String> resolutionCodes) {
        this.code = code;
        this.message = message;
        this.level = level;
        this.httpStatus = httpStatus;
        this.resolutionCodes = resolutionCodes;
    }

    public Error(String code,
                 String message) {
        this.code = String.valueOf(code);
        this.message = message;
        this.level = null;
        this.httpStatus = 500;
        this.resolutionCodes = null;
    }

    public void populateResolutions(List<Resolution> allResolutions) {
        resolutionCodes.forEach(resolutionCode -> {
            Resolution errorResolution = allResolutions.stream()
                    .filter(resolution -> resolution.code.equals(resolutionCode))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException(resolutionCode + " defined in errors but not in resolution list."));
            resolutions.put(resolutionCode, errorResolution);
        });
        resolutionCodes = null;
    }

    public enum ErrorLevel {
        ERROR, WARN, SEVERE
    }

}
