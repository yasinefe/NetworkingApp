/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.google.gson.Gson;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 44027117 on 27/02/2017.
 */
@Component
public class WalkInUpdaterStatus {

    private final ReactiveCRUDRest crudRest;
    private final ReactiveResponseHandler<Map<String,Object>> responseHandler;
    private final AppointmentConfiguration appointmentConfiguration;
    private static final String FEATURE_PREFIX = "UPDATE-WALKIN-STATUS";

    @Autowired
    public WalkInUpdaterStatus(AppointmentConfiguration appointmentConfiguration,
                               ReactiveResponseHandler<Map<String, Object>> responseHandler) {
        this.appointmentConfiguration = appointmentConfiguration;
        this.crudRest = appointmentConfiguration.walkInCRUDRestBuilder(FEATURE_PREFIX).build();
        this.responseHandler = responseHandler;
    }

    public Mono<Map<String, Object>> updateStatus(String appointmentId, AppointmentStatus appointmentStatus) {
        return responseHandler.handleResponse(
                    crudRest.doPost(getUrlWithAppointmentId(appointmentId), requestParams(appointmentStatus), String.class)
                ).map(WalkInJsonTransformer.transform);
    }

    private String getUrlWithAppointmentId(String id) {
        return appointmentConfiguration.getWalkInUpdateUri() + "/" + id;
    }

    private String requestParams(AppointmentStatus status) {
        Map<String,Object> appointmentRequest = new HashMap<String,Object>();
        appointmentRequest.put("appointmentStatus", status.getCode());
        return new Gson().toJson(appointmentRequest);
    }
}
