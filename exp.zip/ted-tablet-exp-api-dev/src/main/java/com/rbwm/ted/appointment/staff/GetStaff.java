/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.staff;

import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.rbwm.ted.appointment.config.StaffConfiguration;
import com.rbwm.ted.appointment.schema.model.Staff;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Collections;

/**
 * Created by 44027117 on 19/04/2017.
 */
@Component
public class GetStaff {
    private final ReactiveCRUDRest crudRest;
    private final StaffConfiguration staffConfiguration;
    private static final String FEATURE_PREFIX = "GET-STAFF";

    @Autowired
    public GetStaff(StaffConfiguration staffConfiguration) {
        this.staffConfiguration = staffConfiguration;
        crudRest = staffConfiguration.staffCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Staff> get(String employeeId) {
        return crudRest.doGet(getUrlWithId(employeeId), Collections.emptyMap(), Staff.class)
                .map(ClientResponse::getBody);
    }

    private String getUrlWithId(String employeeId) {
        return staffConfiguration.getStaffUri() + "/employeeId/" + employeeId;
    }
}
