/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.branch.BranchesRestDataService;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.schema.filter.FilteredConnection;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import com.rbwm.ted.appointment.user.UserProfile;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import static com.rbwm.ted.appointment.error.Exceptions.TEE_INVALID_PARAMETER;
import static com.rbwm.ted.appointment.model.BranchFields.BRANCH_ID;
import static com.rbwm.ted.appointment.model.BranchFields.MAC_ADDRESS;
import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.relay;

/**
 * Created by 44027117 on 07/02/2017.
 */
@Component
public class BranchesDataFetcher {

    public final DataFetcher<CompletableFuture> branchesFetcher;
    public final DataFetcher<CompletableFuture> branchNodeFetcher;
    public final DataFetcher<CompletableFuture> branchFetcher;
    public final DataFetcher<CompletableFuture> branchFetcherBySourceId;

    @Autowired
    public BranchesDataFetcher(BranchesRestDataService branchesRestDataService) {
        Function<DataFetchingEnvironment, String> resolveId = env -> relay.fromGlobalId(env.getArgument("id")).getId();

        branchesFetcher = env -> {
            GraphQLContext context = env.getContext();
            return FilteredConnection.mapConnectionFromMono(branchesRestDataService.getBranches(context.getCountryCode(), getKeyword(env)), env);
        };

        branchNodeFetcher = env -> branchesRestDataService.getBranchById(resolveId.apply(env)).toFuture();

        branchFetcher = env -> {
            String branchId = env.getArgument(BRANCH_ID.val());
            if (StringUtils.isNotEmpty(branchId)) {
                return branchesRestDataService.getBranchById(branchId).toFuture();
            }
            String macAddress = env.getArgument(MAC_ADDRESS.val());
            if (StringUtils.isNotEmpty(macAddress)) {
                return branchesRestDataService.getBranchByMacAddress(macAddress).toFuture();
            }

            return Mono.error(new Exceptions.InvalidRequestException(
                    TEE_INVALID_PARAMETER, null, "Validation error: Branch id and Mac Address is missing, one of them must be provided")).toFuture();
        };

        branchFetcherBySourceId = env -> {
            UserProfile userProfile = env.getSource();
            return userProfile.branchId != null ? branchesRestDataService.getBranchById(userProfile.branchId).toFuture() : null;
        };
    }

    private String getKeyword(DataFetchingEnvironment env) {
        Map<String, Object> filter = env.getArgument("filter");
        return filter != null ? (String) filter.get("search") : null;
    }
}
