/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRestBuilder;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.hsbc.rbwm.ted.rest.http.HttpErrorHandler;
import com.hsbc.rbwm.ted.rest.http.HttpErrorResponseBuilder;
import com.rbwm.ted.appointment.http.CorrelationIdHttpHeaderProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * Created by 43578876 on 18/11/2016.
 */
@Configuration
@Import(DataServiceConfig.class)
public class AppointmentConfiguration {

    @Value("${ted.branches.hostname}")
    private String branchesHostname;

    @Value("${ted.branches.list.uri}")
    private String branchesListUri;

    @Value("${ted.walkins.hostname}")
    private String walkInHostname;

    @Value("${ted.walkins.list.uri}")
    private String walkInListUri;

    @Value("${ted.walkins.get.uri}")
    private String walkInGetUri;

    @Value("${ted.walkins.update.status.uri}")
    private String walkInUpdateUri;

    @Value("${ted.walkins.status.summary.uri}")
    private String walkInStatusSummaryUri;

    @Value("${ted.walkins.stats.uri}")
    private String walkInStatsUri;

    @Value("${ted.walkins.meetings.uri}")
    private String walkInsMeetingsUri;

    @Value("${ted.product.category.hostname}")
    private String productCategoryHostname;

    @Value("${ted.product.category.uri}")
    private String productCategoryUri;

    public String getWalkInListUri() {
        return walkInListUri;
    }

    public String getWalkInGetUri() {
        return walkInGetUri;
    }

    public String getWalkInUpdateUri() { return walkInUpdateUri; }

    public String getWalkInStatusSummaryUri() { return walkInStatusSummaryUri; }

    public String getWalkInStatsUri() { return walkInStatsUri; }

    public String getProductCategoryUri() {
        return productCategoryUri;
    }

    public String getBranchesListUri() {
        return branchesListUri;
    }

    public String getWalkInsMeetingsUri() {
        return walkInsMeetingsUri;
    }

    @Autowired
    private AsyncClientRestTemplate asyncClientRestTemplateForWalkIn;

    @Autowired
    private AsyncClientRestTemplate asyncClientRestTemplateForBranch;

    @Autowired
    private AsyncClientRestTemplate asyncClientRestTemplateForProductCategory;

    public ReactiveCRUDRestBuilder walkInCRUDRestBuilder(String featurePrefix) {
        return createCrudRestBuilder(featurePrefix, walkInHostname, asyncClientRestTemplateForWalkIn);
    }

    public ReactiveCRUDRestBuilder branchCRUDRestBuilder(String featurePrefix) {
        return createReactiveCrudRestBuilder(featurePrefix, branchesHostname, asyncClientRestTemplateForBranch);
    }

    public ReactiveCRUDRestBuilder productCategoryCRUDRestBuilder(String featurePrefix) {
        return createReactiveCrudRestBuilder(featurePrefix, productCategoryHostname, asyncClientRestTemplateForProductCategory);
    }

    private ReactiveCRUDRestBuilder createCrudRestBuilder(String featurePrefix, String hostname, AsyncClientRestTemplate asyncClientRestTemplate) {
        ErrorResponse errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix(HttpConfiguration.APPLICATION_PREFIX)
                        .withFeatureErrorCodePrefix(featurePrefix)
                        .build();

        return new ReactiveCRUDRestBuilder()
                .withClientRestTemplate(asyncClientRestTemplate)
                .withErrorHandler(new HttpErrorHandler(errorsResponse))
                .addHttpHeaderProvider(new CorrelationIdHttpHeaderProvider())
                .withHostname(hostname);
    }

    private ReactiveCRUDRestBuilder createReactiveCrudRestBuilder(String featurePrefix, String hostname, AsyncClientRestTemplate asyncClientRestTemplate) {
        ErrorResponse errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix(HttpConfiguration.APPLICATION_PREFIX)
                        .withFeatureErrorCodePrefix(featurePrefix)
                        .build();

        return new ReactiveCRUDRestBuilder()
                .withClientRestTemplate(asyncClientRestTemplate)
                .withErrorHandler(new HttpErrorHandler(errorsResponse))
                .addHttpHeaderProvider(new CorrelationIdHttpHeaderProvider())
                .withHostname(hostname);
    }
}
