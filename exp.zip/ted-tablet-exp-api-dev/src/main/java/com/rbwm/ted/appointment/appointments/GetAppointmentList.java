/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRest;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.rbwm.ted.appointment.config.AppointmentBookingConfiguration;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.*;

/**
 * Created by 44052007 on 19/06/2017.
 */
@Component
public class GetAppointmentList {

    private final ReactiveCRUDRest crudRest;
    private final AppointmentBookingConfiguration appointmentBookingConfiguration;
    private final ReactiveResponseHandler<Map<String,Object>> responseHandler;
    private static final String FEATURE_PREFIX = "GET-APPOINTMENT-LIST";

    @Autowired
    public GetAppointmentList(AppointmentBookingConfiguration appointmentBookingConfiguration,
                              ReactiveResponseHandler<Map<String,Object>> responseHandler) {
        this.appointmentBookingConfiguration = appointmentBookingConfiguration;
        this.responseHandler = responseHandler;

        crudRest = appointmentBookingConfiguration.appointmentBookingCRUDRestBuilder(FEATURE_PREFIX).build();
    }

    public Mono<Map<String,Object>> getAppointmentList(String branchId,
                                                       AppointmentStatus status) {
        AppointmentStatus actualStatus = status ==null ? AppointmentStatus.UPCOMING : status;

        return responseHandler.extractBody(crudRest.doGet(getUri(branchId), createRequestParams(actualStatus), String.class))
                .map(appointmentListResponse -> {
                    List<Map<String,Object>> appointments = status == null ? Collections.EMPTY_LIST :
                            AppointmentJsonTransformer.transformAppointments.apply((List<Map<String,Object>>)appointmentListResponse.get("appointments"));

                    List<Map<String,Object>> summary = AppointmentSummaryTransformer.transform.apply((Map<String,Object>)appointmentListResponse.get("summary"));
                    Map<String,Object> stats = AppointmentStatsTransformer.transform.apply((Map<String,Object>)appointmentListResponse.get("stats"));

                    Map<String, Object> groups = (Map<String, Object>)appointmentListResponse.get("groups");
                    groups.put("nextBusinessDay", AppointmentJsonTransformer.transformAppointments.apply((List<Map<String,Object>>)groups.get("nextDay")));
                    return new HashMap<String, Object>() {{
                        put("list", appointments);
                        put("summary", summary);
                        put("stats", stats);
                        put("groups", groups);
                    }};
                });
    }

    private Map<String, List<String>> createRequestParams(AppointmentStatus status) {
        Map<String, List<String>> requestParams = new HashMap<>();
        requestParams.put("status", Arrays.asList(status.getCode()));
        return requestParams;
    }

    private String getUri(String branchId) {
        return appointmentBookingConfiguration.getAppointmentsListUri() + "/list/" + branchId;
    }
}
