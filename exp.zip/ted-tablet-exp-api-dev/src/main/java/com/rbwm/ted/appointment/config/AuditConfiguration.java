/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.config;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRestBuilder;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.hsbc.rbwm.ted.rest.http.HttpErrorHandler;
import com.hsbc.rbwm.ted.rest.http.HttpErrorResponseBuilder;
import com.rbwm.ted.appointment.http.CorrelationIdHttpHeaderProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Created by 44027117 on 02/05/2017.
 */
@Configuration
public class AuditConfiguration {

    @Value("${ted.audit.event.hostname}")
    private String auditHostname;

    @Value("${ted.audit.event.uri}")
    private String auditUri;

    public String getAuditUri() {
        return auditUri;
    }

    @Autowired
    private AsyncClientRestTemplate asyncClientRestTemplate;


    public ReactiveCRUDRestBuilder auditCRUDRestBuilder(String featurePrefix) {
        return createCrudRestBuilder(featurePrefix, auditHostname, asyncClientRestTemplate);
    }

    private ReactiveCRUDRestBuilder createCrudRestBuilder(String featurePrefix, String hostname, AsyncClientRestTemplate asyncClientRestTemplate) {
        ErrorResponse errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix(HttpConfiguration.APPLICATION_PREFIX)
                        .withFeatureErrorCodePrefix(featurePrefix)
                        .build();

        return new ReactiveCRUDRestBuilder()
                .withClientRestTemplate(asyncClientRestTemplate)
                .withErrorHandler(new HttpErrorHandler(errorsResponse))
                .addHttpHeaderProvider(new CorrelationIdHttpHeaderProvider())
                .withHostname(hostname);
    }
}
