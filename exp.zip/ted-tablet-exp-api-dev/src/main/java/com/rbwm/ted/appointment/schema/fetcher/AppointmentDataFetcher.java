/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.api.AppointmentBookingServiceApi;
import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.model.AppointmentStatus;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import static com.rbwm.ted.appointment.model.AppointmentFields.APPOINTMENT_ID;
import static com.rbwm.ted.appointment.model.AppointmentFields.APPOINTMENT_STATUS;
import static com.rbwm.ted.appointment.schema.fetcher.NodeDataFetcher.ID_SEPARATOR;
import static com.rbwm.ted.appointment.schema.graphql.GraphQLContext.addActionType;
import static com.rbwm.ted.appointment.schema.graphql.GraphQLContext.branchIdExtractor;
import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.relay;
import static com.rbwm.ted.appointment.schema.graphql.SchemaContext.resolveId;

/**
 * Created by 43578876 on 10/11/2016.
 */
@Component
public class AppointmentDataFetcher {

    public final DataFetcher<CompletableFuture> appointmentFetcher;
    public final DataFetcher<CompletableFuture> appointmentFetcherFromSource;
    public final DataFetcher<CompletableFuture> appointmentListFetcher;
    public final DataFetcher<CompletableFuture> appointmentListNodeFetcher;
    public final DataFetcher<CompletableFuture> appointmentListSummaryNodeFetcher;
    public final DataFetcher<CompletableFuture> appointmentNodeFetcher;

    @Autowired
    public AppointmentDataFetcher(AppointmentBookingServiceApi appointmentBookingService) {
        appointmentListFetcher = env -> {
            Mono<Map<String, Object>> appointmentListMono = appointmentBookingService.getAppointmentList(
                    branchIdExtractor.apply(addActionType.apply(env, AuditableAction.APPOINTMENT_LIST_AND_SUMMARY)),
                    AppointmentStatus.getValue(env.getArgument(APPOINTMENT_STATUS.val())));
            return appointmentListMono.map(appointmentList -> {
                appointmentList.put("id", relay.toGlobalId("appointmentList",
                        String.valueOf(branchIdExtractor.apply(env) + ID_SEPARATOR + env.getArgument(APPOINTMENT_STATUS.val()))));

                List<Map<String, Object>> summaryList = (List<Map<String, Object>>) appointmentList.get("summary");
                summaryList.forEach(appointmentListSummary -> appointmentListSummary.put("id", relay.toGlobalId("appointmentListSummary",
                        branchIdExtractor.apply(env) + ID_SEPARATOR + appointmentListSummary.get(APPOINTMENT_STATUS.val()))));

                return appointmentList;
            }).toFuture();
        };

        appointmentListNodeFetcher = env -> {
            String id = addActionType.apply(env, AuditableAction.APPOINTMENT_LIST_AND_SUMMARY).getArgument("id");
            String[] parameters = resolveId.apply(env.getArgument("id")).split(ID_SEPARATOR);

            String branchId = parameters[0];
            AppointmentStatus appointmentStatus = AppointmentStatus.getValue(parameters[1]);

            return appointmentBookingService.getAppointmentList(branchId, appointmentStatus).map(appointmentList -> {
                appointmentList.put("id", id);

                List<Map<String, Object>> summaryList = (List<Map<String, Object>>) appointmentList.get("summary");
                summaryList.forEach(appointmentListSummary -> appointmentListSummary.put("id", relay.toGlobalId("appointmentListSummary",
                        branchId + ID_SEPARATOR + appointmentListSummary.get(APPOINTMENT_STATUS.val()))));

                return appointmentList;
            }).toFuture();
        };

        Function<String, Mono<Map<String, Object>>> retrieveAppointment = appointmentBookingService::getAppointment;
        appointmentFetcher = env -> {
            GraphQLContext context = env.getContext();
            context.getDataFetcherAudit()
                    .withAuditAction(AuditableAction.APPOINTMENT_RETRIEVE)
                    .withEntityId(env.getArgument(APPOINTMENT_ID.val()));
            return retrieveAppointment.apply(env.getArgument(APPOINTMENT_ID.val())).map(appointment -> {
                context.getDataFetcherAudit().withEntity(appointment);
                return appointment;
            }).toFuture();
        };

        appointmentFetcherFromSource = env -> {
            Map<String, Object> source = env.getSource();
            return retrieveAppointment.apply((String) source.get(APPOINTMENT_ID.val())).toFuture();
        };

        appointmentNodeFetcher = env -> {
            GraphQLContext context = env.getContext();
            context.getDataFetcherAudit()
                    .withAuditAction(AuditableAction.APPOINTMENT_RETRIEVE)
                    .withEntityId(resolveId.apply(env.getArgument("id")));

            return retrieveAppointment.compose(resolveId).apply(env.getArgument("id")).map(appointment -> {
                context.getDataFetcherAudit().withEntity(appointment);
                return appointment;
            }).toFuture();
        };

        appointmentListSummaryNodeFetcher = env -> {
            String id = resolveId.apply(env.getArgument("id"));
            String[] parameters = id.split(ID_SEPARATOR);

            return appointmentBookingService.getAppointmentList(parameters[0], AppointmentStatus.getValue(parameters[1])).map(appointmentList -> {
                List<Map<String, Object>> summaryList = (List<Map<String, Object>>) appointmentList.get("summary");

                Optional<Map<String, Object>> mapOptional = summaryList.stream().filter(appointmentListSummary -> appointmentListSummary.get(APPOINTMENT_STATUS.val()).equals(parameters[1])).findFirst();
                Map<String, Object> appointmentListSummary = mapOptional.orElse(new HashMap<>());
                appointmentListSummary.put("id", relay.toGlobalId("appointmentListSummary", id));

                return appointmentListSummary;
            }).toFuture();
        };
    }

}
