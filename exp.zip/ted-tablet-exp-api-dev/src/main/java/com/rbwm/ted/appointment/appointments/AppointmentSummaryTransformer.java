/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by 43578876 on 26/06/2017.
 */
public final class AppointmentSummaryTransformer {

    private AppointmentSummaryTransformer(){
    }

    private static final Function<Map.Entry<String, Object>, Map<String, Object>> withLabels = i -> new HashMap<String, Object>() {{
        put("count", ((Double) i.getValue()).intValue());
        put("appointmentStatus", i.getKey());
    }};

    public static final Function<Map<String, Object>, List<Map<String, Object>>> transform = map -> map.entrySet().stream()
            .map(withLabels)
            .collect(Collectors.toList());

}
