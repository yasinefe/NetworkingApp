package com.rbwm.ted.appointment.config;

import com.hsbc.rbwm.ted.rest.api.ReactiveCRUDRestBuilder;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.hsbc.rbwm.ted.rest.http.HttpErrorHandler;
import com.hsbc.rbwm.ted.rest.http.HttpErrorResponseBuilder;
import com.rbwm.ted.appointment.http.CorrelationIdHttpHeaderProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

/**
 * Created by 44093684 on 19/03/2018.
 */
@Configuration
public class MIConfiguration {

    @Value("${ted.mi.hostname}")
    private String miHostname;

    @Value("${ted.mi.meetings.summary.uri}")
    private String miMeetingsSummaryUri;

    @Resource
    private AsyncClientRestTemplate asyncClientRestTemplate;

    public String getMiMeetingsSummaryUri() {
        return miMeetingsSummaryUri;
    }

    public ReactiveCRUDRestBuilder miReactiveCRUDRestBuilder(String featurePrefix) {
        ErrorResponse errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix(HttpConfiguration.APPLICATION_PREFIX)
                        .withFeatureErrorCodePrefix(featurePrefix)
                        .build();

        return new ReactiveCRUDRestBuilder()
                .withClientRestTemplate(asyncClientRestTemplate)
                .withErrorHandler(new HttpErrorHandler(errorsResponse))
                .addHttpHeaderProvider(new CorrelationIdHttpHeaderProvider())
                .withHostname(miHostname);
    }


}
