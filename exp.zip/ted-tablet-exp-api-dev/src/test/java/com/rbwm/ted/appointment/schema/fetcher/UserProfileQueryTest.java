/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Created by 43578876 on 09/11/2016.
 */
public class UserProfileQueryTest extends QueryTest {

    @Test
    public void testGetUserProfileViaNodeQuery() {
        Map<String, Object> result = executeCommand("{node (id:\"VXNlclByb2ZpbGU6NDQwMjM0NDU=\") { id ... on UserProfile { userId firstName lastName role trackings { key count } }}}");

        assertEquals("{id=VXNlclByb2ZpbGU6NDQwMjM0NDU=, userId=44023445, firstName=Javier, lastName=Torres, role=ADMIN, trackings=[{key=tracking_key, count=13}]}", result.get("node").toString());
    }

    @Test
    public void testUserProfile() {
        Map<String, Object> result = executeCommand("{viewer{userProfile {lastTimeLogin firstLogin userId firstName lastName role trackings { key count } }}}");

        assertEquals("{userProfile={lastTimeLogin=123456, firstLogin=false, userId=44023445, firstName=Javier, lastName=Torres, role=ADMIN, trackings=[{key=tracking_key, count=13}]}}", result.get("viewer").toString());
    }

    @Test
    public void testUserProfileWithAuthorisation() {
        Map<String, Object> result = executeCommand("{viewer{userProfile {lastTimeLogin firstLogin userId firstName lastName role authorisation { walkIn {create read update delete} appointment {create read update delete} help {create read update delete} miReport {create read update delete} skillbuilders {create read update delete} } }}}");

        assertEquals("{userProfile={lastTimeLogin=123456, firstLogin=false, userId=44023445, firstName=Javier, lastName=Torres, role=ADMIN, authorisation={walkIn={create=true, read=false, update=true, delete=false}, appointment={create=true, read=false, update=true, delete=false}, help={create=true, read=false, update=true, delete=false}, miReport={create=true, read=false, update=true, delete=false}, skillbuilders={create=true, read=false, update=true, delete=false}}}}", result.get("viewer").toString());
    }
}