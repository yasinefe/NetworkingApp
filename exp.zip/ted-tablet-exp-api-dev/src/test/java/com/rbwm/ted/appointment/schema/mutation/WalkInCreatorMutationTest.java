/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.http.HeaderContext;
import com.rbwm.ted.appointment.schema.SchemaTest;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.ExecutionResult;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.rbwm.ted.appointment.model.AppointmentFields.*;
import static com.rbwm.ted.appointment.model.AppointmentStatus.COMPLETED;
import static com.rbwm.ted.appointment.walkins.WalkInFactory.createWalkIn;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

/**
 * Created by 44027117 on 13/03/2017.
 */
public class WalkInCreatorMutationTest extends SchemaTest {

    @Test
    public void testCreate() {
        String request = "mutation CreateWalkInMutation($input:CreateWalkInInput!){" +
                "  createWalkIn(input:$input){ viewer { id } clientMutationId " +
                "    walkIn {id appointmentId appointmentStatus branchId dateTime duration topicId topicCategoryId timezone countryCode attendee{firstName lastName email}} " +
                "    walkInStats {totalForToday averageWaitingTime averageWaitingTimeLastBusinessDay} " +
                "    walkInSummary {id count appointmentStatus} " +
                "}}";

        when(walkInService.updateStatus("VG9kbzow", COMPLETED)).thenReturn(just(createWalkIn()));

        Map<String, Object> arguments = new HashMap<>();

        Map<String, Object> input = new HashMap<String, Object>() {{
                put(GENDER.val(), "MALE");
                put(FIRST_NAME.val(), "Carles");
                put(LAST_NAME.val(), "Puyol");
                put(TOPIC_ID.val(), "Category1");
                put(TOPIC_CATEGORY_ID.val(), "SubCategory1");
                put(TOPIC_SUB_CATEGORY_ID.val(), "SubSubCategory1");
                put(PROOF_OF_ID.val(), Boolean.TRUE);
                put(COMMENTS.val(), "Test");
                put(BRANCH_ID.val(), "406770");
                put("clientMutationId", "10");
        }};
        arguments.put("input", input);

        Map<String, Object> appointmentSummaryMap = new HashMap<String, Object>() {{
            put("count", 12);
            put("appointmentStatus", "IN_MEETING");
        }};
        List<Map<String, Object>> appointmentSummary = new ArrayList<>();
        appointmentSummary.add(appointmentSummaryMap);

        Map<String, Object> stats = new HashMap<String, Object>() {{
            put("totalForToday", 12);
            put("averageWaitingTime", 4);
            put("averageWaitingTimeLastBusinessDay", 5);
        }};

        when(walkInService.create(input)).thenReturn(just(createWalkIn()));
        when(walkInService.getStats("406770")).thenReturn(just(stats));
        when(walkInService.getStatusSummary("406770")).thenReturn(just(appointmentSummary));

        DataFetcherAudit.Builder dataFetcherBuilder = new DataFetcherAudit.Builder();
        dataFetcherBuilder.withType("WalkIn");
        dataFetcherBuilder.withEntityId("EntityId");
        dataFetcherBuilder.withOperationName("New");

        GraphQLContext graphQLContext = new GraphQLContext(new HeaderContext("406770", "12:23:34:45", "someMachineId", "GBR"),
                dataFetcherBuilder, null, null);
        ExecutionResult executionResult = executeCommandReturnResult(request, graphQLContext, arguments);

        Map<String, Object> result = ((Map<String, Object>)((Map<String, Object>) executionResult.getData()).get("createWalkIn"));
        assertEquals("10",result.get("clientMutationId"));
        assertEquals("{viewer={id=Vmlld2VyOjE=}, clientMutationId=10, walkIn={id=d2Fsa0luOjU4YzI3ZGY1YjY0OTM5MGMxMzE3NmYxMw==, " +
                "appointmentId=58c27df5b649390c13176f13, appointmentStatus=CHECKED_IN, branchId=400106, dateTime=1484894200000, duration=90, " +
                "topicId=Mortgages, topicCategoryId=Remortgage A Property, timezone=Europe/London, countryCode=GBR, " +
                "attendee={firstName=Peter, lastName=Jones, email=john.smith@email.com}}, " +
                "walkInStats={totalForToday=12, averageWaitingTime=4, averageWaitingTimeLastBusinessDay=5}, " +
                "walkInSummary=[{id=d2Fsa0luTGlzdFN1bW1hcnk6SU5fTUVFVElORy00MDY3NzA=, count=12, appointmentStatus=IN_MEETING}]}", result.toString());
    }
}
