/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Created by 43578876 on 09/11/2016.
 */
public class WalkInQueryTest extends QueryTest {

    @Test
    public void testGetWalkInSummaryAndList() {
        Map<String, Object> result = executeCommand("{viewer {branch(branchId: \"400706\") {walkIns {id summary {id count appointmentStatus}  list{id appointmentId appointmentStatus branchId dateTime duration topicId topicCategoryId timezone countryCode attendee{firstName lastName email}}}}}}");

        assertEquals("{branch={walkIns={id=d2Fsa0luTGlzdDo0MDA3MDY=, summary=[{id=d2Fsa0luTGlzdFN1bW1hcnk6VVBDT01JTkctNDAwNzA2, count=23, appointmentStatus=UPCOMING}], list=[{id=d2Fsa0luOjEyMzQ=, appointmentId=1234, appointmentStatus=UPCOMING, branchId=400706, dateTime=1496725560000, duration=20, topicId=null, topicCategoryId=null, timezone=Europe/London, countryCode=GBR, attendee=null}]}}}", result.get("viewer").toString());
    }

    @Test
    public void testGetWalkInSummaryAndListWithNodeQuery() {
        Map<String, Object> result = executeCommand("{node (id:\"d2Fsa0luTGlzdDo0MDA3MDY=\") { id ... on walkInList { list { id } summary { id }}}}");

        assertEquals("{id=d2Fsa0luTGlzdDo0MDA3MDY=, list=[{id=d2Fsa0luOjEyMzQ=}], summary=[{id=d2Fsa0luTGlzdFN1bW1hcnk6VVBDT01JTkctNDAwNzA2}]}", result.get("node").toString());
    }

    @Test
    public void testGetWalkInStats() {
        Map<String, Object> result = executeCommand("{ted{walkInStats {id totalForToday averageWaitingTime averageWaitingTimeLastBusinessDay}}}");

        assertEquals("{walkInStats={id=d2Fsa0luU3RhdHM6NDAwNzA2, totalForToday=20, averageWaitingTime=15, averageWaitingTimeLastBusinessDay=5}}", result.get("ted").toString());
    }

    @Test
    public void testGetWalkInStatsWithNodeQuery() {
        Map<String, Object> result = executeCommand("{node (id:\"d2Fsa0luU3RhdHM6NDAwNzA2\") { id ... on walkInStats { id totalForToday averageWaitingTime averageWaitingTimeLastBusinessDay }}}");

        assertEquals("{id=d2Fsa0luU3RhdHM6NDAwNzA2, totalForToday=20, averageWaitingTime=15, averageWaitingTimeLastBusinessDay=5}", result.get("node").toString());
    }

}