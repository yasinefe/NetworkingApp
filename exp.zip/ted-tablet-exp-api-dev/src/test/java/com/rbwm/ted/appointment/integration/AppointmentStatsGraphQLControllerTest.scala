/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 05/05/2017.
  */
@WebAppConfiguration
class AppointmentStatsGraphQLControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "return the summary of the appointment including the counts" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithContentAsync("/stats?branchId=404628", "{\"total\" : 4, \"averageWaitingTime\": 3, \"averageWaitingTimeLastBusinessDay\": 5}", headers)

    val request =
      """
      {
        "query": "{ted{walkInStats {id totalForToday averageWaitingTime averageWaitingTimeLastBusinessDay}}}",
        "variables": {
          }
        }
      """

    val response =
      """
        {
          "data": {
            "ted": {
                "walkInStats": {
                    "id": "d2Fsa0luU3RhdHM6NDA0NjI4",
                    "totalForToday": 4,
                    "averageWaitingTime": 3,
                    "averageWaitingTimeLastBusinessDay": 5
                  }
              }
          }
        }
      """

    val httpHeaders = new HttpHeaders()
    httpHeaders.add("X-BRANCH-ID", "404628")
    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }
}
