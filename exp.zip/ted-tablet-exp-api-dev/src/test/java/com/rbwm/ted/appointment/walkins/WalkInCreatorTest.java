/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.rbwm.ted.appointment.model.Gender;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.LinkedHashMap;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.model.AppointmentFields.*;
import static com.rbwm.ted.appointment.walkins.WalkInFactory.createWalkIn;
import static com.rbwm.ted.appointment.walkins.WalkInFactory.getWalkInResponse;
import static junit.framework.TestCase.assertEquals;

/**
 * Created by 44027117 on 17/03/2017.
 */
public class WalkInCreatorTest {

    private WalkInCreator walkInCreator;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AppointmentConfiguration appointmentConfiguration = new AppointmentConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(appointmentConfiguration, "walkInHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(appointmentConfiguration, "walkInGetUri", "/walkins");
        ReflectionTestUtils.setField(appointmentConfiguration, "asyncClientRestTemplateForWalkIn", new AsyncClientRestTemplate());
        walkInCreator = new WalkInCreator(appointmentConfiguration, new ReactiveResponseHandler<>());
    }

    @Test
    public void testCreateWalkIn() throws Exception {
        stubFor(post(urlPathEqualTo("/walkins"))
                .withRequestBody(equalToJson(getWalkInRequestAsJson(), true, false))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getWalkInResponse())));

        Map<String, Object> walkInResponse = walkInCreator.create(getWalkIn()).block();
        assertEquals(createWalkIn(), walkInResponse);
    }

    @Test(expected = Exceptions.APIException.class)
    public void testUnexpectedApiError() throws Exception {
        stubFor(post(urlPathEqualTo("/walkins"))
                .withRequestBody(equalToJson(getWalkInRequestAsJson(), true, false))
                .willReturn(aResponse()
                        .withStatus(500)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getErrorResponse())));
        try {
            walkInCreator.create(getWalkIn()).block();
        } catch(Exceptions.ServerException e) {
            assertEquals("ERROR_CODE", e.getErrorCode().code);
            throw e;
        }
    }

    private String getErrorResponse() {
        return "{\n" +
                "  \"error\": {\n" +
                "    \"code\": \"ERROR_CODE\",\n" +
                "    \"message\": \"ERROR MESSAGE\"\n" +
                "  }\n" +
                "}";
    }

    private Map<String, Object> getWalkIn() {
        Map<String, Object> walkIn = new LinkedHashMap<>();
        walkIn.put(GENDER.val(), Gender.MALE.getVal());
        walkIn.put(FIRST_NAME.val(), "Javier");
        walkIn.put(LAST_NAME.val(), "Torres");
        walkIn.put(TOPIC_ID.val(), "Category1");
        walkIn.put(TOPIC_CATEGORY_ID.val(), "Category2");
        walkIn.put(TOPIC_SUB_CATEGORY_ID.val(), "Category3");
        walkIn.put(PROOF_OF_ID.val(), Boolean.TRUE);
        walkIn.put(COMMENTS.val(), "This is a test");
        walkIn.put(BRANCH_ID.val(), "24333443");
        return walkIn;
    }

    private String getWalkInRequestAsJson() {
        return "{\n" +
                    "  \"gender\": \"MALE\",\n" +
                    "  \"firstName\": \"Javier\",\n" +
                    "  \"lastName\": \"Torres\",\n" +
                    "  \"topicId\": \"Category1\",\n" +
                    "  \"topicCategoryId\": \"Category2\",\n" +
                    "  \"topicSubCategoryId\": \"Category3\",\n" +
                    "  \"proofOfId\": true,\n" +
                    "  \"comments\": \"This is a test\",\n" +
                    "  \"branchId\": \"24333443\",\n" +
                    "  \"attendee\": {\n" +
                    "    \"gender\": \"MALE\",\n" +
                    "    \"firstName\": \"Javier\",\n" +
                    "    \"lastName\": \"Torres\"\n" +
                    "  },\n" +
                    "  \"appointmentStatus\": \"CHECKED_IN\",\n" +
                    "  \"duration\": 15\n" +
                    "}";
    }

}
