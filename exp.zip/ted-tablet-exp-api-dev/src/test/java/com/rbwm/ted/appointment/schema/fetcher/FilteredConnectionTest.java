/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import graphql.ErrorType;
import graphql.ExecutionResult;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 15/11/2017.
 */
public class FilteredConnectionTest extends QueryTest {

    @Test
    public void testStringEqualTo() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {employeeId:\"44012345\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDU=, employeeId=44012345, firstName=Tom, lastName=Hanks}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testStringNotEqualTo() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {employeeId_not:\"44012345\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDY=, employeeId=44012346, firstName=John, lastName=Silver}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testStringContains() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {employeeId_contains:\"2345\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDU=, employeeId=44012345, firstName=Tom, lastName=Hanks}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testStringNotContains() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {employeeId_not_contains:\"5\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDY=, employeeId=44012346, firstName=John, lastName=Silver}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testStringStartsWith() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {firstName_starts_with:\"T\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDU=, employeeId=44012345, firstName=Tom, lastName=Hanks}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testStringNotStartsWith() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {firstName_not_starts_with:\"T\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDY=, employeeId=44012346, firstName=John, lastName=Silver}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testCombinedStringFilters() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {firstName_contains:\"o\", firstName_starts_with: \"T\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDU=, employeeId=44012345, firstName=Tom, lastName=Hanks}}]}}", result.get("viewer").toString());
    }


    @Test
    public void testIDEqualsTo() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {id:\"U3RhZmY6NDQwMTIzNDY=\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDY=, employeeId=44012346, firstName=John, lastName=Silver}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testIDNotEqualsTo() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\", filter: {id_not:\"U3RhZmY6NDQwMTIzNDY=\"}) { count edges { node { id employeeId firstName lastName } } } } }");

        assertEquals("{branchStaff={count=1, edges=[{node={id=U3RhZmY6NDQwMTIzNDU=, employeeId=44012345, firstName=Tom, lastName=Hanks}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testSortingByNumericValueAsc() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: TOPIC_SUB_CATEGORY, sort: { key: \"count\", order: ASC }) { edges { node { groupValue count } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Open Account, count=1}}, " +
                        "{node={groupValue=Open Business Acc, count=2}}, " +
                        "{node={groupValue=Bill Payment, count=2}}, " +
                        "{node={groupValue=Apply Life insure, count=10}}, " +
                        "{node={groupValue=Close Account, count=13}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testSortingByNumericValueDesc() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: TOPIC_SUB_CATEGORY, sort: { key: \"count\", order: DESC }) { edges { node { groupValue count } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Close Account, count=13}}, " +
                        "{node={groupValue=Apply Life insure, count=10}}, " +
                        "{node={groupValue=Open Business Acc, count=2}}, " +
                        "{node={groupValue=Bill Payment, count=2}}, " +
                        "{node={groupValue=Open Account, count=1}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testSortingByTextValueAsc() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: TOPIC_SUB_CATEGORY, sort: { key: \"groupValue\", order: ASC }) { edges { node { groupValue count } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Apply Life insure, count=10}}, " +
                        "{node={groupValue=Bill Payment, count=2}}, " +
                        "{node={groupValue=Close Account, count=13}}, " +
                        "{node={groupValue=Open Account, count=1}}, " +
                        "{node={groupValue=Open Business Acc, count=2}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testSortingByTextValueDesc() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: TOPIC_SUB_CATEGORY, sort: { key: \"groupValue\", order: DESC }) { edges { node { groupValue count } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Open Business Acc, count=2}}, " +
                        "{node={groupValue=Open Account, count=1}}, " +
                        "{node={groupValue=Close Account, count=13}}, " +
                        "{node={groupValue=Bill Payment, count=2}}, " +
                        "{node={groupValue=Apply Life insure, count=10}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testSortingDefaultIsAsc() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: TOPIC_SUB_CATEGORY, sort: { key: \"count\" }) { edges { node { groupValue count } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Open Account, count=1}}, " +
                        "{node={groupValue=Open Business Acc, count=2}}, " +
                        "{node={groupValue=Bill Payment, count=2}}, " +
                        "{node={groupValue=Apply Life insure, count=10}}, " +
                        "{node={groupValue=Close Account, count=13}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testSortingIsInvalidIfKeyIsNotProvided() throws Exception {
        ExecutionResult executionResult = executeCommandReturnResult("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: TOPIC_SUB_CATEGORY, sort: { order: ASC }) { edges { node { groupValue count } } } }}");
        assertEquals(ErrorType.ValidationError, executionResult.getErrors().get(0).getErrorType());
    }

    @Test
    public void testSortingIsInvalidForUnknownKey() throws Exception {
        ExecutionResult executionResult = executeCommandReturnResult("{ viewer { meetings (filter: {meetingType: WALK_INS}, groupBy: TOPIC_SUB_CATEGORY, sort: { key: \"someOtherField\", order: DESC }) { edges { node { groupValue count } } } }}");
        assertEquals(ErrorType.DataFetchingException, executionResult.getErrors().get(0).getErrorType());
    }

    @Test
    public void testBooleanEqualToTrue() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { newsArticles(filter: {mandatory: true}) { count pageInfo { hasNextPage } edges { " +
                "node { title uri source description publishedOn mandatory } } } } }");

        assertEquals("{newsArticles={count=1, pageInfo={hasNextPage=false}, edges=[{node=" +
                "{title=Feed title mandatory, uri=http://news/feed/mandatory, source=Group News, description=Feed description mandatory, publishedOn=1234567890, mandatory=true}" +
                "}]}}", result.get("viewer").toString());
    }

}
