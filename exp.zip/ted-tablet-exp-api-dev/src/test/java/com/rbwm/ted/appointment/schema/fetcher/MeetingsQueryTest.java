/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.model.MeetingStatus;
import org.junit.Test;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by 44052007 on 01/09/2017.
 */
public class MeetingsQueryTest extends QueryTest {

    @Test
    public void testMeetingList() {
        Map<String, Object> result = executeCommand("{ viewer { meetingList(filter: {branchId: \"400426\", status: UPCOMING, group: UPCOMING, type: APPOINTMENTS}) { " +
                "count pageInfo { hasNextPage } edges { " +
                "node { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } " +
                "bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } " +
                "comments proofOfId countryCode endedBy checklist } } } } }");

        assertEquals("{meetingList={count=1, pageInfo={hasNextPage=false}, edges=[" +
                "{node={id=TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==, status=UPCOMING, group=UPCOMING, type=APPOINTMENTS, meetingId=XCDUNSH, topicId=topicId, topicName=topicName, topicCategoryId=topicCategoryId, " +
                "topicCategoryName=topicCategoryName, topicSubCategoryId=topicSubCategoryId, topicSubCategoryName=topicSubCategoryName, " +
                "conductor={employeeId=012345678, fullName=John Walker}, bookedFor=2001-07-04T12:08:56.235-0700, checkedInAt=2001-07-04T12:08:56.235-0700, " +
                "startedAt=2001-07-04T12:08:56.235-0700, endedAt=2001-07-04T12:08:56.235-0700, duration=30, isNew=true, isOverdue=true, " +
                "isOverdueCritical=false, isOverrun=true, isOverrunCritical=false, attendee={firstName=Jenny, lastName=Davis, email=jenny.davis@mail.com, " +
                "phoneNumber=+44 1234 121212, mobileNumber=+44 1234 121212, gender=FEMALE}, comments=Mortgage, proofOfId=true, countryCode=GBR, endedBy=USER, " +
                "checklist=[proofOfId, proofOfAddress]}}]}}", result.get("viewer").toString());

        assertEquals("MEETING", graphQLContext.getDataFetcherAudit().build().type);
        assertEquals("MEETING_LIST", graphQLContext.getDataFetcherAudit().build().operationName);
    }

    @Test
    public void testNextWorkingDayMeetings() {
        Map<String, Object> result = executeCommand("{ viewer { nextWorkingDayMeetingList (filter: {branchId: \"400426\", status: UPCOMING, group: UPCOMING}) { " +
                "count pageInfo { hasNextPage } edges { " +
                "node { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } " +
                "bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } " +
                "comments proofOfId countryCode endedBy checklist } } } } }");

        assertEquals("{nextWorkingDayMeetingList={count=1, pageInfo={hasNextPage=false}, edges=[" +
                "{node={id=TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==, status=UPCOMING, group=UPCOMING, type=APPOINTMENTS, meetingId=XCDUNSH, topicId=topicId, topicName=topicName, topicCategoryId=topicCategoryId, " +
                "topicCategoryName=topicCategoryName, topicSubCategoryId=topicSubCategoryId, topicSubCategoryName=topicSubCategoryName, " +
                "conductor={employeeId=012345678, fullName=John Walker}, bookedFor=2001-07-04T12:08:56.235-0700, checkedInAt=2001-07-04T12:08:56.235-0700, " +
                "startedAt=2001-07-04T12:08:56.235-0700, endedAt=2001-07-04T12:08:56.235-0700, duration=30, isNew=true, isOverdue=true, " +
                "isOverdueCritical=false, isOverrun=true, isOverrunCritical=false, attendee={firstName=Jenny, lastName=Davis, email=jenny.davis@mail.com, " +
                "phoneNumber=+44 1234 121212, mobileNumber=+44 1234 121212, gender=FEMALE}, comments=Mortgage, proofOfId=true, countryCode=GBR, endedBy=USER, " +
                "checklist=[proofOfId, proofOfAddress]}}]}}", result.get("viewer").toString());

        assertEquals("MEETING", graphQLContext.getDataFetcherAudit().build().type);
        assertEquals("MEETING_NEXT_WORKING_DAY_LIST", graphQLContext.getDataFetcherAudit().build().operationName);
    }

    @Test
    public void tesMeetingsCountWhenFieldsAreAvailable() {
        List<Map<String, Object>> meetings = new ArrayList<>();

        meetings.add(createAppointment("100001", null, false, false, false, false, MeetingStatus.NOSHOW));
        meetings.add(createAppointment("100002", false, false, false, false, false, MeetingStatus.NOSHOW));
        meetings.add(createAppointment("100003", true, false, false, false, false, MeetingStatus.CHECKED_IN));
        meetings.add(createAppointment("100004", true, null, false, false, false, MeetingStatus.CHECKED_IN));
        meetings.add(createAppointment("100005", true, false, false, false, false, MeetingStatus.CHECKED_IN));
        meetings.add(createAppointment("100006", true, true, false, false, false, MeetingStatus.CHECKED_IN));
        meetings.add(createAppointment("100007", true, true, null, false, false, MeetingStatus.CHECKED_IN));
        meetings.add(createAppointment("100008", true, true, false, false, false, MeetingStatus.CHECKED_IN));
        meetings.add(createAppointment("100009", true, true, true, false, false, MeetingStatus.CHECKED_IN));
        meetings.add(createAppointment("100010", true, true, true, null, false, MeetingStatus.IN_MEETING));
        meetings.add(createAppointment("100011", true, true, true, false, false, MeetingStatus.IN_MEETING));
        meetings.add(createAppointment("100012", true, true, true, true, false, MeetingStatus.IN_MEETING));
        meetings.add(createAppointment("100013", true, true, true, true, null, MeetingStatus.IN_MEETING));
        meetings.add(createAppointment("100014", true, true, true, true, false, MeetingStatus.IN_MEETING));
        meetings.add(createAppointment("100015", true, true, true, true, true, MeetingStatus.IN_MEETING));

        when(meetingService.getMeetings("400426", null, null, null)).thenReturn(Mono.just(meetings));

        Map<String, Object> result = executeCommand("{ viewer { meetingList (filter: {branchId: \"400426\"}) { " +
                "count newCount overdueCount overdueCriticalCount overrunCount overrunCriticalCount noShowCount edges { " +
                "node { id meetingId } } } } }");

        assertEquals("{meetingList={count=15, newCount=13, overdueCount=10, overdueCriticalCount=7, overrunCount=4, overrunCriticalCount=1, noShowCount=2, edges=[" +
                "{node={id=APPOINTMENTS/100001, meetingId=100001}}, {node={id=APPOINTMENTS/100002, meetingId=100002}}, " +
                "{node={id=APPOINTMENTS/100003, meetingId=100003}}, {node={id=APPOINTMENTS/100004, meetingId=100004}}, " +
                "{node={id=APPOINTMENTS/100005, meetingId=100005}}, {node={id=APPOINTMENTS/100006, meetingId=100006}}, " +
                "{node={id=APPOINTMENTS/100007, meetingId=100007}}, {node={id=APPOINTMENTS/100008, meetingId=100008}}, " +
                "{node={id=APPOINTMENTS/100009, meetingId=100009}}, {node={id=APPOINTMENTS/100010, meetingId=100010}}, " +
                "{node={id=APPOINTMENTS/100011, meetingId=100011}}, {node={id=APPOINTMENTS/100012, meetingId=100012}}, " +
                "{node={id=APPOINTMENTS/100013, meetingId=100013}}, {node={id=APPOINTMENTS/100014, meetingId=100014}}, " +
                "{node={id=APPOINTMENTS/100015, meetingId=100015}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testGetMeetingWithNodeId() throws Exception {
        Map<String, Object> result = executeCommand("{node (id:\"TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==\") { id ... on Meeting " +
                "{ id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } " +
                "bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } " +
                "comments proofOfId countryCode endedBy checklist }}}");

        assertEquals("{id=TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==, status=UPCOMING, group=UPCOMING, type=APPOINTMENTS, meetingId=XCDUNSH, topicId=topicId, topicName=topicName, topicCategoryId=topicCategoryId, " +
                "topicCategoryName=topicCategoryName, topicSubCategoryId=topicSubCategoryId, topicSubCategoryName=topicSubCategoryName, " +
                "conductor={employeeId=012345678, fullName=John Walker}, bookedFor=2001-07-04T12:08:56.235-0700, checkedInAt=2001-07-04T12:08:56.235-0700, " +
                "startedAt=2001-07-04T12:08:56.235-0700, endedAt=2001-07-04T12:08:56.235-0700, duration=30, isNew=true, isOverdue=true, " +
                "isOverdueCritical=false, isOverrun=true, isOverrunCritical=false, attendee={firstName=Jenny, lastName=Davis, email=jenny.davis@mail.com, " +
                "phoneNumber=+44 1234 121212, mobileNumber=+44 1234 121212, gender=FEMALE}, comments=Mortgage, proofOfId=true, countryCode=GBR, endedBy=USER, " +
                "checklist=[proofOfId, proofOfAddress]}", result.get("node").toString());

        assertEquals("MEETING", graphQLContext.getDataFetcherAudit().build().type);
        assertEquals("APPOINTMENTS/XCDUNSH", graphQLContext.getDataFetcherAudit().build().entityId);
        assertEquals("MEETING_RETRIEVE", graphQLContext.getDataFetcherAudit().build().operationName);
    }

    @Test
    public void testMeetingStats() {
        Map<String, Object> result = executeCommand("{ viewer { meetingStats(branchId: \"400426\") { " +
                "averageWaitingTime, averageWaitingTimeLastWorkingDay, averageMeetingLength, inNextHour } } }");

        assertEquals("{meetingStats={averageWaitingTime=1, averageWaitingTimeLastWorkingDay=2, " +
                "averageMeetingLength=3, inNextHour=4}}", result.get("viewer").toString());
    }

    private Map<String, Object> createAppointment(String id, Boolean isNew, Boolean isOverdue, Boolean isOverdueCritical,
                                                  Boolean isOverrun, Boolean isOverrunCritical, MeetingStatus meetingStatus) {
        Map<String, Object> meeting = new HashMap<>();
        meeting.put("id", "APPOINTMENTS/" + id);
        meeting.put("meetingId", id);
        meeting.put("status", meetingStatus);
        if (isNew != null) meeting.put("isNew", isNew);
        if (isOverdue != null) meeting.put("isOverdue", isOverdue);
        if (isOverdueCritical != null) meeting.put("isOverdueCritical", isOverdueCritical);
        if (isOverrun != null) meeting.put("isOverrun", isOverrun);
        if (isOverrunCritical != null) meeting.put("isOverrunCritical", isOverrunCritical);
        return meeting;
    }

}