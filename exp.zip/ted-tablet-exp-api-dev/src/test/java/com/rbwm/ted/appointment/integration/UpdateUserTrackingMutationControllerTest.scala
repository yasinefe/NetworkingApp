/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpMethod, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 28/02/2017.
  */
@WebAppConfiguration
class UpdateUserTrackingMutationControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "update user tracking" in {

    val responseFromProcessApi =
      """
        |{
        |  "key": "tracking_key",
        |  "count": 1
        |}
      """.stripMargin

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockWithContentAsync("/trackings/43578876/track/tracking_key", responseFromProcessApi, headers, HttpMethod.PUT, "{}")

    val request =
      """
      {
        "query": "mutation TrackMutation($input:TrackInput!){track(input:$input){clientMutationId tracking {key count}}}",
        "variables": {
          "input": {
            "key": "tracking_key",
            "clientMutationId": "10"
          }
        }
      }
      """
    val response =
      """
        {
          "data": {
            "track": {
              "clientMutationId": "10",
              "tracking": {
                "key": "tracking_key",
                "count": 1
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

}
