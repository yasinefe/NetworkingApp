/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer
import org.junit.Assert.{assertEquals, assertNotNull, assertTrue}
import org.scalatest.Ignore
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 11/05/2017.
  */
@WebAppConfiguration
class CorrelationIdTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should " get correlation id from header and log it" in {

    val mockResponse =
      """
        |{
        |   "userId": "43578876",
        |   "lastTimeLogin": 123456789,
        |   "firstLogin": true,
        |   "branchId": "400125",
        |   "firstName": "Rick",
        |   "lastName": "Grimes"
        |}
      """.stripMargin

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithContentAsync("/userProfiles/43578876", mockResponse, headers)

    val request =
      """
      {
        "query": "{ viewer { userProfile {lastTimeLogin firstLogin userId, firstName, lastName, branchId } } }",
        "variables": {
          }
        }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "userProfile": {
                "lastTimeLogin": 123456789,
                "userId": "43578876",
                "firstName": "Rick",
                "lastName": "Grimes",
                "firstLogin": true,
                "branchId": "400125"
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
    val correlationId = CorrelationIdContainer.getId
    assertNotNull(correlationId)
    assertEquals(testLoggingFilter.requestLogging.key,  "CorrelationId")
    assertEquals(testLoggingFilter.requestLogging.value,  correlationId)


    val httpHeaders = new HttpHeaders()
    httpHeaders.add("X-CORRELATION-ID", correlationId)

    executePostTest(request, response, HttpStatus.OK, httpHeaders)

    val newCorrelationId = CorrelationIdContainer.getId

    assertEquals(correlationId, newCorrelationId)
    assertEquals(testLoggingFilter.requestLogging.key,  "CorrelationId")
    assertEquals(testLoggingFilter.requestLogging.value,  newCorrelationId)
  }

}
