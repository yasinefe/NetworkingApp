/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.authorisation;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AuthorisationConfiguration;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.model.Role.ADMIN;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static junit.framework.TestCase.assertEquals;

/**
 * Created by 44052007 on 11/12/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class GetAuthorisationTest {

    private GetAuthorisation getAuthorisation;
    private Authorisation authorisation;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AuthorisationConfiguration authorisationConfiguration = new AuthorisationConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(authorisationConfiguration, "authorisationHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(authorisationConfiguration, "authorisationUri", "/authorisation");
        ReflectionTestUtils.setField(authorisationConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getAuthorisation = new GetAuthorisation(authorisationConfiguration);

        CrudPermission crudPermission = new CrudPermission(true, false, true, false);
        authorisation = new Authorisation(crudPermission, crudPermission, crudPermission, crudPermission, crudPermission);
    }

    @Test
    public void testGetAuthorisationByRole() throws Exception {
        stubFor(get(urlPathEqualTo("/authorisation/" + ADMIN.name()))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("authorisation-response.json"))));

        Authorisation actualAuthorisation = getAuthorisation.get(ADMIN, null, null, null).block();
        assertEquals(authorisation, actualAuthorisation);
    }

    @Test
    public void testGetAuthorisationByAllFields() throws Exception {
        stubFor(get(urlPathEqualTo("/authorisation/" + ADMIN.name()))
                .withQueryParam("userId", equalTo("44052881"))
                .withQueryParam("branchId", equalTo("440012"))
                .withQueryParam("countryCode", equalTo("GBR"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("authorisation-response.json"))));

        Authorisation actualAuthorisation = getAuthorisation.get(ADMIN, "44052881", "440012", "GBR").block();
        assertEquals(authorisation, actualAuthorisation);
    }

}