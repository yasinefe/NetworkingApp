/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.content;

import com.rbwm.ted.appointment.content.ContentMetadata.Metadata;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

/**
 * Created by 44052007 on 31/10/2017.
 */
public class ContentMetadataServiceTest {

    private ContentMetadataService contentMetadataService;
    private GetContentMetadata getContentMetadata;

    private Metadata metadata;

    @Before
    public void setUp() throws Exception {
        getContentMetadata = mock(GetContentMetadata.class);
        metadata = mock(Metadata.class);
        contentMetadataService = new ContentMetadataService(getContentMetadata);
    }

    @Test
    public void getContentMetadata() throws Exception {
        when(getContentMetadata.getContentMetadata()).thenReturn(just(metadata));

        Metadata actualMetadata = contentMetadataService.getContentMetadata().block();

        assertEquals(metadata, actualMetadata);
    }
}
