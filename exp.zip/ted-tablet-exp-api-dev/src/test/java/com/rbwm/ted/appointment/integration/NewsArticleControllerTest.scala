/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44052007 on 01/09/2017.
  */
@WebAppConfiguration
class NewsArticleControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "return news articles" in {

    val mockResponse =
      """
        |[
        |  {
        |    "title": "Feed title",
        |    "link": "http://news/feed",
        |    "source": "Group News",
        |    "description": "Feed description",
        |    "pubDate": 123456789,
        |    "mandatory": true
        |  }
        |]
      """.stripMargin

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithContentAsync("/", mockResponse, headers)

    val request =
      """
      {
        "query": "{ viewer { newsArticles { count pageInfo { hasNextPage } edges { node { title uri source description publishedOn mandatory } } } } }",
        "variables": {}
      }
      """

    val response =
      """
        {
          "data": {
            "viewer": {
              "newsArticles": {
                "count": 1,
                "pageInfo": {
                  "hasNextPage": false
                },
                "edges": [
                  {
                    "node": {
                      "title": "Feed title",
                      "uri": "http://news/feed",
                      "source": "Group News",
                      "description": "Feed description",
                      "publishedOn": 123456789,
                      "mandatory": true
                    }
                  }
                ]
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

}
