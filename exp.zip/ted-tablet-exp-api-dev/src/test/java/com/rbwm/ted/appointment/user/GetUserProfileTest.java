/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.user;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.UserProfileConfiguration;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.model.Role.ADMIN;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static junit.framework.TestCase.assertEquals;

/**
 * Created by 43578876 on 24/04/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class GetUserProfileTest {

    private static final String USER_ID = "12345";

    private GetUserProfile getUserProfile;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private UserProfileConfiguration userProfileConfiguration = new UserProfileConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(userProfileConfiguration, "userProfileHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(userProfileConfiguration, "userProfileUri", "/userProfiles");
        ReflectionTestUtils.setField(userProfileConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getUserProfile = new GetUserProfile(userProfileConfiguration);
    }

    @Test
    public void testGetBranchById() throws Exception {
        stubFor(get(urlPathEqualTo("/userProfiles/" + USER_ID))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("user-profile-response.json"))));

        UserProfile userProfile = getUserProfile.get(USER_ID).block();

        UserProfile expected = new UserProfile("12345", true, 123678L, "Jack",
                "Reacher", "40012", ADMIN);

        assertEquals(expected, userProfile);
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void testUserProfileNotFoundForUserId() throws Exception {
        stubFor(get(urlPathEqualTo("/userProfiles/" + USER_ID))
                .willReturn(aResponse()
                        .withStatus(404)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getErrorResponse())));
        try {
            getUserProfile.get(USER_ID).block();
        } catch(Exceptions.ServerException e) {
            assertEquals("TEE-GET-USER-PROFILE-NOT-FOUND", e.getErrorCode().code);
            throw e;
        }
    }

    private String getErrorResponse() {
        return "{\n" +
                "  \"error\": {\n" +
                "    \"code\": \"ERROR_CODE\",\n" +
                "    \"message\": \"ERROR MESSAGE\"\n" +
                "  }\n" +
                "}";
    }

}