/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.audit;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AuditConfiguration;
import com.rbwm.ted.appointment.http.HeaderContext;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static junit.framework.TestCase.assertEquals;

/**
 * Created by 44052007 on 02/05/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class AuditProcessorTest {

    private AuditProcessor auditProcessor;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AuditConfiguration auditConfiguration = new AuditConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(auditConfiguration, "auditHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(auditConfiguration, "auditUri", "/eventSource");
        ReflectionTestUtils.setField(auditConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        auditProcessor = new AuditProcessor(auditConfiguration);
    }

    @Test
    public void testSendEvent() throws IOException, URISyntaxException {
        stubFor(post(urlPathEqualTo("/eventSource"))
                .withRequestBody(equalTo("{\"countryCode\":\"GBR\",\"branchId\":\"12345\",\"wifiMACAddress\":\"23:34:45:56\",\"machineId\":\"machineId\",\"staffId\":\"staffId\"," +
                        "\"query\":\"query\",\"variables\":{},\"correlationId\":\"test-correlation-id\",\"entityId\":\"entityId\",\"entity\":{\"id\":\"entityId\"}," +
                        "\"operationName\":\"New\",\"type\":\"WalkIn\",\"error\":false}"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")));

        Map<String, Object> entity = new HashMap<>();
        entity.put("id", "entityId");

        DataFetcherAudit dataFetcherAudit = new DataFetcherAudit.Builder()
                .withEntityId("entityId")
                .withOperationName("New")
                .withType("WalkIn")
                .withEntity(entity)
                .build();

        AuditContext auditContext = new AuditContext("test-correlation-id", new HeaderContext("12345", "23:34:45:56",
                "machineId", "GBR"), "staffId", "query", Collections.emptyMap(), false, dataFetcherAudit);

        auditProcessor.sendEvent(auditContext);
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void testNotFound() throws IOException, URISyntaxException {
        stubFor(post(urlPathEqualTo("/eventSource"))
                .withRequestBody(equalTo("{\"countryCode\":\"GBR\",\"branchId\":\"12345\",\"wifiMACAddress\":\"23:34:45:56\",\"machineId\":\"machineId\",\"staffId\":\"staffId\"," +
                        "\"query\":\"query\",\"variables\":{},\"correlationId\":\"test-correlation-id\",\"entityId\":\"entityId\",\"entity\":{\"id\":\"entityId\"}," +
                        "\"operationName\":\"New\",\"type\":\"WalkIn\",\"error\":false}"))
                .willReturn(aResponse()
                        .withStatus(404)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getErrorResponse())));

        Map<String, Object> entity = new HashMap<>();
        entity.put("id", "entityId");

        DataFetcherAudit dataFetcherAudit = new DataFetcherAudit.Builder()
                .withEntityId("entityId")
                .withOperationName("New")
                .withType("WalkIn")
                .withEntity(entity)
                .build();

        AuditContext auditContext = new AuditContext("test-correlation-id", new HeaderContext("12345", "23:34:45:56",
                "machineId", "GBR"), "staffId", "query", Collections.emptyMap(), false, dataFetcherAudit);
        try {
            auditProcessor.sendEvent(auditContext);
        } catch(Exceptions.ServerException e) {
            assertEquals("TEE-CREATE-AUDIT-NOT-FOUND", e.getErrorCode().code);
            throw e;
        }
    }

    private String getErrorResponse() {
        return "{\n" +
                "  \"error\": {\n" +
                "    \"code\": \"ERROR_CODE\",\n" +
                "    \"message\": \"ERROR MESSAGE\"\n" +
                "  }\n" +
                "}";
    }

}