package com.rbwm.ted.appointment.schema.fetcher;

import graphql.ErrorType;
import graphql.ExecutionResult;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Created by 44093684 on 07/12/2017.
 */
public class MeetingsGroupQueryTest extends QueryTest {

    @Test
    public void testWalkInGroupAtGroupByTopicCategory() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: TOPIC_CATEGORY) { edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Other, count=8, averageWaitingTime=2}}, " +
                        "{node={groupValue=Payments, count=8, averageWaitingTime=null}}, " +
                        "{node={groupValue=Bereavement, count=10, averageWaitingTime=15}}, " +
                        "{node={groupValue=Insurance, count=13, averageWaitingTime=1}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testWalkInGroupByTopicSubCategory() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: TOPIC_SUB_CATEGORY) { edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Open Account, count=1, averageWaitingTime=null}}, " +
                        "{node={groupValue=Open Business Acc, count=2, averageWaitingTime=null}}, " +
                        "{node={groupValue=Apply Life insure, count=10, averageWaitingTime=10}}, " +
                        "{node={groupValue=Close Account, count=13, averageWaitingTime=20}}, " +
                        "{node={groupValue=Bill Payment, count=2, averageWaitingTime=null}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testWalkInGroupShouldFailWhenGroupByUnknownCategory() {
        ExecutionResult executionResult = executeCommandReturnResult("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: UNKNOWN_CATEGORY ) { edges { node { groupValue count averageWaitingTime} } } }}");

        assertEquals(ErrorType.ValidationError, executionResult.getErrors().get(0).getErrorType());
    }

    @Test
    public void testWalkInGroupWithGroupValueFilter() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(groupBy: TOPIC_SUB_CATEGORY, filter: {meetingType: WALK_INS, groupValue: \"Open Account\"}){ edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Open Account, count=1, averageWaitingTime=null}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testWalkInGroupWithGroupValueStartsWithFilter() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(groupBy: TOPIC_SUB_CATEGORY, filter: {meetingType: WALK_INS, groupValue_starts_with: \"Open\"}){ edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=Open Account, count=1, averageWaitingTime=null}}, " +
                        "{node={groupValue=Open Business Acc, count=2, averageWaitingTime=null}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAllCustomFiltersSupported() {
        ExecutionResult executionResult = executeCommandReturnResult("{ viewer { meetings(groupBy: TOPIC_CATEGORY," +
                " filter: " +
                "{meetingType: APPOINTMENTS, branchId: \"12443\", topicId: \"New Product\", topicCategoryId: \"Insurance\", topicSubCategoryId: \"Open Account\", " +
                "dateTime_lt: 0, dateTime_lte: 0, dateTime_gt: 999999, dateTime_gte: 99999}) " +
                "{ edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals(0, executionResult.getErrors().size());
    }

    @Test
    public void testWalkInGroupByStatus() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: WALK_INS}, groupBy: STATUS ) { edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=COMPLETED, count=3, averageWaitingTime=20}}, " +
                        "{node={groupValue=IN_MEETING, count=2, averageWaitingTime=null}}, " +
                        "{node={groupValue=CANCELLED, count=1, averageWaitingTime=null}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAppointmentGroupByStatus() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: APPOINTMENTS}, groupBy: STATUS ) { edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=NOSHOW, count=10, averageWaitingTime=null}}, " +
                        "{node={groupValue=CANCELLED, count=3, averageWaitingTime=null}}, " +
                        "{node={groupValue=COMPLETED, count=4, averageWaitingTime=20}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAppointmentGroupByOverdue() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: APPOINTMENTS, isOverdue: true} ) { edges { node { count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={count=10, averageWaitingTime=null}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAppointmentGroupByOverdueCritical() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: APPOINTMENTS, isOverdueCritical: true}) { edges { node { count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={count=1, averageWaitingTime=null}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAppointmentGroupByOverrun() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: APPOINTMENTS, isOverrun: true} ) { edges { node { count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={count=3, averageWaitingTime=50}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAppointmentGroupByOverrunCritical() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: APPOINTMENTS, isOverrunCritical: true}) { edges { node { count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={count=1, averageWaitingTime=60}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAppointmentGroupBy60MinuteInterval() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: APPOINTMENTS}, groupBy: CHECKED_IN_AT__MINUTE__NEAREST_60 ) " +
                "{ edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=09:00:00, count=1, averageWaitingTime=3}}, " +
                        "{node={groupValue=10:00:00, count=5, averageWaitingTime=0}}, " +
                        "{node={groupValue=11:00:00, count=20, averageWaitingTime=0}}, " +
                        "{node={groupValue=12:00:00, count=2, averageWaitingTime=1}}, " +
                        "{node={groupValue=13:00:00, count=1, averageWaitingTime=0}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAppointmentGroupBy60MinuteIntervalHighestCount() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: APPOINTMENTS}," +
                " groupBy: CHECKED_IN_AT__MINUTE__NEAREST_60, sort:[{key:\"count\", order: DESC}], first: 1 ) " +
                "{ edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=11:00:00, count=20, averageWaitingTime=0}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testAppointmentGroupByNone() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(filter: {meetingType: APPOINTMENTS} ) " +
                "{ edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=null, count=99, averageWaitingTime=60}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testMeetingsGroupQueryWithNoMeetingType() {
        Map<String, Object> result = executeCommand("{ viewer { meetings(groupBy: STATUS ) { edges { node { groupValue count averageWaitingTime } } } }}");

        assertEquals("{meetings={" +
                        "edges=[" +
                        "{node={groupValue=COMPLETED, count=3, averageWaitingTime=20}}, " +
                        "{node={groupValue=IN_MEETING, count=2, averageWaitingTime=null}}, " +
                        "{node={groupValue=CANCELLED, count=1, averageWaitingTime=null}}" +
                        "]}}",
                result.get("viewer").toString());
    }

}
