/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.meetings;

import com.rbwm.ted.appointment.appointments.GetAppointmentMeeting;
import com.rbwm.ted.appointment.appointments.GetAppointmentStats;
import com.rbwm.ted.appointment.appointments.GetAppointments;
import com.rbwm.ted.appointment.appointments.UpdateAppointmentMeetingStatus;
import com.rbwm.ted.appointment.error.Exceptions;
import com.rbwm.ted.appointment.model.Gender;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import com.rbwm.ted.appointment.model.MeetingType;
import com.rbwm.ted.appointment.walkins.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

/**
 * Created by 44052007 on 27/04/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class MeetingServiceTest {

    private static final String BRANCH_ID = "409223";

    @Mock
    private GetAppointments getAppointments;

    @Mock
    private GetWalkIns getWalkIns;

    @Mock
    private GetWalkInMeeting getWalkInMeeting;

    @Mock
    private GetAppointmentMeeting getAppointmentMeeting;

    @Mock
    private CreateWalkIn createWalkIn;

    @Mock
    private UpdateWalkInStatus updateWalkInStatus;

    @Mock
    private UpdateAppointmentMeetingStatus updateAppointmentMeetingStatus;

    @Mock
    private GetAppointmentStats getAppointmentStats;

    @Mock
    private GetWalkInStats getWalkInStats;

    @InjectMocks
    private MeetingService meetingService;

    @Before
    public void setUp() throws Exception {
        Map<String, Object> walkIn1 = new HashMap<>();
        walkIn1.put("meetingId", "walkin1");
        walkIn1.put("bookedFor", "2018-04-30T12:08:56.235-0700");
        Map<String, Object> walkIn2 = new HashMap<>();
        walkIn2.put("meetingId", "walkin2");
        walkIn2.put("bookedFor", "2018-04-30T11:08:56.235-0700");

        when(getWalkIns.getWalkIns(BRANCH_ID, MeetingStatus.IN_MEETING, MeetingGroupType.IN_MEETING))
                .thenReturn(just(asList(walkIn1, walkIn2)));
        when(getWalkInMeeting.getWalkIn("walkin1")).thenReturn(Mono.just(walkIn1));
        when(updateWalkInStatus.updateWalkInStatus("walkin1", MeetingStatus.IN_MEETING)).thenReturn(Mono.just(walkIn1));

        MeetingInput meetingInput = new MeetingInput("branchId", Gender.FEMALE, "firstName", "lastName",
                "topicId", "topicCategoryId", "topicSubCategoryId", true, "comments");
        when(createWalkIn.createWalkIn(meetingInput)).thenReturn(Mono.just(walkIn1));


        Map<String, Object> appointment1 = new HashMap<>();
        appointment1.put("meetingId", "appointment1");
        appointment1.put("bookedFor", "2018-04-30T12:07:56.235-0700");
        Map<String, Object> appointment2 = new HashMap<>();
        appointment2.put("meetingId", "appointment2");
        appointment2.put("bookedFor", "2018-04-30T11:07:56.235-0700");

        when(getAppointments.getAppointments(BRANCH_ID, MeetingStatus.IN_MEETING, MeetingGroupType.IN_MEETING))
                .thenReturn(just(asList(appointment1, appointment2)));
        when(getAppointmentMeeting.getAppointment("appointment1")).thenReturn(Mono.just(appointment1));
        when(updateAppointmentMeetingStatus.updateAppointmentStatus("appointment1", MeetingStatus.IN_MEETING, null)).thenReturn(Mono.just(appointment1));
        when(updateAppointmentMeetingStatus.updateAppointmentStatus("appointment1", MeetingStatus.CHECKED_IN, true)).thenReturn(Mono.just(appointment1));
    }

    @Test
    public void testGetMeetingsReturnsOnlyWalkIns() throws Exception {
        List<Map<String, Object>> meetings = meetingService.getMeetings(BRANCH_ID, MeetingStatus.IN_MEETING, MeetingGroupType.IN_MEETING, MeetingType.WALK_INS).block();
        assertEquals(2, meetings.size());
        assertEquals("walkin2", meetings.get(0).get("meetingId"));
        assertEquals("walkin1", meetings.get(1).get("meetingId"));
    }

    @Test
    public void testGetMeetingsReturnsOnlyAppointments() throws Exception {
        List<Map<String, Object>> meetings = meetingService.getMeetings(BRANCH_ID, MeetingStatus.IN_MEETING, MeetingGroupType.IN_MEETING, MeetingType.APPOINTMENTS).block();
        assertEquals(2, meetings.size());
        assertEquals("appointment2", meetings.get(0).get("meetingId"));
        assertEquals("appointment1", meetings.get(1).get("meetingId"));
    }

    @Test
    public void testGetMeetingsReturnsAllAppointments() throws Exception {
        List<Map<String, Object>> meetings = meetingService.getMeetings(BRANCH_ID, MeetingStatus.IN_MEETING, MeetingGroupType.IN_MEETING, null).block();
        assertEquals(4, meetings.size());
        assertEquals("appointment2", meetings.get(0).get("meetingId"));
        assertEquals("walkin2", meetings.get(1).get("meetingId"));
        assertEquals("appointment1", meetings.get(2).get("meetingId"));
        assertEquals("walkin1", meetings.get(3).get("meetingId"));
    }

    @Test
    public void testGetMeetingReturnWalkInAsAMeeting() throws Exception {
        Map<String, Object> meeting = meetingService.getMeeting("WALK_INS/walkin1").block();
        assertEquals("walkin1", meeting.get("meetingId"));
    }

    @Test
    public void testGetMeetingReturnAppointmentAsAMeeting() throws Exception {
        Map<String, Object> meeting = meetingService.getMeeting("APPOINTMENTS/appointment1").block();
        assertEquals("appointment1", meeting.get("meetingId"));
    }

    @Test
    public void testChangeMeetingStatusForWalkIn() throws Exception {
        Map<String, Object> meeting = meetingService.changeMeetingStatus("WALK_INS/walkin1", MeetingStatus.IN_MEETING).block();
        assertEquals("walkin1", meeting.get("meetingId"));
    }

    @Test
    public void testChangeMeetingStatusForAppointment() throws Exception {
        Map<String, Object> meeting = meetingService.changeMeetingStatus("APPOINTMENTS/appointment1", MeetingStatus.IN_MEETING).block();
        assertEquals("appointment1", meeting.get("meetingId"));
    }

    @Test
    public void testCheckInMeeting() throws Exception {
        Map<String, Object> meeting = meetingService.checkInMeeting("APPOINTMENTS/appointment1", true).block();
        assertEquals("appointment1", meeting.get("meetingId"));
    }

    @Test(expected = Exceptions.InvalidRequestException.class)
    public void testCheckInMeetingThrowsExceptionWhenItIsCalledForAWalkIn() throws Exception {
        meetingService.checkInMeeting("WALK_INS/walkin1", true).block();
    }

    @Test(expected = Exceptions.InvalidRequestException.class)
    public void testChangeMeetingStatusThrowsExceptionWhenMeetingTypeIsWrong() throws Exception {
        meetingService.changeMeetingStatus("DUMMY/walkin1", MeetingStatus.IN_MEETING).block();
    }

    @Test(expected = Exceptions.InvalidRequestException.class)
    public void testGetMeetingThrowsExceptionWhenMeetingTypeIsWrong() throws Exception {
        meetingService.getMeeting("DUMMY/appointment1").block();
    }

    @Test(expected = Exceptions.InvalidRequestException.class)
    public void testGetMeetingThrowsExceptionWhenSeparatorIsNotPresent() throws Exception {
        meetingService.getMeeting("APPOINTMENTS:appointment1").block();
    }

    @Test
    public void testGetStatsReturnsMergedStats() throws Exception {
        MeetingStats walkInStats = new MeetingStats(
                new StatData(2, TimeUnit.MINUTES.toMillis(5)),
                new StatData(2, TimeUnit.MINUTES.toMillis(5)),
                new StatData(2, TimeUnit.MINUTES.toMillis(5)),
                5);
        MeetingStats appointmentStats = new MeetingStats(
                new StatData(2, TimeUnit.MINUTES.toMillis(5)),
                new StatData(2, TimeUnit.MINUTES.toMillis(5)),
                new StatData(2, TimeUnit.MINUTES.toMillis(5)),
                5);

        when(getWalkInStats.getWalkInStats(BRANCH_ID)).thenReturn(Mono.just(walkInStats));
        when(getAppointmentStats.getAppointmentStats(BRANCH_ID)).thenReturn(Mono.just(appointmentStats));

        Map<String, Object> meetingStats = meetingService.getMeetingStats(BRANCH_ID).block();

        Map<String, Object> expectedMeetingStats = new HashMap<>();
        expectedMeetingStats.put("averageWaitingTime", 3);
        expectedMeetingStats.put("averageWaitingTimeLastWorkingDay", 3);
        expectedMeetingStats.put("averageMeetingLength", 3);
        expectedMeetingStats.put("inNextHour", 10);

        assertEquals(expectedMeetingStats, meetingStats);
    }

    @Test
    public void testGetStatsReturnsMergedStatsWhenTotalIsZero() throws Exception {
        MeetingStats walkInStats = new MeetingStats(
                new StatData(0, 0L),
                new StatData(0, 0L),
                new StatData(0, 0L),
                0);
        MeetingStats appointmentStats = new MeetingStats(
                new StatData(0, 0L),
                new StatData(0, 0L),
                new StatData(0, 0L),
                0);

        when(getWalkInStats.getWalkInStats(BRANCH_ID)).thenReturn(Mono.just(walkInStats));
        when(getAppointmentStats.getAppointmentStats(BRANCH_ID)).thenReturn(Mono.just(appointmentStats));

        Map<String, Object> meetingStats = meetingService.getMeetingStats(BRANCH_ID).block();

        Map<String, Object> expectedMeetingStats = new HashMap<>();
        expectedMeetingStats.put("averageWaitingTime", null);
        expectedMeetingStats.put("averageWaitingTimeLastWorkingDay", null);
        expectedMeetingStats.put("averageMeetingLength", null);
        expectedMeetingStats.put("inNextHour", 0);

        assertEquals(expectedMeetingStats, meetingStats);
    }
}