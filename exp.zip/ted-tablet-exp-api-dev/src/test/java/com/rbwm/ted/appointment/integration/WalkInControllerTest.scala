/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 22/02/2017.
  */
@WebAppConfiguration
class WalkInControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  val httpHeaders = new HttpHeaders()
  httpHeaders.add("X-BRANCH-ID", "404628")

  it should "return the list of WalkIns under the branch node" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/branchId/404628", "branch-response.json", headers)
    mockGetWithFileContentAsync("/list?branchId=404628", "walkin-list-and-summary-response.json", headers)

    val request =
      """
      {
       "query":"{viewer {branch(branchId: \"404628\") {walkIns {list{appointmentId appointmentStatus branchId dateTime duration overdueOffset topicName topicCategoryName topicSubCategoryName timezone startedAt attendee{firstName lastName email} conductor{fullName employeeId} countryCode endedAt }}}}}",
        "variables": {}
      }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "branch": {
                "walkIns": {
                  "list": [
                {
                  "appointmentId": "58c27df5b649390c13176f13",
                  "appointmentStatus": "COMPLETED",
                  "branchId": "400106",
                  "dateTime": 1484894200000,
                  "startedAt": 1484894200000,
                  "duration": "90",
                  "overdueOffset": "10",
                  "topicName": "Mortgages",
                  "topicCategoryName": "Remortgage A Property",
                  "topicSubCategoryName": null,
                  "timezone": "Europe/London",
                  "attendee": {
                    "firstName": "Peter",
                    "lastName": "Jones",
                    "email": "john.smith@email.com"
                  },
                  "conductor": {
                    "fullName": "Deborah Smithville",
                    "employeeId": "44443232"
                  },
                  "countryCode": "GBR",
                  "endedAt": 1484894200000
                },
                {
                  "appointmentId": "58c27df5b649390c13176f12",
                  "appointmentStatus": "CHECKED_IN",
                  "branchId": "400106",
                  "dateTime": 1486894200000,
                  "startedAt": null,
                  "duration": "90",
                  "overdueOffset": "10",
                  "topicName": "Current Account",
                  "topicCategoryName": "Review",
                  "topicSubCategoryName": null,
                  "timezone": "Europe/London",
                  "attendee": {
                    "firstName": "John",
                    "lastName": "Smith",
                    "email": "john.smith@email.com"
                  },
                  "conductor": {
                    "fullName": "Edna Nashville",
                    "employeeId": "44443232"
                  },
                  "countryCode": "GBR",
                  "endedAt": null
                },
                {
                  "appointmentId": "58c27df5b649390c13176f15",
                  "appointmentStatus": "IN_MEETING",
                  "branchId": "400106",
                  "dateTime": 1483894200000,
                  "startedAt": 1483894200000,
                  "duration": "90",
                  "overdueOffset": "10",
                  "topicName": "Current Account",
                  "topicCategoryName": "Review",
                  "topicSubCategoryName": null,
                  "timezone": "Europe/London",
                  "attendee": {
                    "firstName": "Charles",
                    "lastName": "White",
                    "email": "charles.white@email.com"
                  },
                  "conductor": {
                    "fullName": "Edna Nashville",
                    "employeeId": "44443232"
                  },
                  "countryCode": "GBR",
                  "endedAt": null
                },
                {
                  "appointmentId": "58c27df5b649390c13176f14",
                  "appointmentStatus": "IN_MEETING",
                  "branchId": "400106",
                  "dateTime": 1487894200000,
                  "startedAt": 1487894200000,
                  "duration": "90",
                  "overdueOffset": "10",
                  "topicName": "Current Account",
                  "topicCategoryName": "Review",
                  "topicSubCategoryName": null,
                  "timezone": "Europe/London",
                  "attendee": {
                    "firstName": "Peter",
                    "lastName": "Green",
                    "email": "peter.green@email.com"
                  },
                  "conductor": {
                    "fullName": "Edna Nashville",
                    "employeeId": "44443232"
                  },
                  "countryCode": "GBR",
                  "endedAt": null
                }
              ]
             }
            }
           }
          }
        }
      """
    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }

  it should "return a WalkIn" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/58c27df5b649390c13176f13", "walkin-response.json", headers)

    val request =
      """
      {
        "query":"{ted{walkIn (appointmentId:\"58c27df5b649390c13176f13\")  {appointmentId appointmentStatus branchId dateTime duration, overdueOffset topicId topicCategoryId timezone startedAt attendee{firstName lastName email} conductor{fullName employeeId} countryCode endedAt}}}",
        "variables": {
          }
        }
      """
    val response =
      """
        {
          "data": {
            "ted": {
              "walkIn":
                {
                  "appointmentId": "58c27df5b649390c13176f13",
                  "appointmentStatus": "CHECKED_IN",
                  "branchId": "400106",
                  "dateTime": 1484894200000,
                  "startedAt": 1484894200000,
                  "duration": "90",
                  "overdueOffset": "10",
                  "topicId": "Mortgages",
                  "topicCategoryId": "Remortgage A Property",
                  "timezone": "Europe/London",
                  "attendee": {
                    "firstName": "Peter",
                    "lastName": "Jones",
                    "email": "john.smith@email.com"
                  },
                  "conductor": {
                    "fullName": "Deborah Smithville",
                    "employeeId": "44443232"
                  },
                  "countryCode": "GBR",
                  "endedAt": 1484894200000
                }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }
}
