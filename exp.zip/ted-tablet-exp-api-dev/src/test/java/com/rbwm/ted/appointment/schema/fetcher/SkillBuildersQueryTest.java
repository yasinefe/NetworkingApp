package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.schema.model.VideoSummary;
import org.junit.Test;
import reactor.core.publisher.Mono;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.anyMapOf;
import static org.mockito.Matchers.anyString;

/**
 * Created by 44093684 on 23/01/2018.
 */
public class SkillBuildersQueryTest extends QueryTest {

    @Test
    public void testGetSkillbuildersSummary() {
        //When
        Map<String, Object> result = executeCommand("{ viewer { skillbuilders { summary(branchId: \"400621\") { newUserCount repeatUserCount staffParticipationPercentage totalViews } } } }");

        //Then
        assertEquals("{skillbuilders={" +
                        "summary={newUserCount=10, repeatUserCount=40, staffParticipationPercentage=80, totalViews=50}}" +
                        "}",
                result.get("viewer").toString());
    }

    @Test
    public void testGetSummaryWithAllFiltersUsed() {
        //When
        Map<String, Object> result = executeCommand("{ viewer { skillbuilders { summary(" +
                "branchId: \"400621\", filter:{channelType: [WEB, TABLET], " +
                "eventDateTimeRange: [{ startDateTime: 0, endDateTime: 20}, { startDateTime: 20, endDateTime: 50000}]})" +
                " { totalViews } } } }");

        //Then
        assertNotNull(result);
    }

    @Test
    public void testGetSkillBuildersSummaryWhenStaffParticipationIsNull() {
        //Given
        given(skillBuildersService.getSummary(anyMapOf(String.class, Object.class), anyString(), anyString())).willReturn(Mono.just(new VideoSummary(20, 20, null, 100)));

        //When
        Map<String, Object> result = executeCommand("{ viewer { skillbuilders { summary(branchId: \"200101\")" +
                " { newUserCount repeatUserCount staffParticipationPercentage totalViews } } } }");

        //Then
        assertEquals("{skillbuilders={" +
                        "summary={newUserCount=20, repeatUserCount=20, staffParticipationPercentage=null, totalViews=100}}" +
                        "}",
                result.get("viewer").toString());
    }

    @Test
    public void testGetVideosGroupByMoid() {
        //When
        Map<String, Object> result = executeCommand("{ viewer { skillbuilders { videos(groupBy: MOID)" +
                " { count edges { node { groupValue count viewCount " +
                "group { moid title categories subCategories viewCount ratingCount averageRating playlistParticipationCount } } } } } } } ");

        //Then
        assertEquals("{skillbuilders={videos=" +
                        "{count=3, " +
                        "edges=[" +
                        "{node={groupValue=moid#1, count=1, viewCount=23, group=[{moid=moid#1, title=Title #1," +
                        " categories=[Category1], subCategories=[SubCategory1, SubCategory2], viewCount=23, ratingCount=1, averageRating=5, playlistParticipationCount=8}]}}, " +
                        "{node={groupValue=moid#2, count=1, viewCount=23, group=[{moid=moid#2, title=Title #2," +
                        " categories=[Category2], subCategories=[SubCategory3], viewCount=23, ratingCount=20, averageRating=5, playlistParticipationCount=8}]}}, " +
                        "{node={groupValue=moid#3, count=1, viewCount=23, group=[{moid=moid#3, title=Title #3," +
                        " categories=[Category2], subCategories=[SubCategory4], viewCount=50, ratingCount=30, averageRating=5, playlistParticipationCount=8}]}}" +
                        "]" +
                        "}}}",
                result.get("viewer").toString());
    }

    @Test
    public void testGetVideosGroupByCategory() {
        //When
        Map<String, Object> result = executeCommand("{ viewer { skillbuilders { videos(groupBy: VIDEO_CATEGORY)" +
                " { count edges { node { groupValue count viewCount " +
                "group { moid title categories subCategories viewCount ratingCount averageRating playlistParticipationCount } } } } } } } ");

        //Then
        assertEquals("{skillbuilders={videos=" +
                        "{count=2, " +
                        "edges=[{node={groupValue=Category1, count=1, viewCount=23, group=[{moid=moid#1, title=Title #1," +
                        " categories=[Category1], subCategories=[SubCategory1, SubCategory2], viewCount=23, ratingCount=1, averageRating=5, playlistParticipationCount=8}]}}, " +
                        "{node={groupValue=Category2, count=2, viewCount=73, group=[{moid=moid#2, title=Title #2," +
                        " categories=[Category2], subCategories=[SubCategory3], viewCount=23, ratingCount=20, averageRating=5, playlistParticipationCount=8}, " +
                        "{moid=moid#3, title=Title #3," +
                        " categories=[Category2], subCategories=[SubCategory4], viewCount=50, ratingCount=30, averageRating=5, playlistParticipationCount=8}]}}]}}}",
                result.get("viewer").toString());
    }

    @Test
    public void testGetVideosGroupByNothing() {
        //When
        Map<String, Object> result = executeCommand("{ viewer { skillbuilders { videos" +
                " { count edges { node { groupValue count viewCount " +
                "group { moid title categories subCategories viewCount ratingCount averageRating playlistParticipationCount } } } } } } } ");

        //Then
        assertEquals("{skillbuilders={videos=" +
                        "{count=1, " +
                        "edges=[{node={groupValue=ALL, count=3, viewCount=23, group=[{moid=moid#1, title=Title #1," +
                        " categories=[Category1], subCategories=[SubCategory1, SubCategory2], viewCount=23, ratingCount=1, averageRating=5, playlistParticipationCount=8}, " +
                        "{moid=moid#2, title=Title #2," +
                        " categories=[Category2], subCategories=[SubCategory3], viewCount=23, ratingCount=20, averageRating=5, playlistParticipationCount=8}, " +
                        "{moid=moid#3, title=Title #3," +
                        " categories=[Category2], subCategories=[SubCategory4], viewCount=50, ratingCount=30, averageRating=5, playlistParticipationCount=8}]}}]}}}",
                result.get("viewer").toString());
    }

    @Test
    public void testGetByGroupByNothingWithGroupSort() {
        //When
        Map<String, Object> result = executeCommand("{ viewer { skillbuilders { videos( groupSort: { key: \"ratingCount\", order: DESC }) " +
                " { count edges { node { groupValue count viewCount " +
                "group { moid title categories subCategories viewCount ratingCount averageRating playlistParticipationCount } } } } } } } ");

        //Then
        assertEquals("{skillbuilders={videos=" +
                        "{count=1, " +
                        "edges=[{node={groupValue=ALL, count=3, viewCount=23, " +
                        "group=[{moid=moid#3, title=Title #3," +
                        " categories=[Category2], subCategories=[SubCategory4], viewCount=50, ratingCount=30, averageRating=5, playlistParticipationCount=8}, " +
                        "{moid=moid#2, title=Title #2," +
                        " categories=[Category2], subCategories=[SubCategory3], viewCount=23, ratingCount=20, averageRating=5, playlistParticipationCount=8}, " +
                        "{moid=moid#1, title=Title #1," +
                        " categories=[Category1], subCategories=[SubCategory1, SubCategory2], viewCount=23, ratingCount=1, averageRating=5, playlistParticipationCount=8}" +
                        "]}}]}}}",
                result.get("viewer").toString());
    }

    @Test
    public void testVideoQueryWithAllFiltersUsed() {
        //When
        Map<String, Object> result = executeCommand("{ viewer { skillbuilders {" +
                " videos(groupBy: MOID," +
                " branchId: \"200000\", countryCode: \"GBR\", filter : { channelType: [WEB, TABLET], " +
                " eventDateTimeRange: [{ startDateTime: 0, endDateTime: 20}, { startDateTime: 20, endDateTime: 50000}]})" +
                " { count edges { node { groupValue count viewCount group { moid } } } } } } } ");

        //Then
        assertNotNull(result.get("viewer"));
    }

}
