package com.rbwm.ted.appointment.walkins;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.github.tomakehurst.wiremock.matching.EqualToJsonPattern;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.MIConfiguration;
import com.rbwm.ted.appointment.meetings.GetMeetingsGroups;
import com.rbwm.ted.appointment.schema.model.MeetingsGroup;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44093684 on 07/12/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class GetMeetingsGroupsTest {

    private GetMeetingsGroups getMeetingsGroups;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private MIConfiguration miConfiguration = new MIConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(miConfiguration, "miHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(miConfiguration, "miMeetingsSummaryUri", "/meetings/summary");
        ReflectionTestUtils.setField(miConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getMeetingsGroups = new GetMeetingsGroups(miConfiguration);
    }

    @Test
    public void testWalkInsGroupByTopicCategory() throws IOException, URISyntaxException {
        //Given
        stubFor(post(urlPathEqualTo("/meetings/summary"))
                .withRequestBody(new EqualToJsonPattern("{\"filter\":{\"meetingType\":\"WALK_INS\"}," +
                        "\"groupBy\":\"TOPIC_CATEGORY\"}", true, false))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("mi-summary-response.json"))));


        //When
        Map<String, Object> filter = new HashMap<>();
        filter.put("meetingType", "WALK_INS");

        List<MeetingsGroup> actual = getMeetingsGroups.get(filter, "TOPIC_CATEGORY").block();

        //Then
        List<MeetingsGroup> expected = asList(
                new MeetingsGroup("Unsecured Lending", 4, 20),
                new MeetingsGroup("Savings", 5, null),
                new MeetingsGroup("Mortgage", 11, 2),
                new MeetingsGroup("Premier", 16, null),
                new MeetingsGroup("Other", 1, 1)
        );
        assertEquals(expected, actual);
    }

    @Test
    public void testAppointmentsGroupByNearest15MinInterval() throws IOException, URISyntaxException {
        //Given
        stubFor(post(urlPathEqualTo("/meetings/summary"))
                .withRequestBody(new EqualToJsonPattern("{\"filter\":{\"meetingType\":\"APPOINTMENTS\"}," +
                        "\"groupBy\":\"CHECKED_IN_AT__MINUTE__NEAREST_15\"}", true, false))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("mi-summary-response-15min-interval.json"))));
        //When
        Map<String, Object> filter = new HashMap<>();
        filter.put("meetingType", "APPOINTMENTS");
        List<MeetingsGroup> actual = getMeetingsGroups.get(filter, "CHECKED_IN_AT__MINUTE__NEAREST_15").block();

        //Then
        List<MeetingsGroup> expected = asList(
                new MeetingsGroup("09:00:00", 1, 1),
                new MeetingsGroup("09:15:00", 2, 3),
                new MeetingsGroup("09:30:00", 4, 10),
                new MeetingsGroup("09:45:00", 0, null),
                new MeetingsGroup("10:00:00", 0, null),
                new MeetingsGroup("10:15:00", 0, null),
                new MeetingsGroup("10:30:00", 5, 20),
                new MeetingsGroup("10:45:00", 0, null),
                new MeetingsGroup("11:00:00", 0, null)
        );
        assertEquals(expected, actual);
    }

    @Test(expected = Exceptions.UnexpectedException.class)
    public void testInproperJsonThrowsUnexpectedException(){
        stubFor(post(urlPathEqualTo("/meetings/summary"))
                .withRequestBody(new EqualToJsonPattern("{\"filter\":{\"meetingType\":\"WALK_INS\"}," +
                        "\"groupBy\":\"TOPIC_CATEGORY\"}", true, false))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{ UNPARSIB+LE JSON }")));

        Map<String, Object> filter = new HashMap<>();
        filter.put("meetingType", "WALK_INS");
        getMeetingsGroups.get(filter, "TOPIC_CATEGORY").block();
    }


}
