package com.rbwm.ted.appointment.sort;

import com.rbwm.ted.appointment.schema.sort.ObjectFieldComparator;
import com.rbwm.ted.appointment.schema.sort.Sort;
import com.rbwm.ted.appointment.schema.sort.SortOrder;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44093684 on 01/02/2018.
 */
public class ObjectFieldComparatorTest {

    @Test
    public void testSortingByOneStringField() {
        //Given
        ObjectFieldComparator<CategoryCountObject> objectFieldComparator = new ObjectFieldComparator<>(Collections.singletonList(new Sort("category", SortOrder.ASC)));
        List<CategoryCountObject> objectsToSort = asList(
                new CategoryCountObject("Ant", "Banana", 42, 0.1),
                new CategoryCountObject("Bank", "Ardvark", 23, 4.4),
                new CategoryCountObject("Aaple", "Charlie", 2, 0.2)
        );

        //When
        objectsToSort.sort(objectFieldComparator);

        //Then
        List<CategoryCountObject> expectedAfterSort = asList(
                new CategoryCountObject("Aaple", "Charlie", 2, 0.2),
                new CategoryCountObject("Ant", "Banana", 42, 0.1),
                new CategoryCountObject("Bank", "Ardvark", 23, 4.4)
        );
        assertEquals(expectedAfterSort, objectsToSort);
    }

    @Test
    public void testSortingByTwoStringFields() {
        ObjectFieldComparator<CategoryCountObject> objectFieldComparator = new ObjectFieldComparator<>(Arrays.asList(
                new Sort("category", SortOrder.ASC),
                new Sort("subCategory", SortOrder.ASC)
        ));
        List<CategoryCountObject> objectsToSort = asList(
                new CategoryCountObject("B", "BB", 2, 0d),
                new CategoryCountObject("A", "AC", 42, 0d),
                new CategoryCountObject("A", "AB", 23, 0d),
                new CategoryCountObject("C", "CB", 34, 0d),
                new CategoryCountObject("C", "CA", 4, 0d)
        );

        //When
        objectsToSort.sort(objectFieldComparator);

        //Then
        List<CategoryCountObject> expectedAfterSort = asList(
                new CategoryCountObject("A", "AB", 23, 0d),
                new CategoryCountObject("A", "AC", 42, 0d),
                new CategoryCountObject("B", "BB", 2, 0d),
                new CategoryCountObject("C", "CA", 4, 0d),
                new CategoryCountObject("C", "CB", 34, 0d)
        );
        assertEquals(expectedAfterSort, objectsToSort);
    }

    @Test
    public void testSortingByOneNumberField() {
        //Given
        ObjectFieldComparator<CategoryCountObject> objectFieldComparator = new ObjectFieldComparator<>(Collections.singletonList(new Sort("count", SortOrder.DESC)));
        List<CategoryCountObject> objectsToSort = asList(
                new CategoryCountObject("B", "BB", 2, 0d),
                new CategoryCountObject("A", "AC", 42, 0d),
                new CategoryCountObject("A", "AB", 23, 0d),
                new CategoryCountObject("C", "CB", 34, 0d),
                new CategoryCountObject("C", "CA", 4, 0d)
        );

        //When
        objectsToSort.sort(objectFieldComparator);

        //Then
        List<CategoryCountObject> expectedAfterSort = asList(
                new CategoryCountObject("A", "AC", 42, 0d),
                new CategoryCountObject("C", "CB", 34, 0d),
                new CategoryCountObject("A", "AB", 23, 0d),
                new CategoryCountObject("C", "CA", 4, 0d),
                new CategoryCountObject("B", "BB", 2, 0d)
        );
        assertEquals(expectedAfterSort, objectsToSort);
    }

    @Test
    public void testSortingByTwoNumberFields() {
        //Given
        ObjectFieldComparator<CategoryCountObject> objectFieldComparator = new ObjectFieldComparator<>(Arrays.asList(
                new Sort("count", SortOrder.ASC),
                new Sort("average", SortOrder.ASC)
        ));
        List<CategoryCountObject> objectsToSort = asList(
                new CategoryCountObject("A", "AB", 2, 1.5),
                new CategoryCountObject("B", "BB", 1, 1.1),
                new CategoryCountObject("C", "CB", 2, 1.4),
                new CategoryCountObject("A", "AC", 1, 1.2),
                new CategoryCountObject("C", "CA", 3, 0d)
        );

        //When
        objectsToSort.sort(objectFieldComparator);

        //Then
        List<CategoryCountObject> expectedAfterSort = asList(
                new CategoryCountObject("B", "BB", 1, 1.1),
                new CategoryCountObject("A", "AC", 1, 1.2),
                new CategoryCountObject("C", "CB", 2, 1.4),
                new CategoryCountObject("A", "AB", 2, 1.5),
                new CategoryCountObject("C", "CA", 3, 0d)
        );
        assertEquals(expectedAfterSort, objectsToSort);
    }

    @Test
    public void testSortingAttemptByUnSortableFieldShouldLeaveOrderTheSame() {
        ObjectFieldComparator<CategoryCountObject> objectFieldComparator = new ObjectFieldComparator<>(Collections.singletonList(new Sort("unsortableField", SortOrder.DESC)));
        List<CategoryCountObject> objectsToSort = asList(
                new CategoryCountObject("A", "AB", 2, 1.5, new UnSortableObject(2000)),
                new CategoryCountObject("B", "BB", 1, 1.1, new UnSortableObject(23)),
                new CategoryCountObject("C", "CB", 2, 1.4, new UnSortableObject(34)),
                new CategoryCountObject("A", "AC", 1, 1.2, new UnSortableObject(3)),
                new CategoryCountObject("C", "CA", 3, 0d, new UnSortableObject(1))
        );

        //When
        objectsToSort.sort(objectFieldComparator);

        //Then
        List<CategoryCountObject> collectionAfterSort = asList(
                new CategoryCountObject("A", "AB", 2, 1.5, new UnSortableObject(2000)),
                new CategoryCountObject("B", "BB", 1, 1.1, new UnSortableObject(23)),
                new CategoryCountObject("C", "CB", 2, 1.4, new UnSortableObject(34)),
                new CategoryCountObject("A", "AC", 1, 1.2, new UnSortableObject(3)),
                new CategoryCountObject("C", "CA", 3, 0d, new UnSortableObject(1))
        );
        assertEquals(collectionAfterSort, objectsToSort);
    }

    @Test
    public void testSortingNullsFirstIfAsc() {
        //Given
        ObjectFieldComparator<CategoryCountObject> objectFieldComparator = new ObjectFieldComparator<>(Arrays.asList(
                new Sort("category", SortOrder.ASC),
                new Sort("subCategory", SortOrder.ASC)));

        List<CategoryCountObject> objectsToSort = asList(
                new CategoryCountObject("B", "BB", 2, 0d),
                new CategoryCountObject(null, "AC", 42, 0d),
                new CategoryCountObject(null, "AB", 23, 0d),
                new CategoryCountObject("C", "CB", 34, 0d)
        );

        //When
        objectsToSort.sort(objectFieldComparator);

        //Then
        List<CategoryCountObject> afterSort = asList(
                new CategoryCountObject(null, "AB", 23, 0d),
                new CategoryCountObject(null, "AC", 42, 0d),
                new CategoryCountObject("B", "BB", 2, 0d),
                new CategoryCountObject("C", "CB", 34, 0d)
        );
        assertEquals(afterSort, objectsToSort);
    }

    @Test
    public void testSortingNullsLastIfDesc() {
        //Given
        ObjectFieldComparator<CategoryCountObject> objectFieldComparator = new ObjectFieldComparator<>(Arrays.asList(
                new Sort("category", SortOrder.DESC),
                new Sort("subCategory", SortOrder.DESC)));

        List<CategoryCountObject> objectsToSort = asList(
                new CategoryCountObject("B", "BB", 2, 0d),
                new CategoryCountObject(null, "AC", 42, 0d),
                new CategoryCountObject(null, "AB", 23, 0d),
                new CategoryCountObject("C", "CB", 34, 0d)
        );

        //When
        objectsToSort.sort(objectFieldComparator);

        //Then
        List<CategoryCountObject> afterSort = asList(
                new CategoryCountObject("C", "CB", 34, 0d),
                new CategoryCountObject("B", "BB", 2, 0d),
                new CategoryCountObject(null, "AC", 42, 0d),
                new CategoryCountObject(null, "AB", 23, 0d)
        );
        assertEquals(afterSort, objectsToSort);
    }

    @ToString
    @EqualsAndHashCode
    public static class CategoryCountObject {
        public final String category;
        public final String subCategory;
        public final Integer count;
        public final Double average;
        public final UnSortableObject unsortableField;

        private CategoryCountObject(String category, String subCategory, Integer count, Double average) {
            this.category = category;
            this.subCategory = subCategory;
            this.count = count;
            this.average = average;
            this.unsortableField = null;
        }

        public CategoryCountObject(String category, String subCategory, Integer count, Double average, UnSortableObject unSortableField) {
            this.category = category;
            this.subCategory = subCategory;
            this.count = count;
            this.average = average;
            this.unsortableField = unSortableField;
        }
    }

    @ToString
    @EqualsAndHashCode
    //not implementing comparable.
    public static class UnSortableObject {
        public final int number;

        public UnSortableObject(int number) {
            this.number = number;
        }
    }


}
