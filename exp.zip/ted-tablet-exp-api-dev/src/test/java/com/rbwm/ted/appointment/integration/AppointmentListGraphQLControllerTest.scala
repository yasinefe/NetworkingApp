/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 19/01/2017.
  */
@WebAppConfiguration
class AppointmentListGraphQLControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {
  val httpHeaders = new HttpHeaders()
  httpHeaders.add("X-BRANCH-ID", "404628")

  it should "return 1 UPCOMING appointments" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/branchId/404628", "branch-response.json", headers)
    mockGetWithFileContentAsync("/appointments/list/404628?status=CHECKED_IN", "get-appointment-list-response.json", headers)

    val request =
      """
      {
        "query": "{viewer {branch(branchId: \"404628\"){appointments (appointmentStatus:CHECKED_IN) {id list {id appointmentId appointmentStatus branchId dateTime duration topicId topicName topicCategoryId topicCategoryName timezone attendee{firstName lastName email} conductor{fullName employeeId}} summary { id count appointmentStatus } stats { id inNextHour } groups { id nextBusinessDay {id appointmentId appointmentStatus branchId dateTime duration topicId topicName topicCategoryId topicCategoryName timezone attendee{firstName lastName email} conductor{fullName employeeId}}}}}}}",
        "variables": {
          }
        }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "branch": {
                "appointments": {
                  "id": "YXBwb2ludG1lbnRMaXN0OjQwNDYyOC1DSEVDS0VEX0lO",
                  "list": [
                     {
                       "id": "YXBwb2ludG1lbnQ6WEVGMTUzMg==",
                       "appointmentId": "XEF1532",
                       "appointmentStatus": "CHECKED_IN",
                       "branchId": "404628",
                       "dateTime": 1477465200000,
                       "duration": "90",
                       "topicId": "Mortgages",
                       "topicName": "Mortgages",
                       "topicCategoryId": "Purchase a Property",
                       "topicCategoryName": "Purchase a Property",
                       "timezone": "Asia/Shanghai",
                       "attendee": {
                         "firstName": "Jonathan",
                         "lastName": "Talbot",
                         "email": null
                       },
                       "conductor": {
                         "fullName": "MR PIETRO RIZZI",
                         "employeeId": "01747754"
                       }
                     }
                  ],
                  "summary" : [
                     {
                       "id": "YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDQ2MjgtQ0hFQ0tFRF9JTg==",
                       "count": 0,
                       "appointmentStatus": "CHECKED_IN"
                     },
                     {
                       "id": "YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDQ2MjgtQ09NUExFVEVE",
                       "count": 2,
                       "appointmentStatus": "COMPLETED"
                     },
                     {
                       "id": "YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDQ2MjgtSU5fTUVFVElORw==",
                       "count": 3,
                       "appointmentStatus": "IN_MEETING"
                     },
                     {
                       "id": "YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDQ2MjgtTk9TSE9X",
                       "count": 1,
                       "appointmentStatus": "NOSHOW"
                     },
                     {
                       "id": "YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDQ2MjgtT1ZFUkRVRQ==",
                       "count": 4,
                       "appointmentStatus": "OVERDUE"
                     },
                     {
                       "id": "YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDQ2MjgtT1ZFUlJVTg==",
                       "count": 7,
                       "appointmentStatus": "OVERRUN"
                     },
                     {
                       "id": "YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDQ2MjgtVVBDT01JTkc=",
                       "count": 19,
                       "appointmentStatus": "UPCOMING"
                     }
                   ],
                   "stats": {
                     "id": "YXBwb2ludG1lbnRTdGF0czo0MDQ2Mjg=",
                     "inNextHour": 2
                   },
                   "groups": {
                     "id": "YXBwb2ludG1lbnRHcm91cHM6NDA0NjI4",
                     "nextBusinessDay": [
                      {
                        "id": "YXBwb2ludG1lbnQ6WEVGMTUzMg==",
                        "appointmentId": "XEF1532",
                        "appointmentStatus": "CHECKED_IN",
                        "branchId": "404628",
                        "dateTime": 1477465200000,
                        "duration": "90",
                        "topicId": "Mortgages",
                        "topicName": "Mortgages",
                        "topicCategoryId": "Purchase a Property",
                        "topicCategoryName": "Purchase a Property",
                        "timezone": "Asia/Shanghai",
                        "attendee": {
                          "firstName": "Jonathan",
                          "lastName": "Talbot",
                          "email": null
                        },
                        "conductor": {
                          "fullName": "MR PIETRO RIZZI",
                          "employeeId": "01747754"
                        }
                      }
                     ]
                   }
                }
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }

  it should "return only the summary of appointments when no status is passed in as an argument" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/branchId/404628", "branch-response.json", headers)
    mockGetWithFileContentAsync("/appointments/list/404628?status=UPCOMING", "get-appointment-list-response.json", headers)

    val request =
      """
      {
        "query": "{viewer {branch(branchId: \"404628\"){appointments {list {appointmentId appointmentStatus branchId dateTime duration topicId topicName topicCategoryId topicCategoryName timezone attendee{firstName lastName email} conductor{fullName employeeId}} summary { count appointmentStatus } }}}}",
        "variables": {
          }
        }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "branch": {
                "appointments": {
                  "list": [],
                  "summary" : [
                     {
                       "count": 0,
                       "appointmentStatus": "CHECKED_IN"
                     },
                     {
                       "count": 2,
                       "appointmentStatus": "COMPLETED"
                     },
                     {
                       "count": 3,
                       "appointmentStatus": "IN_MEETING"
                     },
                     {
                       "count": 1,
                       "appointmentStatus": "NOSHOW"
                     },
                     {
                       "count": 4,
                       "appointmentStatus": "OVERDUE"
                     },
                     {
                       "count": 7,
                       "appointmentStatus": "OVERRUN"
                     },
                     {
                       "count": 19,
                       "appointmentStatus": "UPCOMING"
                     }
                   ]
                }
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }
}
