/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import com.rbwm.ted.appointment.authentication.AuthenticationFacade
import com.rbwm.ted.appointment.filter.LoggingFilter
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer
import org.junit.runner.RunWith
import org.mockito.Mockito._
import org.scalatest.junit.JUnitRunner
import org.scalatest.mockito.MockitoSugar
import org.scalatest.{BeforeAndAfter, FlatSpec, GivenWhenThen, Matchers}
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.security.core.Authentication
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.test.context.{ActiveProfiles, TestContextManager, TestPropertySource}
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders._
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import org.springframework.test.web.servlet.setup.{DefaultMockMvcBuilder, MockMvcBuilders}
import org.springframework.web.context.WebApplicationContext

/**
  * Created by 44052007 on 19/01/2018.
  */
@RunWith(classOf[JUnitRunner])
@ActiveProfiles(profiles = Array("int-be-test"))
@TestPropertySource(properties = Array[String] {
  "spring.config.location = classpath:config/ted-tablet-exp-api.yaml"
})
@SpringBootTest(classes = Array(classOf[Application]))
@WebAppConfiguration
class ReportingControllerTest extends FlatSpec
  with Matchers
  with MockitoSugar
  with BeforeAndAfter
  with GivenWhenThen {

  var mvc: MockMvc = _

  @Autowired
  val webApplicationContext: WebApplicationContext = null

  @Autowired
  var reportingController: ReportingController = null

  var authenticationFacade: AuthenticationFacade = null
  var authentication: Authentication = null
  var log: Logger = null

  before {
    authenticationFacade = mock[AuthenticationFacade]
    authentication = mock[Authentication]
    log = mock[Logger]

    new TestContextManager(this.getClass).prepareTestInstance(this)
    val mvcBuilder: DefaultMockMvcBuilder = MockMvcBuilders.webAppContextSetup(webApplicationContext)
      .addFilters(new LoggingFilter(authenticationFacade))
    mvc = mvcBuilder.build()

    ReflectionTestUtils.setField(reportingController, "authenticationFacade", authenticationFacade)
    ReflectionTestUtils.setField(reportingController, "logger", log)
  }

  it should "report error log with all parameters" in {
    CorrelationIdContainer.setId("correlationId")
    when(authentication.getName).thenReturn("userId")
    when(authenticationFacade.getAuthentication).thenReturn(authentication)

    val request =
      """
      { "error" : "UI Error's" }
      """

    val httpHeaders = new HttpHeaders()
    httpHeaders.add("X-CORRELATION-ID", "correlationId")
    httpHeaders.add("X-BRANCH-ID", "branchId")
    httpHeaders.add("X-MACHINE-ID", "machineId")
    httpHeaders.add("X-WIFI-MAC-ADDRESS", "wifiMACAddress")
    httpHeaders.add("X-COUNTRY-CODE", "countryCode")

    executePostTest(request, HttpStatus.OK, httpHeaders)

    verify(log).error("ErrorType=UI UserId={} BranchId={} MachineId={} WifiMacAddress={} CountryCode={} CorrelationId={} ErrorDetail='{}'", "userId", "branchId", "machineId", "wifiMACAddress", "countryCode", "correlationId", "{\"error\":\"UI Errors\"}")
  }

  it should "report error log without optional parameters" in {
    CorrelationIdContainer.setId(null)
    when(authenticationFacade.getAuthentication).thenReturn(authentication)

    val request = "{}"

    executePostTest(request, HttpStatus.OK, new HttpHeaders())
    verify(log).error("ErrorType=UI UserId={} BranchId={} MachineId={} WifiMacAddress={} CountryCode={} CorrelationId={} ErrorDetail='{}'", null, null, null, null, null, null, "{}")
  }

  def executePostTest(request: String, httpStatus: HttpStatus, httpHeaders: HttpHeaders) = {
    mvc.perform(post("/report/error")
      .contentType(MediaType.APPLICATION_JSON)
      .headers(httpHeaders)
      .content(request))
      .andExpect(status().is(httpStatus.value()))
  }

}

