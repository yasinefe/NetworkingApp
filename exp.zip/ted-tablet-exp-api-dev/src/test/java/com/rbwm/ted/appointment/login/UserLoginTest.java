/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.login;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.LoginConfiguration;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static junit.framework.TestCase.assertEquals;

/**
 * Created by 43578876 on 24/04/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class UserLoginTest {

    private UserLogin userLogin;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private LoginConfiguration loginConfiguration = new LoginConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(loginConfiguration, "loginHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(loginConfiguration, "loginUri", "/login");
        ReflectionTestUtils.setField(loginConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        userLogin = new UserLogin(loginConfiguration, new ReactiveResponseHandler<>());
    }

    @Test
    public void testLogin() throws Exception {
        stubFor(post(urlPathEqualTo("/login"))
                .withRequestBody(equalToJson("{ \"staffId\" : \"44052007\", \"password\": \"pass\"}"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("login-response.json"))));

        LoginResponse loginResponse = userLogin.login(new Credentials("44052007", "pass")).block();

        LoginResponse expected = new LoginResponse(new User("CN=44052007,OU=HSBCPeople,DC=InfoDir,DC=Dev,DC=HSBC",
                "44052007", "Yasin", "Efe", "GBR", "HGSU",
                "http://photos.global.hsbc/casual/square/4405/44052007.jpg"), "NDQwNTIwMDc==");

        assertEquals(expected, loginResponse);
    }

    @Test(expected = Exceptions.UnauthorisedException.class)
    public void testLoginWhenAuthenticationFailed() throws Exception {
        stubFor(post(urlPathEqualTo("/login"))
                .withRequestBody(equalToJson("{ \"staffId\" : \"44052007\", \"password\": \"pass\"}"))
                .willReturn(aResponse()
                        .withStatus(401)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{ \"error\" : { \"code\" : \"ERROR-CODE\", \"message\" : \"error-message\" } }")));

        userLogin.login(new Credentials("44052007", "pass")).block();
    }

    @Test(expected = HttpClientErrorException.class)
    public void testLoginWhenAnyOtherHttpClientExceptionOccurred() throws Exception {
        stubFor(post(urlPathEqualTo("/login"))
                .withRequestBody(equalToJson("{ \"staffId\" : \"44052007\", \"password\": \"pass\"}"))
                .willReturn(aResponse()
                        .withStatus(403)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{ \"error\" : { \"code\" : \"ERROR-CODE\", \"message\" : \"error-message\" } }")));

        userLogin.login(new Credentials("44052007", "pass")).block();
    }
}