package com.rbwm.ted.appointment.skillbuilders;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.SkillBuildersConfiguration;
import com.rbwm.ted.appointment.schema.model.Video;
import com.rbwm.ted.appointment.schema.model.VideoGroup;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static java.util.stream.Collectors.toSet;
import static java.util.stream.Stream.of;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44093684 on 26/01/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class GetVideosTest {

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private SkillBuildersConfiguration skillBuildersConfiguration;

    private GetVideos getVideos;

    @Before
    public void setUp() {
        skillBuildersConfiguration = new SkillBuildersConfiguration();
        ReflectionTestUtils.setField(skillBuildersConfiguration, "skillbuildersHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(skillBuildersConfiguration, "skillbuildersVideoStatsUri", "/videos");
        ReflectionTestUtils.setField(skillBuildersConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());

        getVideos = new GetVideos(skillBuildersConfiguration);
    }

    @Test
    public void testGetVideos() throws IOException, URISyntaxException {
        //Given
        stubFor(post(urlPathEqualTo("/videos"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("skillbuilders-videos.json"))));

        //When
        List<VideoGroup> actual = getVideos.get(Collections.emptyMap(), "VIDEO_CATEGORY", "GBR", singletonList("44090001")).block();

        //Then
        List<Video> expectedVideoGroup1 = asList(
                new Video("f12c6667-a1de-4d5f-9e9f-9cc98db5f16b", "Counting money", of("Staff").collect(toSet()),
                        of("Cashier").collect(toSet()), 0, 3, 3, 1),
                new Video("6ef48962-afb6-4459-8e3a-d01c9bebb271", "Channel - Outbound Calls", of("Staff").collect(toSet()),
                        of("Conversation Enablers").collect(toSet()), 8, 2, 1, 0)
        );
        List<Video> expectedVideoGroup2 = singletonList(
                new Video("f12c6667-a1de-4d5f-9e9f-9cc98db5f16b", "Counting money", of("Topic").collect(toSet()),
                        of("Universal Banker").collect(toSet()), 0, 3, 3, 1)
        );
        List<VideoGroup> expected = asList(
                new VideoGroup("Staff", 2, expectedVideoGroup1, 8),
                new VideoGroup("Topic", 1, expectedVideoGroup2, 0)
        );
        assertEquals(expected, actual);
    }

    @Test(expected = Exceptions.UnexpectedException.class)
    public void testExceptionThrownDuringGetVideos()  {
        //given
        stubFor(post(urlPathEqualTo("/videos"))
                .willReturn(aResponse()
                        .withStatus(500)
                        .withHeader("Content-Type", "application/json")));

        getVideos = new GetVideos(skillBuildersConfiguration);

        //When
        getVideos.get(Collections.emptyMap(), "MOID", "GBR", singletonList("44090001")).block();
    }


}
