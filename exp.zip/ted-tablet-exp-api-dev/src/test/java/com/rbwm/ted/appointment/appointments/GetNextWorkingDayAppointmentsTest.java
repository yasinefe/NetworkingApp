/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AppointmentBookingConfiguration;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 30/04/2018.
 */
public class GetNextWorkingDayAppointmentsTest {

    private static final String BRANCH_ID = "400219";

    private GetNextWorkingDayAppointments getNextWorkingDayAppointments;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AppointmentBookingConfiguration appointmentBookingConfiguration = new AppointmentBookingConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "appointmentsHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "meetingsUri", "/meetings");
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getNextWorkingDayAppointments = new GetNextWorkingDayAppointments(appointmentBookingConfiguration, new ReactiveResponseHandler<>());
    }

    @Test
    public void testGetAppointmentsGivenStatusAndGroup() throws Exception {
        stubFor(get(urlPathEqualTo("/meetings/branchId/" + BRANCH_ID + "/nextWorkingDay"))
                .withQueryParam("meetingStatus", equalTo("IN_MEETING"))
                .withQueryParam("meetingGroup", equalTo("CHECKED_IN"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-meetings-response.json"))));

        List<Map<String, Object>> appointments = getNextWorkingDayAppointments.getAppointments(BRANCH_ID, MeetingStatus.IN_MEETING, MeetingGroupType.CHECKED_IN).block();
        validateResponse(appointments);
    }

    @Test
    public void testGetAppointmentsGivenStatus() throws Exception {
        stubFor(get(urlPathEqualTo("/meetings/branchId/" + BRANCH_ID + "/nextWorkingDay"))
                .withQueryParam("meetingStatus", equalTo("IN_MEETING"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-meetings-response.json"))));

        List<Map<String, Object>> appointments = getNextWorkingDayAppointments.getAppointments(BRANCH_ID, MeetingStatus.IN_MEETING, null).block();
        validateResponse(appointments);
    }

    @Test
    public void testGetAppointmentsGivenGroup() throws Exception {
        stubFor(get(urlPathEqualTo("/meetings/branchId/" + BRANCH_ID + "/nextWorkingDay"))
                .withQueryParam("meetingGroup", equalTo("CHECKED_IN"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-meetings-response.json"))));

        List<Map<String, Object>> appointments = getNextWorkingDayAppointments.getAppointments(BRANCH_ID, null, MeetingGroupType.CHECKED_IN).block();
        validateResponse(appointments);
    }

    private void validateResponse(List<Map<String, Object>> appointments) {
        assertEquals(1, appointments.size());
        assertEquals("TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==", appointments.get(0).get("id"));
        assertEquals(30, appointments.get(0).get("duration"));
        assertEquals("APPOINTMENTS", appointments.get(0).get("type"));
    }
}