/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment

import com.hsbc.rbwm.ted.rest.error.{ErrorCode, Exceptions}
import com.rbwm.ted.appointment.api.LoginServiceApi
import com.rbwm.ted.appointment.audit.{AuditContext, AuditProcessor, DataFetcherAudit}
import com.rbwm.ted.appointment.authentication.AuthenticationFacade
import com.rbwm.ted.appointment.filter.LoggingFilter
import com.rbwm.ted.appointment.http.HeaderContext
import com.rbwm.ted.appointment.login.{Credentials, LoginResponse, User}
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer
import org.junit.runner.RunWith
import org.mockito.Mockito._
import org.scalatest.junit.JUnitRunner
import org.scalatest.mockito.MockitoSugar
import org.scalatest.{BeforeAndAfter, FlatSpec, GivenWhenThen, Matchers}
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.test.context.{ActiveProfiles, TestContextManager, TestPropertySource}
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders._
import org.springframework.test.web.servlet.result.{MockMvcResultHandlers, MockMvcResultMatchers}
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.{request, _}
import org.springframework.test.web.servlet.setup.{DefaultMockMvcBuilder, MockMvcBuilders}
import org.springframework.web.context.WebApplicationContext
import reactor.core.publisher.Mono

/**
  * Created by 44052007 on 29/11/2017.
  */
@RunWith(classOf[JUnitRunner])
@ActiveProfiles(profiles = Array("int-be-test"))
@TestPropertySource(properties = Array[String]{"spring.config.location = classpath:config/ted-tablet-exp-api.yaml"})
@SpringBootTest(classes = Array(classOf[Application]))
@WebAppConfiguration
class LoginControllerTest extends FlatSpec
  with Matchers
  with MockitoSugar
  with BeforeAndAfter
  with GivenWhenThen {

  var mvc: MockMvc = _

  @Autowired
  val webApplicationContext: WebApplicationContext = null

  @Autowired
  var loginController: LoginController =null

  @Autowired
  var authenticationFacade: AuthenticationFacade =null

  var loginService: LoginServiceApi =null
  var auditProcessor: AuditProcessor =null

  before {
    new TestContextManager(this.getClass).prepareTestInstance(this)
    val mvcBuilder: DefaultMockMvcBuilder = MockMvcBuilders.webAppContextSetup(webApplicationContext)
      .addFilters(new LoggingFilter(authenticationFacade))
    mvc = mvcBuilder.build()

    loginService = mock[LoginServiceApi]
    auditProcessor = mock[AuditProcessor]

    ReflectionTestUtils.setField(loginController, "loginService", loginService)
    ReflectionTestUtils.setField(loginController, "auditProcessor", auditProcessor)
  }

  val credentials = new Credentials("12345678","password")

  it should "authorise a user with the correct credentials " in {
    CorrelationIdContainer.setId("correlationId")

    val user = new User("", "12345678", "Jo","Bloggs","GBR", "HGSU","http://photos.global.hsbc/casual/square/1234/12345.jpg")
    val loginResponse = new LoginResponse(user, "generated-token")
    when(loginService.login(credentials)).thenReturn(Mono.just(loginResponse));

    val request =
      """
      {"staffId":"12345678", "password":"password"}
      """

    val response =
      """
        |{
        |  "user":{"cn":"","employeeId":"12345678","firstName":"Jo","lastName":"Bloggs","countryCode":"GBR","organisationCode":"HGSU","portraitUrl":"http://photos.global.hsbc/casual/square/1234/12345.jpg"},
        |  "token":"generated-token"
        |}
      """.stripMargin.trim

    executePostTest(request, response, HttpStatus.OK)

    val headerContext = new HeaderContext("400621", "23:23:12:12", "machineId", "GBR")
    val dataFetcherAudit= new DataFetcherAudit("12345678", "LOGIN", "USER_PROFILE", user)
    verify(auditProcessor).sendEvent(new AuditContext("correlationId", headerContext, "12345678", null, null, false, dataFetcherAudit))
  }

  it should "not authorise a user with the incorrect credentials" in {
    when(loginService.login(credentials)).thenThrow(new Exceptions.UnauthorisedException(new ErrorCode("TEE-LOGIN-USER-UNAUTHORISED") ,new RuntimeException(), ""))

    val request =
      """
      {"staffId":"12345678", "password":"password"}
      """

    val response =
      """
        |{
        |  "data":null,
        |  "errors":[{"code":"TEE-LOGIN-USER-UNAUTHORISED","message":""}]
        |}
      """.stripMargin

    executePost(request, response, HttpStatus.UNAUTHORIZED)
  }

  it should "not authorise a user when runtime exception occurred" in {
    when(loginService.login(credentials)).thenThrow(new Exceptions.UnexpectedException(
      new ErrorCode("TEE-UNEXPECTED"), new RuntimeException(), "error message"))

    val request =
      """
      {"staffId":"12345678", "password":"password"}
      """

    val response =
      """
        |{
        |  "data":null,
        |  "errors":[{"code":"TEE-UNEXPECTED","message":"error message"}]
        |}
      """.stripMargin

    executePost(request, response, HttpStatus.INTERNAL_SERVER_ERROR)
  }

  def executePostTest(requestBody: String, response: String, httpStatus : HttpStatus) = {
    val httpHeaders = new HttpHeaders()
    httpHeaders.add("X-CORRELATION-ID", "correlationId")
    httpHeaders.add("X-BRANCH-ID", "400621")
    httpHeaders.add("X-MACHINE-ID", "machineId")
    httpHeaders.add("X-WIFI-MAC-ADDRESS", "23:23:12:12")
    httpHeaders.add("X-COUNTRY-CODE", "GBR")

    val mvcResult = mvc.perform(post("/login")
      .contentType(MediaType.APPLICATION_JSON)
      .content(requestBody)
      .headers(httpHeaders))
      .andExpect(request().asyncStarted())
      .andReturn()

    mvc.perform(asyncDispatch(mvcResult))
      .andDo(MockMvcResultHandlers.log())
      .andExpect(status().is(httpStatus.value()))
      .andExpect(MockMvcResultMatchers.content.json(response))
  }

  def executePost(requestBody: String, response: String, httpStatus : HttpStatus) = {
    val httpHeaders = new HttpHeaders()
    httpHeaders.add("X-CORRELATION-ID", "correlationId")
    httpHeaders.add("X-BRANCH-ID", "400621")
    httpHeaders.add("X-MACHINE-ID", "machineId")
    httpHeaders.add("X-WIFI-MAC-ADDRESS", "23:23:12:12")
    httpHeaders.add("X-COUNTRY-CODE", "GBR")

    mvc.perform(post("/login")
      .contentType(MediaType.APPLICATION_JSON)
      .content(requestBody)
      .headers(httpHeaders))
      .andExpect(status().is(httpStatus.value()))
  }

}