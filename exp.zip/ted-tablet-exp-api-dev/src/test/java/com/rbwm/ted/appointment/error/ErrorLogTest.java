/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.error;

import com.rbwm.ted.appointment.error.ErrorLogging.ErrorLog;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 18/05/2017.
 */
public class ErrorLogTest {

    private ErrorLog errorLog = new ErrorLog();

    @Test
    public void returnEmptyStringWhenThereIsNoAttribute() throws Exception {
        assertEquals("", errorLog.toString());
    }

    @Test
    public void returnLogWhenThereIsOneAttributeWithNullValue() throws Exception {
        errorLog.add("Attribute", null);
        assertEquals("Attribute=", errorLog.toString());
    }

    @Test
    public void returnLogWhenThereIsOneAttribute() throws Exception {
        errorLog.add("Attribute", "Value");
        assertEquals("Attribute=Value", errorLog.toString());
    }

    @Test
    public void returnLogWhenThereIsMultipleAttribute() throws Exception {
        errorLog.add("Attribute", "Value").add("Attribute2", "Value2");
        assertEquals("Attribute=Value Attribute2=Value2", errorLog.toString());
    }

    @Test
    public void returnLogWithReplacingDoubleQuotes() throws Exception {
        errorLog.add("Attribute", "Value").add("Attribute2", "Va\'lue2");
        assertEquals("Attribute=Value Attribute2=Va'lue2", errorLog.toString());
    }

    @Test
    public void returnLogWithWrappingValuesWithDoubleQuotesIfThereIsASpaceInValue() throws Exception {
        errorLog.add("Attribute", "Value").add("Attribute2", "Va\'lue2 Value3");
        assertEquals("Attribute=Value Attribute2=\"Va'lue2 Value3\"", errorLog.toString());
    }
}
