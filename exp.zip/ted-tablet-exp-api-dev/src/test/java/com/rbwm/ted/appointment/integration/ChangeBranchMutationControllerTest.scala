/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpMethod, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 28/02/2017.
  */
@WebAppConfiguration
class ChangeBranchMutationControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "update branch in user profile" in {

    val responseFromProcessApi =
      """
        |{
        |   "userId": "43578876",
        |   "lastTimeLogin": 123456789,
        |   "firstLogin": false,
        |   "branchId": "12345"
        |}
      """.stripMargin

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockWithContentAsync("/userProfiles/43578876", responseFromProcessApi, headers, HttpMethod.PUT, "{\"branchId\":\"12345\"}")

    val request =
      """
      {
        "query": "mutation ChangeBranchMutation($input:ChangeBranchInput!){changeBranch(input:$input){clientMutationId userProfile {userId, branchId, lastTimeLogin, firstLogin}}}",
        "variables": {
          "input": {
            "branchId": "12345",
            "clientMutationId": "10"
          }
        }
      }
      """
    val response =
      """
        {
          "data": {
            "changeBranch": {
              "clientMutationId": "10",
              "userProfile": {
                "lastTimeLogin": 123456789,
                "userId": "43578876",
                "firstLogin": false,
                "branchId": "12345"
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

}
