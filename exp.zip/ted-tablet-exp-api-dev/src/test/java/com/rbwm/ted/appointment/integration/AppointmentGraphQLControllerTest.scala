/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.github.tomakehurst.wiremock.client.WireMock
import com.rbwm.ted.appointment.AppointmentGraphQLController
import com.rbwm.ted.telemetry.correlation.CorrelationIdGenerator
import org.springframework.http._
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 23/01/2017.
  */
@WebAppConfiguration
class AppointmentGraphQLControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "return the appointment when requesting by appointmentId" in {

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/appointments/VY8L18W1", "get-appointment-response.json", headers)

    val request =
      """
      {
        "query": "{ted{appointment (appointmentId:\"VY8L18W1\") {appointmentId appointmentStatus branchId dateTime duration topicId topicName topicCategoryId topicCategoryName timezone criticalOverdueOffset overRunOffset noShowDuration attendee{firstName lastName email} conductor{fullName employeeId} }}}",
        "variables": {
          }
        }
      """
    val response =
      """
        {
          "data": {
            "ted": {
              "appointment": {
                "dateTime": 1477465200000,
                "timezone": "Asia/Shanghai",
                "duration": "90",
                "appointmentId": "XEF1532",
                "appointmentStatus": "CHECKED_IN",
                "branchId": "404628",
                "topicId": "Mortgages",
                "topicCategoryId": "Purchase a Property",
                "topicName": "Mortgages",
                "topicCategoryName": "Purchase a Property",
                "attendee": {
                  "firstName": "Jonathan",
                  "lastName": "Talbot",
                  "email": null
                },
                "conductor": {
                  "employeeId": "01747754",
                  "fullName": "MR PIETRO RIZZI"
                }
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

  it should "return the specific error when requesting by incorrect appointmentId" in {
    mockNotFoundGetAppointmentRestTemplate("/appointments/ERRORMCAB")
    val request =
      """
      {
        "query": "{ted{appointment (appointmentId:\"ERRORMCAB\") {appointmentId appointmentStatus branchId dateTime duration topicId topicCategoryId timezone criticalOverdueOffset overRunOffset noShowDuration attendee{firstName lastName email} conductor{fullName employeeId} }}}",
        "variables": {
          }
        }
      """
    val response =
      """
        {
          "data": {
            "ted": {
                "appointment": null
            }
          },
          "errors": [
            {
              "code" : "TEE-GET-APPOINTMENT-NOT-FOUND",
              "message" : "/appointments/ERRORMCAB not found"
            }
          ]
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

  def mockNotFoundGetAppointmentRestTemplate(url : String) = {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)
    headers.add(CorrelationIdGenerator.CORRELATION_ID_HEADER, "test-correlation-id")

    val errorBody =
      """
        |{
        |  "error": {
        |    "code": "TEE-GET-APPOINTMENT-NOT-FOUND",
        |    "message": "No found resource to retrieve appointment"
        |  }
        |}
      """.stripMargin

    WireMock.stubFor(WireMock.get(WireMock.urlPathEqualTo(url))
      .willReturn(WireMock.aResponse
        .withStatus(HttpStatus.NOT_FOUND.value())
        .withHeader("Content-Type", "application/json")
        .withBody(errorBody)))

  }
}
