/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 07/02/2017.
  */
@WebAppConfiguration
class BranchesControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "return all branches" in {

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/countryCode/GBR?search", "branch-list-response.json", headers)

    val request =
      """
      {
        "query": "{ viewer { branches { count pageInfo { hasNextPage } edges { node { id branchId name latitude longitude timezone address { addressLine1 addressLine2 city postcode county countryCode } } } } } }",
        "variables": {
          }
        }
      """
    val response =
      """
        |{
        |	"data": {
        |		"viewer": {
        |			"branches": {
        |				"count": 2,
        |				"pageInfo": {
        |					"hasNextPage": false
        |				},
        |				"edges": [{
        |					"node": {
        |						"id": "QnJhbmNoOjQwMDEyNQ==",
        |						"branchId": "400125",
        |						"name": "Aberdeen",
        |						"latitude": 0.0,
        |						"longitude": 0.0,
        |           "timezone": "Europe/London",
        |						"address": {
        |							"addressLine1": "95-99 Union Street",
        |							"addressLine2": null,
        |							"city": "Aberdeen",
        |							"postcode": "AB11 6BD",
        |							"county": "Scotland",
        |							"countryCode": null
        |						}
        |					}
        |				}, {
        |					"node": {
        |						"id": "QnJhbmNoOjQwMDgwNA==",
        |						"branchId": "400804",
        |						"name": "Abergavenny",
        |						"latitude": 0.0,
        |						"longitude": 0.0,
        |           "timezone": "Europe/London",
        |						"address": {
        |							"addressLine1": "2 Frogmore Street",
        |							"addressLine2": null,
        |							"city": "Abergavenny",
        |							"postcode": "NP7 5AF",
        |							"county": "Monmouthshire",
        |							"countryCode": null
        |						}
        |					}
        |				}]
        |			}
        |		}
        |	}
        |}
      """.stripMargin

    val requestHeaders: HttpHeaders = new HttpHeaders
    requestHeaders.add("X-COUNTRY-CODE", "GBR")
    executePostTest(request, response, HttpStatus.OK, requestHeaders)
  }

  it should "return branch with mac address" in {

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/macAddress/dd:hh:re:43", "branch-response.json", headers)

    val request =
      """
      {
        "query": "{viewer {branch(macAddress: \"dd:hh:re:43\") {name, branchId, latitude, longitude, timezone, address{addressLine1, addressLine2, city, postcode, county, countryCode} }}}",
        "variables": {
          }
        }
      """
    val response =
      """
        | {
        |   "data": {
        |     "viewer": {
        |       "branch": {
        |         "branchId": "400125",
        |         "longitude": 12.093233,
        |         "latitude": -21.223232,
        |         "timezone": "Europe/London",
        |         "name": "Aberdeen",
        |         "address": {
        |           "addressLine1": "95-99 Union Street",
        |           "addressLine2": "address line 2",
        |           "city": "Aberdeen",
        |           "postcode": "AB11 6BD",
        |           "county": "Scotland",
        |           "countryCode": "GBR"
        |         }
        |       }
        |     }
        |   }
        | }
      """.stripMargin

    val requestHeaders = new HttpHeaders
    requestHeaders.add("X-WIFI-MAC-ADDRESS", "dd:hh:re:43")

    executePostTest(request, response, HttpStatus.OK, requestHeaders)
  }

  it should "return branch with id" in {

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/branchId/400125", "branch-response.json", headers)

    val request =
      """
      {
        "query": "{viewer {branch(branchId: \"400125\") {name, branchId, latitude, longitude, timezone, address{addressLine1, addressLine2, city, postcode, county, countryCode} }}}",
        "variables": {
          }
        }
      """
    val response =
      """
        | {
        |   "data": {
        |     "viewer": {
        |       "branch": {
        |         "branchId": "400125",
        |         "longitude": 12.093233,
        |         "latitude": -21.223232,
        |         "timezone": "Europe/London",
        |         "name": "Aberdeen",
        |         "address": {
        |           "addressLine1": "95-99 Union Street",
        |           "addressLine2": "address line 2",
        |           "city": "Aberdeen",
        |           "postcode": "AB11 6BD",
        |           "county": "Scotland",
        |           "countryCode": "GBR"
        |         }
        |       }
        |     }
        |   }
        | }
      """.stripMargin

    val requestHeaders: HttpHeaders = new HttpHeaders
    requestHeaders.add("X-BRANCH-ID", "400125")

    executePostTest(request, response, HttpStatus.OK, requestHeaders)
  }

}
