package com.rbwm.ted.appointment.skillbuilders;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.SkillBuildersConfiguration;
import com.rbwm.ted.appointment.schema.model.VideoSummary;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Collections;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static java.util.Collections.singletonList;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44093684 on 26/01/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class GetSummaryTest {

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private SkillBuildersConfiguration skillBuildersConfiguration;

    private GetSummary getSummary;

    @Before
    public void setUp() {
        skillBuildersConfiguration = new SkillBuildersConfiguration();
        ReflectionTestUtils.setField(skillBuildersConfiguration, "skillbuildersHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(skillBuildersConfiguration, "skillbuildersSummaryUri", "/mi/summary");
        ReflectionTestUtils.setField(skillBuildersConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getSummary = new GetSummary(skillBuildersConfiguration);
    }

    @Test
    public void testGetVideoSummary() throws IOException, URISyntaxException {
        //Given
        stubFor(post(urlPathEqualTo("/mi/summary"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("skillbuilders-summary.json"))));

        //When
        VideoSummary actual = getSummary.get(Collections.emptyMap(), "GBR", singletonList("44090001")).block();

        //Then
        VideoSummary expected = new VideoSummary(3, 1, 8, 5);
        assertEquals(expected, actual);
    }

}
