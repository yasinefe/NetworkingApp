/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import java.net.URL
import java.nio.file.{Files, Paths}

import com.github.tomakehurst.wiremock.client.WireMock
import com.rbwm.ted.appointment.Application
import com.rbwm.ted.appointment.audit.AuditProcessor
import com.rbwm.ted.appointment.authentication.AuthenticationFacade
import com.rbwm.ted.appointment.config.AuditConfiguration
import com.rbwm.ted.appointment.filter.{CorrelationIdFilter, LoggingFilter}
import com.rbwm.ted.appointment.util.FileUtil
import com.rbwm.ted.telemetry.correlation.CorrelationIdGenerator
import com.rbwm.ted.telemetry.logging.RequestLogging
import org.junit.runner.RunWith
import org.mockito.Mockito._
import org.scalatest._
import org.scalatest.junit.JUnitRunner
import org.scalatest.mockito.MockitoSugar
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock
import org.springframework.http.{HttpMethod, _}
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity
import org.springframework.test.context.{ActiveProfiles, TestContextManager, TestPropertySource}
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.test.web.servlet.{MockMvc, ResultActions, ResultHandler}
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.{request => _}
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import org.springframework.test.web.servlet.result.{MockMvcResultHandlers, PrintingResultHandler}
import org.springframework.test.web.servlet.setup.{AbstractMockMvcBuilder, MockMvcBuilders, StandaloneMockMvcBuilder}
import org.springframework.util.concurrent.ListenableFuture
import org.springframework.web.context.WebApplicationContext

/**
  * Created by javierbracerotorres on 22/11/2016.
  */
@RunWith(classOf[JUnitRunner])
@ActiveProfiles(profiles = Array("int-be-test"))
@TestPropertySource(properties = Array[String] {
  "spring.config.location = classpath:config/ted-tablet-exp-api.yaml"
})
@SpringBootTest(webEnvironment = WebEnvironment.MOCK, classes = Array(classOf[Application]))
@AutoConfigureWireMock(port = 9999)
abstract class ControllerTest(controllerClass: Class[_]) extends FlatSpec
  with Matchers
  with MockitoSugar
  with BeforeAndAfter
  with GivenWhenThen {

  behavior of controllerClass.getSimpleName

  var mvc: MockMvc = _

  @Autowired
  val webApplicationContext: WebApplicationContext = null

  @Autowired
  val auditProcessor: AuditProcessor = null

  @Autowired
  val auditConfiguration: AuditConfiguration = null

  @Autowired
  val authenticationFacade: AuthenticationFacade = null

  var testLoggingFilter: TestLoggingFilter = _

  before {
    new TestContextManager(this.getClass).prepareTestInstance(this)

    testLoggingFilter = new TestLoggingFilter(authenticationFacade)

    val mvcBuilder: AbstractMockMvcBuilder[_ <: AbstractMockMvcBuilder[StandaloneMockMvcBuilder]] = MockMvcBuilders
      .webAppContextSetup(webApplicationContext)
      .addFilters(new CorrelationIdFilter, testLoggingFilter)

    val mvcSecurity: AbstractMockMvcBuilder[_ <: AbstractMockMvcBuilder[StandaloneMockMvcBuilder]] = mvcBuilder.apply(springSecurity)

    mvc = mvcSecurity.build

    val response = mock[ListenableFuture[ResponseEntity[String]]]
    when(response.get).thenReturn(new ResponseEntity[String]("", HttpStatus.OK))

    //Catch-all case
    WireMock.configureFor(9999)
    WireMock.stubFor(WireMock.get(WireMock.urlMatching(".*")).atPriority(10).willReturn(WireMock.aResponse().withStatus(404)))
    WireMock.stubFor(WireMock.post(WireMock.urlMatching(".*")).atPriority(10).willReturn(WireMock.aResponse().withStatus(404)))
    WireMock.stubFor(WireMock.put(WireMock.urlMatching(".*")).atPriority(10).willReturn(WireMock.aResponse().withStatus(404)))

    WireMock.stubFor(WireMock.post(WireMock.urlPathEqualTo("/eventSource"))
      .willReturn(WireMock.aResponse
        .withStatus(200)
        .withHeader("Content-Type", "application/json")
        .withBody("")))

    ReflectionTestUtils.setField(auditProcessor, "crudRest", auditConfiguration.auditCRUDRestBuilder("CREATE_AUDIT").build())
  }

  def mockGetWithFileContentAsync(url: String, fileLocation: String, headers: HttpHeaders): Any = {
    if (!headers.containsKey(CorrelationIdGenerator.CORRELATION_ID_HEADER)) {
      headers.add(CorrelationIdGenerator.CORRELATION_ID_HEADER, "test-correlation-id")
    }

    val fileContent: String = FileUtil.getMockData(fileLocation)

    WireMock.stubFor(WireMock.get(WireMock.urlEqualTo(url))
      .willReturn(WireMock.aResponse
        .withStatus(200)
        .withHeader("Content-Type", "application/json")
        .withBody(fileContent)))
  }

  def mockGetWithContentAsync(url: String, content: String, headers: HttpHeaders): Any = {
    if (!headers.containsKey(CorrelationIdGenerator.CORRELATION_ID_HEADER)) {
      headers.add(CorrelationIdGenerator.CORRELATION_ID_HEADER, "test-correlation-id")
    }

    WireMock.stubFor(WireMock.get(WireMock.urlEqualTo(url))
      .willReturn(WireMock.aResponse
        .withStatus(200)
        .withHeader("Content-Type", "application/json")
        .withBody(content)))
  }

  def mockWithContentAsync(url: String, content: String, headers: HttpHeaders, httpMethod: HttpMethod, body: String): Any = {
    if (!headers.containsKey(CorrelationIdGenerator.CORRELATION_ID_HEADER)) {
      headers.add(CorrelationIdGenerator.CORRELATION_ID_HEADER, "test-correlation-id")
    }

    WireMock.stubFor(WireMock.request(httpMethod.name(), WireMock.urlEqualTo(url))
      .withRequestBody(WireMock.equalToJson(body))
      .willReturn(WireMock.aResponse
        .withStatus(200)
        .withHeader("Content-Type", "application/json")
        .withBody(content)))
  }

  def mockWithErrorAsync(url: String, errorCode: Int,  errorBody: String): Any = {
    WireMock.stubFor(WireMock.get(WireMock.urlEqualTo(url))
      .willReturn(WireMock.aResponse
        .withStatus(errorCode)
        .withHeader("Content-Type", "application/json")
        .withBody(errorBody)))
  }

  def executeGetTest(url: String, response: String, httpStatus: HttpStatus, httpHeaders: HttpHeaders = new HttpHeaders()) = {
    mvc.perform(MockMvcRequestBuilders.get(url)
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON))
      .andExpect(status().is(httpStatus.value()))
      .andExpect(content.json(response))
  }

  def executePostTest(request: String, response: String, httpStatus: HttpStatus, httpHeaders: HttpHeaders = new HttpHeaders()) = {
    if (!httpHeaders.containsKey(CorrelationIdGenerator.CORRELATION_ID_HEADER)) {
      httpHeaders.add(CorrelationIdGenerator.CORRELATION_ID_HEADER, "test-correlation-id")
    }
    mvc.perform(MockMvcRequestBuilders.post("/graphql")
      .contentType(MediaType.APPLICATION_JSON)
      .headers(httpHeaders)
      .header("Authorization", "Bearer NDM1Nzg4NzY+WoyxfVHwsDGsKLnD+JaD5w4nheojQhnEz4tBQZjYif0+MTQ5MDExNTgxOQ==")
      .content(request))
      .andExpect(status().is(httpStatus.value()))
      .andExpect(content.json(response))

    executeNotAuthorised(request, httpHeaders)
  }

  def executePost(request: String, httpStatus: HttpStatus, httpHeaders: HttpHeaders = new HttpHeaders()) = {
    if (!httpHeaders.containsKey(CorrelationIdGenerator.CORRELATION_ID_HEADER)) {
      httpHeaders.add(CorrelationIdGenerator.CORRELATION_ID_HEADER, "test-correlation-id")
    }

    mvc.perform(MockMvcRequestBuilders.post("/graphql")
      .headers(httpHeaders)
      .header("Authorization", "Bearer NDM1Nzg4NzY+WoyxfVHwsDGsKLnD+JaD5w4nheojQhnEz4tBQZjYif0+MTQ5MDExNTgxOQ==")
      .contentType(MediaType.APPLICATION_JSON)
      .content(request))
      .andExpect(status().is(httpStatus.value()))

    executeNotAuthorised(request, httpHeaders)
  }

  def executeNotAuthorised(request: String, httpHeaders: HttpHeaders = new HttpHeaders()) = {
    if (!httpHeaders.containsKey(CorrelationIdGenerator.CORRELATION_ID_HEADER)) {
      httpHeaders.add(CorrelationIdGenerator.CORRELATION_ID_HEADER, "test-correlation-id")
    }

    mvc.perform(MockMvcRequestBuilders.post("/graphql")
      .headers(httpHeaders)
      .contentType(MediaType.APPLICATION_JSON)
      .content(request))
      .andExpect(status().is(HttpStatus.FORBIDDEN.value()))
  }

  class TestLoggingFilter(var authenticationFacade: AuthenticationFacade) extends LoggingFilter(authenticationFacade) {

    var requestLogging: TestRequestLogging = _

    override def getRequestLogging: RequestLogging = {
      requestLogging = new TestRequestLogging
      requestLogging
    }
  }

  class TestRequestLogging() extends RequestLogging {

    var key: String = _
    var value: String = _

    override def withKeyValue(key: String, value: String): RequestLogging = {
      super.withKeyValue(key, value)
      this.key = key
      this.value = value
      this
    }
  }

}