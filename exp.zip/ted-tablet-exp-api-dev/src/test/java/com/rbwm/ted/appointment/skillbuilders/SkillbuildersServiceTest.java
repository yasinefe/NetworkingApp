package com.rbwm.ted.appointment.skillbuilders;

import com.rbwm.ted.appointment.api.SkillBuildersServiceApi;
import com.rbwm.ted.appointment.schema.model.Staff;
import com.rbwm.ted.appointment.schema.model.Video;
import com.rbwm.ted.appointment.schema.model.VideoGroup;
import com.rbwm.ted.appointment.schema.model.VideoSummary;
import com.rbwm.ted.appointment.staff.GetAllStaff;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static java.util.Collections.singletonList;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.anyMapOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;

/**
 * Created by 44093684 on 30/01/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class SkillbuildersServiceTest {

    @Mock
    public GetAllStaff getAllStaff;

    @Mock
    private GetSummary getSummary;

    @Mock
    private GetVideos getVideos;

    private SkillBuildersServiceApi skillBuildersServiceApi;

    @Before
    public void setUp() {
        given(getAllStaff.get(eq("400672"))).willReturn(Mono.just(singletonList(
                new Staff("44090001", null, null, null)
        )));

        skillBuildersServiceApi = new SkillbuildersService(getAllStaff, getSummary, getVideos);
    }

    @Test
    public void testGetSummary() {
        //Given
        VideoSummary summary = new VideoSummary(23, 23, 50, 0);
        given(getSummary.get(anyMapOf(String.class, Object.class), eq("GBR"), eq(singletonList("44090001")))).willReturn(Mono.just(summary));

        //When
        VideoSummary actual = skillBuildersServiceApi.getSummary(Collections.emptyMap(), "GBR", "400672").block();

        //Then
        assertEquals(summary, actual);
    }

    @Test
    public void testGetVideos() {
        //Given
        List<Video> videos = singletonList(
                new Video("moid1", "Title #1", Collections.emptySet(), Collections.emptySet(), 0, 0, 0, 0)
        );
        List<VideoGroup> videoGroups = singletonList(new VideoGroup("moid1", 1, videos, 0));
        given(getVideos.get(anyMapOf(String.class, Object.class), eq("MOID"), eq("GBR"), eq(singletonList("44090001")))).willReturn(Mono.just(videoGroups));

        //When
        List<VideoGroup> actual = skillBuildersServiceApi.getVideoGroups(Collections.emptyMap(), "MOID", "GBR", "400672").block();

        //Then
        assertEquals(videoGroups, actual);
    }

}
