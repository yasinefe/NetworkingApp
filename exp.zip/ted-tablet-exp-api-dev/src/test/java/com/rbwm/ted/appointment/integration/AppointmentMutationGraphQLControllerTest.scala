/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.mockito.Mockito._
import org.springframework.http.{HttpEntity, HttpHeaders, _}
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.web.client.{HttpClientErrorException, RestClientException, RestTemplate}


/**
  * Created by 44027117 on 23/01/2017.
  */
@WebAppConfiguration
class AppointmentMutationGraphQLControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "update the status of an appointment" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    val mockRequest = "{\"appointmentStatus\":\"IN_MEETING\"}"

    val mockResponse =
      """
        {
          "appointmentId": "XEF1532"
        }
      """

    mockWithContentAsync("/appointments/XEF1532", mockResponse, headers, HttpMethod.PUT, mockRequest)
    mockGetWithFileContentAsync("/appointments/XEF1532", "get-appointment-response.json", headers)

    val request =
      """
        {
          "query": "mutation ChangeStatusMutation($input:ChangeStatusInput!){changeStatus(input:$input){clientMutationId, appointment {id,appointmentId, appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": "XEF1532",
              "appointmentStatus": "IN_MEETING",
              "clientMutationId": "10"
            }
          }
        }
      """

    val response =
      """
        {
          "data": {
            "changeStatus": {
              "clientMutationId": "10",
              "appointment": {
                "id": "YXBwb2ludG1lbnQ6WEVGMTUzMg==",
                "appointmentId": "XEF1532"
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

  it should "return bad request when trying to update to an incorrect appointment status" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)
    headers.set("X-HDR-Channel-CC", "GB")

    val request =
      """
        {
          "query": "mutation ChangeStatusMutation($input:ChangeStatusInput!){changeStatus(input:$input){clientMutationId, appointment {id,appointmentId, appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": "XEF1532",
              "appointmentStatus": "INVALID",
              "clientMutationId": "10"
            }
          }
        }
      """

    val response =
      """
        {
          "errors": [
            {
              "code": "TEE-INVALID-GRAPHQL"
            }
          ]
        }
      """

    executePostTest(request, response, HttpStatus.BAD_REQUEST)
  }

  it should "check in an appointment" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    val mockRequestToSetProofOfId = "{\"proofOfId\":true}"
    val mockRequestToChangeStatus = "{\"appointmentStatus\":\"CHECKED_IN\"}"

    val mockResponse =
      """
        {
          "appointmentId": "XEF1532"
        }
      """

    mockWithContentAsync("/appointments/XEF1532", mockResponse, headers, HttpMethod.PUT, mockRequestToChangeStatus)
    mockWithContentAsync("/appointments/XEF1532/proofOfId", mockResponse, headers, HttpMethod.PUT, mockRequestToSetProofOfId)
    mockGetWithFileContentAsync("/appointments/XEF1532", "get-appointment-response.json", headers)

    val request =
      """
        {
          "query": "mutation CheckInMutation($input:CheckInInput!){checkIn(input:$input){clientMutationId appointment {id appointmentId proofOfId appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": "XEF1532",
              "proofOfId": true,
              "clientMutationId": "10"
            }
          }
        }
      """

    val response =
      """
        {
          "data": {
            "checkIn": {
              "clientMutationId": "10",
              "appointment": {
                "id": "YXBwb2ludG1lbnQ6WEVGMTUzMg==",
                "appointmentId": "XEF1532",
                "appointmentStatus": "CHECKED_IN"
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

}
