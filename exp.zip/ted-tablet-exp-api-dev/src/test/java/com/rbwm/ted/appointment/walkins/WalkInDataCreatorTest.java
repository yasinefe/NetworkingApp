/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.rbwm.ted.appointment.audit.AuditableAction;
import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.http.HeaderContext;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import com.rbwm.ted.appointment.schema.mutation.WalkInDataCreator;
import graphql.schema.DataFetchingEnvironment;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import static com.rbwm.ted.appointment.model.AppointmentFields.*;
import static com.rbwm.ted.appointment.walkins.WalkInFactory.createWalkIn;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by 44027117 on 18/05/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class WalkInDataCreatorTest {
    WalkInDataCreator walkInDataCreator;

    @Mock
    WalkInService walkInService;

    @Mock
    DataFetchingEnvironment env;

    private GraphQLContext graphQLContext;

    @Before
    public void setUp() {
        walkInDataCreator = new WalkInDataCreator(walkInService);

        Map<String, Object> input = new HashMap<String, Object>() {{
            put("clientMutationId", "11111");
            put(ATTENDEE.val(), new HashMap<>());
            put(TOPIC_ID.val(), "1");
            put(TOPIC_CATEGORY_ID.val(), "2");
            put(PROOF_OF_ID.val(), Boolean.FALSE);
            put(COMMENTS.val(), "This is a test");
            put(BRANCH_ID.val(), "4000");

        }};

        DataFetcherAudit.Builder dataFetcherAuditBuilder = new DataFetcherAudit.Builder();
        graphQLContext = new GraphQLContext(new HeaderContext("4000", "22:33:44", "localhost", "GBR"), dataFetcherAuditBuilder, null, null);

        when(env.getArgument("input")).thenReturn(input);
        when(env.getContext()).thenReturn(graphQLContext);
        when(walkInService.create(input)).thenReturn(Mono.just(createWalkIn()));
    }

    @Test
    public void testCheckDataFetcherAuditContext() {
        walkInDataCreator.walkInCreater.get(env);

        DataFetcherAudit.Builder dataFetcherAuditBuilderExp = new DataFetcherAudit.Builder();
        dataFetcherAuditBuilderExp.withEntityId("58c27df5b649390c13176f13").withAuditAction(AuditableAction.WALKIN_CREATE);
        assertEquals(dataFetcherAuditBuilderExp.toString(), graphQLContext.getDataFetcherAudit().toString());
        assertEquals(dataFetcherAuditBuilderExp.build(),graphQLContext.getDataFetcherAudit().build());
    }

    @Test
    public void testGenerateData() throws ExecutionException, InterruptedException {
        Map<String, Object> walkIn = (Map<String, Object>)walkInDataCreator.walkInCreater.get(env).get();
        assertEquals("{clientMutationId=11111, walkIn={dateTime=1484894200000, branchId=400106, " +
                "attendee={firstName=Peter, lastName=Jones, phoneNumber=07957445933, mobileNumber=020 4444 4444, email=john.smith@email.com}, " +
                "overdueOffset=10, timezone=Europe/London, appointmentStatus=CHECKED_IN, startedAt=1484894200000, topicSubCategoryName=null, " +
                "conductor={fullName=Deborah Smithville, employeeId=44443232}, duration=90, topicCategoryName=Remortgage A Property, " +
                "topicId=Mortgages, appointmentId=58c27df5b649390c13176f13, countryCode=GBR, endedAt=1484894200000, topicCategoryId=Remortgage A Property, " +
                "topicName=Mortgages, id=d2Fsa0luOjU4YzI3ZGY1YjY0OTM5MGMxMzE3NmYxMw==}}", walkIn.toString());
    }
}
