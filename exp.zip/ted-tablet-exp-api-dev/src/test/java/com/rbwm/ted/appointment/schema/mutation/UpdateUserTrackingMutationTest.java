/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.http.HeaderContext;
import com.rbwm.ted.appointment.schema.SchemaTest;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import com.rbwm.ted.appointment.user.Tracking;
import graphql.ExecutionResult;
import org.junit.Test;
import org.springframework.security.core.Authentication;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.model.UserProfileFields.KEY;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by 44052007 on 27/03/2018.
 */
public class UpdateUserTrackingMutationTest extends SchemaTest {

    @Test
    public void testAppointmentMutationCheckedIn() {
        String request = "mutation Track($input:TrackInput!){ track(input:$input){ clientMutationId tracking { key count } viewer {id} }}";

        Authentication authentication = mock(Authentication.class);
        when(authentication.getName()).thenReturn("56789");
        when(authenticationFacade.getAuthentication()).thenReturn(authentication);

        when(userProfileService.track("56789", "tracking_key")).thenReturn(Mono.just(new Tracking("tracking_key", 1L)));

        Map<String, Object> arguments = new HashMap<>();
        arguments.put("input", new HashMap<String, Object>() {
            {
                put(KEY.val(), "tracking_key");
                put("clientMutationId", "10");
            }
        });

        GraphQLContext graphQLContext = new GraphQLContext(new HeaderContext("12345", "macAddress", "machineId", "GBR"), new DataFetcherAudit.Builder(), "56789", "correlationId");
        ExecutionResult executionResult = executeCommandReturnResult(request, graphQLContext, arguments);
        Map<String, Object> result = ((Map<String, Object>)((Map<String, Object>) executionResult.getData()).get("track"));
        assertEquals("10",result.get("clientMutationId"));
        assertEquals("{clientMutationId=10, tracking={key=tracking_key, count=1}, viewer={id=Vmlld2VyOjE=}}", result.toString());
    }

}
