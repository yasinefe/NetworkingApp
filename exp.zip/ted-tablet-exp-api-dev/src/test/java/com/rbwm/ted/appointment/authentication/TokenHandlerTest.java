/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.authentication;

import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.*;

/**
 * Created by 43578876 on 09/02/2017.
 */
public class TokenHandlerTest {


    TokenHandler tokenHandler = new TokenHandler();

    @Test
    public void testValidTokenOk() {
        String header = "Bearer NDM1Nzg4NzY+WoyxfVHwsDGsKLnD+JaD5w4nheojQhnEz4tBQZjYif0+MTQ5MDExNTgxOQ==";
        Optional<String> userId = tokenHandler.parseUserFromToken(header);
        assertEquals(Optional.of("43578876"),userId);
    }

    @Test
    public void testValidHeaderInvalidTokenOk() {
        String header = "Bearer IjEyMTIxMjEyIg==.VyxTPorqUXU11rdcx1vcTMKLGhvbsCLci2UYgmXn8RE=";
        boolean haveError = false;
        try {
            Optional<String> userId = tokenHandler.parseUserFromToken(header);
        }
        catch (java.lang.IllegalArgumentException e) {
            haveError = true;
        }

        assertTrue(haveError);
    }

    @Test
    public void testShortTokenInvalidOk() {
        String header = "Bearer ";
        Optional<String> userId = tokenHandler.parseUserFromToken(header);
        assertEquals(Optional.empty(),userId);
    }

    @Test
    public void testNoBearerInvalidOk() {
        String header = "fdsafdsafdsaf";
        Optional<String> userId = tokenHandler.parseUserFromToken(header);
        assertEquals(Optional.empty(),userId);
    }



}