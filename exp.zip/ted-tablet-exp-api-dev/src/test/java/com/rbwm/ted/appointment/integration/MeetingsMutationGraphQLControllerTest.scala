/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import com.rbwm.ted.appointment.util.FileUtil
import com.rbwm.ted.appointment.util.FileUtil.getMockData
import org.springframework.http.{HttpHeaders, HttpMethod, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 19/01/2017.
  */
@WebAppConfiguration
class MeetingsMutationGraphQLControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  val meeting =
    """
      {
        "status": "UPCOMING",
        "group": "UPCOMING",
        "meetingId": "XCDUNSH",
        "topicId": "topicId",
        "topicName": "topicName",
        "topicCategoryId": "topicCategoryId",
        "topicCategoryName": "topicCategoryName",
        "topicSubCategoryId": "topicSubCategoryId",
        "topicSubCategoryName": "topicSubCategoryName",
        "conductor": {
          "employeeId": "012345678",
          "fullName": "John Walker"
        },
        "bookedFor": "2001-07-04T12:08:56.235-0700",
        "checkedInAt": "2001-07-04T12:08:56.235-0700",
        "startedAt": "2001-07-04T12:08:56.235-0700",
        "endedAt": "2001-07-04T12:08:56.235-0700",
        "duration": 30,
        "isNew": true,
        "isOverdue": true,
        "isOverdueCritical": false,
        "isOverrun": true,
        "isOverrunCritical": false,
        "attendee": {
          "firstName": "Jenny",
          "lastName": "Davis",
          "email": "jenny.davis@mail.com",
          "phoneNumber": "+44 1234 121212",
          "mobileNumber": "+44 1234 121212",
          "gender": "FEMALE"
        },
        "comments": "Mortgage",
        "proofOfId": true,
        "countryCode": "GBR",
        "endedBy": "USER",
        "checklist": ["proofOfId", "proofOfAddress"]
      }
    """.stripMargin

  it should "check in an appointment" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    val mockRequest = """{"meetingStatus":"CHECKED_IN", "proofOfId": true}"""

    mockWithContentAsync("/meetings/XCDUNSH", FileUtil.getMockData("get-meeting-response.json"), headers, HttpMethod.PUT, mockRequest)

    val request =
      """
      {
        "query": "mutation CheckInMeetingMutation($input:CheckInMeetingInput!){checkInMeeting(input:$input) { clientMutationId meeting { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } comments proofOfId countryCode endedBy checklist }}}",
        "variables": {
          "input": {
            "id": "TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==",
            "proofOfId": true,
            "clientMutationId": "10"
          }
        }
      }
      """
    val response =
      s"""
        {
          "data" : {
            "checkInMeeting": {
              "clientMutationId" : "10",
              "meeting": ${meeting}
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, headers)
  }

  it should "change meeting status for appointment" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    val mockRequest = """{"meetingStatus":"IN_MEETING"}"""

    mockWithContentAsync("/meetings/XCDUNSH", FileUtil.getMockData("get-meeting-response.json"), headers, HttpMethod.PUT, mockRequest)

    val request =
      """
      {
        "query": "mutation ChangeMeetingStatusMutation($input:ChangeMeetingStatusInput!){changeMeetingStatus(input:$input) { clientMutationId meeting { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } comments proofOfId countryCode endedBy checklist }}}",
        "variables": {
          "input": {
            "id": "TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==",
            "meetingStatus": "IN_MEETING",
            "clientMutationId": "10"
          }
        }
      }
      """
    val response =
      s"""
        {
          "data" : {
            "changeMeetingStatus": {
              "clientMutationId" : "10",
              "meeting": ${meeting}
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, headers)
  }

  it should "change meeting status for walkIn" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    val mockRequest = """{"meetingStatus":"IN_MEETING"}"""

    mockWithContentAsync("/meetings/XCDUNSH", FileUtil.getMockData("get-meeting-response.json"), headers, HttpMethod.PUT, mockRequest)

    val request =
      """
      {
        "query": "mutation ChangeMeetingStatusMutation($input:ChangeMeetingStatusInput!){changeMeetingStatus(input:$input) { clientMutationId meeting { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } comments proofOfId countryCode endedBy checklist }}}",
        "variables": {
          "input": {
            "id": "TWVldGluZzpXQUxLX0lOUy9YQ0RVTlNI",
            "meetingStatus": "IN_MEETING",
            "clientMutationId": "10"
          }
        }
      }
      """
    val response =
      s"""
        {
          "data" : {
            "changeMeetingStatus": {
              "clientMutationId" : "10",
              "meeting": ${meeting}
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, headers)
  }

  it should "create meeting for walkIn" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)
    headers.add("X-BRANCH-ID", "400123")

    val mockRequest = getMockData("create-meeting-request.json")

    mockWithContentAsync("/meetings", FileUtil.getMockData("get-meeting-response.json"), headers, HttpMethod.POST, mockRequest)

    val request =
      """
      {
        "query": "mutation CreateMeetingMutation($input:CreateMeetingInput!){createMeeting(input:$input) { clientMutationId meeting { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } comments proofOfId countryCode endedBy checklist }}}",
        "variables": {
          "input": {
            "firstName": "firstName",
            "lastName": "lastName",
            "gender": "FEMALE",
            "topicId": "topicId",
            "topicCategoryId": "topicCategoryId",
            "topicSubCategoryId": "topicSubCategoryId",
            "comments": "comments",
            "proofOfId": true,
            "clientMutationId": "10"
          }
        }
      }
      """
    val response =
      s"""
        {
          "data" : {
            "createMeeting": {
              "clientMutationId" : "10",
              "meeting": ${meeting}
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, headers)
  }

}
