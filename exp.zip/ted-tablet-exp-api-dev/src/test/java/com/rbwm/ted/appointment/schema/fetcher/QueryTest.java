/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.authorisation.Authorisation;
import com.rbwm.ted.appointment.authorisation.CrudPermission;
import com.rbwm.ted.appointment.http.HeaderContext;
import com.rbwm.ted.appointment.model.*;
import com.rbwm.ted.appointment.news.NewsArticle;
import com.rbwm.ted.appointment.schema.SchemaTest;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import com.rbwm.ted.appointment.schema.model.*;
import com.rbwm.ted.appointment.user.Tracking;
import com.rbwm.ted.appointment.user.UserProfile;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.introspection.IntrospectionQuery;
import org.joda.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Stream;

import static com.rbwm.ted.appointment.meetings.MeetingFactory.createMeeting;
import static com.rbwm.ted.appointment.model.AppointmentFields.*;
import static com.rbwm.ted.appointment.model.AppointmentStatus.UPCOMING;
import static com.rbwm.ted.appointment.model.Role.ADMIN;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static java.util.stream.Collectors.toSet;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

/**
 * Created by 43578876 on 09/11/2016.
 */
public class QueryTest extends SchemaTest {

    protected GraphQLContext graphQLContext;

    @Before
    public void setUpQuery() {
        prepareBranch();
        prepareAppointment();
        prepareUserProfile();
        prepareUserTrackings();
        prepareAuthorisation();
        prepareWalkInSummary();
        prepareWalkInStats();
        prepareWalkInList();
        prepareStaff();
        prepareMeetingGroups();
        prepareSkillbuildersVideos();
        prepareSkillBuildersSummary();
        prepareNewsArticles();
        prepareMeetings();
        prepareMeetingsStats();

        graphQLContext = new GraphQLContext(new HeaderContext("400706", "dd:hh:re:43", "someonesTablet", "GBR"), new DataFetcherAudit.Builder(), "44023445", null);
    }

    private void prepareBranch() {
        Address address = new Address("address line 1", "address line 2", "London", "W1 NT2", "Waterloo", "GBR");
        Branch branch = new Branch("400706", "Holborn Branch", 11.234d, -12.234d, "Europe/London", address);
        when(branchesRestDataService.getBranches("GBR", null)).thenReturn(just(singletonList(branch)));
        when(branchesRestDataService.getBranches("GBR", "Holborn")).thenReturn(just(singletonList(branch)));
        when(branchesRestDataService.getBranchByMacAddress("dd:hh:re:43")).thenReturn(just(branch));
        when(branchesRestDataService.getBranchById("400706")).thenReturn(just(branch));
    }

    private void prepareAppointment() {
        Map<String, Object> appointment = new HashMap<>();
        appointment.put("id", "YXBwb2ludG1lbnQ6MTIzNA==");
        appointment.put("appointmentId", "1234");
        appointment.put(AppointmentFields.BRANCH_ID.val(), "400706");
        appointment.put(APPOINTMENT_STATUS.val(), UPCOMING.getCode());
        appointment.put(DURATION.val(), 20);
        appointment.put(CRITICAL_OVERDUE_OFFSET.val(), 10);
        appointment.put(IS_NOSHOW.val(), true);
        appointment.put("dateTime", new LocalDateTime(2017, 6, 6, 6, 6).toDateTime().getMillis());
        appointment.put("startedAt", new LocalDateTime(2017, 7, 6, 6, 6).toDateTime().getMillis());
        appointment.put(CHECKLIST.val(), Stream.of("proofOfId", "proofOfAddress").collect(toSet()));

        Map<String, Object> conductor = new HashMap<>();
        conductor.put("employeeId", "44052008");
        conductor.put("fullName", "Jack Reacher");

        appointment.put("conductor", conductor);

        Map<String, Object> summary = new HashMap<>();
        summary.put(COUNT.val(), 23);
        summary.put(APPOINTMENT_STATUS.val(), UPCOMING.getCode());
        List<Map<String, Object>> appointmentSummary = asList(summary);

        when(appointmentBookingService.getAppointmentSummary("400706", new HashSet(asList(UPCOMING.getCode())))).thenReturn(just(appointmentSummary));

        Map<String, Object> stats = new HashMap<>();
        stats.put("inNextHour", 17);

        Map<String, Object> appointmentList = new HashMap<>();
        appointmentList.put("list", asList(appointment));
        appointmentList.put("summary", appointmentSummary);
        appointmentList.put("stats", stats);

        Map<String, Object> groups = new HashMap<>();
        groups.put("nextBusinessDay", asList(appointment));

        appointmentList.put("groups", groups);

        when(appointmentBookingService.getAppointmentList("400706", AppointmentStatus.UPCOMING)).thenReturn(just(appointmentList));
        when(appointmentBookingService.getAppointmentList("400706", null)).thenReturn(just(appointmentList));
        when(appointmentBookingService.getAppointment("1234")).thenReturn(just(appointment));
    }

    private void prepareUserProfile() {
        UserProfile userProfile = new UserProfile("44023445", false, 123456L, "Javier",
                "Torres", "400706", ADMIN);
        when(userProfileService.getUserProfile("44023445")).thenReturn(just(userProfile));
    }

    private void prepareUserTrackings() {
        when(userProfileService.getTrackings("44023445")).thenReturn(just(Arrays.asList(new Tracking("tracking_key", 13L))));
    }

    private void prepareAuthorisation() {
        CrudPermission crudPermission = new CrudPermission(true, false, true, false);
        Authorisation authorisation = new Authorisation(crudPermission, crudPermission, crudPermission, crudPermission, crudPermission);
        when(userProfileService.getAuthorisation(Role.ADMIN, "44023445", "400706", "GBR")).thenReturn(just(authorisation));
    }

    private void prepareWalkInStats() {
        Map<String, Object> walkInStats = new HashMap<>();
        walkInStats.put("totalForToday", 20);
        walkInStats.put("averageWaitingTime", 15);
        walkInStats.put("averageWaitingTimeLastBusinessDay", 5);
        when(walkInService.getStats("400706")).thenReturn(just(walkInStats));
    }

    private void prepareWalkInSummary() {
        Map<String, Object> summary = new HashMap<>();
        summary.put(COUNT.val(), 23);
        summary.put(APPOINTMENT_STATUS.val(), UPCOMING.getCode());
        List<Map<String, Object>> walkInSummary = asList(summary);
        when(walkInService.getStatusSummary("400706")).thenReturn(just(walkInSummary));
    }


    private void prepareWalkInList() {
        Map<String, Object> summary = new HashMap<>();
        summary.put(COUNT.val(), 23);
        summary.put(APPOINTMENT_STATUS.val(), UPCOMING.getCode());
        List<Map<String, Object>> walkInSummary = asList(summary);

        Map<String, Object> walkIn = new HashMap<>();
        walkIn.put("id", "d2Fsa0luOjEyMzQ=");
        walkIn.put("appointmentId", "1234");
        walkIn.put(BRANCH_ID.val(), "400706");
        walkIn.put(APPOINTMENT_STATUS.val(), UPCOMING.getCode());
        walkIn.put(DURATION.val(), 20);
        walkIn.put("dateTime", new LocalDateTime(2017, 6, 6, 6, 6).toDateTime().getMillis());
        walkIn.put("startedAt", new LocalDateTime(2017, 7, 6, 6, 6).toDateTime().getMillis());
        walkIn.put("timezone", "Europe/London");
        walkIn.put("countryCode", "GBR");

        HashMap<String, Object> walkInList = new HashMap<String, Object>() {{
            put("list", asList(walkIn));
            put("summary", walkInSummary);
        }};

        when(walkInService.getWalkInList("400706")).thenReturn(just(walkInList));
    }

    private void prepareStaff() {
        Staff tom = new Staff("44012345", "Tom", "Hanks", "http://photos.global.hsbc/casual/square/4401/44012345.jpg");
        Staff john = new Staff("44012346", "John", "Silver", "http://photos.global.hsbc/casual/square/4401/44012346.jpg");

        when(staffService.getAllStaff("400706")).thenReturn(just(asList(tom, john)));
        when(staffService.getStaff("44012345")).thenReturn(just(tom));
        when(staffService.getStaff("44012346")).thenReturn(just(john));
    }

    private void prepareMeetingGroups() {
        List<MeetingsGroup> groupByTopicCategories = asList(
                new MeetingsGroup("Other", 8, 2),
                new MeetingsGroup("Payments", 8, null),
                new MeetingsGroup("Bereavement", 10, 15),
                new MeetingsGroup("Insurance", 13, 1)
        );

        List<MeetingsGroup> groupByTopicSubCategories = asList(
                new MeetingsGroup("Open Account", 1, null),
                new MeetingsGroup("Open Business Acc", 2, null),
                new MeetingsGroup("Apply Life insure", 10, 10),
                new MeetingsGroup("Close Account", 13, 20),
                new MeetingsGroup("Bill Payment", 2, null)
        );

        List<MeetingsGroup> groupByStatus = asList(
                new MeetingsGroup("COMPLETED", 3, 20),
                new MeetingsGroup("IN_MEETING", 2, null),
                new MeetingsGroup("CANCELLED", 1, null)
        );

        when(meetingsGroupServiceApi.get(anyMapOf(String.class, Object.class), any())).thenReturn(just(emptyList()));
        when(meetingsGroupServiceApi.get(anyMapOf(String.class, Object.class), eq("TOPIC_CATEGORY"))).thenReturn(just(groupByTopicCategories));
        when(meetingsGroupServiceApi.get(anyMapOf(String.class, Object.class), eq("TOPIC_SUB_CATEGORY"))).thenReturn(just(groupByTopicSubCategories));
        when(meetingsGroupServiceApi.get(anyMapOf(String.class, Object.class), eq("STATUS"))).thenReturn(just(groupByStatus));


        List<MeetingsGroup> appointmentGroupByStatus = asList(
                new MeetingsGroup("NOSHOW", 10, null),
                new MeetingsGroup("CANCELLED", 3, null),
                new MeetingsGroup("COMPLETED", 4, 20)
        );

        List<MeetingsGroup> appointmentGroupByOverdue = singletonList(
                new MeetingsGroup(null, 10, null)
        );

        List<MeetingsGroup> appointmentGroupByOverdueCritical = singletonList(
                new MeetingsGroup(null, 1, null)
        );

        List<MeetingsGroup> appointmentGroupByOverrun = singletonList(
                new MeetingsGroup(null, 3, 50)
        );

        List<MeetingsGroup> appointmentGroupByOverrunCritical = singletonList(
                new MeetingsGroup(null, 1, 60)
        );

        List<MeetingsGroup> groupBy60MinuteTimeInterval = asList(
                new MeetingsGroup("09:00:00", 1, 3),
                new MeetingsGroup("10:00:00", 5, 0),
                new MeetingsGroup("11:00:00", 20, 0),
                new MeetingsGroup("12:00:00", 2, 1),
                new MeetingsGroup("13:00:00", 1, 0)
        );

        List<MeetingsGroup> groupByNone = singletonList(
                new MeetingsGroup(null, 99, 60)
        );

        Map<String, Object> appointmentsFilter = new HashMap<>();
        appointmentsFilter.put("meetingType", "APPOINTMENTS");
        when(meetingsGroupServiceApi.get(eq(appointmentsFilter), eq("STATUS"))).thenReturn(just(appointmentGroupByStatus));
        when(meetingsGroupServiceApi.get(eq(appointmentsFilter), eq("CHECKED_IN_AT__MINUTE__NEAREST_60"))).thenReturn(just(groupBy60MinuteTimeInterval));
        when(meetingsGroupServiceApi.get(eq(appointmentsFilter), eq(null))).thenReturn(just(groupByNone));

        Map<String, Object> overdueFilter = new HashMap<>();
        overdueFilter.put("meetingType", "APPOINTMENTS");
        overdueFilter.put("isOverdue", true);
        when(meetingsGroupServiceApi.get(eq(overdueFilter), eq(null))).thenReturn(just(appointmentGroupByOverdue));

        Map<String, Object> overdueCriticalFilter = new HashMap<>();
        overdueCriticalFilter.put("meetingType", "APPOINTMENTS");
        overdueCriticalFilter.put("isOverdueCritical", true);
        when(meetingsGroupServiceApi.get(eq(overdueCriticalFilter), eq(null))).thenReturn(just(appointmentGroupByOverdueCritical));

        Map<String, Object> overrunFilter = new HashMap<>();
        overrunFilter.put("meetingType", "APPOINTMENTS");
        overrunFilter.put("isOverrun", true);
        when(meetingsGroupServiceApi.get(eq(overrunFilter), eq(null))).thenReturn(just(appointmentGroupByOverrun));

        Map<String, Object> overrunCriticalFilter = new HashMap<>();
        overrunCriticalFilter.put("meetingType", "APPOINTMENTS");
        overrunCriticalFilter.put("isOverrunCritical", true);
        when(meetingsGroupServiceApi.get(eq(overrunCriticalFilter), eq(null))).thenReturn(just(appointmentGroupByOverrunCritical));
    }

    private void prepareSkillbuildersVideos() {
        Video video = new Video("moid#1", "Title #1", Stream.of("Category1").collect(toSet()), Stream.of("SubCategory1", "SubCategory2").collect(toSet()), 23, 5, 1, 8);
        Video video2 = new Video("moid#2", "Title #2", Stream.of("Category2").collect(toSet()), Stream.of("SubCategory3").collect(toSet()), 23, 5, 20, 8);
        Video video3 = new Video("moid#3", "Title #3", Stream.of("Category2").collect(toSet()), Stream.of("SubCategory4").collect(toSet()), 50, 5, 30, 8);
        List<VideoGroup> groupByCategoryResults = asList(
                new VideoGroup("Category1", 1, singletonList(video), 23),
                new VideoGroup("Category2", 2, asList(video2, video3), 73)
        );
        when(skillBuildersService.getVideoGroups(anyMapOf(String.class, Object.class), eq("VIDEO_CATEGORY"), anyString(), anyString())).thenReturn(just(groupByCategoryResults));

        List<VideoGroup> groupByMoidResults = asList(
                new VideoGroup("moid#1", 1, singletonList(video), 23),
                new VideoGroup("moid#2", 1, singletonList(video2), 23),
                new VideoGroup("moid#3", 1, singletonList(video3), 23)
        );
        when(skillBuildersService.getVideoGroups(anyMapOf(String.class, Object.class), eq("MOID"), anyString(), anyString())).thenReturn(just(groupByMoidResults));

        List<VideoGroup> noGroupByResults = singletonList(
                new VideoGroup("ALL", 3, asList(video, video2, video3), 23)
        );
        when(skillBuildersService.getVideoGroups(anyMapOf(String.class, Object.class), eq(null), anyString(), anyString())).thenReturn(just(noGroupByResults));
    }

    private void prepareSkillBuildersSummary() {
        VideoSummary summary = new VideoSummary(10, 40, 80, 50);
        when(skillBuildersService.getSummary(anyMapOf(String.class, Object.class), anyString(), anyString())).thenReturn(just(summary));
    }

    private void prepareNewsArticles() {
        NewsArticle mandatoryNewsArticle = new NewsArticle("Feed title mandatory", "http://news/feed/mandatory", "Group News",
                "Feed description mandatory", 1234567890L, true);
        NewsArticle newsArticle = new NewsArticle("Feed title", "http://news/feed", "Group News",
                "Feed description", 1234567891L, false);

        when(newsFeedService.getNewsFeed()).thenReturn(just(asList(mandatoryNewsArticle, newsArticle)));
    }

    private void prepareMeetings() {
        Map<String, Object> meeting = createMeeting();

        when(meetingService.getMeetings("400426", MeetingStatus.UPCOMING, MeetingGroupType.UPCOMING, MeetingType.APPOINTMENTS)).thenReturn(Mono.just(singletonList(meeting)));
        when(meetingService.getNextWorkingDayMeetings("400426", MeetingStatus.UPCOMING, MeetingGroupType.UPCOMING)).thenReturn(Mono.just(singletonList(meeting)));
        when(meetingService.getMeeting("APPOINTMENTS/XCDUNSH")).thenReturn(Mono.just(meeting));
    }

    private void prepareMeetingsStats() {
        Map<String, Object> meetingStats = new HashMap<>();
        meetingStats.put("averageWaitingTime", 1);
        meetingStats.put("averageWaitingTimeLastWorkingDay", 2);
        meetingStats.put("averageMeetingLength", 3);
        meetingStats.put("inNextHour", 4);

        when(meetingService.getMeetingStats("400426")).thenReturn(Mono.just(meetingStats));
    }

    protected Map<String, Object> executeCommand(String command) {
        return executeCommandReturnResult(command).getData();
    }

    protected ExecutionResult executeCommandReturnResult(String command) {
        return executeCommandReturnResult(command, graphQLContext, null);
    }

    @Test
    public void runIntrospectionQueryOnAppointmentSchema() {
        Map<String, Object> result = GraphQL.newGraphQL(schema.getSchema()).build()
                .execute(IntrospectionQuery.INTROSPECTION_QUERY)
                .getData();

        assertTrue(result.containsKey("__schema"));
    }

}