/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AppointmentBookingConfiguration;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 30/04/2018.
 */
public class GetAppointmentMeetingTest {

    private static final String MEETING_ID = "400219";

    private GetAppointmentMeeting getAppointmentMeeting;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AppointmentBookingConfiguration appointmentBookingConfiguration = new AppointmentBookingConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "appointmentsHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "meetingsUri", "/meetings");
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getAppointmentMeeting = new GetAppointmentMeeting(appointmentBookingConfiguration, new ReactiveResponseHandler<>());
    }

    @Test
    public void testGetAppointmentMeeting() throws Exception {
        stubFor(get(urlPathEqualTo("/meetings/" + MEETING_ID))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-meeting-response.json"))));

        Map<String, Object> appointment = getAppointmentMeeting.getAppointment(MEETING_ID).block();
        validateResponse(appointment);
    }

    private void validateResponse(Map<String, Object> appointment) {
        assertEquals("TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==", appointment.get("id"));
        assertEquals(30, appointment.get("duration"));
        assertEquals("APPOINTMENTS", appointment.get("type"));
    }
}