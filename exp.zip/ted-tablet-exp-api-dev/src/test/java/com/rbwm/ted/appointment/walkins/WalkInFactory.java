package com.rbwm.ted.appointment.walkins;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.util.FileUtil.getMockData;

/**
 * Created by 44052007 on 01/03/2018.
 */
public class WalkInFactory {

    public static Map<String, Object> createWalkIn() {
        Map<String, Object> walkIn = new HashMap<>();
        walkIn.put("appointmentId", "58c27df5b649390c13176f13");
        walkIn.put("appointmentStatus", "CHECKED_IN");
        walkIn.put("duration", 90L);
        walkIn.put("overdueOffset", 10L);
        walkIn.put("branchId", "400106");

        Map<String, Object> attendee = new HashMap<>();
        attendee.put("firstName", "Peter");
        attendee.put("lastName", "Jones");
        attendee.put("email", "john.smith@email.com");
        attendee.put("phoneNumber", "07957445933");
        attendee.put("mobileNumber", "020 4444 4444");

        walkIn.put("attendee", attendee);

        Map<String, Object> conductor = new HashMap<>();
        conductor.put("employeeId", "44443232");
        conductor.put("fullName", "Deborah Smithville");

        walkIn.put("conductor", conductor);
        walkIn.put("timezone", "Europe/London");
        walkIn.put("countryCode", "GBR");
        walkIn.put("id", "d2Fsa0luOjU4YzI3ZGY1YjY0OTM5MGMxMzE3NmYxMw==");
        walkIn.put("dateTime", 1484894200000L);
        walkIn.put("startedAt", 1484894200000L);
        walkIn.put("topicId", "Mortgages");
        walkIn.put("topicCategoryId", "Remortgage A Property");
        walkIn.put("topicName", "Mortgages");
        walkIn.put("topicCategoryName", "Remortgage A Property");
        walkIn.put("topicSubCategoryName", null);
        walkIn.put("endedAt", 1484894200000L);

        return walkIn;
    }

    public static String getWalkInResponse() throws IOException, URISyntaxException {
        return getMockData("walkin-response.json");
    }

}
