/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema;

import com.rbwm.ted.appointment.api.*;
import com.rbwm.ted.appointment.authentication.AuthenticationFacadeApi;
import com.rbwm.ted.appointment.branch.BranchesRestDataService;
import com.rbwm.ted.appointment.category.ProductCategoryService;
import com.rbwm.ted.appointment.meetings.MeetingService;
import com.rbwm.ted.appointment.news.NewsFeedService;
import com.rbwm.ted.appointment.schema.fetcher.*;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import com.rbwm.ted.appointment.schema.graphql.SchemaContext;
import com.rbwm.ted.appointment.schema.mutation.*;
import com.rbwm.ted.appointment.schema.wiring.*;
import com.rbwm.ted.appointment.user.UserProfileService;
import graphql.ExecutionInput;
import graphql.ExecutionResult;
import graphql.GraphQL;
import org.junit.Before;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;

/**
 * Created by 44027117 on 13/03/2017.
 */
public class SchemaTest {

    protected AppointmentSchema schema;

    @Mock
    protected AppointmentBookingServiceApi appointmentBookingService;

    @Mock
    protected BranchesRestDataService branchesRestDataService;

    @Mock
    protected WalkInServiceApi walkInService;

    @Mock
    protected ProductCategoryService productCategoryService;

    @Mock
    protected UserProfileService userProfileService;

    @Mock
    protected NewsFeedService newsFeedService;

    @Mock
    protected AuthenticationFacadeApi authenticationFacade;

    @Mock
    protected StaffServiceApi staffService;

    @Mock
    protected MeetingsGroupServiceApi meetingsGroupServiceApi;

    @Mock
    protected SkillBuildersServiceApi skillBuildersService;

    @Mock
    protected MeetingService meetingService;

    @Before
    public void setUpSchema() {
        MockitoAnnotations.initMocks(this);
        SchemaContext schemaContext = new SchemaContext();

        RootDataFetcher rootDataFetcher = new RootDataFetcher(schemaContext);
        WalkInDataUpdater walkInDataUpdater = new WalkInDataUpdater(walkInService);
        WalkInDataCreator walkInDataCreator = new WalkInDataCreator(walkInService);
        UserProfileBranchDataUpdater userProfileBranchDataUpdater = new UserProfileBranchDataUpdater(userProfileService);
        AppointmentDataFetcher appointmentDataFetcher = new AppointmentDataFetcher(appointmentBookingService);
        AppointmentDataUpdater appointmentDataUpdater = new AppointmentDataUpdater(appointmentBookingService);
        BranchesDataFetcher branchesDataFetcher = new BranchesDataFetcher(branchesRestDataService);
        WalkInDataFetcher walkInDataFetcher = new WalkInDataFetcher(walkInService);
        UserProfileDataFetcher userProfileDataFetcher = new UserProfileDataFetcher(userProfileService);
        ProductCategoryDataFetcher productCategoryDataFetcher = new ProductCategoryDataFetcher(productCategoryService);
        NewsDataFetcher newsDataFetcher = new NewsDataFetcher(newsFeedService);
        StaffDataFetcher staffDataFetcher = new StaffDataFetcher(staffService);
        AuthorisationDataFetcher authorisationDataFetcher = new AuthorisationDataFetcher(userProfileService);
        SkillbuildersDataFetcher skillBuildersDataFetcher = new SkillbuildersDataFetcher(skillBuildersService);
        MeetingsDataFetcher meetingsDataFetcher = new MeetingsDataFetcher(meetingsGroupServiceApi, meetingService);
        UserProfileTrackingUpdater userProfileTrackingUpdater = new UserProfileTrackingUpdater(userProfileService);
        MeetingUpdater meetingUpdater = new MeetingUpdater(meetingService);
        MeetingCreator meetingCreator = new MeetingCreator(meetingService);

        NodeDataFetcher nodeDataFetcher = new NodeDataFetcher(appointmentDataFetcher, userProfileDataFetcher, walkInDataFetcher,
                staffDataFetcher, branchesDataFetcher, meetingsDataFetcher);

        AppointmentTypeWiring appointmentTypeWiring = new AppointmentTypeWiring(rootDataFetcher);
        BranchTypeWiring branchTypeWiring = new BranchTypeWiring(rootDataFetcher, appointmentDataFetcher, walkInDataFetcher);
        MutationTypeWiring mutationTypeWiring = new MutationTypeWiring(rootDataFetcher, walkInDataFetcher, appointmentDataUpdater,
                userProfileBranchDataUpdater, walkInDataUpdater, walkInDataCreator, appointmentDataFetcher, userProfileTrackingUpdater,
                meetingUpdater, meetingCreator);
        RootTypeWiring rootTypeWiring = new RootTypeWiring(nodeDataFetcher, rootDataFetcher, appointmentDataFetcher,
                newsDataFetcher, productCategoryDataFetcher, walkInDataFetcher, branchesDataFetcher, staffDataFetcher,
                userProfileDataFetcher, skillBuildersDataFetcher, meetingsDataFetcher);
        UserProfileTypeWiring userProfileTypeWiring = new UserProfileTypeWiring(rootDataFetcher, branchesDataFetcher,
                authorisationDataFetcher, userProfileDataFetcher);
        WalkInTypeWiring walkInTypeWiring = new WalkInTypeWiring(rootDataFetcher);
        SkillbuildersTypeWiring skillBuildersTypeWiring = new SkillbuildersTypeWiring(rootDataFetcher, skillBuildersDataFetcher);
        NewsTypeWiring newsTypeWiring = new NewsTypeWiring(rootDataFetcher);
        MeetingTypeWiring meetingTypeWiring = new MeetingTypeWiring(rootDataFetcher, meetingsDataFetcher);

        schema = new AppointmentSchema(schemaContext, Arrays.asList(appointmentTypeWiring, branchTypeWiring,
                mutationTypeWiring, rootTypeWiring, userProfileTypeWiring,
                walkInTypeWiring, skillBuildersTypeWiring, newsTypeWiring, meetingTypeWiring));
    }

    public Function<AppointmentSchema, GraphQL> graphQL = schema -> GraphQL.newGraphQL(schema.getSchema()).build();

    protected ExecutionResult executeCommandReturnResult(String command, GraphQLContext graphQLContext, Map<String, Object> variables) {
        System.out.println("Command   : " + command);
        System.out.println("Context   : " + graphQLContext);
        System.out.println("Variables : " + variables);
        ExecutionResult executionResult = graphQL.apply(schema).execute(new ExecutionInput.Builder().query(command).context(graphQLContext).variables(variables));
        System.out.println("Data      : " + executionResult.getData());
        System.out.println("Errors    : " + executionResult.getErrors());
        return executionResult;
    }
}
