/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Created by 43578876 on 09/11/2016.
 */
public class AppointmentQueryTest extends QueryTest {

    @Test
    public void testGetAppointment() {
        Map<String, Object> result = executeCommand("{ted{appointment(appointmentId:\"1234\") {appointmentId dateTime duration isNoShow startedAt checklist proofOfId conductor {employeeId fullName}}}}");

        assertEquals("{appointment={appointmentId=1234, dateTime=1496725560000, duration=20, isNoShow=true, startedAt=1499317560000, checklist=[proofOfId, proofOfAddress], proofOfId=null, conductor={employeeId=44052008, fullName=Jack Reacher}}}", result.get("ted").toString());
        assertEquals("APPOINTMENT", graphQLContext.getDataFetcherAudit().build().type);
        assertEquals("APPOINTMENT_RETRIEVE", graphQLContext.getDataFetcherAudit().build().operationName);
        assertEquals("1234", graphQLContext.getDataFetcherAudit().build().entityId);
        assertEquals("1234", ((Map<String, Object>)graphQLContext.getDataFetcherAudit().build().entity).get("appointmentId"));
    }

    @Test
    public void testGetAppointmentViaNodeQuery() {
        Map<String, Object> result = executeCommand("{node (id:\"YXBwb2ludG1lbnQ6MTIzNA==\") { id ... on appointment {appointmentId dateTime duration}}}");

        assertEquals("{id=YXBwb2ludG1lbnQ6MTIzNA==, appointmentId=1234, dateTime=1496725560000, duration=20}", result.get("node").toString());
        assertEquals("APPOINTMENT", graphQLContext.getDataFetcherAudit().build().type);
        assertEquals("APPOINTMENT_RETRIEVE", graphQLContext.getDataFetcherAudit().build().operationName);
        assertEquals("1234", graphQLContext.getDataFetcherAudit().build().entityId);
        assertEquals("1234", ((Map<String, Object>)graphQLContext.getDataFetcherAudit().build().entity).get("appointmentId"));
    }

    @Test
    public void testGetAppointmentListViaNodeQuery() {
        Map<String, Object> result = executeCommand("{node (id:\"YXBwb2ludG1lbnRMaXN0OjQwMDcwNi1VUENPTUlORw==\") { id ... on appointmentList { list { id } summary { id }}}}");

        assertEquals("{id=YXBwb2ludG1lbnRMaXN0OjQwMDcwNi1VUENPTUlORw==, list=[{id=YXBwb2ludG1lbnQ6MTIzNA==}], summary=[{id=YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDA3MDYtVVBDT01JTkc=}]}", result.get("node").toString());
        assertEquals("APPOINTMENT", graphQLContext.getDataFetcherAudit().build().type);
        assertEquals("APPOINTMENT_LIST_AND_SUMMARY", graphQLContext.getDataFetcherAudit().build().operationName);
    }

    @Test
    public void testGetAppointmentListSummaryViaNodeQuery() {
        Map<String, Object> result = executeCommand("{node (id:\"YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDA3MDYtVVBDT01JTkc=\") { id ... on appointmentListSummary { id count appointmentStatus }}}");

        assertEquals("{id=YXBwb2ludG1lbnRMaXN0U3VtbWFyeTo0MDA3MDYtVVBDT01JTkc=, count=23, appointmentStatus=UPCOMING}", result.get("node").toString());
    }

}