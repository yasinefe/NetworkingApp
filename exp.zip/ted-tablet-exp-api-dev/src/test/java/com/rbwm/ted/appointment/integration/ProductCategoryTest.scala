/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 30/03/2017.
  */
@WebAppConfiguration
class ProductCategoryTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "return the list of WalkIn" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)
    headers.add("X-COUNTRY-CODE", "GBR")

    mockGetWithFileContentAsync("/", "product-category-list-response.json", headers)

    val request =
      """
      {
        "query":"{ted{productCategories {name productCategories {name productCategories {name}}}}}",
        "variables": {
          }
        }
      """

    val response =
      """
        |{
        |  "data": {
        |    "ted": {
        |      "productCategories": [
        |        {
        |          "name": "first-level-category",
        |          "productCategories": [
        |            {
        |              "name": "second-level-category",
        |              "productCategories": [
        |                {
        |                  "name": "third-level-category"
        |                }
        |              ]
        |            }
        |          ]
        |        }
        |      ]
        |    }
        |  }
        |}
      """.stripMargin

    executePostTest(request, response, HttpStatus.OK)
  }
}
