package com.rbwm.ted.appointment.filter;

import com.rbwm.ted.appointment.schema.filter.GroupedFilteredConnection;
import com.rbwm.ted.appointment.schema.model.GroupedNode;
import com.rbwm.ted.appointment.schema.sort.SortFields;
import graphql.relay.Connection;
import graphql.relay.Edge;
import graphql.schema.DataFetchingEnvironment;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

/**
 * Created by 44093684 on 06/02/2018.
 */
@RunWith(MockitoJUnitRunner.class)
public class GroupedFilterConnectionTest {

    @Test
    public void testGroupedApplySort() {
        //Given
        DataFetchingEnvironment env = mock(DataFetchingEnvironment.class);
        LinkedHashMap<String, Object> sortArgument = new LinkedHashMap<>();
        sortArgument.put(SortFields.SORT_KEY.value, "order");
        sortArgument.put(SortFields.SORT_ORDER.value, "DESC");
        given(env.getArgument("groupSort")).willReturn(Collections.singletonList(sortArgument));

        SampleGroup group = new SampleGroup("group1", asList(
                new SampleObject(2),
                new SampleObject(5),
                new SampleObject(3),
                new SampleObject(1)
        ));
        SampleGroup group2 = new SampleGroup("group2", asList(
                new SampleObject(1),
                new SampleObject(9),
                new SampleObject(5)
        ));
        GroupedFilteredConnection<SampleGroup> groupedFilteredConnection = new GroupedFilteredConnection<>(asList(group, group2));

        //When
        Connection<SampleGroup> groupConnection = groupedFilteredConnection.get(env);

        //Then
        SampleGroup expectedGroup = new SampleGroup("group1", asList(
                new SampleObject(5),
                new SampleObject(3),
                new SampleObject(2),
                new SampleObject(1)
        ));
        SampleGroup expectedGroup2 = new SampleGroup("group2", asList(
                new SampleObject(9),
                new SampleObject(5),
                new SampleObject(1)
        ));

        List<SampleGroup> expectedGroups = Arrays.asList(expectedGroup, expectedGroup2);
        List<SampleGroup> actualGroups = groupConnection.getEdges().stream().map(Edge::getNode).collect(Collectors.toList());
        assertEquals(expectedGroups, actualGroups);
    }

    @EqualsAndHashCode
    @ToString
    public static class SampleGroup implements GroupedNode {

        public final String groupName;
        public final List<SampleObject> group;

        public SampleGroup(String groupName, List<SampleObject> group) {
            this.groupName = groupName;
            this.group = group;
        }

        @Override
        public List getGroup() {
            return group;
        }
    }

    @EqualsAndHashCode
    @ToString
    public static class SampleObject {

        public final int order;

        public SampleObject(int order) {
            this.order = order;
        }
    }

}
