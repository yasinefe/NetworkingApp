/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.schema.SchemaTest;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.ExecutionResult;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.meetings.MeetingFactory.createMeeting;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

/**
 * Created by 44052007 on 17/05/2018.
 */
public class CheckInMeetingMutationTest extends SchemaTest {

    @Test
    public void testCheckInMeetingMutation() {
        when(meetingService.checkInMeeting("APPOINTMENTS/XCDUNSH", true)).thenReturn(just(createMeeting()));

        String request = "mutation CheckInMeetingMutation($input:CheckInMeetingInput!){checkInMeeting(input:$input)" +
                "{ viewer { id } clientMutationId meeting { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } " +
                "bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } " +
                "comments proofOfId countryCode endedBy checklist }}}";

        Map<String, Object> arguments = new HashMap<>();
        arguments.put("input", new HashMap<String, Object>() {
            {
                put("id", "TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==");
                put("proofOfId", true);
                put("clientMutationId", "10");
            }
        });

        GraphQLContext graphQLContext = new GraphQLContext(null, new DataFetcherAudit.Builder(), null, null);
        ExecutionResult executionResult = executeCommandReturnResult(request, graphQLContext, arguments);
        Map<String, Object> result = ((Map<String, Object>) ((Map<String, Object>) executionResult.getData()).get("checkInMeeting"));
        assertEquals("{viewer={id=Vmlld2VyOjE=}, clientMutationId=10, meeting={id=TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==, " +
                "status=UPCOMING, group=UPCOMING, type=APPOINTMENTS, meetingId=XCDUNSH, topicId=topicId, topicName=topicName, " +
                "topicCategoryId=topicCategoryId, topicCategoryName=topicCategoryName, topicSubCategoryId=topicSubCategoryId, " +
                "topicSubCategoryName=topicSubCategoryName, conductor={employeeId=012345678, fullName=John Walker}, " +
                "bookedFor=2001-07-04T12:08:56.235-0700, checkedInAt=2001-07-04T12:08:56.235-0700, startedAt=2001-07-04T12:08:56.235-0700, " +
                "endedAt=2001-07-04T12:08:56.235-0700, duration=30, isNew=true, isOverdue=true, isOverdueCritical=false, isOverrun=true, " +
                "isOverrunCritical=false, attendee={firstName=Jenny, lastName=Davis, email=jenny.davis@mail.com, phoneNumber=+44 1234 121212, " +
                "mobileNumber=+44 1234 121212, gender=FEMALE}, comments=Mortgage, proofOfId=true, countryCode=GBR, endedBy=USER, " +
                "checklist=[proofOfId, proofOfAddress]}}", result.toString());

        assertEquals("APPOINTMENTS/XCDUNSH", graphQLContext.getDataFetcherAudit().build().entityId);
        assertEquals("MEETING", graphQLContext.getDataFetcherAudit().build().type);
        assertEquals("MEETING_CHECK_IN", graphQLContext.getDataFetcherAudit().build().operationName);
    }

}
