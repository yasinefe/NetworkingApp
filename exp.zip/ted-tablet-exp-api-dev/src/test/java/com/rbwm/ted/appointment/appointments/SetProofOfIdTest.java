/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AppointmentBookingConfiguration;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static java.lang.String.format;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by 44052007 on 12/09/2017.
 */
public class SetProofOfIdTest {

    private SetProofOfId setProofOfId;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AppointmentBookingConfiguration appointmentBookingConfiguration = new AppointmentBookingConfiguration();


    @Before
    public void setUp() {
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "appointmentsHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "appointmentsListUri", "/appointments");
        ReflectionTestUtils.setField(appointmentBookingConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        setProofOfId = new SetProofOfId(appointmentBookingConfiguration, new ReactiveResponseHandler<>());
    }

    @Test
    public void testGetAppointments() throws Exception {
        String jsonRequest = format("{\"proofOfId\":true }");
        String fileContent = "{ \"appointmentId\": \"12345\" }";

        stubFor(put(urlPathEqualTo("/appointments/12345/proofOfId"))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(fileContent)));

        Map<String, Object> response = setProofOfId.setProofOfId("12345", true).block();
        assertTrue(response != null);
        assertEquals("12345", response.get("appointmentId"));
    }

}
