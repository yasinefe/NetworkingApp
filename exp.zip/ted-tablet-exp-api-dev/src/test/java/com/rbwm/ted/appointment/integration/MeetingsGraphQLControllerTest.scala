/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 19/01/2017.
  */
@WebAppConfiguration
class MeetingsGraphQLControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {
  val httpHeaders = new HttpHeaders()
  httpHeaders.add("X-BRANCH-ID", "404628")

  it should "return meetings" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/meetings/branchId/400426?meetingStatus=UPCOMING&meetingGroup=UPCOMING", "get-meetings-response.json", headers)

    val request =
      """
      {
        "query": "{ viewer { meetingList(filter: {branchId: \"400426\", status: UPCOMING, group: UPCOMING, type: APPOINTMENTS}) { count newCount overdueCount overdueCriticalCount overrunCount overrunCriticalCount noShowCount pageInfo { hasNextPage } edges { node { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } comments proofOfId countryCode endedBy checklist } } } } }",
        "variables": {}
        }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "meetingList": {
                "count": 1,
                "newCount": 1,
                "overdueCount": 1,
                "overdueCriticalCount": 0,
                "overrunCount": 1,
                "overrunCriticalCount": 0,
                "noShowCount": 0,
                "pageInfo": {
                  "hasNextPage" : false
                },
                "edges": [
                {
                  "node": {
                    "id": "TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==",
                    "status": "UPCOMING",
                    "group": "UPCOMING",
                    "type": "APPOINTMENTS",
                    "meetingId": "XCDUNSH",
                    "topicId": "topicId",
                    "topicName": "topicName",
                    "topicCategoryId": "topicCategoryId",
                    "topicCategoryName": "topicCategoryName",
                    "topicSubCategoryId": "topicSubCategoryId",
                    "topicSubCategoryName": "topicSubCategoryName",
                    "conductor": {
                      "employeeId": "012345678",
                      "fullName": "John Walker"
                    },
                    "bookedFor": "2001-07-04T12:08:56.235-0700",
                    "checkedInAt": "2001-07-04T12:08:56.235-0700",
                    "startedAt": "2001-07-04T12:08:56.235-0700",
                    "endedAt": "2001-07-04T12:08:56.235-0700",
                    "duration": 30,
                    "isNew": true,
                    "isOverdue": true,
                    "isOverdueCritical": false,
                    "isOverrun": true,
                    "isOverrunCritical": false,
                    "attendee": {
                      "firstName": "Jenny",
                      "lastName": "Davis",
                      "email": "jenny.davis@mail.com",
                      "phoneNumber": "+44 1234 121212",
                      "mobileNumber": "+44 1234 121212",
                      "gender": "FEMALE"
                    },
                    "comments": "Mortgage",
                    "proofOfId": true,
                    "countryCode": "GBR",
                    "endedBy": "USER",
                    "checklist": ["proofOfId", "proofOfAddress"]
                  }
                }
                ]
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }

  it should "return next working day meetings" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/meetings/branchId/400426/nextWorkingDay?meetingStatus=UPCOMING&meetingGroup=UPCOMING", "get-meetings-response.json", headers)

    val request =
      """
      {
        "query": "{ viewer { nextWorkingDayMeetingList(filter: {branchId: \"400426\", status: UPCOMING, group: UPCOMING, type: APPOINTMENTS}) { count pageInfo { hasNextPage } edges { node { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } comments proofOfId countryCode endedBy checklist } } } } }",
        "variables": {}
        }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "nextWorkingDayMeetingList": {
                "count": 1,
                "pageInfo": {
                  "hasNextPage" : false
                },
                "edges": [
                {
                  "node": {
                    "id": "TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==",
                    "status": "UPCOMING",
                    "group": "UPCOMING",
                    "type": "APPOINTMENTS",
                    "meetingId": "XCDUNSH",
                    "topicId": "topicId",
                    "topicName": "topicName",
                    "topicCategoryId": "topicCategoryId",
                    "topicCategoryName": "topicCategoryName",
                    "topicSubCategoryId": "topicSubCategoryId",
                    "topicSubCategoryName": "topicSubCategoryName",
                    "conductor": {
                      "employeeId": "012345678",
                      "fullName": "John Walker"
                    },
                    "bookedFor": "2001-07-04T12:08:56.235-0700",
                    "checkedInAt": "2001-07-04T12:08:56.235-0700",
                    "startedAt": "2001-07-04T12:08:56.235-0700",
                    "endedAt": "2001-07-04T12:08:56.235-0700",
                    "duration": 30,
                    "isNew": true,
                    "isOverdue": true,
                    "isOverdueCritical": false,
                    "isOverrun": true,
                    "isOverrunCritical": false,
                    "attendee": {
                      "firstName": "Jenny",
                      "lastName": "Davis",
                      "email": "jenny.davis@mail.com",
                      "phoneNumber": "+44 1234 121212",
                      "mobileNumber": "+44 1234 121212",
                      "gender": "FEMALE"
                    },
                    "comments": "Mortgage",
                    "proofOfId": true,
                    "countryCode": "GBR",
                    "endedBy": "USER",
                    "checklist": ["proofOfId", "proofOfAddress"]
                  }
                }
                ]
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }

  it should "return meeting with node id" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/meetings/XCDUNSH", "get-meeting-response.json", headers)

    val request =
      """
      {
        "query": "{node (id:\"TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==\") { id ... on Meeting { id status group type meetingId topicId topicName topicCategoryId topicCategoryName topicSubCategoryId topicSubCategoryName conductor { employeeId fullName } bookedFor checkedInAt startedAt endedAt duration isNew isOverdue isOverdueCritical isOverrun isOverrunCritical attendee { firstName lastName email phoneNumber mobileNumber gender } comments proofOfId countryCode endedBy checklist }}}",
        "variables": {}
        }
      """
    val response =
      """
        {
          "data": {
            "node": {
              "id": "TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==",
              "status": "UPCOMING",
              "group": "UPCOMING",
              "type": "APPOINTMENTS",
              "meetingId": "XCDUNSH",
              "topicId": "topicId",
              "topicName": "topicName",
              "topicCategoryId": "topicCategoryId",
              "topicCategoryName": "topicCategoryName",
              "topicSubCategoryId": "topicSubCategoryId",
              "topicSubCategoryName": "topicSubCategoryName",
              "conductor": {
                "employeeId": "012345678",
                "fullName": "John Walker"
              },
              "bookedFor": "2001-07-04T12:08:56.235-0700",
              "checkedInAt": "2001-07-04T12:08:56.235-0700",
              "startedAt": "2001-07-04T12:08:56.235-0700",
              "endedAt": "2001-07-04T12:08:56.235-0700",
              "duration": 30,
              "isNew": true,
              "isOverdue": true,
              "isOverdueCritical": false,
              "isOverrun": true,
              "isOverrunCritical": false,
              "attendee": {
                "firstName": "Jenny",
                "lastName": "Davis",
                "email": "jenny.davis@mail.com",
                "phoneNumber": "+44 1234 121212",
                "mobileNumber": "+44 1234 121212",
                "gender": "FEMALE"
              },
              "comments": "Mortgage",
              "proofOfId": true,
              "countryCode": "GBR",
              "endedBy": "USER",
              "checklist": ["proofOfId", "proofOfAddress"]
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }

  it should "return meeting stats" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/meetings/stats/branchId/400426", "get-meeting-stats-response.json", headers)

    val request =
      """
      {
        "query": "{ viewer { meetingStats(branchId: \"400426\") { averageWaitingTime, averageWaitingTimeLastWorkingDay, averageMeetingLength, inNextHour } } }",
        "variables": {}
        }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "meetingStats": {
                "averageWaitingTime": 1,
                "averageWaitingTimeLastWorkingDay": 1,
                "averageMeetingLength": 2,
                "inNextHour": 14
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }

}
