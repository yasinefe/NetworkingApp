/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http._
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.web.client.ResourceAccessException

/**
  * Created by 44027117 on 22/02/2017.
  */
@WebAppConfiguration
class ErrorHandlingTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "return bad request if query is null" in {
    val request =
      """
        {
          "query": null,
          "variables": {}
        }
      """
    val response =
      """
      {
        "data": null,
        "errors": [
          {
            "code": "TEE-INVALID-PARAMETER",
            "message": "query is null"
          }
        ]
      }
      """

    executePostTest(request, response, HttpStatus.BAD_REQUEST)
  }

  it should "return bad request if variables is null" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    val request =
      """
        {
          "query": {},
          "variables": null
        }
      """
    val response =
      """
      {
        "data": null,
        "errors": [
           {
             "code": "TEE-INVALID-PARAMETER",
             "message": "variables is null"
           }
         ]
      }
      """

    executePostTest(request, response, HttpStatus.BAD_REQUEST)
  }

}
