package com.rbwm.ted.appointment.staff;

import com.rbwm.ted.appointment.api.StaffServiceApi;
import com.rbwm.ted.appointment.schema.model.Staff;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by 44052007 on 17/11/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class StaffServiceTest {

    private static final String EMPLOYEE_ID = "employeeId";
    private static final String BRANCH_ID = "branchId";

    private StaffServiceApi staffService;

    @Mock
    private GetStaff getStaff;

    @Mock
    private GetAllStaff getAllStaff;

    @Before
    public void setUp() throws Exception {
        staffService = new StaffService(getStaff, getAllStaff);
    }

    @Test
    public void testGetStaff() throws Exception {
        Staff expectedStaff = new Staff(EMPLOYEE_ID, "Jack", "Reacher", "http://photos.global.hsbc/casual/square/buck/employeeId.jpg");
        when(getStaff.get(EMPLOYEE_ID)).thenReturn(Mono.just(expectedStaff));

        Staff staff = staffService.getStaff(EMPLOYEE_ID).block();

        assertEquals(expectedStaff, staff);
    }

    @Test
    public void testGetAllStaff() throws Exception {
        List<Staff> expectedStaffList = Collections.singletonList(new Staff(EMPLOYEE_ID, "Jack", "Reacher", "http://photos.global.hsbc/casual/square/buck/employeeId.jpg"));
        when(getAllStaff.get(BRANCH_ID)).thenReturn(Mono.just(expectedStaffList));

        List<Staff> staffList = staffService.getAllStaff(BRANCH_ID).block();

        assertEquals(expectedStaffList, staffList);
    }
}