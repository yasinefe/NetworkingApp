/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44027117 on 05/05/2017.
 */
public class WalkInStatsTest {
    private static final Integer BRANCH_ID = 343242;

    private WalkInStats walkInStats;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AppointmentConfiguration appointmentConfiguration = new AppointmentConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(appointmentConfiguration, "walkInHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(appointmentConfiguration, "walkInStatsUri", "/walkins/stats");
        ReflectionTestUtils.setField(appointmentConfiguration, "asyncClientRestTemplateForWalkIn", new AsyncClientRestTemplate());
        walkInStats = new WalkInStats(appointmentConfiguration, new ReactiveResponseHandler<>());
    }

    @Test
    public void testGetTotalForToday()  {
        stubFor(get(urlPathEqualTo("/walkins/stats"))
                .withQueryParam("branchId", equalTo(String.valueOf(BRANCH_ID)))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{\"total\" : 4, \"averageWaitingTime\": 3, \"averageWaitingTimeLastBusinessDay\": 5}")));
        Map<String, Object> stats = walkInStats.getTotalForToday("343242").block();
        assertEquals(4, stats.get("totalForToday"));
        assertEquals(3, stats.get("averageWaitingTime"));
        assertEquals(5, stats.get("averageWaitingTimeLastBusinessDay"));
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void testBranchNotFoundForBranchId() throws Exception {
        stubFor(get(urlPathEqualTo("/walkins/stats"))
                .withQueryParam("branchId", equalTo(String.valueOf(BRANCH_ID)))
                .willReturn(aResponse()
                        .withStatus(404)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getErrorResponse())));
        try {
            walkInStats.getTotalForToday("343242").block();
        } catch(Exceptions.ServerException e) {
            TestCase.assertEquals("TEE-GET-WALKIN-STATS-NOT-FOUND", e.getErrorCode().code);
            throw e;
        }
    }

    private String getErrorResponse() {
        return "{\n" +
                "  \"error\": {\n" +
                "    \"code\": \"ERROR_CODE\",\n" +
                "    \"message\": \"ERROR MESSAGE\"\n" +
                "  }\n" +
                "}";
    }
}
