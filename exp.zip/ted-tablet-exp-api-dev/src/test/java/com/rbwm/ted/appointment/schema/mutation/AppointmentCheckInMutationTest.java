/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.schema.SchemaTest;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import graphql.ExecutionResult;
import org.joda.time.LocalDateTime;
import org.junit.Test;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import static com.rbwm.ted.appointment.model.AppointmentFields.*;
import static com.rbwm.ted.appointment.model.AppointmentStatus.CHECKED_IN;
import static java.util.stream.Collectors.toSet;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

/**
 * Created by 44052007 on 11/09/2017.
 */
public class AppointmentCheckInMutationTest extends SchemaTest {

    @Test
    public void testCheckInMutation() {
        prepareAppointment();
        String request = "mutation CheckInMutation($input:CheckInInput!){checkIn(input:$input){ viewer { id } clientMutationId appointment " +
                "{id, appointmentId appointmentStatus branchId proofOfId dateTime duration criticalOverdueOffset isNoShow startedAt " +
                "checklist conductor {employeeId fullName}}}}";

        Map<String, Object> arguments = new HashMap<>();
        arguments.put("input", new HashMap<String, Object>() {
            {
                put(APPOINTMENT_ID.val(), "VG9kbzow");
                put(PROOF_OF_ID.val(), true);
                put("clientMutationId", "10");
            }
        });

        GraphQLContext graphQLContext = new GraphQLContext(null, new DataFetcherAudit.Builder(), null, null);
        ExecutionResult executionResult = executeCommandReturnResult(request, graphQLContext, arguments);
        Map<String, Object> result = ((Map<String, Object>) ((Map<String, Object>) executionResult.getData()).get("checkIn"));
        assertEquals("10", result.get("clientMutationId"));
        assertEquals("{viewer={id=Vmlld2VyOjE=}, clientMutationId=10, appointment={id=YXBwb2ludG1lbnQ6Vkc5a2J6b3c=, appointmentId=VG9kbzow, " +
                "appointmentStatus=CHECKED_IN, branchId=400706, proofOfId=true, dateTime=1496725560000, duration=20, " +
                "criticalOverdueOffset=10, isNoShow=true, startedAt=1499317560000, checklist=[proofOfId, proofOfAddress], " +
                "conductor={employeeId=44052008, fullName=Jack Reacher}}}", result.toString());
        assertEquals("APPOINTMENT", graphQLContext.getDataFetcherAudit().build().type);
        assertEquals("APPOINTMENT_CHECK_IN", graphQLContext.getDataFetcherAudit().build().operationName);
        assertEquals("VG9kbzow", graphQLContext.getDataFetcherAudit().build().entityId);
    }

    private void prepareAppointment() {
        Map<String, Object> appointment = new HashMap<>();
        appointment.put("id", "YXBwb2ludG1lbnQ6Vkc5a2J6b3c=");
        appointment.put(APPOINTMENT_ID.val(), "VG9kbzow");
        appointment.put(BRANCH_ID.val(), "400706");
        appointment.put(APPOINTMENT_STATUS.val(), CHECKED_IN.getCode());
        appointment.put(DURATION.val(), 20);
        appointment.put(CRITICAL_OVERDUE_OFFSET.val(), 10);
        appointment.put(IS_NOSHOW.val(), true);
        appointment.put(PROOF_OF_ID.val(), true);
        appointment.put(DATE_TIME.val(), new LocalDateTime(2017, 6, 6, 6, 6).toDateTime().getMillis());
        appointment.put(STARTED_AT.val(), new LocalDateTime(2017, 7, 6, 6, 6).toDateTime().getMillis());
        appointment.put(CHECKLIST.val(), Stream.of("proofOfId", "proofOfAddress").collect(toSet()));

        Map<String, Object> conductor = new HashMap<>();
        conductor.put("employeeId", "44052008");
        conductor.put("fullName", "Jack Reacher");

        appointment.put("conductor", conductor);
        when(appointmentBookingService.getAppointment("VG9kbzow")).thenReturn(just(appointment));

        when(appointmentBookingService.updateAppointmentStatus("VG9kbzow", CHECKED_IN)).thenReturn(Mono.just(appointment));
        when(appointmentBookingService.updateProofOfId("VG9kbzow", true)).thenReturn(Mono.just(appointment));
    }
}
