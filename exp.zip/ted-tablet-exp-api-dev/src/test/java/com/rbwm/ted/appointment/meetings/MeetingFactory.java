/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.meetings;

import com.rbwm.ted.appointment.model.Gender;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import com.rbwm.ted.appointment.model.MeetingType;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toSet;

/**
 * Created by 44052007 on 17/05/2018.
 */
public class MeetingFactory {

    public static Map<String, Object> createMeeting() {
        Map<String, Object> conductor = new HashMap<>();
        conductor.put("employeeId", "012345678");
        conductor.put("fullName", "John Walker");

        Map<String, Object> person = new HashMap<>();
        person.put("firstName", "Jenny");
        person.put("lastName", "Davis");
        person.put("email", "jenny.davis@mail.com");
        person.put("phoneNumber", "+44 1234 121212");
        person.put("mobileNumber", "+44 1234 121212");
        person.put("gender", Gender.FEMALE.getVal());

        Map<String, Object> meeting = new HashMap<>();
        meeting.put("id", "TWVldGluZzpBUFBPSU5UTUVOVFMvWENEVU5TSA==");
        meeting.put("status", MeetingStatus.UPCOMING.name());
        meeting.put("group", MeetingGroupType.UPCOMING.name());
        meeting.put("type", MeetingType.APPOINTMENTS.name());
        meeting.put("meetingId", "XCDUNSH");
        meeting.put("topicId", "topicId");
        meeting.put("topicName", "topicName");
        meeting.put("topicCategoryId", "topicCategoryId");
        meeting.put("topicCategoryName", "topicCategoryName");
        meeting.put("topicSubCategoryId", "topicSubCategoryId");
        meeting.put("topicSubCategoryName", "topicSubCategoryName");
        meeting.put("conductor", conductor);
        meeting.put("bookedFor", "2001-07-04T12:08:56.235-0700");
        meeting.put("checkedInAt", "2001-07-04T12:08:56.235-0700");
        meeting.put("startedAt", "2001-07-04T12:08:56.235-0700");
        meeting.put("endedAt", "2001-07-04T12:08:56.235-0700");
        meeting.put("duration", 30);
        meeting.put("isNew", true);
        meeting.put("isOverdue", true);
        meeting.put("isOverdueCritical", false);
        meeting.put("isOverrun", true);
        meeting.put("isOverrunCritical", false);
        meeting.put("attendee", person);
        meeting.put("comments", "Mortgage");
        meeting.put("proofOfId", true);
        meeting.put("countryCode", "GBR");
        meeting.put("endedBy", "USER");
        meeting.put("checklist", Stream.of("proofOfId", "proofOfAddress").collect(toSet()));

        return meeting;
    }

}
