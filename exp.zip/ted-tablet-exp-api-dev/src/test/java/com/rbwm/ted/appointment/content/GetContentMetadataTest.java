/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.content;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.ContentConfiguration;
import com.rbwm.ted.appointment.content.ContentMetadata.Content;
import com.rbwm.ted.appointment.content.ContentMetadata.Metadata;
import com.rbwm.ted.appointment.content.ContentMetadata.Section;
import com.rbwm.ted.appointment.content.ContentMetadata.Video;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static java.util.Collections.singletonList;
import static junit.framework.TestCase.assertEquals;

/**
 * Created by 44027117 on 31/10/2017.
 */
public class GetContentMetadataTest {

    private GetContentMetadata getContentMetadata;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private ContentConfiguration contentConfiguration = new ContentConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(contentConfiguration, "videoContentHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(contentConfiguration, "videoContentMetadataUri", "/metadata");
        ReflectionTestUtils.setField(contentConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getContentMetadata = new GetContentMetadata(contentConfiguration);
    }

    @Test
    public void testGetContentMetadata() throws Exception {
        stubFor(get(urlPathEqualTo("/metadata"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-content-metadata-response.json"))));

        Video video = new Video("http://localhost:" + wireMockRule.port() + "/url");
        Content content = new Content("content id", "content name", "tip", "description", false, video);
        Section section = new Section("section id", "section name", "duration", singletonList(content));
        Metadata expectedMetadata = new Metadata(singletonList(section));

        Metadata metadata = getContentMetadata.getContentMetadata().block();
        assertEquals(expectedMetadata, metadata);
    }

}
