/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import org.junit.Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.model.AppointmentFields.*;
import static org.junit.Assert.assertEquals;

/**
 * Created by 43578876 on 03/04/2017.
 */
public class WalkInJsonTransformerTest {

    @Test
    public void transformWalkIn() {
        Map<String, Object> walkin = new HashMap<>();

        walkin.put(BRANCH_ID.val(), "400706");
        walkin.put(DATE_TIME.val(), 1483894200000L);
        walkin.put("created", 1483894400000L);
        walkin.put("updated", 1483894600000L);
        walkin.put(STARTED_AT.val(), 1483898400000L);
        walkin.put(TOPIC_ID.val(), "mortgages");
        walkin.put(TOPIC_CATEGORY_ID.val(), "savings");
        walkin.put(TOPIC_SUB_CATEGORY_ID.val(), "other");
        walkin.put(APPOINTMENT_ID.val(), "AS2323KKS");
        walkin.put(OVERDUE_OFFSET.val(), 15L);
        walkin.put(DURATION.val(), 10L);
        walkin.put(ENDED_AT.val(), 1483898400000L);

        Map<String, Object> result = WalkInJsonTransformer.transform.apply(walkin);

        Map<String, Object> expected = new LinkedHashMap<>();
        expected.put("dateTime", 1483894200000L);
        expected.put("branchId", "400706");
        expected.put("overdueOffset", 15L);
        expected.put("created", 1483894400000L);
        expected.put("startedAt", 1483898400000L);
        expected.put("topicSubCategoryName", "other");
        expected.put("topicSubCategoryId", "other");
        expected.put("duration", 10L);
        expected.put("topicCategoryName", "savings");
        expected.put("topicId", "mortgages");
        expected.put("appointmentId", "AS2323KKS");
        expected.put("topicCategoryId", "savings");
        expected.put("topicName", "mortgages");
        expected.put("id", "d2Fsa0luOkFTMjMyM0tLUw==");
        expected.put("updated", 1483894600000L);
        expected.put("endedAt", 1483898400000L);
        assertEquals(expected, result);
    }

}