/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.staff;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.StaffConfiguration;
import com.rbwm.ted.appointment.schema.model.Staff;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static junit.framework.TestCase.assertEquals;

/**
 * Created by 44052007 on 17/11/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class GetStaffTest {

    private static final String ENPLOYEE_ID = "12345";

    private GetStaff getStaff;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private StaffConfiguration staffConfiguration = new StaffConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(staffConfiguration, "staffHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(staffConfiguration, "staffUri", "/staff");
        ReflectionTestUtils.setField(staffConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getStaff = new GetStaff(staffConfiguration);
    }

    @Test
    public void testGetStaffByEmployeeId() throws Exception {
        stubFor(get(urlPathEqualTo("/staff/employeeId/" + ENPLOYEE_ID))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-staff-response.json"))));

        Staff staff = getStaff.get(ENPLOYEE_ID).block();

        Staff expectedStaff =
                new Staff("44052007", "Jack", "Reacher", "http://photos.global.hsbc/casual/square/4405/44052007.jpg");
        assertEquals(expectedStaff, staff);
    }

}