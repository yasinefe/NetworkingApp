/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.rbwm.ted.appointment.model.MeetingGroupType;
import com.rbwm.ted.appointment.model.MeetingStatus;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 30/04/2018.
 */
public class GetWalkInsTest {

    private static final String BRANCH_ID = "400219";

    private GetWalkIns getWalkIns;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AppointmentConfiguration appointmentConfiguration = new AppointmentConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(appointmentConfiguration, "walkInHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(appointmentConfiguration, "walkInsMeetingsUri", "/meetings");
        ReflectionTestUtils.setField(appointmentConfiguration, "asyncClientRestTemplateForWalkIn", new AsyncClientRestTemplate());
        getWalkIns = new GetWalkIns(appointmentConfiguration, new ReactiveResponseHandler<>());
    }

    @Test
    public void testGetAppointmentsGivenStatusAndGroup() throws Exception {
        stubFor(get(urlPathEqualTo("/meetings/branchId/" + BRANCH_ID))
                .withQueryParam("meetingStatus", equalTo("IN_MEETING"))
                .withQueryParam("meetingGroup", equalTo("CHECKED_IN"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-meetings-response.json"))));

        List<Map<String, Object>> appointments = getWalkIns.getWalkIns(BRANCH_ID, MeetingStatus.IN_MEETING, MeetingGroupType.CHECKED_IN).block();
        validateResponse(appointments);
    }

    @Test
    public void testGetAppointmentsGivenStatus() throws Exception {
        stubFor(get(urlPathEqualTo("/meetings/branchId/" + BRANCH_ID))
                .withQueryParam("meetingStatus", equalTo("IN_MEETING"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-meetings-response.json"))));

        List<Map<String, Object>> appointments = getWalkIns.getWalkIns(BRANCH_ID, MeetingStatus.IN_MEETING, null).block();
        validateResponse(appointments);
    }

    @Test
    public void testGetAppointmentsGivenGroup() throws Exception {
        stubFor(get(urlPathEqualTo("/meetings/branchId/" + BRANCH_ID))
                .withQueryParam("meetingGroup", equalTo("CHECKED_IN"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-meetings-response.json"))));

        List<Map<String, Object>> appointments = getWalkIns.getWalkIns(BRANCH_ID, null, MeetingGroupType.CHECKED_IN).block();
        validateResponse(appointments);
    }

    private void validateResponse(List<Map<String, Object>> appointments) {
        assertEquals(1, appointments.size());
        assertEquals("TWVldGluZzpXQUxLX0lOUy9YQ0RVTlNI", appointments.get(0).get("id"));
        assertEquals(30, appointments.get(0).get("duration"));
        assertEquals("WALK_INS", appointments.get(0).get("type"));
    }

}