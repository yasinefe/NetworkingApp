/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import java.util

import com.fasterxml.jackson.databind.ObjectMapper
import com.rbwm.ted.appointment.AppointmentGraphQLController
import com.rbwm.ted.appointment.audit.{AuditContext, DataFetcherAudit}
import com.rbwm.ted.appointment.http.HeaderContext
import com.rbwm.ted.appointment.walkins.WalkInFactory
import org.springframework.http._
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 28/02/2017.
  */
@WebAppConfiguration
class AuditGraphQLControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "send event for audit" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)
    headers.add("X-BRANCH-ID", "23456")
    headers.add("X-MACHINE-ID", "MachineID")
    headers.add("X-WIFI-MAC-ADDRESS", "12:23:34:45")

    val headersForProApi: HttpHeaders = new HttpHeaders
    headersForProApi.setContentType(MediaType.APPLICATION_JSON)

    val variables: util.Map[String, AnyRef] = new util.LinkedHashMap[String, AnyRef]()
    val input: util.Map[String, AnyRef] = new util.LinkedHashMap[String, AnyRef]()
    input.put("appointmentId", "58c27df5b649390c13176f13")
    input.put("appointmentStatus", "CHECKED_IN")
    input.put("clientMutationId", "10")
    variables.put("input", input)


    val dataFetcherAudit = new DataFetcherAudit.Builder().withEntityId("58c27df5b649390c13176f13").withType("WalkIn").withOperationName("New")

    val auditContext = new AuditContext("test-correlation-id", new HeaderContext("23456", "12:23:34:45", "MachineID", "GBR"), "43578876",
      "mutation ChangeStatusWalkInMutation($input:ChangeStatusWalkInInput!){changeStatusWalkIn(input:$input){clientMutationId walkIn {id, appointmentId, appointmentStatus}}}",
      variables, false, dataFetcherAudit.build());

    val auditRequestBody = new ObjectMapper().writeValueAsString(auditContext)

    mockWithContentAsync("/eventSource", "", headersForProApi, HttpMethod.POST, auditRequestBody)
    mockWithContentAsync("/58c27df5b649390c13176f13", WalkInFactory.getWalkInResponse, headersForProApi, HttpMethod.POST, "{\"appointmentStatus\":\"CHECKED_IN\"}")

    val request =
      """
        {
          "query": "mutation ChangeStatusWalkInMutation($input:ChangeStatusWalkInInput!){changeStatusWalkIn(input:$input){clientMutationId walkIn {id, appointmentId, appointmentStatus}}}",
          "variables": {
            "input": {
              "appointmentId": "58c27df5b649390c13176f13",
              "appointmentStatus": "CHECKED_IN",
              "clientMutationId": "10"
              }
          }
        }
      """
    val response =
      """
        {
          "data": {
            "changeStatusWalkIn": {
              "clientMutationId": "10",
              "walkIn": {
                "id": "d2Fsa0luOjU4YzI3ZGY1YjY0OTM5MGMxMzE3NmYxMw==",
                "appointmentId": "58c27df5b649390c13176f13",
                "appointmentStatus": "CHECKED_IN"
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK, headers)
  }
}
