/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import org.junit.Test;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by 43578876 on 09/11/2016.
 */
public class ProductCategoryQueryTest extends QueryTest {

    @Test
    public void testGetProductCategories() throws Exception {
        HashMap<String, Object> firstLevelCategory = new HashMap<>();
        firstLevelCategory.put("name", "first-level-category");

        HashMap<String, Object> secondLevelCategory = new HashMap<>();
        secondLevelCategory.put("name", "second-level-category");

        HashMap<String, Object> thirdLevelCategory = new HashMap<>();
        thirdLevelCategory.put("name", "third-level-category");

        secondLevelCategory.put("productCategories", Arrays.asList(thirdLevelCategory));
        firstLevelCategory.put("productCategories", Arrays.asList(secondLevelCategory));

        when(productCategoryService.getCategories("GBR")).thenReturn(Mono.just(Arrays.asList(firstLevelCategory)));

        Map<String, Object> result = executeCommand("{ted{productCategories {name productCategories {name productCategories {name}}}}}");

        assertEquals("{productCategories=[{name=first-level-category, productCategories=[{name=second-level-category, productCategories=[{name=third-level-category}]}]}]}",
                result.get("ted").toString());
    }

}