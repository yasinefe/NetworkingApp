/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import graphql.ExecutionResult;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by 43578876 on 09/11/2016.
 */
public class BranchQueryTest extends QueryTest {

    @Test
    public void testGetBranches() {
        Map<String, Object> result = executeCommand("{ viewer { branches { count pageInfo { hasNextPage } edges { node { id branchId name latitude longitude timezone address { addressLine1 addressLine2 city postcode county countryCode } } } } } }");

        assertEquals("{branches={count=1, pageInfo={hasNextPage=false}, edges=[{node={id=QnJhbmNoOjQwMDcwNg==, branchId=400706, name=Holborn Branch, latitude=-12.234, longitude=11.234, timezone=Europe/London, address={addressLine1=address line 1, addressLine2=address line 2, city=London, postcode=W1 NT2, county=Waterloo, countryCode=GBR}}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testGetBranchesWithSearch() {
        Map<String, Object> result = executeCommand("{ viewer { branches(filter: { search: \"Holborn\"}) { count pageInfo { hasNextPage } edges { node { id branchId name latitude longitude timezone address { addressLine1 addressLine2 city postcode county countryCode } } } } } }");

        assertEquals("{branches={count=1, pageInfo={hasNextPage=false}, edges=[{node={id=QnJhbmNoOjQwMDcwNg==, branchId=400706, name=Holborn Branch, latitude=-12.234, longitude=11.234, timezone=Europe/London, address={addressLine1=address line 1, addressLine2=address line 2, city=London, postcode=W1 NT2, county=Waterloo, countryCode=GBR}}}]}}", result.get("viewer").toString());
    }

    @Test
    public void testBranchQueryByNodeInterface() throws Exception {
        Map<String, Object> result = executeCommand("{node (id:\"QnJhbmNoOjQwMDcwNg==\") { id ... on Branch {id branchId name latitude longitude timezone address { addressLine1 addressLine2 city postcode county countryCode }}}}");

        assertEquals("{id=QnJhbmNoOjQwMDcwNg==, branchId=400706, name=Holborn Branch, latitude=-12.234, longitude=11.234, timezone=Europe/London, address={addressLine1=address line 1, addressLine2=address line 2, city=London, postcode=W1 NT2, county=Waterloo, countryCode=GBR}}", result.get("node").toString());
    }

    @Test
    public void testGetBranchByMacAddress() throws Exception {
        Map<String, Object> result = executeCommand("{viewer {branch(macAddress: \"dd:hh:re:43\") {branchId, name} }}");

        assertEquals("{branch={branchId=400706, name=Holborn Branch}}", result.get("viewer").toString());
    }


    @Test
    public void testGetBranchById() throws Exception {
        Map<String, Object> result = executeCommand("{viewer {branch(branchId: \"400706\")  {branchId, name} }}");

        assertEquals("{branch={branchId=400706, name=Holborn Branch}}", result.get("viewer").toString());
    }

    @Test
    public void testGetBranchReturnsValidationError() throws Exception {
        ExecutionResult result = executeCommandReturnResult("{viewer {branch  {branchId, name} }}");

        assertTrue(result.getErrors().get(0).getMessage().contains("Validation error: Branch id and Mac Address is missing, one of them must be provided"));
    }

    @Test
    public void testGetBranchByWithAppointments() throws Exception {
        Map<String, Object> result = executeCommand("{viewer {branch(branchId: \"400706\")  {appointments (appointmentStatus:UPCOMING) {list {appointmentId duration dateTime checklist} summary {count,appointmentStatus} }}}}");

        assertEquals("{branch={appointments={list=[{appointmentId=1234, duration=20, dateTime=1496725560000, checklist=[proofOfId, proofOfAddress]}], summary=[{count=23, appointmentStatus=UPCOMING}]}}}",
                result.get("viewer").toString());
    }

    @Test
    public void testGetBranchByWithAppointmentsSummaryOnlyNoStatus() throws Exception {
        Map<String, Object> result = executeCommand("{viewer {branch(branchId: \"400706\")  {appointments {list {appointmentId duration dateTime checklist} summary {count,appointmentStatus} }}}}");

        assertEquals("{branch={appointments={list=[{appointmentId=1234, duration=20, dateTime=1496725560000, checklist=[proofOfId, proofOfAddress]}], summary=[{count=23, appointmentStatus=UPCOMING}]}}}",
                result.get("viewer").toString());
    }

    @Test
    public void testGetBranchWithWalkIns() throws Exception {
        Map<String, Object> result = executeCommand("{viewer {branch(branchId: \"400706\") {walkIns {list {id appointmentStatus duration} }}}}");

        assertEquals("{branch={walkIns={list=[{id=d2Fsa0luOjEyMzQ=, appointmentStatus=UPCOMING, duration=20}]}}}",
                result.get("viewer").toString());
    }

}