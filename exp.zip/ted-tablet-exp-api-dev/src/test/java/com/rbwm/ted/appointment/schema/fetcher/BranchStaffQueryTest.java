/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.fetcher;

import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 15/11/2017.
 */
public class BranchStaffQueryTest extends QueryTest {

    @Test
    public void testBranchStaffQuery() throws Exception {
        Map<String, Object> result = executeCommand("{ viewer { branchStaff (id:\"QnJhbmNoOjQwMDcwNg==\") { count pageInfo { hasNextPage } edges { node { id employeeId firstName lastName portraitUrl } } } } }");

        assertEquals("{branchStaff={count=2, pageInfo={hasNextPage=false}," +
                        " edges=[" +
                        "{node={id=U3RhZmY6NDQwMTIzNDU=, employeeId=44012345, firstName=Tom, lastName=Hanks, portraitUrl=http://photos.global.hsbc/casual/square/4401/44012345.jpg}}, " +
                        "{node={id=U3RhZmY6NDQwMTIzNDY=, employeeId=44012346, firstName=John, lastName=Silver, portraitUrl=http://photos.global.hsbc/casual/square/4401/44012346.jpg}}" +
                        "]}}",
                result.get("viewer").toString());
    }

    @Test
    public void testBranchStaffQueryByNodeInterface() throws Exception {
        Map<String, Object> result = executeCommand("{node (id:\"U3RhZmY6NDQwMTIzNDU=\") { id ... on Staff {id employeeId firstName lastName portraitUrl}}}");

        assertEquals("{id=U3RhZmY6NDQwMTIzNDU=, employeeId=44012345, firstName=Tom, lastName=Hanks, portraitUrl=http://photos.global.hsbc/casual/square/4401/44012345.jpg}",
                result.get("node").toString());
    }
}
