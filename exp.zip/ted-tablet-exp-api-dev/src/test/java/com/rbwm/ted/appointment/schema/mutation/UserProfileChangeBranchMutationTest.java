/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.schema.mutation;

import com.rbwm.ted.appointment.audit.DataFetcherAudit;
import com.rbwm.ted.appointment.http.HeaderContext;
import com.rbwm.ted.appointment.schema.SchemaTest;
import com.rbwm.ted.appointment.schema.graphql.GraphQLContext;
import com.rbwm.ted.appointment.schema.model.Branch;
import com.rbwm.ted.appointment.user.UserProfile;
import graphql.ExecutionResult;
import org.junit.Test;
import org.springframework.security.core.Authentication;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;

import static com.rbwm.ted.appointment.model.Role.ADMIN;
import static com.rbwm.ted.appointment.model.UserProfileFields.BRANCH_ID;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by 44052007 on 09/12/2016.
 */
public class UserProfileChangeBranchMutationTest extends SchemaTest {

    @Test
    public void testAppointmentMutationCheckedIn() {
        String request = "mutation ChangeBranch($input:ChangeBranchInput!){changeBranch(input:$input){clientMutationId userProfile {branchId, firstName, lastName, role, branch{name} }}}";

        Authentication authentication = mock(Authentication.class);
        when(authentication.getName()).thenReturn("56789");
        when(authenticationFacade.getAuthentication()).thenReturn(authentication);

        UserProfile userProfile = new UserProfile("56789",false,12345L,"Rick","Grimes","12345", ADMIN);
        
        when(userProfileService.updateBranch("56789", "12345")).thenReturn(Mono.just(userProfile));

        Branch branch = new Branch("12345", "Holborn Branch", 0d, 0d, "Europe/London", null);
        when(branchesRestDataService.getBranchById("12345")).thenReturn(Mono.just(branch));

        Map<String, Object> arguments = new HashMap<>();
        arguments.put("input", new HashMap<String, Object>() {
            {
                put(BRANCH_ID.val(), "12345");
                put("clientMutationId", "10");
            }
        });

        GraphQLContext graphQLContext = new GraphQLContext(new HeaderContext("12345", "macAddress", "machineId", "GBR"), new DataFetcherAudit.Builder(), "56789", "correlationId");
        ExecutionResult executionResult = executeCommandReturnResult(request, graphQLContext, arguments);
        Map<String, Object> result = ((Map<String, Object>)((Map<String, Object>) executionResult.getData()).get("changeBranch"));
        assertEquals("10",result.get("clientMutationId"));
        assertEquals("{clientMutationId=10, userProfile={branchId=12345, firstName=Rick, lastName=Grimes, role=ADMIN, branch={name=Holborn Branch}}}", result.toString());
    }

}
