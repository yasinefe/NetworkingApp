/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.walkins;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.api.ReactiveResponseHandler;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.rbwm.ted.appointment.model.MeetingStatus;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 16/05/2018.
 */
public class UpdateWalkInStatusTest {

    private UpdateWalkInStatus updateWalkInStatus;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AppointmentConfiguration appointmentConfiguration = new AppointmentConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(appointmentConfiguration, "walkInHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(appointmentConfiguration, "walkInsMeetingsUri", "/meetings");
        ReflectionTestUtils.setField(appointmentConfiguration, "asyncClientRestTemplateForWalkIn", new AsyncClientRestTemplate());
        updateWalkInStatus = new UpdateWalkInStatus(appointmentConfiguration, new ReactiveResponseHandler<>());
    }

    @Test
    public void testUpdateWalkInStatus() throws Exception {
        stubFor(put(urlPathEqualTo("/meetings/meetingId"))
                .withRequestBody(equalToJson("{\"meetingStatus\": \"IN_MEETING\"}"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-meeting-response.json"))));

        Map<String, Object> walkIn = updateWalkInStatus.updateWalkInStatus("meetingId", MeetingStatus.IN_MEETING).block();
        validateResponse(walkIn);
    }

    private void validateResponse(Map<String, Object> walkIn) {
        assertEquals("TWVldGluZzpXQUxLX0lOUy9YQ0RVTlNI", walkIn.get("id"));
        assertEquals(30, walkIn.get("duration"));
        assertEquals("WALK_INS", walkIn.get("type"));
    }

}