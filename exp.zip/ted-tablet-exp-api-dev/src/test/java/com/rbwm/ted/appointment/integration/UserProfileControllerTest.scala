/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.apache.commons.lang3.StringUtils
import org.springframework.http.{HttpHeaders, HttpMethod, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 19/04/2017.
  */
@WebAppConfiguration
class UserProfileControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "return a user Profile" in {

    val mockResponse =
      """
        |{
        |   "userId": "43578876",
        |   "lastTimeLogin": 123456789,
        |   "firstLogin": true,
        |   "branchId": "400125",
        |   "firstName": "Rick",
        |   "lastName": "Grimes",
        |   "role": "ADMIN"
        |}
      """.stripMargin

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithFileContentAsync("/branchId/400125", "branch-response.json", headers)
    mockGetWithContentAsync("/userProfiles/43578876", mockResponse, headers)
    mockGetWithFileContentAsync("/ADMIN?userId=43578876&branchId&countryCode=GBR", "authorisation-response.json", headers)
    mockGetWithFileContentAsync("/trackings/43578876", "user-trackings-response.json", headers)

    val request =
      """
      {
        "query": "{viewer {userProfile {lastTimeLogin firstLogin userId, firstName, lastName, role, branchId, trackings {key count} branch {name, address {addressLine1}} authorisation {walkIn {create read update delete} appointment {create read update delete} help {create read update delete} miReport {create read update delete} skillbuilders {create read update delete}}}}}",
        "variables": {
          }
        }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "userProfile": {
                "lastTimeLogin": 123456789,
                "userId": "43578876",
                "firstName": "Rick",
                "lastName": "Grimes",
                "role": "ADMIN",
                "firstLogin": true,
                "branchId": "400125",
                "trackings": [
                  {
                    "key": "tracking_key",
                    "count": 13
                  }
                ],
                "branch": {
                  "name": "Aberdeen",
                  "address": {
                    "addressLine1": "95-99 Union Street"
                  }
                },
                "authorisation": {
                  "walkIn": {
                    "create": true,
                    "read": false,
                    "update": true,
                    "delete": false
                  },
                  "appointment": {
                    "create": true,
                    "read": false,
                    "update": true,
                    "delete": false
                  },
                  "help": {
                    "create": true,
                    "read": false,
                    "update": true,
                    "delete": false
                  },
                  "miReport": {
                    "create": true,
                    "read": false,
                    "update": true,
                    "delete": false
                  },
                  "skillbuilders": {
                    "create": true,
                    "read": false,
                    "update": true,
                    "delete": false
                  }
                }
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

  it should "return a user Profile without branch" in {

    val mockResponse =
      """
        |{
        |   "userId": "43578876",
        |   "lastTimeLogin": 123456789,
        |   "firstLogin": true,
        |   "firstName": "Rick",
        |   "lastName": "Grimes",
        |   "role": "ADMIN"
        |}
      """.stripMargin

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithContentAsync("/userProfiles/43578876", mockResponse, headers)

    val request =
      """
      {
        "query": "{viewer{userProfile {lastTimeLogin firstLogin userId, firstName, lastName, role, branchId, branch {name, address {addressLine1}}}}}",
        "variables": {
          }
        }
      """
    val response =
      """
        {
          "data": {
            "viewer": {
              "userProfile": {
                "lastTimeLogin": 123456789,
                "userId": "43578876",
                "firstName": "Rick",
                "lastName": "Grimes",
                "role": "ADMIN",
                "firstLogin": true
              }
            }
          }
        }
      """

    executePostTest(request, response, HttpStatus.OK)
  }

  it should "return a user Profile with Branch Not Found" in {

    val mockResponse =
      """
        |{
        |   "userId": "43578876",
        |   "lastTimeLogin": 123456789,
        |   "firstLogin": true,
        |   "firstName": "Rick",
        |   "lastName": "Grimes",
        |   "branchId": "3423",
        |   "role": "ADMIN"
        |}
      """.stripMargin

    val errorResponse =
      """
        |{
        |  "error": {
        |    "code" : "TEE-UNEXPECTED-ERROR",
        |    "message": "error-message"
        |  }
        |}
      """.stripMargin

    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    mockGetWithContentAsync("/userProfiles/43578876", mockResponse, headers)
    mockWithErrorAsync("/branchId/3423", 500, errorResponse)

    val request =
      """
      {
        "query": "{viewer{userProfile {lastTimeLogin firstLogin userId, firstName, lastName, role, branchId, branch {name, address {addressLine1}} }}}",
        "variables": {
          }
        }
      """
    val response =
      """
        {
        |  "data": {
        |    "viewer": {
        |      "userProfile": {
        |        "lastTimeLogin": 123456789,
        |        "firstLogin": true,
        |        "userId": "43578876",
        |        "firstName": "Rick",
        |        "lastName": "Grimes",
        |        "role": "ADMIN",
        |        "branchId": "3423",
        |        "branch": null
        |      }
        |    }
        |  },
        |  "errors": [
        |    {
        |      "code": "TEE-GET-BRANCH-UNEXPECTED"
        |    }
        |  ]
        |}
      """.stripMargin

    executePostTest(request, response, HttpStatus.OK)
  }

}
