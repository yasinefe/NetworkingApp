/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.integration

import com.rbwm.ted.appointment.AppointmentGraphQLController
import org.springframework.http.{HttpHeaders, HttpMethod, HttpStatus, MediaType}
import org.springframework.test.context.web.WebAppConfiguration

/**
  * Created by 44027117 on 28/02/2017.
  */
@WebAppConfiguration
class WalkInMutationControllerTest extends ControllerTest(classOf[AppointmentGraphQLController]) {

  it should "update the status of a walkIn" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)


    val apiResponse =
      """
        {
        |  "appointmentId": "XEF1532",
        |  "clientMutationId": "10",
        |  "topicId": "category level 1",
        |  "topicCategoryId": "category level 2",
        |  "topicSubCategoryId": "Optional category level 3",
        |  "proofOfId": false,
        |  "comments": "This is a test",
        |  "branchId": "400106",
        |  "attendee": {
        |    "firstName": "Carles",
        |    "lastName": "Pujol",
        |    "gender": "MALE"
        |  },
        |  "appointmentStatus": "COMPLETED",
        |  "duration": 15
        |}
      """.stripMargin

    mockWithContentAsync("/XEF1532", apiResponse, headers, HttpMethod.POST, "{\"appointmentStatus\":\"COMPLETED\"}")
    mockGetWithContentAsync("/stats?branchId=404628", "{\"total\" : 4, \"averageWaitingTime\": 3, \"averageWaitingTimeLastBusinessDay\": 5}", headers)

    val request =
      """
        {
          "query": "mutation ChangeStatusWalkInMutation($input:ChangeStatusWalkInInput!){changeStatusWalkIn(input:$input){clientMutationId walkIn {id, appointmentId, appointmentStatus} walkInStats {id totalForToday averageWaitingTime averageWaitingTimeLastBusinessDay}}}",
            "variables": {
              "input": {
                "appointmentId": "XEF1532",
                "appointmentStatus": "COMPLETED",
                "clientMutationId": "10"
                }
            }
        }
      """
    val response =
      """
        {
          "data": {
            "changeStatusWalkIn": {
              "clientMutationId": "10",
              "walkIn": {
                "id": "d2Fsa0luOlhFRjE1MzI=",
                "appointmentId": "XEF1532",
                "appointmentStatus": "COMPLETED"
              },
              "walkInStats":{
                "id":"d2Fsa0luU3RhdHM6NDA0NjI4",
                "totalForToday":4,
                "averageWaitingTime":3,
                "averageWaitingTimeLastBusinessDay":5
              }
            }
          }
        }
      """

    val requestHeaders: HttpHeaders = new HttpHeaders
    requestHeaders.setContentType(MediaType.APPLICATION_JSON)
    requestHeaders.add("X-BRANCH-ID", "404628")

    executePostTest(request, response, HttpStatus.OK, requestHeaders)
  }

  it should "create a walkIn" in {
    val headers: HttpHeaders = new HttpHeaders
    headers.setContentType(MediaType.APPLICATION_JSON)

    val request =
      """
        {
          "query": "mutation CreateWalkInMutation($input:CreateWalkInInput!){createWalkIn(input:$input){clientMutationId walkIn {appointmentId, attendee{firstName lastName gender} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments, branchId}}}",
          "variables": {
            "input": {
              "gender": "MALE",
              "firstName": "Carles",
              "lastName": "Pujol",
              "topicId": "category level 1",
              "topicCategoryId": "category level 2",
              "topicSubCategoryId": "Optional category level 3",
              "proofOfId": false,
              "comments": "This is a test",
              "branchId": "0",
              "clientMutationId": "10"
            }
          }
        }
      """

    val apiRequest = "{\"clientMutationId\":\"10\",\"gender\":\"MALE\",\"firstName\":\"Carles\",\"lastName\":\"Pujol\",\"topicId\":\"category level 1\",\"topicCategoryId\":\"category level 2\",\"topicSubCategoryId\":\"Optional category level 3\",\"proofOfId\":false,\"comments\":\"This is a test\",\"branchId\":\"400106\",\"attendee\":{\"firstName\":\"Carles\",\"lastName\":\"Pujol\",\"gender\":\"MALE\"},\"appointmentStatus\":\"CHECKED_IN\",\"duration\":15}"

    val apiResponse =
      """
        {
        |  "appointmentId": "234sdfsf324",
        |  "clientMutationId": "10",
        |  "topicId": "category level 1",
        |  "topicCategoryId": "category level 2",
        |  "topicSubCategoryId": "Optional category level 3",
        |  "proofOfId": false,
        |  "comments": "This is a test",
        |  "branchId": "400106",
        |  "attendee": {
        |    "firstName": "Carles",
        |    "lastName": "Pujol",
        |    "gender": "MALE"
        |  },
        |  "appointmentStatus": "CHECKED_IN",
        |  "duration": 15
        |}
      """.stripMargin

    val response =
      """
        |{
        |  "data": {
        |    "createWalkIn": {
        |      "clientMutationId": "10",
        |      "walkIn": {
        |        "appointmentId": "234sdfsf324",
        |        "attendee": {
        |           "firstName": "Carles",
        |           "lastName": "Pujol",
        |           "gender": "MALE"
        |        },
        |        "topicId": "category level 1",
        |        "topicCategoryId": "category level 2",
        |        "topicSubCategoryId": "Optional category level 3",
        |        "proofOfId": false,
        |        "comments": "This is a test",
        |        "branchId": "400106"
        |      }
        |    }
        |  }
        |}
      """.stripMargin

    mockWithContentAsync("/", apiResponse, headers, HttpMethod.POST, apiRequest)
    val httpHeaders = new HttpHeaders()
    httpHeaders.add("X-BRANCH-ID", "400106")
    executePostTest(request, response, HttpStatus.OK, httpHeaders)
  }
}
