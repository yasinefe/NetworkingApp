/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment.news;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.rest.http.AsyncClientRestTemplate;
import com.rbwm.ted.appointment.config.NewsFeedConfiguration;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.rbwm.ted.appointment.util.FileUtil.getMockData;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by 44027117 on 22/02/2017.
 */
public class GetNewsFeedTest {

    private GetNewsFeed getNewsFeed;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private NewsFeedConfiguration newsFeedConfiguration = new NewsFeedConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(newsFeedConfiguration, "newsFeedHostname", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(newsFeedConfiguration, "newsFeedListUri", "/news/feed");
        ReflectionTestUtils.setField(newsFeedConfiguration, "asyncClientRestTemplate", new AsyncClientRestTemplate());
        getNewsFeed = new GetNewsFeed(newsFeedConfiguration);
    }

    @Test
    public void testNewsFeed() throws Exception {
        stubFor(get(urlPathEqualTo("/news/feed"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(getMockData("get-news-feed-response.json"))));

        List<NewsArticle> newsFeed = getNewsFeed.getNewsFeed().block();
        assertTrue(newsFeed != null);
        assertEquals(10, newsFeed.size());


        NewsArticle newsArticle = new NewsArticle("Pistols, papers and parcels of treasure",
                "http://newswire.global.hsbc/en/news/Pages/archives-feature-group-20170831.aspx",
                "UK News",
                "Step inside the HSBC archives for a fascinating insight into the bank's proud and colourful past.",
                1504177200000L,
                true);
        assertEquals(newsArticle, newsFeed.get(0));

        newsArticle = new NewsArticle("Our Archives team stars in BBC programme",
                "http://newswire.global.hsbc/en/news/Pages/bbc-hong-kong-group-20170830.aspx",
                "Group News",
                "Tonight's episode of World's Busiest Cities focuses on Hong Kong and the history of our bank in the former British colony.",
                1504090800000L,
                true);
        assertEquals(newsArticle, newsFeed.get(1));

        newsArticle = new NewsArticle("Mortgage platform for brokers is right up their street",
                "http://newswire.global.hsbc/en/news/Pages/mortgages-united-kingdom-20170830.aspx",
                "Group News",
                "Our latest system will revolutionise how we work with intermediaries while providing a first-class service for customers.",
                1504090800000L,
                true);
        assertEquals(newsArticle, newsFeed.get(2));

    }

}
