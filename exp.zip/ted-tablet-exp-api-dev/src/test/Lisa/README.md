# Overview

* Lisa Environment 11 DevTest Console

    http://hkp3vl1097o.hk.hsbc:1505/
    
* Virtualised Service

  Name: Appointment_Booking_SysAPI
    
  Hostname: http://hkp3vl1097o.hk.hsbc
    
  Port: 8881

## Requests


* 200 OK
  
  [GET] http://hkp3vl1097o.hk.hsbc:8881/queue?locationId=123&locale=en-GB


