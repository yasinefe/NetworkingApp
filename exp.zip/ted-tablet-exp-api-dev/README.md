# ted-tablet-exp-api

Ted Tablet Experience Api.

##Overview

* To run Application locally.

	Issue the following commands:-

	Open a command prompt

	`mvn clean package`

	`java -jar target/ted-tablet-exp-api-<version>.jar`

	*to use mock data - currently switching this via spring profiles (use the profile called local-config) ie*

	`java -jar target/ted-tablet-exp-api-<version>.jar`

* Running on PCF (development).

	Currently running in PCF at the following url :-

	https://ted-appointment-exp-dev.cf.wgdc-drn-01.cloud.uk.hsbc

* Maven build lifecycle

	mvn clean compile - compile
	mvn clean test - compile, run unit tests
	mvn clean package - compile, run unit tests, package compiled code
	mvn clean verify - compile, run unit tests, package compiled code, integration tests
	mvn clean install - compile, run unit tests, package compiled code, integration tests, installs package

* Running integration tests

	To run the integration tests against your local server (spins up local server) :-

	mvn clean verify

	To run the integration tests against another environment (already running server) :-
	NOTE: If the server is configured to `http://localhost` and the port is configured to `8080` it will spin up a local server

  mvn clean verify -Dexperience.server.base={server} -Dexperience.server.port={port}


* For testing, use POSTMAN OR CURL as below
```
	curl -XPOST  -H 'Content-Type:application/json' -d <REQUEST BODY> http://localhost:8080/graphql
```

* Server DateTime for automation tests


To simplify the automation test suit using the MCAB mock data is required to set a fixed date and time on the server. At the moment is set to 25/10/2016 09:00:00 using the format (dd/MM/yyyy HH:mm:ss)

This fixed date and time will be set when the server is starting using the useMockData=true.
```
java -jar target/ted-tablet-exp-api-<version>.jar --ted.mock.current.datetime=true
```

# Headers to use on the POST GraphQL
```
X-BRANCH-ID Integer branchId,
X-MACHINE-ID String machineId,
X-WIFI-MAC-ADDRESS String wifiMACAddress
X-CORRELATION-ID unique request id (UUID)
```

# Logging

Logs can be monitored on Splunk. Details : [Splunk Logging](https://digital-confluence.systems.uk.hsbc/confluence/display/SDTed/Splunk+Logging+Integration)

##Security
In order to post any GraphQL query, it's required to pass the Token Bearer on the Http Header Request. For example:
```
Authorization: Bearer MTIxMjEyMTI++TcU2k78SAGxclHlDSbWaN7q6PXyPeMvGaWEvAX5g8A=
```
##Retrieve the application configuration
No authentication is required. At the moment is only containing the errors element on the Json Response but it could
have more elements as required.

```
HTTP GET http:\\domain\config
```

##Login
```
POST: https://<host>/login
HEADERS:
    X-BRANCH-ID
    X-MACHINE-ID
    X-WIFI-MAC-ADDRESS
    X-COUNTRY-CODE
BODY:
{
    "staffId": "4400232",
    "password": "pass123"
}

RESPONSE:
{
  "user": {
    "cn": "CN=44052007,OU=HSBCPeople,DC=InfoDir,DC=Dev,DC=HSBC",
    "employeeId": "4400232",
    "firstName": "John",
    "lastName": "John",
    "countryCode": "GBR",
    "organisationCode": "HGSU",
    "portraitUrl": "http://photos.global.hsbc/casual/square/4400/4400232.jpg"
  },
  "token": "NDQwNTIwMDcXlfBpFLKJlhsdkLKJlklsk0MzA2Mw=="
}
```

##Reporting UI Error

To report an error from UI.

```
POST: https://<host>/report/error
HEADERS:
    X-BRANCH-ID: if available
    X-MACHINE-ID: if available
    X-WIFI-MAC-ADDRESS: if available
    X-COUNTRY-CODE: if available
    Authorization: Bearer MTIxMjEyMTI++TcU2k78SAGxclHlDSbWaN7q6PXyPeMvGaWEvAX5g8A= (if available)
BODY:
{
    <any object>
}
```

##Example Querying appointments, NEW APPOINTMENT STRUCTURE, ie return list and summary together
```
{"query":"{ted{appointmentList (appointmentStatus:UPCOMING) {list {appointmentId appointmentStatus locationId startedAt dateTime duration topicId topicCategoryId timezone attendee{firstName lastName email gender} conductor{fullName employeeId}} summary { count appointmentStatus } stats {inNextHour} groups { nextBusinessDay { appointmentId appointmentStatus locationId startedAt dateTime duration topicId topicCategoryId timezone attendee{firstName lastName email gender} conductor{fullName employeeId} }} }}}","variables":{},"operationName":null}
```

##Example Querying appointments
Branch id needs to be provided as a request header.

```
{"query":"{ted{appointments (appointmentStatus:UPCOMING)  {appointmentId duration dateTime checklist}}}","variables":{},"operationName":null}
```
```
{"query":"{ted{appointments (appointmentStatus:UPCOMING)  {appointmentId duration dateTime checklist attendee{firstName lastName email} }}}","variables":{},"operationName":null}
```
```
{"query":"{ted{appointments (appointmentStatus:UPCOMING) {appointmentId appointmentStatus locationId dateTime checklist duration topicId topicName topicCategoryId topicCategoryName timezone attendee{firstName lastName email} conductor{fullName employeeId} }}}","variables":{},"operationName":null}
```

##Example Querying appointment counts
```
{"query":"{ted{appointmentSummary (appointmentStatus:[CHECKED_IN,UPCOMING,IN_MEETING,OVERRUN,OVERDUE,COMPLETED,NOSHOW,NEXT_DAY]) {count,appointmentStatus}}}","variables":{},"operationName":null}
```

##Example Retrieving an appointment
```
{"query":"{ted{appointment(appointmentId: \"XEF1546\") {appointmentId duration dateTime topicName topicCategoryName }}}","variables":{},"operationName":null}
```
##Example mutate appointment status
```
{"query":"mutation ChangeStatusMutation($input:ChangeStatusInput!){changeStatus(input:$input){clientMutationId, appointment {id,appointmentId, appointmentStatus}}}","variables":{"input":{"appointmentId":"VG9kbzow","appointmentStatus":"CHECKED_IN","clientMutationId":"10"}}}
```
##Example mutate proof of id
```
{"query":"mutation CheckInMutation($input:CheckInInput!){checkIn(input:$input){clientMutationId, appointment {id, appointmentId, proofOfId, appointmentStatus}}}","variables":{"input":{"appointmentId":"VG9kbzow","proofOfId":true,"clientMutationId":"10"}}}
```

##Example Retrieving an appointment via node based query
```
{"query":"{node (id:\"YXBwb2ludG1lbnQ6WEVGMTUyOQ==\") { id ... on appointment  {appointmentId appointmentStatus locationId dateTime duration topicId topicCategoryId timezone attendee{firstName lastName email} conductor{fullName employeeId} }}}","variables":{},"operationName":null}
```
##Example Retrieving all branches
```
{
  "query": "{ viewer { branches {name, branchId, latitude, longitude address{addressLine1, addressLine2, city, postcode, county, countryCode } } } }",
  "variables": {

  }
}
```
##Example Retrieving a branch by MAC Address
```
{
    "query":"{ viewer {branch(macAddress: \"12:12:12:12\") {name, branchId, latitude, longitude address{addressLine1, addressLine2, city, postcode, county, countryCode}} }}",
    "variables":{}
}
```

##Example Retrieving a branch by id
```
{
    "query":"{ viewer {branch(branchId: \"400621\")  {name, branchId, latitude, longitude address{addressLine1, addressLine2, city, postcode, county, countryCode}} }}",
    "variables":{}
}
```

##Example Querying walkIns NEW STRUCTURE, return list and summary together
```
{"query":"{ted {branch {walkIns {list {appointmentId appointmentStatus locationId dateTime duration topicId topicCategoryId timezone attendee{firstName lastName email} conductor{fullName employeeId} } summary { count appointmentStatus } }}}}","variables":{},"operationName":null}
```

##Example Querying walkIns
```
{"query":"{ted{walkIns {appointmentId appointmentStatus locationId startedAt dateTime duration topicId topicCategoryId timezone attendee{firstName lastName email gender} conductor{fullName employeeId} }}}","variables":{},"operationName":null}
```

##Example Querying walkIn counts
```
{"query":"{ted{walkInSummary {count,appointmentStatus}}}","variables":{},"operationName":null}
```

##Example WalkIn Change Status
```
{"query":"mutation ChangeStatusWalkInMutation($input:ChangeStatusWalkInInput!){changeStatusWalkIn(input:$input){clientMutationId walkIn {id, appointmentId, appointmentStatus} walkInStats {id totalForToday averageWaitingTime averageWaitingTimeLastBusinessDay}}}","variables":{"input":{"appointmentId":"XEF1546","appointmentStatus":"CHECKED_IN","clientMutationId":"10"}}}
```

##Example New WalkIn
```
{"query":"mutation CreateWalkInMutation($input:CreateWalkInInput!){createWalkIn(input:$input){clientMutationId walkIn {attendee{gender, firstName, lastName} topicId, topicCategoryId, topicSubCategoryId, proofOfId, comments, locationId} walkInStats {totalForToday} walkInSummary {count appointmentStatus}}}","variables":{"input":{"gender":"MALE","firstName":"Javier","lastName":"Torres","topicId":"category level 1","topicCategoryId":"category level 2","topicSubCategoryId":"Optional category level 3","proofOfId":false, "comments":"This is a test","locationId":"400106","clientMutationId":"10"}}}
```

##Example Querying product categories
```
{"query":"{ted{productCategories {name productCategories {name productCategories {name}}}}}","variables":{},"operationName":null}
```

##Example of getting a user profile
```
{
    "query":"{
        viewer {
            userProfile {
                userId
                firstLogin
                lastTimeLogin
                firstName
                lastName
                role
                branch{
                    branchId
                    name
                    address
                    {addressLine1}
                }
                authorisations {
                    walkIn {
                        create
                        read
                        update
                        delete
                    }
                    appointment {
                        create
                        read
                        update
                        delete
                    }
                    help {
                        create
                        read
                        update
                        delete
                    }
                    miReport {
                        create
                        read
                        update
                        delete
                    }
                    skillBuilder {
                        create
                        read
                        update
                        delete
                    }
                }
            }
        }
    }",
    "variables":{},
    "operationName":null}
```

##Example mutate branch on a user profile
```
{
	"query": "mutation ChangeBranchMutation($input:ChangeBranchInput!) {
		changeBranch(input:$input) {
			clientMutationId
			userProfile {
				userId,
				branchId,
				lastTimeLogin,
				firstLogin,
				branch {
				    branchId name
				}
			}
		}
	}",
	"variables": {
		"input": {
			"branchId": "12345",
			"clientMutationId": "10"
		}
	}
}
```

##Example of getting a walkIn by id
```
{"query":"{ted{walkIn(appointmentId: \"58e60a68e6ace40d10eb69f5\") {appointmentId appointmentStatus locationId dateTime duration topicId topicCategoryId timezone attendee{firstName lastName gender} conductor{fullName employeeId} }}}","variables":{},"operationName":null}
```

##Example Querying walkIn stats
Branch id needs to be provided as a request header.

```
{"query":"{ted{walkInStats {id totalForToday averageWaitingTime averageWaitingTimeLastBusinessDay}}}","variables":{},"operationName":null}
```

##Example Query using fragments, ie appointments / summary / user profile / walkins / walkin summary in one request
```
{"query":"query Relay($appointmentStatus_0:appointmentStatus!,$appointmentStatus_1:[appointmentStatus]!) {\n  ted {\n    ...F6\n  }\n}\nfragment F0 on appointment {\n  id,\n  appointmentStatus,\n  appointmentId,\n  criticalOverdueOffset,\n  overRunOffset,\n  noShowDuration,\n  isNoShow,\n  topicId,\n  topicCategoryId,\n  dateTime,\n  duration,\n  attendee {\n    firstName,\n    lastName\n  },\n  conductor {\n    fullName\n  }\n}\nfragment F1 on walkIn {\n  id,\n  appointmentStatus,\n  appointmentId,\n  overdueOffset,\n  topicCategoryId,\n  topicSubCategoryId,\n  dateTime,\n  comments,\n  attendee {\n    firstName,\n    lastName\n  },\n  conductor {\n    fullName\n  }\n}\nfragment F3 on appointmentListSummary {\n  count,\n  appointmentStatus\n}\nfragment F4 on ted {\n  _appointmentSummary2SIsKG:appointmentSummary(appointmentStatus:$appointmentStatus_1) {\n    ...F3\n  },\n  walkInSummary {\n    ...F3\n  }\n}\nfragment F5 on ted {\n  userProfile {\n    },\n    id\n  },\n  ...F4\n}\nfragment F6 on ted {\n  _appointments1zWmnz:appointments(appointmentStatus:$appointmentStatus_0) @skip(if:false) {\n    id,\n    ...F0\n  },\n  walkIns {\n    id,\n    ...F1\n  },\n  ...F5\n}","variables":{"appointmentStatus_0":"COMPLETED","appointmentStatus_1":["UPCOMING","CHECKED_IN","OVERDUE","IN_MEETING","OVERRUN","COMPLETED","NOSHOW","NEXT_DAY"]}}
```

##Example Query for news articles
```
{"query":"{ted{newsArticles {title uri source description publishedOn }}}","variables":{},"operationName":null}
```

##Example Query for branch staff
```
{"query":"{ viewer { branchStaff (id:"QnJhbmNoOjQwMDcwNg==") { count pageInfo { hasNextPage } edges { node { id employeeId firstName lastName } } } } }","variables":{},"operationName":null}
```

##Example query for WalkIns group and group by a sub category with count
```
{ query: viewer { meetings(filter: {meetingType: WALK_INS, branchId: "402527", topicId:"New Product", topicCategoryId: "Premier"}, groupBy: TOPIC_SUB_CATEGORY ) { edges { node { groupValue count averageWaitingTime } } } }} 
```

##Excample query for Walkins group by and filter by status
```
{ query: viewer { meetings(groupBy: STATUS, filter: {meetingType: WALK_INS, status: COMPLETED, branchId: "402527"}) { edges { node { groupValue count averageWaitingTime} } } } } 
```

##Example query for Appointments group by and filter by status
```
{ query:  viewer { meetings(groupBy: STATUS, filter: {meetingType: APPOINTMENTS, branchId: "402527"}) { edges { node { groupValue count averageWaitingTime } } } }}
```

##Example query for Appointments group by 15 minute intervals with only retrieving data for WEDNESDAYs
```
{ query: 
    viewer {
        meetings(filter: {meetingType: APPOINTMENTS, dayOfWeek: WEDNESDAY}, groupBy: STARTED_AT__MINUTE__NEAREST_15) {
          edges {
            node {
              groupValue
              count
              averageWaitingTime
            }
          }
        }
      }
    }
```