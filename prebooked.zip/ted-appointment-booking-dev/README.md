# ted-appointment-booking
ted-appointment-booking

##Provides a process api around MCAB Appointment Booking functionality

# Create Appointment

To create appointments for tests following command can be used. It will create 21 appointments using 3 different customer id.

```
./create-appointments.sh
```

Also exposed an endpoint to create appointment.

```
POST http://ted-appointment-booking-dev.cf.wgdc-drn-01.cloud.uk.hsbc/appointments

Body:

{
  "customerId": "aCustomerId",
  "branchId": "400246",
  "dateTime": 123452342342,
  "topicId": "business_banking_direct",
  "topicCategoryId": "business_account_application",
  "duration": 30
}
```

## Password Encryption

To encrypt the password use following url:

```
https://propertyfileencryptor.cf.wgdc-drn-01.cloud.uk.hsbc/api/encryption/digital-ted/dev/property?prop=<password>
```