timestamp() {
  date -v+5H -v+$1M +%s
}

# USMMBI507000100 Yasin Efe                     yasin.efe@hsbc.com
# USMMBI507000101 Adam Lee Edwards              adam.l.edwards@hsbc.com
# USMMBI507000102 Gerrone Richard Matticks      gerrone.r.matticks@hsbc.com
# USMMBI507000103 Oliver Relph                  oliver.relph@hsbc.com
# USMMBI507000104 Ozgul Ozeli                   ozgul.ozeli@hsbc.com
# USMMBI507000105 Daniel John Costin            daniel.j.costin@hsbc.com
# USMMBI507000106 Daryl Michael Sobers Browne   daryl.m.browne@hsbc.com
# USMMBI507000107 Yann Vallery-Radot            yann.vallery-radot@hsbc.com
# USMMBI507000108 Tipu Ali                      tipu.ali@hsbc.com
# USMMBI507000109 Angela M Iglio                angela.m.iglio@hsbc.com

declare -a customers=("USMMBI507000100" "USMMBI507000101" "USMMBI507000102" "USMMBI507000103" "USMMBI507000104" "USMMBI507000105" "USMMBI507000106" "USMMBI507000107" "USMMBI507000108" "USMMBI507000109")

for i in {0..99}
do

min=$(($i * 6))
t=$(timestamp $min)000
customer=${customers[($i % 10)]}

echo $t
echo $customer

curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Postman-Token: a3a001e7-c2b0-53c5-2c0e-424240020451" -d '{
     "customerId": "'$customer'",
     "branchId": "30111639",
     "dateTime": '$t',
     "topicId": "branch_purchase_a_property",
     "topicCategoryId": "mortgage",
     "duration": 5,
     "countryCode": "US",
     "timezone": "America/New_York"
}' "http://ted-appointment-booking-v1-uat-us.cf.wgdc-drn-01.cloud.uk.hsbc/appointments/"

done