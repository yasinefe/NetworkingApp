/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment;

import com.hsbc.rbwm.ted.appointment.api.AppointmentServiceApi;
import com.hsbc.rbwm.ted.appointment.model.AppointmentInput;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.appointment.model.Appointments.Appointment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;

/**
 * Created by 44052007 on 19/06/2017.
 */
@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    private final AppointmentServiceApi appointmentService;

    @Autowired
    public AppointmentController(AppointmentServiceApi appointmentService) {
        this.appointmentService = appointmentService;
    }

    @GetMapping(value = "/branch/{branchId}")
    public Flux<Map<String, Object>> getAppointments(@PathVariable("branchId") String branchId,
                                                     @RequestParam(value = "status", required = false, defaultValue = "") Set<AppointmentStatus> statusList) {
        return appointmentService.getAppointments(branchId, statusList);
    }

    @GetMapping(value = "/branch/{branchId}/historical")
    public Flux<Map<String, Object>> getHistoricalAppointments(@PathVariable("branchId") String branchId,
                                                               @RequestParam(value = "spanInDays") Integer spanInDays) {
        return appointmentService.getHistoricalAppointments(branchId, spanInDays);
    }

    @GetMapping(value = "/list/{branchId}")
    public Mono<Map<String, Object>> getAppointmentList(@PathVariable("branchId") String branchId,
                                                        @RequestParam(value = "status", required = false, defaultValue = "") Set<AppointmentStatus> statusList) {
        return appointmentService.getAppointmentList(branchId, statusList);
    }

    @PutMapping(value = "/{appointmentId}")
    public Mono<Map<String, Object>> updateAppointmentStatus(@PathVariable("appointmentId") String appointmentId,
                                                             @RequestBody AppointmentStatus appointmentStatus) {
        return appointmentService.updateAppointmentStatus(appointmentId, appointmentStatus);
    }

    @PutMapping(value = "/{appointmentId}/proofOfId")
    public Mono<Appointment> updateProofOfId(@PathVariable("appointmentId") String appointmentId,
                                             @RequestBody Appointment appointment) {
        return appointmentService.updateProofOfId(appointmentId, appointment.proofOfId);
    }

    @GetMapping(value = "/{appointmentId}")
    public Mono<Map<String, Object>> getAppointment(@PathVariable("appointmentId") String appointmentId) {
        return appointmentService.getAppointment(appointmentId);
    }

    @GetMapping(value = "/summary/branch/{branchId}")
    public Mono<Map<AppointmentStatus, Long>> getAppointmentsSummary(@PathVariable("branchId") String branchId,
                                                                     @RequestParam(value = "status") Set<AppointmentStatus> statusList) {
        return appointmentService.getAppointmentSummary(branchId, statusList);
    }

    @PostMapping(value = "/")
    public Mono<Map<String, Object>> createAppointment(@RequestBody AppointmentInput input) {
        return appointmentService.createAppointment(input);
    }

}
