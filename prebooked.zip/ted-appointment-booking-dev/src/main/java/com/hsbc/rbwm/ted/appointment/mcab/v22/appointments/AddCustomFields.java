/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.service.AppointmentFunctions;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.*;

/**
 * Created by 43578876 on 23/06/2017.
 */
@Component
public class AddCustomFields {

    public static final DateTimeFormatter dateTimeFormatter = DateTimeFormat
            .forPattern("YYYY-MM-dd hh:mm aa 'UTC'")
            .withZone(DateTimeZone.UTC);

    private final AppointmentConfiguration appointmentConfiguration;
    private final AppointmentFunctions appointmentFunctions;

    @Autowired
    public AddCustomFields(AppointmentConfiguration appointmentConfiguration,
                           AppointmentFunctions appointmentFunctions) {
        this.appointmentConfiguration = appointmentConfiguration;
        this.appointmentFunctions = appointmentFunctions;
    }

    public Map<String,Object> extractAppointment(Map<String,Object> appointmentMap) {

        Long dateTime = dateTimeFormatter.parseDateTime(appointmentMap.get(DATE_TIME.val()).toString()).getMillis();
        appointmentMap.put(DATE_TIME.val(), dateTime);
        appointmentMap.put(NO_SHOW_DURATION.val(), appointmentConfiguration.getNoShowDuration() + "");
        appointmentMap.put(CRITICAL_OVERDUE_OFFSET.val(), appointmentConfiguration.getCriticalOverdueOffset() + "");

        //derive no show here as we will update the status
        appointmentMap.put(IS_NOSHOW.val(), appointmentFunctions.isNoShow(appointmentMap, dateTime));

        return appointmentMap;
    }
}
