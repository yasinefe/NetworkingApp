/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.api;

import com.hsbc.rbwm.ted.appointment.model.AppointmentInput;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.appointment.model.Appointments.Appointment;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;

/**
 * Created by 43578876 on 15/06/2017.
 */
public interface AppointmentServiceApi {

    Flux<Map<String, Object>> getAppointments(String branchCode,
                                              Set<AppointmentStatus> statuses);

    Flux<Map<String, Object>> getYesterdayAppointments(String branchCode,
                                              Set<AppointmentStatus> statuses);

    Flux<Map<String, Object>> getNextWorkingDayAppointments(String branchCode);

    Flux<Map<String, Object>> getHistoricalAppointments(String branchCode, Integer spanInDays);

    Mono<Map<String, Object>> getAppointmentList(String branchCode,
                                                 Set<AppointmentStatus> statuses);

    Mono<Map<String, Object>> updateAppointmentStatus(String appointmentId, AppointmentStatus appointmentStatus);

    Mono<Map<String, Object>> getAppointment(String appointmentId);

    Mono<Map<AppointmentStatus, Long>> getAppointmentSummary(String branchCode, Set<AppointmentStatus> statuses);

    Mono<Appointment> updateProofOfId(String appointmentId, Boolean proofOfId);

    Mono<Map<String, Object>> createAppointment(AppointmentInput input);
}
