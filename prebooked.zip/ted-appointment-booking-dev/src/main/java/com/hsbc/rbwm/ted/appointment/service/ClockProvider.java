/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import org.springframework.stereotype.Component;

import java.time.*;

/**
 * Created by 43578876 on 30/06/2017.
 */
@Component
public class ClockProvider {

    private final Clock clock;

    public ClockProvider() {
        this.clock =Clock.systemUTC();
    }

    public ClockProvider(Clock clock) {
        this.clock = clock;
    }

    public Clock getClock() {
        return clock;
    }

    public Clock getClock(String timezone) {
        return clock.withZone(ZoneId.of(timezone));
    }

    public Instant getUTCInstant() {
        return clock.instant().atZone(ZoneId.of("UTC")).toInstant();
    }
}
