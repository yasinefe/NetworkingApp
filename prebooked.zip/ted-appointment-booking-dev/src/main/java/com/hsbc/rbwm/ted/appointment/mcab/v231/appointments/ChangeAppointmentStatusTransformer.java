/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v231.appointments;

import com.hsbc.rbwm.ted.appointment.model.AppointmentFields;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.HttpErrorResponseBuilder;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 44052007 on 15/06/2017.
 */
@Component
public class ChangeAppointmentStatusTransformer {
    private ErrorResponse errorsResponse;

    public ChangeAppointmentStatusTransformer() {
        errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix("ABP")
                        .withFeatureErrorCodePrefix("UPDATE-APPOINTMENT")
                        .build();
    }

    public Mono<Map<String,Object>> parseResponse(Map<String, Object> response) {
        checkIfResponseInError(response);

        HashMap<String, Object> updateResponse = new HashMap<>();

        List<Map<String,Object>> confNumber = (List<Map<String, Object>>) response.get("confirmationNumberListType");

        if (!confNumber.isEmpty()) {
            updateResponse.put(AppointmentFields.APPOINTMENT_ID.val(), confNumber.get(0).get("confirmationNumber"));
        }

        return Mono.just(updateResponse);
    }

    private void checkIfResponseInError(Map<String, Object> response) {
        if (response.containsKey("confirmationNumberListType")) {
            List<Map<String, Object>> confirmationNumberListType = (List<Map<String, Object>>) response.get("confirmationNumberListType");
            if (confirmationNumberListType.get(0).containsKey("ttStatus")) {
                Map<String, Object> ttStatus = (Map<String, Object>)confirmationNumberListType.get(0).get("ttStatus");
                if (ttStatus.containsKey("result") && ttStatus.get("result").equals("FAILED")) {
                    throw new Exceptions.NotFoundException(errorsResponse.getNotFoundErrorCode(), new RuntimeException("Appointment not found"), "Not found");
                }
            }
        }
    }

}
