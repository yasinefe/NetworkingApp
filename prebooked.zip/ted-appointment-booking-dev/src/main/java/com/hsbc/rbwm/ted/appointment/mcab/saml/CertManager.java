/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.saml;

import com.hsbc.rbwm.ted.appointment.config.SamlConfiguration;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

@Component
public class CertManager {

    private SamlConfiguration samlConfiguration;
    private BasicX509Credential credential;

    @Autowired
    public CertManager(SamlConfiguration samlConfiguration) throws UnrecoverableKeyException, CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException {
        this.samlConfiguration = samlConfiguration;
        initCredentials();
    }

    private void initCredentials() throws CertificateException, IOException, KeyStoreException, NoSuchAlgorithmException, UnrecoverableKeyException {
        // create public key (cert) portion of credential
        InputStream inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(samlConfiguration.getCertFile());
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        X509Certificate publicKey = (X509Certificate) cf.generateCertificate(inStream);
        inStream.close();

        KeyStore keyStore = KeyStore.getInstance("JKS");
        InputStream fis = Thread.currentThread().getContextClassLoader().getResourceAsStream(samlConfiguration.getKeyStoreFile());
        keyStore.load(fis, samlConfiguration.getKeyStorePassword().toCharArray());

        PrivateKey privateKey = (PrivateKey) keyStore.getKey(samlConfiguration.getKeyAlias(), samlConfiguration.getKeyStorePassword().toCharArray());
        credential = new BasicX509Credential();
        credential.setEntityCertificate(publicKey);
        credential.setPrivateKey(privateKey);
    }

    public Credential getSigningCredential() {
        return credential;
    }
}
