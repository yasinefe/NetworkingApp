/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments

import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration
import com.hsbc.rbwm.ted.appointment.model.AppointmentInput
import com.hsbc.rbwm.ted.rest.api.ClientResponse
import com.hsbc.rbwm.ted.rest.api.ResponseHandler
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import reactor.core.publisher.Mono

/**
 * Created by 43578876 on 20/09/2017.
 */
@Component
open class CreateAppointment @Autowired constructor(val mcabConfiguration: MCABConfiguration,
                                               val responseHandler: ResponseHandler<Map<String, Object>>) {

    val resourceUri: String = mcabConfiguration.getMcabCreateAppointment()
    val crudRest = mcabConfiguration
                .getMcabCRUDRestBuilder("CREATE-APPOINTMENT")
                .build()

    open fun createAppointment(input: AppointmentInput): Mono<Map<String,Object>> {

        val response: ClientResponse<String> = crudRest.doPost(resourceUri, getBody(input)) as ClientResponse<String>

        return Mono.just(responseHandler.extractBody(
               response
        ))

    }

    private fun getBody(input: AppointmentInput): String {
        return """
        {
          "securityDataInfo": null,
          "createAppointmentDetail": {
            "customerIdentifier": {
              "entity": {
                "countryCode": "${input.countryCode}",
                "groupMemberCode": "HBEU"
              },
              "customerId": "${input.customerId}"
            },
            "topicCategoryId": "${input.branchTopicCategoryId()}",
            "topicId": "${input.branchTopicId()}",
            "mode": "0",
            "locationId": "${input.branchId}",
            "notes": "None",
            "duration": ${input.duration},
            "attendeeCount": 1,
            "dateTime": "${input.formattedDateTime()}",
            "timezone": "${input.timezone}",
            "appointmentContact": {
              "email": [
                {
                  "emailAddress": "ravindrapowar1@gmail.com",
                  "emailType": "0"
                }
              ],
              "mobilePhone": {
                "purpose": "mobile",
                "areaCode": "000",
                "countryCode": "000",
                "fullNumber": " ",
                "phoneNumber": " ",
                "extension": "0000",
                "phoneTypeCode": "mobile"
              },
              "contactPhone": {
                "purpose": "home",
                "areaCode": "000",
                "countryCode": "000",
                "fullNumber": "+44 7400 123456",
                "phoneNumber": "+44 7400 123456",
                "extension": "0000",
                "phoneTypeCode": "home"
              },
              "smsReminder": false,
              "emailReminder": true,
              "rmReminder": false
            },
            "attendee": {
              "firstName": "Dilip",
              "lastName": "FY GFZ22 (GVX)"
            },
            "customerSegment": null,
            "platformIndicator": "sfe"
          }
        }
        """
    }
}
