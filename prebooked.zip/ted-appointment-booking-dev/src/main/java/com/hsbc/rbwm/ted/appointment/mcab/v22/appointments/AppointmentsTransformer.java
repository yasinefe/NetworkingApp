/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.appointment.service.AppointmentFunctions;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.*;

/**
 * Created by 43578876h on 15/06/2017.
 */
@Component
public class AppointmentsTransformer {

    private final AddCustomFields addCustomFields;

    @Autowired
    public AppointmentsTransformer(AddCustomFields addCustomFields) {
        this.addCustomFields = addCustomFields;
    }

    private static BiFunction<Map<String, Object>, String, Long> toLong = (map, key) ->
            (map.get(key) != null) ? new Double(String.valueOf(map.get(key))).longValue() : null;

    private Map<String, Object> extractAppointment(Map<String, Object> appointmentMap) {

        Map<String, Object> appointment = appointmentMap.entrySet()
                .stream()
                .filter(entry -> entry.getKey().equals("appointmentDetails"))
                .map(entry -> (Map<String, Object>) entry.getValue())
                .findFirst()
                .get();

        Map<String, Object> appointmentId = (Map<String, Object>) appointment.get("appointmentIdentifier");
        appointment.put(APPOINTMENT_STATUS.val(), AppointmentStatus.fromMcabCode(appointment.get("lifeCycleState").toString()).getCode());

        appointment.put(APPOINTMENT_ID.val(), appointmentId.get("appointmentIdentifier"));

        putAttendeeValues((Map<String,Object>) appointment.get("attendee"));

        List<Map<String, Object>> conductors = (List<Map<String, Object>>) appointment.get("conductors");

        Map<String, Object> conductor = conductors.get(0);
        conductor.put(EMPLOYEE_ID.val(), conductor.get("employeeIdentifier"));
        appointment.put(CONDUCTOR.val(), conductor);

        appointment.put(DURATION.val(), toLong.apply(appointment, DURATION.val()));
        appointment.put(ATTENDEE_COUNT.val(), toLong.apply(appointment, ATTENDEE_COUNT.val()));
        appointment.put(COMMENTS.val(), appointment.get("notes"));

        return addCustomFields.extractAppointment(appointment);
    }

    private void putAttendeeValues(Map<String,Object> attendee) {
        Map<String,Object> appointmentContact = (Map<String,Object>) attendee.get("appointmentContact");
        List<Map<String,Object>> emails = (List<Map<String,Object>>) appointmentContact.get("email");
        String email = (String) emails.get(0).get("emailAddress");
        if (!StringUtils.isEmpty(email)) {
            attendee.put(EMAIL.val(), email);
        }

        appointmentContact.remove("email"); // This causes conversion issue on audit : For detail : https://jira.spring.io/browse/DATAMONGO-1764

        Map<String,Object> mobilePhone = (Map<String,Object>) appointmentContact.get("mobilePhone");
        Map<String,Object> contactPhone = (Map<String,Object>) appointmentContact.get("contactPhone");
        if (mobilePhone != null && !mobilePhone.isEmpty()) {
            attendee.put(MOBILE_NUMBER.val(), mobilePhone.get("phoneNumber"));
        }
        if (contactPhone != null && !contactPhone.isEmpty()) {
            attendee.put(PHONE_NUMBER.val(), contactPhone.get("phoneNumber"));
        }
    }

    public Flux<Map<String, Object>> parseListResponse(Map<String, Object> allAppointments) {

        //NEED TO LOOK IN BOTH upcoming and past buckets to get current days's appointments
        Optional<List<Map<String, Object>>> upcoming = extractSubList(allAppointments, "upcomingAppointments");

        Optional<List<Map<String, Object>>> past = extractSubList(allAppointments, "pastAppointments");

        List<Map<String, Object>> combined = (List<Map<String, Object>>) Stream
                .concat(parseSubList(past).stream(), parseSubList(upcoming).stream())
                .sorted(AppointmentFunctions.comparatorByDateTime)
                .collect(Collectors.toList());

        return Flux.fromIterable(
                combined
        );
    }

    public Mono<Map<String, Object>> parseResponse(Map<String, Object> appointment) {
        return Mono.just(extractAppointment(appointment));
    }

    private List parseSubList(Optional<List<Map<String, Object>>> subList) {
        return subList.isPresent() ?
                subList.get()
                        .stream()
                        .map(map -> extractAppointment(map))
                        .collect(Collectors.toList()) :
                Collections.EMPTY_LIST;
    }

    public static Optional<List<Map<String, Object>>> extractSubList(Map<String, Object> data,
                                                                     String subListName) {
        return (data != null && !data.isEmpty()) ?
                data.entrySet()
                        .stream()
                        .filter(entry -> entry.getKey().equals(subListName))
                        .map(entry -> (List<Map<String, Object>>) entry.getValue())
                        .findFirst()
                :
                Optional.empty();
    }
}
