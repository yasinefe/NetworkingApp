/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.hsbc.rbwm.ted.appointment.api.AppointmentMetaServiceApi;
import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.rest.api.CRUDRest;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.function.Function;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.CHECKLIST;
import static java.lang.String.format;

/**
 * Created by 44027117 on 19/06/2017.
 */
@Component
public class RetrieveAppointment {
    private final CRUDRest crudRest;
    private final String resourceUri;
    private final ResponseHandler<Map<String,Object>> responseHandler;
    private final AppointmentsTransformer appointmentsTransformer;
    private final AppointmentMetaServiceApi appointmentMetaService;
    private final Function<Map<String, Object>, Map<String, Object>> checklistBuilder;

    private static final String FEATURE_ERROR_CODE_PREFIX = "GET-APPOINTMENT";

    @Autowired
    public RetrieveAppointment(MCABConfiguration mcabConfiguration, ResponseHandler responseHandler,
                               AppointmentsTransformer appointmentsTransformer, AppointmentMetaServiceApi appointmentMetaService) {
        resourceUri = mcabConfiguration.getMcabRetrieveAppointment();
        this.responseHandler = responseHandler;
        this.appointmentsTransformer = appointmentsTransformer;
        this.appointmentMetaService = appointmentMetaService;

        checklistBuilder = appointment -> {
            appointment.put(CHECKLIST.val(),
                    appointmentMetaService.findChecklist((String) appointment.get("topicId"), (String) appointment.get("topicCategoryId")));
            return appointment;
        };

        crudRest = mcabConfiguration
                .getMcabCRUDRestBuilder(FEATURE_ERROR_CODE_PREFIX)
                .build();
    }

    public Mono<Map<String,Object>> getAppointment(String appointmentId) {
        return appointmentsTransformer.parseResponse(
                responseHandler.extractBody(crudRest.doPost(resourceUri, getBody(appointmentId)))
        ).map(checklistBuilder).map(CategoryTransformer.getCategoryAndTopicNamesMapper(appointmentMetaService));
    }

    private String getBody(String appointmentId) {
        return format("{\"customerIdentifier\": {}, \"appointmentIdentifier\": {\"appointmentIdentifier\": \"%s\"},\"platformIndicator\":\"ted\"}", appointmentId);
    }
}
