/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.api.MeetingStatsServiceApi;
import com.hsbc.rbwm.ted.appointment.model.MeetingStats;
import com.hsbc.rbwm.ted.appointment.model.StatData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.List;
import java.util.LongSummaryStatistics;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentStatus.CANCELLED;
import static com.hsbc.rbwm.ted.appointment.model.AppointmentStatus.COMPLETED;

/**
 * Created by 44052007 on 21/05/2018.
 */
@Service
public class MeetingStatsService implements MeetingStatsServiceApi {

    private final AppointmentService appointmentService;
    private final ClockProvider clockProvider;

    @Autowired
    public MeetingStatsService(AppointmentService appointmentService, ClockProvider clockProvider) {
        this.appointmentService = appointmentService;
        this.clockProvider = clockProvider;
    }

    @Override
    public Mono<MeetingStats> getMeetingStats(String branchId) {
        Flux<Map<String, Object>> todayAppointments = appointmentService.getAppointments(branchId, Collections.emptySet());
        Flux<Map<String, Object>> yesterdayAppointments = appointmentService.getYesterdayAppointments(branchId, Collections.emptySet());

        return Flux.zip(todayAppointments.collectList(), yesterdayAppointments.collectList())
                .map(pair -> getMeetingStats(pair.getT1(), pair.getT2()))
                .next();
    }

    private MeetingStats getMeetingStats(List<Map<String, Object>> todayAppointments, List<Map<String, Object>> yesterdayAppointments) {
        LongSummaryStatistics todayWaitingTimeStats = summarizeWaitingTime(todayAppointments);
        LongSummaryStatistics yesterdayWaitingTimeStats = summarizeWaitingTime(yesterdayAppointments);
        LongSummaryStatistics todayMeetingLengthTimeStats = summarizeMeetingLengthTime(yesterdayAppointments);

        return new MeetingStats(
                new StatData((int) todayWaitingTimeStats.getCount(), todayWaitingTimeStats.getSum()),
                new StatData((int) yesterdayWaitingTimeStats.getCount(), yesterdayWaitingTimeStats.getSum()),
                new StatData((int) todayMeetingLengthTimeStats.getCount(), todayMeetingLengthTimeStats.getSum()),
                getCountInNextHour(todayAppointments));
    }

    private LongSummaryStatistics summarizeWaitingTime(List<Map<String, Object>> appointments) {
        return appointments.stream()
                .filter(appointment -> appointment.get("checkedInAt") != null)
                .collect(Collectors.summarizingLong(this::waitingTime));
    }

    private Long waitingTime(Map<String, Object> appointment) {
        Long startedAt = (Long) appointment.get("startedAt");
        Long checkedInAt = (Long) appointment.get("checkedInAt");
        Long endedAt = (Long) appointment.get("endedAt");
        if (startedAt != null) {
            return startedAt - checkedInAt;
        } else if (endedAt != null) {
            return endedAt - checkedInAt;
        } else {
            return clockProvider.getUTCInstant().toEpochMilli() - checkedInAt;
        }
    }

    private LongSummaryStatistics summarizeMeetingLengthTime(List<Map<String, Object>> appointments) {
        return appointments.stream()
                .filter(appointment -> COMPLETED.equals(appointment.get("appointmentStatus")))
                .filter(this::hasStartedAndEndedTime)
                .collect(Collectors.summarizingLong(this::meetingLengthTime));
    }

    private Long meetingLengthTime(Map<String, Object> appointment) {
        return (Long) appointment.get("endedAt") - (Long) appointment.get("startedAt");
    }

    private boolean hasStartedAndEndedTime(Map<String, Object> appointment) {
        return appointment.get("startedAt") != null && appointment.get("endedAt") != null && (Long) appointment.get("startedAt") < (Long) appointment.get("endedAt");
    }

    private Integer getCountInNextHour(List<Map<String, Object>> appointments) {
        Long count = appointments.stream()
                .filter(appointment -> !CANCELLED.equals(appointment.get("appointmentStatus")))
                .filter(this::inNextHour)
                .count();
        return count.intValue();
    }

    private Boolean inNextHour(Map<String, Object> appointment) {
        Long now = clockProvider.getUTCInstant().toEpochMilli();
        Long dateTime = (Long) appointment.get("dateTime");
        return dateTime != null && dateTime > now && dateTime <= now + TimeUnit.HOURS.toMillis(1);
    }

}
