/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.config.SamlConfiguration;
import com.hsbc.rbwm.ted.appointment.mcab.saml.GenerateSAML2;
import com.hsbc.rbwm.ted.rest.api.HttpHeaderProvider;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by 44052007 on 13/07/2017.
 */
@Component
public class MCABHttpHeaderProvider implements HttpHeaderProvider {

    private GenerateSAML2 generateSAML2;
    private MCABConfiguration mcabConfiguration;
    private SamlConfiguration samlConfiguration;

    @Autowired
    public MCABHttpHeaderProvider(GenerateSAML2 generateSAML2, MCABConfiguration mcabConfiguration, SamlConfiguration samlConfiguration) {
        this.generateSAML2 = generateSAML2;
        this.mcabConfiguration = mcabConfiguration;
        this.samlConfiguration = samlConfiguration;
    }

    @Override
    public Map<String, List<String>> getHttpHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("X-HDR-Channel-CC", mcabConfiguration.getHeaderChannelCC());
        httpHeaders.set("X-HDR-Channel-CorrelationId", CorrelationIdContainer.getId());
        httpHeaders.set("X-HDR-Channel-GMC", "HBEU");
        httpHeaders.set("X-HDR-Channel-Locale", "en");
        httpHeaders.set("X-HSBC-Channel-Id", samlConfiguration.getChannelId());
        if (mcabConfiguration.getSamlEnabled()) {
            String saml = generateSAML2.generate().replaceAll("\n", "");
            httpHeaders.set("X-HSBC-Saml", saml);
        }
        return httpHeaders;
    }
}
