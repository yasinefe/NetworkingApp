/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Created by 44052007 on 18/08/2017.
 */
@Configuration
public class SamlConfiguration {

    @Value("${ted.appointment.mcab.saml.channel.id}")
    private String channelId;
    @Value("${ted.appointment.mcab.saml.cam.level}")
    private String camLevel;
    @Value("${ted.appointment.mcab.saml.ip.id}")
    private String ipId;
    @Value("${ted.appointment.mcab.saml.secondary.user.id}")
    private String secondaryUserId;
    @Value("${ted.appointment.mcab.saml.issuer}")
    private String issuer;
    @Value("${ted.appointment.mcab.saml.subject}")
    private String subject;

    @Value("${ted.appointment.mcab.saml.key.store.password}")
    private String keyStorePassword;
    @Value("${ted.appointment.mcab.saml.expiration}")
    private Integer expiration;
    @Value("${ted.appointment.mcab.saml.cert.file}")
    private String certFile;
    @Value("${ted.appointment.mcab.saml.key.store.file}")
    private String keyStoreFile;
    @Value("${ted.appointment.mcab.saml.key.alias}")
    private String keyAlias;

    public String getChannelId() {
        return channelId;
    }

    public String getCamLevel() {
        return camLevel;
    }

    public String getIpId() {
        return ipId;
    }

    public String getSecondaryUserId() {
        return secondaryUserId;
    }

    public String getIssuer() {
        return issuer;
    }

    public String getSubject() {
        return subject;
    }

    public String getKeyStorePassword() {
        return keyStorePassword;
    }

    public Integer getExpiration() {
        return expiration;
    }

    public String getCertFile() {
        return certFile;
    }

    public String getKeyStoreFile() {
        return keyStoreFile;
    }

    public String getKeyAlias() {
        return keyAlias;
    }
}
