/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

/**
 * Created by 44027117 on 31/07/2017.
 */
public interface CheckList {
    class Category {
        public final String topicCategoryId;
        public final String name;
        public final Set<Topic> topics;

        @JsonCreator
        public Category(@JsonProperty("topicCategoryId") final String topicCategoryId,
                        @JsonProperty("name") final String name,
                        @JsonProperty("topics") final Set<Topic> topics) {
            this.topicCategoryId = topicCategoryId;
            this.name = name;
            this.topics = topics;
        }
    }

    class Topic {
        public final String id;
        public final String name;
        public final Set<String> checkList;

        @JsonCreator
        public Topic(@JsonProperty("id") final String id,
                     @JsonProperty("name") final String name,
                     @JsonProperty("checkList") final Set<String> checkList) {
            this.id = id;
            this.name = name;
            this.checkList = checkList;
        }
    }
}
