/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.hsbc.rbwm.ted.appointment.api.AppointmentMetaServiceApi;
import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.service.ClockProvider;
import com.hsbc.rbwm.ted.rest.api.CRUDRest;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Map;

/**
 * Created by 44027117 on 19/06/2017.
 */
@Component
public class RetrieveAppointments {
    private final CRUDRest crudRest;
    private ClockProvider clockProvider;
    private final AppointmentMetaServiceApi appointmentMetaService;
    private final String resourceUri;
    private final ResponseHandler<Map<String,Object>> responseHandler;
    private final AppointmentsTransformer appointmentsTransformer;
    private static final String FEATURE_ERROR_CODE_PREFIX = "RETRIEVE-APPOINTMENTS";

    @Autowired
    public RetrieveAppointments(MCABConfiguration mcabConfiguration,
                                ResponseHandler responseHandler,
                                AppointmentsTransformer appointmentsTransformer,
                                AppointmentMetaServiceApi appointmentMetaService,
                                ClockProvider clockProvider) {
        resourceUri = mcabConfiguration.getMcabRetrieveAppointments();
        this.responseHandler = responseHandler;
        this.appointmentsTransformer = appointmentsTransformer;
        this.appointmentMetaService = appointmentMetaService;
        this.clockProvider = clockProvider;

        crudRest = mcabConfiguration
                .getMcabCRUDRestBuilder(FEATURE_ERROR_CODE_PREFIX)
                .build();
    }

    public Flux<Map<String,Object>> getAppointments(String branchCode) {
        return getAppointments(branchCode, getDefaultSpanInDays());
    }

    public Flux<Map<String, Object>> getAppointments(String branchCode, int spanInDays) {
        return appointmentsTransformer.parseListResponse(
                responseHandler.extractBody(crudRest.doPost(resourceUri, getBody(branchCode, spanInDays)))
        ).map(CategoryTransformer.getCategoryAndTopicNamesMapper(appointmentMetaService));
    }

    private String getBody(String branchCode, int spanInDays) {
        String body = "{\n" +
                "  \"customerIdentifier\": {\n" +
                "  },\n" +
                "  \"resourceIdentifier\": {\n" +
                "  },\n" +
                "  \"locationType\": {\n" +
                "    \"locationId\": \"" + branchCode + "\"" +
                "  },\n" +
                "  \"spanInDays\": \"" + spanInDays + "\",\n" +
                "  \"platformIndicator\": \"ted\"" +
                "}";

        return body;
    }

    public int getDefaultSpanInDays() {
        return LocalDate.now(clockProvider.getClock()).getDayOfWeek() == DayOfWeek.SATURDAY ? 3 : 2;
    }
}
