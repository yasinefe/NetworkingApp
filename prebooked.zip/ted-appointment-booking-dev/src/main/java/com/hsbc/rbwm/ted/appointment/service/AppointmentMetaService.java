/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.api.AppointmentMetaServiceApi;
import com.hsbc.rbwm.ted.appointment.model.CheckListContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

/**
 * Created by 44052007 on 28/07/2017.
 */
@Service
public class AppointmentMetaService implements AppointmentMetaServiceApi {

    private final CheckListContainer checkListContainer;

    @Autowired
    public AppointmentMetaService(CheckListContainer checkListContainer) {
        this.checkListContainer = checkListContainer;
    }

    @Override
    public Set<String> findChecklist(String topicId, String topicCategoryId) {
        Optional<Set<String>> checkList = this.checkListContainer.getCheckList().stream()
                .filter(category -> category.topicCategoryId.equalsIgnoreCase(topicId))
                .flatMap(category -> category.topics.stream())
                .filter(topic -> topic.id.equalsIgnoreCase(topicCategoryId))
                .map(topic -> topic.checkList)
                .findFirst();

        return checkList.isPresent() ? checkList.get() : Collections.EMPTY_SET;
    }

    @Override
    public Optional<String> getTopicName(String topicId) {
        return checkListContainer.getCheckList().stream()
                .flatMap(category -> category.topics.stream())
                .filter(topic -> topic.id.equalsIgnoreCase(topicId))
                .map(topic -> topic.name)
                .findFirst();
    }

    @Override
    public Optional<String> getCategoryName(String categoryTopicId) {
        return checkListContainer.getCheckList().stream()
                .filter(category -> category.topicCategoryId.equalsIgnoreCase(categoryTopicId))
                .map(category -> category.name)
                .findFirst();
    }
}
