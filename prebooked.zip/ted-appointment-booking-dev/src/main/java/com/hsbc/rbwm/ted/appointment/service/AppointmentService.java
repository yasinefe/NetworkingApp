/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.api.AppointmentServiceApi;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.CreateAppointment;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.RetrieveAppointment;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.RetrieveAppointments;
import com.hsbc.rbwm.ted.appointment.mcab.v231.appointments.ChangeAppointmentLifeCycle;
import com.hsbc.rbwm.ted.appointment.model.AppointmentInput;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.appointment.model.Appointments.Appointment;
import com.hsbc.rbwm.ted.appointment.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.APPOINTMENT_ID;
import static com.hsbc.rbwm.ted.appointment.model.AppointmentStatus.*;
import static java.util.stream.Collectors.toList;

/**
 * Created by 43578876 on 15/06/2017.
 */
@Component
public class AppointmentService implements AppointmentServiceApi {

    private final RetrieveAppointments retrieveAppointments;
    private final ChangeAppointmentLifeCycle updateAppointmentLifeCycle;
    private final RetrieveAppointment retrieveAppointment;
    private final CreateAppointment createAppointment;
    private final Filters filters;
    private final AppointmentRepository appointmentRepository;
    private final ClockProvider clockProvider;
    private final Set<AppointmentStatus> allAppointmentStatuses;

    @Autowired
    public AppointmentService(RetrieveAppointments retrieveAppointments,
                              ChangeAppointmentLifeCycle changeAppointmentLifeCycle,
                              RetrieveAppointment retrieveAppointment,
                              CreateAppointment createAppointment,
                              Filters filters,
                              AppointmentRepository appointmentRepository,
                              ClockProvider clockProvider) {
        this.retrieveAppointments = retrieveAppointments;
        this.updateAppointmentLifeCycle = changeAppointmentLifeCycle;
        this.retrieveAppointment = retrieveAppointment;
        this.createAppointment = createAppointment;
        this.filters = filters;
        this.appointmentRepository = appointmentRepository;
        this.clockProvider = clockProvider;
        allAppointmentStatuses = Stream.of(AppointmentStatus.values()).collect(Collectors.toSet());
    }

    @Override
    public Flux<Map<String, Object>> getAppointments(String branchCode,
                                                     Set<AppointmentStatus> statuses) {
        Flux<Map<String, Object>> appointments = retrieveAppointments.getAppointments(branchCode);
        return appointments.collectList().map(appointmentList -> {
            List<Map<String, Object>> extendedAppointments = combineAppointmentsWithExtended(appointmentList);
            return getAppointments(extendedAppointments, statuses);
        }).flatMapMany(Flux::fromIterable);
    }

    @Override
    public Flux<Map<String, Object>> getYesterdayAppointments(String branchCode, Set<AppointmentStatus> statuses) {
        Flux<Map<String, Object>> appointments = retrieveAppointments.getAppointments(branchCode);
        return appointments.collectList().map(appointmentList -> {
            List<Map<String, Object>> extendedAppointments = combineAppointmentsWithExtended(appointmentList);
            return getYesterdayAppointments(extendedAppointments, statuses);
        }).flatMapMany(Flux::fromIterable);
    }

    @Override
    public Flux<Map<String, Object>> getNextWorkingDayAppointments(String branchCode) {
        Flux<Map<String, Object>> appointments = retrieveAppointments.getAppointments(branchCode);
        return appointments.collectList().map(appointmentList -> getAppointments(appointmentList, AppointmentStatus.NEXT_DAY))
                .flatMapMany(Flux::fromIterable);
    }

    @Override
    public Flux<Map<String, Object>> getHistoricalAppointments(String branchCode, Integer spanInDays) {
        return retrieveAppointments.getAppointments(branchCode, spanInDays);
    }

    @Override
    public Mono<Map<AppointmentStatus, Long>> getAppointmentSummary(String branchCode,
                                                                    Set<AppointmentStatus> statuses) {
        Flux<Map<String, Object>> appointments = retrieveAppointments.getAppointments(branchCode);
        return appointments.collectList().map(appointmentList -> getAppointmentSummary(statuses, appointmentList));
    }

    @Override
    public Mono<Map<String, Object>> getAppointmentList(String branchCode,
                                                        Set<AppointmentStatus> statuses) {

        Flux<Map<String, Object>> allAppointments = retrieveAppointments.getAppointments(branchCode);
        return allAppointments.collectList().map(appointments -> {

            List<Map<String, Object>> extendedAppointments = combineAppointmentsWithExtended(appointments);
            List<Map<String, Object>> appointmentList = getAppointments(extendedAppointments, statuses);
            List<Map<String, Object>> nextDayAppointments = getAppointments(extendedAppointments, AppointmentStatus.NEXT_DAY);
            Map<AppointmentStatus, Long> appointmentSummary = getAppointmentSummary(allAppointmentStatuses, extendedAppointments);

            Map<String, Object> appointmentStats = getAppointmentStats(extendedAppointments);

            HashMap<String, Object> map = new HashMap<>();
            map.put("appointments", appointmentList);
            map.put("summary", appointmentSummary);
            map.put("stats", appointmentStats);
            map.put("groups", new HashMap<String, Object>() {{
                put("nextDay", nextDayAppointments);
            }});

            return map;
        });
    }

    @Override
    public Mono<Map<String, Object>> updateAppointmentStatus(String appointmentId, AppointmentStatus appointmentStatus) {
        return updateAppointmentLifeCycle.update(appointmentId, appointmentStatus)
                .then(updateRepositoryForStatusChange(appointmentId, appointmentStatus))
                .map(appointment -> {
                    Map<String, Object> returnBody = new HashMap<>();
                    returnBody.put(APPOINTMENT_ID.val(), appointment.appointmentId);
                    return returnBody;
                });
    }

    @Override
    public Mono<Map<String, Object>> getAppointment(String appointmentId) {
        Mono<Map<String, Object>> appointment = retrieveAppointment.getAppointment(appointmentId);
        Mono<Appointment> extendedAppointment = appointmentRepository.findById(appointmentId);

        return Mono.zip(appointment, extendedAppointment)
                .map(objects -> combineAppointmentWithExtended(objects.getT1(), Optional.of(objects.getT2())));
    }

    @Override
    public Mono<Appointment> updateProofOfId(String appointmentId, Boolean proofOfId) {
        long currentTime = clockProvider.getUTCInstant().toEpochMilli();
        Mono<Appointment> updatedAppointmentMono = appointmentRepository.findById(appointmentId)
                .map(appointment -> new Appointment(appointmentId, proofOfId, appointment.createdAt != null ? appointment.createdAt : currentTime, appointment.checkedInAt, appointment.startedAt, appointment.endedAt));
        return appointmentRepository.save(updatedAppointmentMono);
    }

    @Override
    public Mono<Map<String, Object>> createAppointment(AppointmentInput input) {
        return createAppointment.createAppointment(input);
    }

    private List<Map<String, Object>> getAppointments(List<Map<String, Object>> appointments, Set<AppointmentStatus> statuses) {
        return appointments.stream()
                .filter(filters.isSameDay)
                .filter(buildFilterFunction(statuses))
                .collect(toList());
    }

    private List<Map<String, Object>> getYesterdayAppointments(List<Map<String, Object>> appointments, Set<AppointmentStatus> statuses) {
        return appointments.stream()
                .filter(filters.isYesterday)
                .filter(buildFilterFunction(statuses))
                .collect(toList());
    }

    private List<Map<String, Object>> getAppointments(List<Map<String, Object>> appointments, AppointmentStatus status) {
        return appointments.stream()
                .filter(buildFilterFunction(new HashSet<>(Collections.singleton(status))))
                .collect(toList());
    }

    private Map<AppointmentStatus, Long> getAppointmentSummary(Set<AppointmentStatus> statuses, List<Map<String, Object>> appointments) {
        List<Map<String, Object>> today = appointments.stream().filter(filters.isSameDay).collect(toList());

        return buildPredicates(statuses)
                .entrySet()
                .stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        o -> deriveCount(
                                o.getValue(),
                                determineListToSearch(o.getKey(), appointments, today)
                        )));
    }

    private Map<String, Object> getAppointmentStats(List<Map<String, Object>> appointments) {
        long count = appointments
                .stream()
                .filter(filters.isWaiting)
                .filter(filters.isNextHour)
                .count();
        return new HashMap() {{
            put("inNextHour", count);
        }};
    }

    private List<Map<String, Object>> determineListToSearch(AppointmentStatus status, List<Map<String, Object>> allAppointments, List<Map<String, Object>> todaysAppointments) {
        return status.equals(AppointmentStatus.NEXT_DAY) ? allAppointments : todaysAppointments;
    }

    private Long deriveCount(final Predicate<Map<String, Object>> predicate,
                             final List<Map<String, Object>> allAppointments) {
        return allAppointments
                .stream()
                .filter(predicate)
                .count();
    }

    private Map<AppointmentStatus, Predicate<Map<String, Object>>> buildPredicates(Set<AppointmentStatus> statuses) {
        return statuses.stream()
                .collect(Collectors.toMap(
                        status -> status, this::deriveCorrectFilterFunction
                ));
    }

    private Predicate<Map<String, Object>> buildFilterFunction(Set<AppointmentStatus> statuses) {
        if (statuses.isEmpty()) {
            return o -> true;
        }

        List<Predicate<Map<String, Object>>> predicates = buildPredicates(statuses)
                .entrySet()
                .stream()
                .map(Map.Entry::getValue)
                .collect(toList());

        return predicates.size() > 1 ?
                predicates.get(0).or(predicates.get(1)) : //TODO not sure why we are only matching on two statuses maximum. should be changed?
                predicates.get(0);
    }

    private Filters.FilterMap deriveCorrectFilterFunction(AppointmentStatus status) {
        return filters.postProcessingFilterMap.getOrDefault(status, Filters.mapByStatus.apply(status));
    }

    private Mono<Appointment> updateRepositoryForStatusChange(String appointmentId, AppointmentStatus appointmentStatus) {
        long currentTime = clockProvider.getUTCInstant().toEpochMilli();

        Mono<Appointment> appointmentMono = appointmentRepository.findById(appointmentId);
        Mono<Appointment> updatedAppointmentMono;

        if (CHECKED_IN.equals(appointmentStatus)) {
            updatedAppointmentMono = appointmentMono.map(appointment ->
                    new Appointment(appointmentId, appointment.proofOfId, appointment.createdAt != null ? appointment.createdAt : currentTime, currentTime, appointment.startedAt, appointment.endedAt));

        } else if (IN_MEETING.equals(appointmentStatus)) {
            updatedAppointmentMono = appointmentMono.map(appointment ->
                    new Appointment(appointmentId, appointment.proofOfId, appointment.createdAt, appointment.checkedInAt, currentTime, appointment.endedAt));

        } else if (COMPLETED.equals(appointmentStatus) || CANCELLED.equals(appointmentStatus)) {
            updatedAppointmentMono = appointmentMono.map(appointment ->
                    new Appointment(appointmentId, appointment.proofOfId, appointment.createdAt, appointment.checkedInAt, appointment.startedAt, currentTime));

        } else {
            return Mono.empty();
        }

        return appointmentRepository.save(updatedAppointmentMono);
    }

    private List<Map<String, Object>> combineAppointmentsWithExtended(List<Map<String, Object>> appointments) {
        List<String> ids = appointments.stream().map(appointment -> (String) appointment.get(APPOINTMENT_ID.val()))
                .collect(toList());

        Flux<Appointment> appointmentFromDB = appointmentRepository.findByIds(ids);
        Map<String, Appointment> idAppointmentMap = appointmentFromDB.collectMap(appointment -> appointment.appointmentId, appointment -> appointment).block();

        return appointments
                .stream()
                .map(appointment -> {
                    String appointmentId = (String) appointment.get(APPOINTMENT_ID.val());
                    Appointment extendedAppointment = idAppointmentMap.get(appointmentId);

                    return combineAppointmentWithExtended(appointment, Optional.ofNullable(extendedAppointment));
                })
                .collect(toList());
    }

    private Map<String, Object> combineAppointmentWithExtended(Map<String, Object> appointment, Optional<Appointment> extendedAppOpt) {
        if (!extendedAppOpt.isPresent()) {
            return appointment;
        }
        Appointment extendedApp = extendedAppOpt.get();
        if (extendedApp.proofOfId != null) appointment.put("proofOfId", extendedApp.proofOfId);
        if (extendedApp.checkedInAt != null) appointment.put("checkedInAt", extendedApp.checkedInAt);
        if (extendedApp.startedAt != null) appointment.put("startedAt", extendedApp.startedAt);
        if (extendedApp.endedAt != null) appointment.put("endedAt", extendedApp.endedAt);
        if (extendedApp.createdAt != null) appointment.put("createdAt", extendedApp.createdAt);
        return appointment;
    }
}
