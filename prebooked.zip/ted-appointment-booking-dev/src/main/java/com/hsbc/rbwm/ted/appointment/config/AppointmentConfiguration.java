/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Created by 43578876 on 23/06/2017.
 */
@Configuration
public class AppointmentConfiguration {

    @Value("${ted.appointment.noShow.duration}")
    private Integer noShowDuration;

    @Value("${ted.appointment.overdue.offset}")
    private Integer overdueOffset;

    @Value("${ted.appointment.critical.overdue.offset}")
    private Integer criticalOverdueOffset;

    @Value("${ted.appointment.critical.overrun.offset}")
    private Integer criticalOverRunOffset;

    public Integer getNoShowDuration() {
        return noShowDuration;
    }

    public Integer getCriticalOverdueOffset() {
        return criticalOverdueOffset;
    }

    public Integer getOverdueOffset() {
        return overdueOffset;
    }

    public Integer getCriticalOverRunOffset() {
        return criticalOverRunOffset;
    }
}
