/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.model.AppointmentFields;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.DATE_TIME;

/**
 * Created by 43578876 on 22/06/2017.
 */
@Component
public class AppointmentFunctions {

    private static final String ISO_DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
    public static final Comparator comparatorByDateTime = Comparator.comparingLong(a -> (Long) (((Map<String, Object>) a).get(DATE_TIME.val())));

    private final ClockProvider clockProvider;
    private final AppointmentConfiguration appointmentConfiguration;

    @Autowired
    public AppointmentFunctions(ClockProvider clockProvider, AppointmentConfiguration appointmentConfiguration) {
        this.clockProvider = clockProvider;
        this.appointmentConfiguration = appointmentConfiguration;
    }

    public static LocalDate localDateOf(Long utcTime, String timezone) {
        return Instant.ofEpochMilli(utcTime).atZone(ZoneId.of(timezone)).toLocalDate();
    }

    public static String toIsoFormat(Long datetime, String timezone) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ISO_DATE_PATTERN);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone(timezone));
        return simpleDateFormat.format(new Date(datetime));
    }

    public Boolean isInNextHour(Long date) {
        return clockProvider.getUTCInstant().toEpochMilli() < date && date < clockProvider.getUTCInstant().plus(1, ChronoUnit.HOURS).toEpochMilli();
    }

    public Boolean isSameDate(LocalDate date, String timezone) {
        return LocalDate.now(clockProvider.getClock(timezone)).equals(date);
    }

    public LocalDate getYesterday(String timezone) {
        LocalDate yesterday = LocalDate.now(clockProvider.getClock(timezone)).minus(1, ChronoUnit.DAYS);
        if (yesterday.getDayOfWeek() == DayOfWeek.SUNDAY) {
            yesterday = yesterday.minus(1, ChronoUnit.DAYS);
        }
        return yesterday;
    }

    public Boolean isSameDateWithOffset(LocalDate date, String timezone, Integer offset) {
        return getNextWorkingDay(offset, timezone).equals(date);
    }

    public Boolean isNoShow(Map<String, Object> appointment, Long dateTime) {
        return (Filters.mapByStatus.apply(AppointmentStatus.UPCOMING).test(appointment) || Filters.mapByStatus.apply(AppointmentStatus.NOSHOW).test(appointment)) &&
                isPassedDuration(dateTime, Integer.parseInt((String) appointment.get(AppointmentFields.NO_SHOW_DURATION.val())));
    }

    public Boolean isPassedDuration(Long utcTime, Integer duration) {
        return clockProvider.getUTCInstant().isAfter(Instant.ofEpochMilli(utcTime).atZone(ZoneId.of("UTC")).plusMinutes(duration).toInstant());
    }

    public Boolean isOverDue(Long dateTime) {
        return isPassedDuration(dateTime, appointmentConfiguration.getOverdueOffset());
    }

    public LocalDate getNextWorkingDay(int days, String timezone) {
        LocalDate nextDay = LocalDate.now(clockProvider.getClock(timezone)).plusDays(days);
        if (nextDay.getDayOfWeek() == DayOfWeek.SUNDAY) {
            nextDay = nextDay.plus(1, ChronoUnit.DAYS);
        }
        return nextDay;
    }

}
