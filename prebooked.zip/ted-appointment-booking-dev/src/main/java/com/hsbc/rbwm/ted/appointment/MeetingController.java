/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment;


import com.hsbc.rbwm.ted.appointment.api.MeetingServiceApi;
import com.hsbc.rbwm.ted.appointment.api.MeetingStatsServiceApi;
import com.hsbc.rbwm.ted.appointment.model.Meeting;
import com.hsbc.rbwm.ted.appointment.model.MeetingGroup;
import com.hsbc.rbwm.ted.appointment.model.MeetingStats;
import com.hsbc.rbwm.ted.appointment.model.MeetingStatus;
import com.hsbc.rbwm.ted.appointment.model.UpdateMeetingStatusInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Created by 44052007 on 02/05/2018.
 */
@RestController
@RequestMapping("/meetings")
public class MeetingController {

    private final MeetingServiceApi meetingService;
    private final MeetingStatsServiceApi meetingStatsService;

    @Autowired
    public MeetingController(MeetingServiceApi meetingService, MeetingStatsServiceApi meetingStatsService) {
        this.meetingService = meetingService;
        this.meetingStatsService = meetingStatsService;
    }

    @GetMapping(value = "/branchId/{branchId}")
    public Flux<Meeting> getMeetings(@PathVariable("branchId") String branchId,
                                     @RequestParam(value = "meetingStatus", required = false) MeetingStatus meetingStatus,
                                     @RequestParam(value = "meetingGroup", required = false) MeetingGroup meetingGroup) {
        return meetingService.getMeetings(branchId, meetingStatus, meetingGroup);
    }

    @GetMapping(value = "/branchId/{branchId}/nextWorkingDay")
    public Flux<Meeting> getNextWorkingDayMeetings(@PathVariable("branchId") String branchId,
                                     @RequestParam(value = "meetingStatus", required = false) MeetingStatus meetingStatus,
                                     @RequestParam(value = "meetingGroup", required = false) MeetingGroup meetingGroup) {
        return meetingService.getNextWorkingDayMeetings(branchId, meetingStatus, meetingGroup);
    }

    @GetMapping(value = "/{meetingId}")
    public Mono<Meeting> getMeetings(@PathVariable("meetingId") String meetingId) {
        return meetingService.getMeeting(meetingId);
    }

    @PutMapping(value = "/{meetingId}")
    public Mono<Meeting> updateMeetingStatus(@PathVariable("meetingId") String meetingId, @RequestBody UpdateMeetingStatusInput updateMeetingStatusInput) {
        return meetingService.updateMeetingStatus(meetingId, updateMeetingStatusInput);
    }

    @GetMapping(value = "/stats/branchId/{branchId}")
    public Mono<MeetingStats> getMeetingStats(@PathVariable("branchId") String branchId) {
        return meetingStatsService.getMeetingStats(branchId);
    }
}
