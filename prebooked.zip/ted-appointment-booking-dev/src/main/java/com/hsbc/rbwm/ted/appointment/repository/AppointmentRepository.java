/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.repository;

import com.hsbc.rbwm.ted.appointment.config.MongoConfig;
import com.hsbc.rbwm.ted.appointment.model.Appointments.Appointment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Function;

/**
 * Created by 44052007 on 08/09/2017.
 */
@Repository
public class AppointmentRepository {

    private final String appointmentsCollection;
    private final ReactiveMongoTemplate mongoTemplate;

    private final Function<String, Appointment> newAppointment = appointmentId -> new Appointment(appointmentId, null, null, null, null, null);

    @Autowired
    public AppointmentRepository(ReactiveMongoTemplate mongoTemplate, MongoConfig mongoConfig) {
        this.mongoTemplate = mongoTemplate;
        this.appointmentsCollection = mongoConfig.getAppointmentsCollection();
    }

    public Mono<Appointment> save(Mono<Appointment> appointment) {
        return mongoTemplate.save(appointment, appointmentsCollection);
    }

    public Mono<Appointment> findById(String appointmentId) {
        return mongoTemplate
                .findById(appointmentId, Appointment.class, appointmentsCollection)
                .defaultIfEmpty(newAppointment.apply(appointmentId));
    }

    public Flux<Appointment> findByIds(List<String> appointmentIds) {
        Query query = new Query(Criteria.where("_id").in(appointmentIds));
        return mongoTemplate.find(query, Appointment.class, appointmentsCollection);
    }

}
