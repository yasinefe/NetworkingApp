/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.model;

import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.Set;

/**
 * Created by 44052007 on 30/04/2018.
 */
@EqualsAndHashCode
@ToString
public class Meeting {

    public final MeetingStatus status;
    public final MeetingGroup group;
    public final String meetingId;
    public final String topicId;
    public final String topicName;
    public final String topicCategoryId;
    public final String topicCategoryName;
    public final Employee conductor;
    public final String bookedFor;
    public final String checkedInAt;
    public final String startedAt;
    public final String endedAt;
    public final Integer duration;
    public final Boolean isOverdue;
    public final Boolean isOverdueCritical;
    public final Boolean isOverrun;
    public final Boolean isOverrunCritical;
    public final Person attendee;
    public final String comments;
    public final Boolean proofOfId;
    public final ModifierType endedBy;
    public final Set<String> checklist;
    public final String timezone;

    public Meeting(MeetingStatus status,
                   MeetingGroup group,
                   String meetingId,
                   String topicId,
                   String topicName,
                   String topicCategoryId,
                   String topicCategoryName,
                   Employee conductor,
                   String bookedFor,
                   String checkedInAt,
                   String startedAt,
                   String endedAt,
                   Integer duration,
                   Boolean isOverdue,
                   Boolean isOverdueCritical,
                   Boolean isOverrun,
                   Boolean isOverrunCritical,
                   Person attendee,
                   String comments,
                   Boolean proofOfId,
                   ModifierType endedBy,
                   Set<String> checklist,
                   String timezone) {
        this.status = status;
        this.group = group;
        this.meetingId = meetingId;
        this.topicId = topicId;
        this.topicName = topicName;
        this.topicCategoryId = topicCategoryId;
        this.topicCategoryName = topicCategoryName;
        this.conductor = conductor;
        this.bookedFor = bookedFor;
        this.checkedInAt = checkedInAt;
        this.startedAt = startedAt;
        this.endedAt = endedAt;
        this.duration = duration;
        this.isOverdue = isOverdue;
        this.isOverdueCritical = isOverdueCritical;
        this.isOverrun = isOverrun;
        this.isOverrunCritical = isOverrunCritical;
        this.attendee = attendee;
        this.comments = comments;
        this.proofOfId = proofOfId;
        this.endedBy = endedBy;
        this.checklist = checklist;
        this.timezone = timezone;
    }
}
