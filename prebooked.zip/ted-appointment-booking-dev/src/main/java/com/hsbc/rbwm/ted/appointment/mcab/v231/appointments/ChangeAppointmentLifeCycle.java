/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v231.appointments;

import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.rest.api.CRUDRest;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Map;

import static java.lang.String.format;

/**
 * Created by 44027117 on 19/06/2017.
 */
@Component()
public class ChangeAppointmentLifeCycle {
    private final CRUDRest crudRest;
    private final String resourceUri;
    private final ResponseHandler<Map<String,Object>> responseHandler;
    private final ChangeAppointmentStatusTransformer changeAppointmentStatusTransformer;

    private static final String FEATURE_ERROR_CODE_PREFIX = "UPDATE-APPOINTMENT";
    public final static String UPDATE_APPOINTMENT_LIFECYCLE_REQUEST = "{\"confirmationNumber\":[\"%s\"], \"appointmentStatus\":\"%s\", \"confirmed\":false}";

    @Autowired
    public ChangeAppointmentLifeCycle(MCABConfiguration mcabConfiguration,
                                      ResponseHandler responseHandler,
                                      ChangeAppointmentStatusTransformer changeAppointmentStatusTransformer) {
        resourceUri = mcabConfiguration.getMcabUpdateStatus();
        this.responseHandler = responseHandler;
        this.changeAppointmentStatusTransformer = changeAppointmentStatusTransformer;

        crudRest = mcabConfiguration
                .getMcabCRUDRestBuilder(FEATURE_ERROR_CODE_PREFIX)
                .build();
    }

    public Mono<Map<String,Object>> update(String appointmentId, AppointmentStatus appointmentStatus) {
        return changeAppointmentStatusTransformer.parseResponse(
                responseHandler.extractBody(crudRest.doPost(resourceUri, getBody(appointmentId, appointmentStatus)))
        );
    }

    private String getBody(String appointmentId, AppointmentStatus appointmentStatus) {
        return format(UPDATE_APPOINTMENT_LIFECYCLE_REQUEST, appointmentId, appointmentStatus.getMcabCode());
    }
}
