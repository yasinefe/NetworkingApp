/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.config;

import com.hsbc.rbwm.ted.rest.error.ErrorCode;
import com.hsbc.rbwm.ted.rest.error.Exceptions.NotFoundException;
import com.hsbc.rbwm.ted.rest.error.Exceptions.ServerException;
import com.hsbc.rbwm.ted.rest.error.Exceptions.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.HashMap;
import java.util.Map;


/**
 * Created by 44052007 on 06/04/2017.
 */
@ControllerAdvice
@Configuration
public class ControllerExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ControllerExceptionHandler.class);
    private static final ErrorCode UNCHECKED_EXCEPTION = new ErrorCode("ErrorCode", "Unchecked Exception");

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity missingRequestParams() {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }

    @ExceptionHandler(ServerException.class)
    public ResponseEntity serverException(ServerException exception) {
        log.error(exception.getErrorCode().message + " " + exception.getMessage(), exception);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(createError(exception.getErrorCode()));
    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity notFoundException(NotFoundException exception) {
        log.error(exception.getErrorCode().message + " " + exception.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(createError(exception.getErrorCode()));
    }

    @ExceptionHandler(Throwable.class)
    public ResponseEntity throwable(Throwable exception){
        UnexpectedException unexpectedException = new UnexpectedException(UNCHECKED_EXCEPTION, exception, exception.getMessage());
        log.error(unexpectedException.getMessage(), exception);
        return serverException(unexpectedException);
    }

    private Map<String, ErrorCode> createError(final ErrorCode error) {
        Map<String, ErrorCode> newErrorAttributes = new HashMap<>();
        newErrorAttributes.put("error", error);
        return newErrorAttributes;
    }

}
