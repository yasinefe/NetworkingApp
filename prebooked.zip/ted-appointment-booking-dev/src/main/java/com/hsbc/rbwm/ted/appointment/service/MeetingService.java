/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.api.AppointmentServiceApi;
import com.hsbc.rbwm.ted.appointment.api.MeetingServiceApi;
import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.Set;

import static java.time.Duration.ofMillis;
import static java.time.Duration.ofMinutes;
import static java.util.Collections.emptySet;

/**
 * Created by 44052007 on 02/05/2018.
 */
@Service
public class MeetingService implements MeetingServiceApi {

    private final AppointmentServiceApi appointmentService;
    private final AppointmentConfiguration appointmentConfiguration;
    private final ClockProvider clockProvider;

    @Autowired
    public MeetingService(AppointmentServiceApi appointmentService, AppointmentConfiguration appointmentConfiguration, ClockProvider clockProvider) {
        this.appointmentService = appointmentService;
        this.appointmentConfiguration = appointmentConfiguration;
        this.clockProvider = clockProvider;
    }

    @Override
    public Flux<Meeting> getMeetings(String branchId, MeetingStatus meetingStatus, MeetingGroup meetingGroup) {
        return convertToMeetingsAndFilter(appointmentService.getAppointments(branchId, emptySet()), meetingStatus, meetingGroup);
    }

    @Override
    public Flux<Meeting> getNextWorkingDayMeetings(String branchId, MeetingStatus meetingStatus, MeetingGroup meetingGroup) {
        return convertToMeetingsAndFilter(appointmentService.getNextWorkingDayAppointments(branchId), meetingStatus, meetingGroup);
    }

    @Override
    public Mono<Meeting> getMeeting(String meetingId) {
        return appointmentService.getAppointment(meetingId).map(this::convertToMeeting);
    }

    @Override
    public Mono<Meeting> updateMeetingStatus(String meetingId, UpdateMeetingStatusInput updateMeetingStatusInput) {
        Mono<?> updateProofOfId = updateMeetingStatusInput.meetingStatus == MeetingStatus.CHECKED_IN ?
                appointmentService.updateProofOfId(meetingId, updateMeetingStatusInput.proofOfId):
                Mono.just(new Object());

        return updateProofOfId
                .then(appointmentService.updateAppointmentStatus(meetingId, AppointmentStatus.valueOf(updateMeetingStatusInput.meetingStatus.name())))
                .then(appointmentService.getAppointment(meetingId))
                .map(this::convertToMeeting);
    }

    private Flux<Meeting> convertToMeetingsAndFilter(Flux<Map<String, Object>> appointments, MeetingStatus meetingStatus, MeetingGroup meetingGroup) {
        return appointments
                .filter(appointment -> !AppointmentStatus.UNMAPPED.name().equals(appointment.get("appointmentStatus")))
                .map(this::convertToMeeting)
                .filter(meeting -> meetingStatus == null || meetingStatus.equals(meeting.status))
                .filter(meeting -> meetingGroup == null || meetingGroup.equals(meeting.group));
    }

    private Meeting convertToMeeting(Map<String, Object> appointment) {
        Map<String, Object> conductor = (Map<String, Object>) appointment.get("conductor");
        Employee employee = new Employee((String) conductor.get("employeeId"), (String) conductor.get("fullName"));

        Map<String, Object> attendee = (Map<String, Object>) appointment.get("attendee");
        Person person = new Person((String) attendee.get("firstName"), (String) attendee.get("lastName"),
                (String) attendee.get("email"), (String) attendee.get("phoneNumber"), (String) attendee.get("mobileNumber"),
                null);

        MeetingStatus meetingStatus = getMeetingStatus(appointment);
        return new Meeting(
                meetingStatus,
                getMeetingGroup(appointment),
                (String) appointment.get("appointmentId"),
                (String) appointment.get("topicId"),
                (String) appointment.get("topicName"),
                (String) appointment.get("topicCategoryId"),
                (String) appointment.get("topicCategoryName"),
                employee,
                formatDateTime((Long) appointment.get("dateTime"), (String) appointment.get("timezone")),
                formatDateTime((Long) appointment.get("checkedInAt"), (String) appointment.get("timezone")),
                formatDateTime((Long) appointment.get("startedAt"), (String) appointment.get("timezone")),
                formatDateTime((Long) appointment.get("endedAt"), (String) appointment.get("timezone")),
                ((Long) appointment.get("duration")).intValue(),
                isOverDue(appointment, meetingStatus, appointmentConfiguration.getOverdueOffset()),
                isOverDue(appointment, meetingStatus, appointmentConfiguration.getCriticalOverdueOffset()),
                isOverRun(appointment, meetingStatus, (Long) appointment.get("duration")),
                isOverRun(appointment, meetingStatus, (Long) appointment.get("duration") + appointmentConfiguration.getCriticalOverRunOffset()),
                person,
                (String) appointment.get("comments"),
                (Boolean) appointment.get("proofOfId"),
                getEndedBy(meetingStatus),
                (Set<String>) appointment.get("checklist"),
                (String) appointment.get("timezone"));
    }

    // We do not have batch process, with batch process we keep this info in appointment in mongo db
    private ModifierType getEndedBy(MeetingStatus meetingStatus) {
        if (meetingStatus == MeetingStatus.COMPLETED || meetingStatus == MeetingStatus.CANCELLED) {
            return ModifierType.USER;
        } else if (meetingStatus == MeetingStatus.NOSHOW) {
            return ModifierType.SYSTEM;
        } else {
            return null;
        }
    }

    private MeetingStatus getMeetingStatus(Map<String, Object> appointment) {
        if (AppointmentStatus.NEXT_DAY.name().equals(appointment.get("appointmentStatus"))) {
            return MeetingStatus.UPCOMING;
        } else if ((Boolean) appointment.get("isNoShow")) {
            return MeetingStatus.NOSHOW;
        } else if (!(Boolean) appointment.get("isNoShow") && AppointmentStatus.NOSHOW.name().equals(appointment.get("appointmentStatus"))) {
            return MeetingStatus.UPCOMING;
        } else {
            return MeetingStatus.valueOf((String) appointment.get("appointmentStatus"));
        }
    }

    private MeetingGroup getMeetingGroup(Map<String, Object> appointment) {
        if (AppointmentStatus.NEXT_DAY.name().equals(appointment.get("appointmentStatus"))) {
            return MeetingGroup.UPCOMING;
        } else if (AppointmentStatus.CANCELLED.name().equals(appointment.get("appointmentStatus")) || (Boolean) appointment.get("isNoShow")) {
            return MeetingGroup.COMPLETED;
        } else if (!(Boolean) appointment.get("isNoShow") && AppointmentStatus.NOSHOW.name().equals(appointment.get("appointmentStatus"))) {
            return MeetingGroup.UPCOMING;
        } else {
            return MeetingGroup.valueOf((String) appointment.get("appointmentStatus"));
        }
    }

    private String formatDateTime(Long dateTime, String timezone) {
        return dateTime != null ? AppointmentFunctions.toIsoFormat(dateTime, timezone) : null;
    }

    // It is true if meeting has at least been checked in and datetime is in past, it should have been started at datetime.
    private Boolean isOverDue(Map<String, Object> appointment, MeetingStatus meetingStatus, long offset) {
        Long dateTime = (Long) appointment.get("dateTime");
        Long currentTime = clockProvider.getUTCInstant().toEpochMilli();
        
        switch (meetingStatus) {
            case CHECKED_IN:
                return isElapsedTimeOverDuration(dateTime, currentTime, offset);
            case IN_MEETING:
            case COMPLETED:
                return isElapsedTimeOverDuration(dateTime, (Long) appointment.get("startedAt"), offset);
            case CANCELLED:
                return isElapsedTimeOverDuration(dateTime, (Long) appointment.get("endedAt"), offset);
            default:
                return false;
        }
    }

    // It is true if meeting takes X minutes longer then duration
    private Boolean isOverRun(Map<String, Object> appointment, MeetingStatus meetingStatus, long offset) {
        Long startedAt = (Long) appointment.get("startedAt");
        Long currentTime = clockProvider.getUTCInstant().toEpochMilli();

        switch (meetingStatus) {
            case IN_MEETING:
                return isElapsedTimeOverDuration(startedAt, currentTime, offset);
            case COMPLETED:
                return isElapsedTimeOverDuration(startedAt, (Long) appointment.get("endedAt"), offset);
            default:
                return false;
        }
    }

    private Boolean isElapsedTimeOverDuration(Long beginningTime, Long endingTime, long duration) {
        return beginningTime != null && endingTime != null && ofMillis(endingTime - beginningTime).compareTo(ofMinutes(duration)) > 0;
    }

}
