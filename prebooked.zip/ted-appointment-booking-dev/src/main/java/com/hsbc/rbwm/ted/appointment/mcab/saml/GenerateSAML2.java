/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.saml;


import com.hsbc.rbwm.ted.appointment.config.SamlConfiguration;
import org.joda.time.DateTime;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.impl.ResponseMarshaller;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.util.XMLHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Element;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;

import static java.util.Collections.singletonList;

@Component
public class GenerateSAML2 {

    private SamlAssertionProducer samlAssertionProducer;
    private SamlConfiguration samlConfiguration;

    @Autowired
    public GenerateSAML2(SamlAssertionProducer samlAssertionProducer, SamlConfiguration samlConfiguration) {
        this.samlAssertionProducer = samlAssertionProducer;
        this.samlConfiguration = samlConfiguration;
    }

    public String generate() {
        try {
            HashMap<String, List<String>> attributes = new HashMap<String, List<String>>();

            attributes.put("channelId", singletonList(samlConfiguration.getChannelId()));
            attributes.put("camLevel", singletonList(samlConfiguration.getCamLevel()));
            attributes.put("ipId", singletonList(samlConfiguration.getIpId()));
            attributes.put("secondaryUserId", singletonList(samlConfiguration.getSecondaryUserId()));

            Response responseInitial = samlAssertionProducer.createSAMLResponse(new DateTime(), attributes);

            ResponseMarshaller marshaller = new ResponseMarshaller();
            Element element = marshaller.marshall(responseInitial);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            XMLHelper.writeNode(element, baos);
            return new String(baos.toByteArray());
        } catch (MarshallingException e) {
            throw new RuntimeException(e);
        }
    }

}


