/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.model

import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.*

/**
 * Created by 43578876 on 20/09/2017.
 */
data class AppointmentInput(var customerId: String = "",
                            var branchId: String = "",
                            var dateTime: Long = 0,
                            var topicId: String = "",
                            var topicCategoryId: String = "",
                            var duration: Int = 60,
                            var countryCode: String = "GB",
                            var timezone: String = "Europe/London") {

        fun branchTopicId (): String = "branch_".plus(topicId)

        fun branchTopicCategoryId (): String = "branch_".plus(topicCategoryId)

        fun formattedDateTime(): String = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a 'UTC'", Locale.ENGLISH).format(
                LocalDateTime.ofInstant(Instant.ofEpochMilli(dateTime), ZoneId.of("UTC"))
        )

}