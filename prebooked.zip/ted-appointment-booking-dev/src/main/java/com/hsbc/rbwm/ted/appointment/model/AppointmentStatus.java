/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Arrays;
import java.util.Optional;

/**
 * Created by 43578876 on 16/11/2016.
 */
public enum AppointmentStatus {

    UPCOMING("UPCOMING","SCHEDULED"),
        NOSHOW("NOSHOW","NO_SHOW",UPCOMING),
    CHECKED_IN("CHECKED_IN","CHECKED_IN"),
        OVERDUE("OVERDUE","OVERDUE",CHECKED_IN),
    IN_MEETING("IN_MEETING","IN_PROGRESS"),
        OVERRUN("OVERRUN","OVERRUN",IN_MEETING),
    COMPLETED("COMPLETED","COMPLETED",null,NOSHOW),
    NEXT_DAY("NEXT_DAY",""),
    CANCELLED("CANCELLED",""),
    UNMAPPED("UNMAPPED","");

    private String code;
    private String mcabCode;
    private AppointmentStatus derivedStatus;
    private Optional<AppointmentStatus> childStatus;

    AppointmentStatus(String code,
                      String mcabCode,
                      AppointmentStatus derivedStatus,
                      AppointmentStatus childStatus
    ) {
        this.code = code;
        this.mcabCode = mcabCode;
        this.derivedStatus = derivedStatus;
        this.childStatus = childStatus!=null?Optional.of(childStatus): Optional.empty();
    }

    AppointmentStatus(String code,
                      String mcabCode,
                      AppointmentStatus derivedStatus) {
        this(code,mcabCode,derivedStatus,null);
    }

    AppointmentStatus(String code,
                      String mcabCode) {
        this(code,mcabCode,null,null);
    }

    @JsonCreator
    public static AppointmentStatus fromVal(@JsonProperty("appointmentStatus") String value) {
        return AppointmentStatus.valueOf(value);
    }

    public String getCode() {
        return code;
    }

    public String getMcabCode() {
        return mcabCode;
    }

    public static AppointmentStatus fromMcabCode(String mcabCode) {
        Optional<AppointmentStatus> status = Arrays.stream(AppointmentStatus.values())
                .filter(s -> s.getMcabCode().equals(mcabCode))
                .findFirst();

        return status.isPresent()?status.get(): AppointmentStatus.UNMAPPED;
    }
}
