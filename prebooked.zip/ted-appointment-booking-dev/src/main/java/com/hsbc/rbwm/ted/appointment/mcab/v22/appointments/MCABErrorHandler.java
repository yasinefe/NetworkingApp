/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.rbwm.ted.rest.api.ClientResponse;
import com.hsbc.rbwm.ted.rest.api.ClientRestTemplate;
import com.hsbc.rbwm.ted.rest.api.ErrorHandler;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.HttpRequestValues;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;

import javax.net.ssl.SSLHandshakeException;
import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

/**
 * Created by 44027117 on 19/06/2017.
 */
public class MCABErrorHandler implements ErrorHandler {
    private final ErrorResponse errorResponse;

    public MCABErrorHandler(ErrorResponse errorResponse) {
        this.errorResponse = errorResponse;
    }

    public String extractErrorMessage(HttpStatusCodeException httpStatusCodeException) {
        try {
            ClientResponse clientResponse = new ClientResponse(httpStatusCodeException.getResponseBodyAsString(),
                    httpStatusCodeException.getStatusCode().value(), httpStatusCodeException.getResponseHeaders());

            ObjectMapper e = new ObjectMapper();
            MCABErrorHandler.Response response = e.readValue((String)clientResponse.getBody(), MCABErrorHandler.Response.class);

            return response.reasons.stream()
                    .map(r -> r.description)
                    .collect(Collectors.joining(", "));

        } catch (IOException e) {
            throw new Exceptions.UnexpectedException(this.errorResponse.getUnexpectedErrorCode(), e, "Error extracting MCAB Response Error");
        }
    }

    @Override
    public ClientResponse handler(ClientRestTemplate clientRestTemplate, HttpRequestValues httpRequestValues) {
        try {
            return clientRestTemplate.doExchange(httpRequestValues.url, httpRequestValues.queryParams,
                    httpRequestValues.headers, httpRequestValues.body, httpRequestValues.httpMethod);

        } catch (ExecutionException | InterruptedException | RestClientException | NoSuchAlgorithmException | KeyManagementException e) {
            if((e.getCause() instanceof ConnectException) || (e.getCause() instanceof UnknownHostException) || (e.getCause() instanceof SSLHandshakeException) || (e.getCause() instanceof SocketTimeoutException)) {
                throw new Exceptions.NoConnectionException(this.errorResponse.getNotConnectionErrorCode(), e, httpRequestValues.url + " " + e.getMessage());
            } else {
                if (e instanceof HttpStatusCodeException) {
                    this.handleHttpStatusCodeException(httpRequestValues.url, (HttpStatusCodeException) e);
                }

                throw new Exceptions.UnexpectedException(this.errorResponse.getUnexpectedErrorCode(), e, httpRequestValues.url + " " + e.getMessage());
            }
        }
    }

    private void handleHttpStatusCodeException(String url, HttpStatusCodeException httpStatusCodeException) {
        switch (httpStatusCodeException.getStatusCode()) {
            case NOT_FOUND:
            case CONFLICT:
                throw new Exceptions.NotFoundException(this.errorResponse.getNotFoundErrorCode(), httpStatusCodeException, url);

            case INTERNAL_SERVER_ERROR:
                throw new Exceptions.APIException(this.errorResponse.getApiErrorCode(), httpStatusCodeException,
                        url + " " + extractErrorMessage(httpStatusCodeException));

            default:
                throw new Exceptions.UnexpectedException(errorResponse.getUnexpectedErrorCode(), httpStatusCodeException,
                        url + " " + httpStatusCodeException.getMessage());
        }
    }

    static class Reasons {
        public String code;
        public String description;
        @JsonIgnore
        public String trace;
        @JsonIgnore
        public String keys;
        @JsonIgnore
        public String values;
    }

    static class Response {
        public List<Reasons> reasons;
        public String responseCode;
    }
}
