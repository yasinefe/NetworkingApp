/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Created by 44052007 on 08/09/2017.
 */
public interface Appointments {

    @Document
    @EqualsAndHashCode
    class Appointment {

        @Id
        public final String appointmentId;
        public final Boolean proofOfId;
        public final Long createdAt;
        public final Long checkedInAt;
        public final Long startedAt;
        public final Long endedAt;

        @JsonCreator
        public Appointment(@JsonProperty("appointmentId") final String appointmentId,
                           @JsonProperty("proofOfId") final Boolean proofOfId,
                           @JsonProperty("createdAt") final Long createdAt,
                           @JsonProperty("checkedInAt") final Long checkedInAt,
                           @JsonProperty("startedAt") final Long startedAt,
                           @JsonProperty("endedAt") final Long endedAt) {

            this.appointmentId = appointmentId;
            this.proofOfId = proofOfId;
            this.createdAt = createdAt;
            this.checkedInAt = checkedInAt;
            this.startedAt = startedAt;
            this.endedAt = endedAt;
        }
    }

}
