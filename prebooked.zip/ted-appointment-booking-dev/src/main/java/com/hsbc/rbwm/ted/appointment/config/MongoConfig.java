/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.config;

import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.ReactiveMongoDatabaseFactory;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.SimpleReactiveMongoDatabaseFactory;

/**
 * Created by 43578876 on 21/02/2017.
 */
@Configuration
public class MongoConfig {

    @Value("${ted.appointment.mongo.hostname}")
    private String mongoHostname;

    @Value("${ted.appointment.mongo.port}")
    private String mongoPort;

    @Value("${ted.appointment.mongo.database}")
    private String mongoDb;

    @Value("${ted.appointment.mongo.userName}")
    private String userName;

    @Value("${ted.appointment.mongo.password}")
    private String password;

    @Value("${ted.appointment.mongo.collection.appointments}")
    private String appointmentsCollection;

    @Bean
    public MongoClient mongoClient() {
        return MongoClients.create(getConnectionUri());
    }

    @Bean
    public ReactiveMongoDatabaseFactory reactiveMongoDbFactory(MongoClient mongoClient) {
        return new SimpleReactiveMongoDatabaseFactory(mongoClient, mongoDb);
    }

    @Bean
    public ReactiveMongoTemplate reactiveMongoTemplate(ReactiveMongoDatabaseFactory mongoDbFactory) {
        return new ReactiveMongoTemplate(mongoDbFactory);
    }


    private String getConnectionUri() {
        return "mongodb://" + userName + ":"  + password + "@" + mongoHostname + ":" + mongoPort + "/" + mongoDb;
    }

    public String getAppointmentsCollection() {
        return appointmentsCollection;
    }
}
