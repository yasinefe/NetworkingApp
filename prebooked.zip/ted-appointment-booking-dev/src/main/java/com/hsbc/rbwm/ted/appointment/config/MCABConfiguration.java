/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.config;

import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.MCABErrorHandler;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.MCABHttpHeaderProvider;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.MCABSyncClientRestTemplate;
import com.hsbc.rbwm.ted.rest.api.CRUDRestBuilder;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.http.HttpErrorResponseBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Created by 43578876 on 15/06/2017.
 */
@Configuration
public class MCABConfiguration {

    @Value("${ted.appointment.mcab.hostName}")
    private String mcabHostName;

    @Value("${ted.appointment.mcab.base.uri}")
    private String mcabBaseUri;

    @Value("${ted.appointment.mcab.retrieve.appointments.uri}")
    private String mcabRetrieveAppointments;

    @Value("${ted.appointment.mcab.retrieve.appointment.uri}")
    private String mcabRetrieveAppointment;

    @Value("${ted.appointment.mcab.updateStatus.uri}")
    private String mcabUpdateStatus;

    @Value("${ted.appointment.mcab.create.appointment.uri}")
    private String mcabCreateAppointment;

    @Value("${ted.appointment.mcab.saml.enabled}")
    private Boolean samlEnabled;

    @Value("${ted.appointment.mcab.header.channelCC}")
    private String headerChannelCC;

    @Value("${ted.appointment.mcab.timeout.seconds}")
    private Integer mcabTimeOutSeconds;

    @Autowired
    private MCABHttpHeaderProvider mcabHttpHeaderProvider;

    @Autowired
    private MCABSyncClientRestTemplate mcabSyncClientRestTemplate;

    private static final String APP_ERROR_CODE_PREFIX = "ABP";

    public String getMcabRetrieveAppointments() {
        return this.mcabRetrieveAppointments;
    }

    public String getMcabRetrieveAppointment() {
        return this.mcabRetrieveAppointment;
    }

    public String getMcabUpdateStatus() {
        return this.mcabUpdateStatus;
    }

    public String getMcabCreateAppointment() {
        return this.mcabCreateAppointment;
    }

    public Boolean getSamlEnabled() {
        return samlEnabled;
    }

    public String getHeaderChannelCC() {
        return headerChannelCC;
    }

    public Integer getMcabTimeOutSeconds() {
        return mcabTimeOutSeconds;
    }

    public CRUDRestBuilder getMcabCRUDRestBuilder(String featureErrorCodePrefix) {
        ErrorResponse errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix(APP_ERROR_CODE_PREFIX)
                        .withFeatureErrorCodePrefix(featureErrorCodePrefix)
                        .build();

        return new CRUDRestBuilder()
                .withClientRestTemplate(mcabSyncClientRestTemplate)
                .addHttpHeaderProvider(mcabHttpHeaderProvider)
                .withErrorHandler(new MCABErrorHandler(errorsResponse))
                .withSSLActivated(true)
                .withHostname(mcabHostName + "/" + mcabBaseUri);
    }
}
