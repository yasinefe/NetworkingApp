/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.model.AppointmentFields;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.*;

/**
 * Created by 43578876 on 22/06/2017.
 */
@Component
public class Filters {

    interface FilterMap extends Predicate<Map<String, Object>> {}

    final Map<AppointmentStatus, Filters.FilterMap> postProcessingFilterMap = new HashMap();

    public final FilterMap isOverDueMap;

    /**
     *  Only applicable to IN_MEETING status
     */
    public final FilterMap isOverRun;

    public final FilterMap isSameDay;

    public final FilterMap isYesterday;

    public final FilterMap isNextDay;

    public final FilterMap isNextHour;

    @Autowired
    public Filters(AppointmentFunctions appointmentFunctions) {
        isOverDueMap = map -> mapByStatus.apply(AppointmentStatus.CHECKED_IN).test(map) && appointmentFunctions.isOverDue((Long) map.get(AppointmentFields.DATE_TIME.val()));
        isOverRun = map -> mapByStatus.apply(AppointmentStatus.IN_MEETING).test(map) && appointmentFunctions.isPassedDuration((Long) map.get(AppointmentFields.DATE_TIME.val()),
                ((Long) map.get(AppointmentFields.DURATION.val())).intValue());

        isSameDay = map -> appointmentFunctions.isSameDate(AppointmentFunctions.localDateOf((Long) map.get(DATE_TIME.val()), (String) map.get(TIMEZONE.val())), (String) map.get(TIMEZONE.val()));
        isNextDay = map -> appointmentFunctions.isSameDateWithOffset(AppointmentFunctions.localDateOf((Long) map.get(DATE_TIME.val()), (String) map.get(TIMEZONE.val())), (String) map.get(TIMEZONE.val()), 1);
        isNextHour = map -> appointmentFunctions.isInNextHour((Long) map.get(DATE_TIME.val()));
        isYesterday = map -> AppointmentFunctions.localDateOf((Long) map.get(DATE_TIME.val()), (String) map.get(TIMEZONE.val())).equals(appointmentFunctions.getYesterday((String) map.get(TIMEZONE.val())));

        postProcessingFilterMap.put(AppointmentStatus.NOSHOW, Filters.isNoShow);
        postProcessingFilterMap.put(AppointmentStatus.UPCOMING, isUpcoming);
        postProcessingFilterMap.put(AppointmentStatus.OVERDUE, isOverDueMap);
        postProcessingFilterMap.put(AppointmentStatus.COMPLETED, isCompleted);
        postProcessingFilterMap.put(AppointmentStatus.NEXT_DAY, isNextDay);
        postProcessingFilterMap.put(AppointmentStatus.OVERRUN, isOverRun);
    }

    public final static Function<AppointmentStatus, FilterMap> mapByStatus = status -> map ->  map.get(APPOINTMENT_STATUS.val()).equals(status.getCode());

    /**
     * DerIves NO SHOW Behaviour FROM THE IS_NOSHOW property ie derived from the actual duration no show property.
     */
    public final static FilterMap isNoShow = map -> map.containsKey(IS_NOSHOW.val()) && (Boolean) map.get(IS_NOSHOW.val());

    /**
     * Includes NOSHOW status that have not become isNoShow yet based on the property.
     */
    public final static FilterMap isUpcoming = map -> (mapByStatus.apply(AppointmentStatus.UPCOMING).test(map) || mapByStatus.apply(AppointmentStatus.NOSHOW).test(map)) && !isNoShow.test(map);

    /**
     * includes any NOSHOWS as well as COMPLETED
     */
    public final static FilterMap isCompleted = map -> mapByStatus.apply(AppointmentStatus.COMPLETED).test(map) || isNoShow.test(map);

    /**
     * includes any UPCOMING as well as CHECKED_IN
     */
    public final static FilterMap isWaiting = map -> isUpcoming.test(map) || mapByStatus.apply(AppointmentStatus.CHECKED_IN).test(map);
}
