package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.rest.http.SyncClientRestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

/**
 * Created by 44093684 on 23/02/2018.
 */
@Component
public class MCABSyncClientRestTemplate extends SyncClientRestTemplate {

    private final Integer mcabTimeOutSeconds;

    @Autowired
    public MCABSyncClientRestTemplate(MCABConfiguration mcabConfiguration) {
        this.mcabTimeOutSeconds = mcabConfiguration.getMcabTimeOutSeconds();
    }

    @Override
    public RestTemplate getRestTemplate() throws NoSuchAlgorithmException, KeyManagementException {
        HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
        httpRequestFactory.setConnectionRequestTimeout(mcabTimeOutSeconds * 1000);
        httpRequestFactory.setConnectTimeout(mcabTimeOutSeconds * 1000);
        httpRequestFactory.setReadTimeout(mcabTimeOutSeconds * 1000);

        return new RestTemplate(httpRequestFactory);
    }
}
