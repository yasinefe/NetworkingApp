package com.rbwm.ted.appointment.config;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

/**
 * Created by 44052007 on 16/05/2017.
 */
public class ConfigProvider {
    private static Config config;

    public static Config config() {
        if (config == null) {
            config = ConfigFactory.load();
            String env = config.getString("env");
            config = config.getConfig(env.toLowerCase()).withFallback(config);
        }
        return config;
    }
}
