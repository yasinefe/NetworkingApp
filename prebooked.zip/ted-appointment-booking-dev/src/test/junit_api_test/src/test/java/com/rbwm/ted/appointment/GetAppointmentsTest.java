/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.jayway.restassured.response.Response;
import org.json.JSONException;
import org.junit.Ignore;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;

import static com.jayway.restassured.RestAssured.given;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;

/**
 MCAB APPOINTMENTS RESPONSE
 --------------------------
 APP ID		lifeCycleState		dateTime
 VR8S1701	Scheduled			now + 36h
 VR8S1702	NoShow				now - 1m
 VR8S1703	Scheduled			now + 1h
 VR8S1704	CheckedIn			now + 15m
 VR8S1705	InProgress			now - 5m
 VR8S1706	Completed   		now - 10m

 VR8S1708	Scheduled			now - 30m
 VR8S1709	NoShow				now - 25m
 VR8S1710	CheckedIn			now - 1h
 VR8S1711	InProgress			now - 15m
 VR8S1712	Completed   		now - 3h
 VR8S1713	Completed   		now - 32h
 VR8S1714	InProgress			now - 2h		duration: 30


 APPOINTMENT BOOKING RESULTS
 ---------------------------

 UPCOMING
 ----------
 VR8S1703	isNoShow=false
 VR8S1708   isNoShow=true
 VR8S1709   isNoShow=true

 NOSHOW
 ----------
 VR8S1708	isNoShow=true
 VR8S1709	isNoShow=true

 CHECKED_IN includes OVERDUE
 ----------
 VR8S1704
 VR8S1710

 OVERDUE
 ----------
 VR8S1710

 IN_MEETING includes OVERRUN
 ----------
 VR8S1705
 VR8S1711
 VR8S1714

 OVERRUN
 ----------
 VR8S1714

 COMPLETED inludes NOSHOW
 ----------
 VR8S1706
 VR8S1712
 VR8S1713
 VR8S1708	isNoShow=true
 VR8S1709	isNoShow=true

 PROBLEM
 VR8S1712
 VR8S1713

 NEXT_DAY
 ----------
 VR8S1701

 */
public class GetAppointmentsTest extends IntegrationTest {


    @Test
    public void testGetAppointmentsForUpComing() throws Exception {
        callAndAssert("UPCOMING", "responses/get-upcoming-appointments.json");
    }

    @Test
    public void testGetAppointmentsForCheckedIn() throws Exception {
        callAndAssert("CHECKED_IN", "responses/get-checked-in-appointments.json");
    }

    @Test
    public void testGetAppointmentsForNoShow() throws Exception {
        callAndAssert("NOSHOW", "responses/get-noshow-appointments.json");
    }

    @Test
    public void testGetAppointmentsForOverdue() throws Exception {
        callAndAssert("OVERDUE", "responses/get-overdue-appointments.json");
    }

    @Test
    public void testGetAppointmentsForInMeeting() throws Exception {
        callAndAssert("IN_MEETING", "responses/get-in-meeting-appointments.json");
    }

    @Test
    @Ignore
    public void testGetAppointmentsForOverrun() throws Exception {
        //NOTE WE DON'T RETURN ANY OVERRUN APPOINTMENTS HERE AS OVERRUN IS A SUBSET OF EVERYTHING THAT IS IN MEETING (f.e ONLY requests IN_MEETING )
        callAndAssert("OVERRUN", "responses/get-overrun-appointments.json");
    }

    @Test
    public void testGetAppointmentsForCompleted() throws Exception {
        callAndAssert("COMPLETED", "responses/get-completed-appointments.json");
    }

    @Test
    public void testGetAppointmentsForNextDay() throws Exception {
        callAndAssert("NEXT_DAY", "responses/get-next-day-appointments.json");
    }

    private void callAndAssert(String appointmentStatus, String responseFileName) throws JSONException {

        Response response = given()
                .when()
                .get(config.getString("appointmentPath") + "/list/404519?status=" + appointmentStatus)
                .then()
                .extract().response();

        assertThat(response.getStatusCode(), is(SC_OK));
        // dateTime has skipped for assertion as it is dynamic
        assertEquals(getFileContent(responseFileName), response.asString(), JSONCompareMode.LENIENT);
    }
}
