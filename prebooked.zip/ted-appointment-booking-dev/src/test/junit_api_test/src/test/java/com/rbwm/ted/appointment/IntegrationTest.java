/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.rbwm.ted.appointment.config.ConfigProvider;
import com.typesafe.config.Config;
import org.junit.Before;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

import static com.jayway.restassured.RestAssured.basePath;
import static com.jayway.restassured.RestAssured.baseURI;

public class IntegrationTest {

    Config config;
    private String host = System.getenv("FULL_HOST_URL");

    @Before
    public void setUp() throws Exception {
        config = ConfigProvider.config();
        if (host == null || host.isEmpty()) {
            host = config.getString("baseUri");
        }
        baseURI = host;
        basePath = config.getString("basePath");
    }

    String getFileContent(String fileName) {
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource(fileName);
        try {
            return new String(Files.readAllBytes(Paths.get(path.toURI())));
        } catch (IOException | URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }
}
