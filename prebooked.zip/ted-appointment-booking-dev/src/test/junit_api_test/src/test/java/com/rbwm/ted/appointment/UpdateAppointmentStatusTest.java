/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.appointment;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;

import static com.jayway.restassured.RestAssured.given;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;

public class UpdateAppointmentStatusTest extends IntegrationTest {

    @Test
    public void testUpdateAppointmentStatus() throws Exception {
        Response response = given()
                .when()
                .body("{ \"appointmentStatus\": \"CHECKED_IN\" }")
                .contentType(ContentType.JSON)
                .put(config.getString("appointmentPath") + "/VC8L4N63")
                .then()
                .extract().response();

        assertThat(response.getStatusCode(), is(SC_OK));
        // dateTime has skipped for assertion as it is dynamic
        assertEquals("{ \"appointmentId\": \"VC8L4N63\" }", response.asString(), JSONCompareMode.LENIENT);
    }

}
