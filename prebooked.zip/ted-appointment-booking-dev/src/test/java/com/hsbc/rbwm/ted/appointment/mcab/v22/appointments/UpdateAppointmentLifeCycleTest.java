/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.config.SamlConfiguration;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static java.lang.String.format;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by 44052007 on 23/06/2017.
 */
public class UpdateAppointmentLifeCycleTest {

    private static final String APPOINTMENT_ID = "VC8L4N63";
    private static final AppointmentStatus APPOINTMENT_STATUS = AppointmentStatus.CHECKED_IN;
    private UpdateAppointmentLifeCycle updateAppointmentLifeCycle;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private MCABConfiguration mcabConfiguration = new MCABConfiguration();

    private SamlConfiguration samlConfiguration = new SamlConfiguration();

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(mcabConfiguration, "mcabHostName", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(mcabConfiguration, "mcabBaseUri", "/mcabBaseUri");
        ReflectionTestUtils.setField(mcabConfiguration, "mcabUpdateStatus", "/updateAppointmentLifeCycle");
        ReflectionTestUtils.setField(mcabConfiguration, "samlEnabled", Boolean.FALSE);
        ReflectionTestUtils.setField(mcabConfiguration, "headerChannelCC", "GB");
        ReflectionTestUtils.setField(mcabConfiguration, "mcabTimeOutSeconds", 5);
        ReflectionTestUtils.setField(mcabConfiguration, "mcabHttpHeaderProvider", new MCABHttpHeaderProvider(null, mcabConfiguration, samlConfiguration));
        ReflectionTestUtils.setField(mcabConfiguration, "mcabSyncClientRestTemplate", new MCABSyncClientRestTemplate(mcabConfiguration));

        updateAppointmentLifeCycle = new UpdateAppointmentLifeCycle(mcabConfiguration, new ResponseHandler(), new UpdateAppointmentTransformer());

        CorrelationIdContainer.setId("test-correlation-id");
    }

    @Test
    public void testUpdateAppointments() throws Exception {
        String jsonRequest = format("{\"appointmentIdentifier\":\"%s\", \"apptLifeCycleState\":\"%s\"}", APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());
        String jsonResponse = format("{\"reasons\":[],\"extension\":{},\"appointmentIdentifier\":\"%s\"}", APPOINTMENT_ID);

        stubFor(post(urlPathEqualTo("/mcabBaseUri/updateAppointmentLifeCycle"))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        Map<String, Object> updateResponse = updateAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        assertTrue(updateResponse != null);
        assertEquals(APPOINTMENT_ID, updateResponse.get("appointmentId"));
    }

    @Test(expected = Exceptions.APIException.class)
    public void testUpdateAppointmentsWhenMcabThrowsApiException() throws Exception {
        String jsonRequest = format("{\"appointmentIdentifier\":\"%s\", \"apptLifeCycleState\":\"%s\"}", APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());
        String jsonResponse = format("{ \"reasons\": [ { \"code\": \"8\", \"description\": \"Appointment State cannot be updated\", \"trace\": [], \"keys\": [], \"values\": [] } ], \"responseCode\": \"500\" }", APPOINTMENT_ID);

        stubFor(post(urlPathEqualTo("/mcabBaseUri/updateAppointmentLifeCycle"))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(500)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        try {
            updateAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        } catch (Exceptions.APIException e) {
            assertEquals("ABP-UPDATE-APPOINTMENT-API", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.UnexpectedException.class)
    public void testUpdateAppointmentsWhenMcabThrowsUnexpectedException() throws Exception {
        String jsonRequest = format("{\"appointmentIdentifier\":\"%s\", \"apptLifeCycleState\":\"%s\"}", APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());
        String jsonResponse = format("{ \"reasons\": [ { \"code\": \"8\", \"description\": \"Appointment State cannot be updated\", \"trace\": [], \"keys\": [], \"values\": [] } ], \"responseCode\": \"403\" }", APPOINTMENT_ID);

        stubFor(post(urlPathEqualTo("/mcabBaseUri/updateAppointmentLifeCycle"))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(403)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        try {
            updateAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        } catch (Exceptions.UnexpectedException e) {
            assertEquals("ABP-UPDATE-APPOINTMENT-UNEXPECTED", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void testUpdateAppointmentsResourceNotFound() throws Exception {
        String jsonRequest = format("{\"appointmentIdentifier\":\"%s\", \"apptLifeCycleState\":\"%s\"}", APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());

        stubFor(post(urlPathEqualTo("/mcabBaseUri/updateAppointmentLifeCycle"))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(404)));

        try {
            updateAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        } catch (Exceptions.NotFoundException e) {
            assertEquals("ABP-UPDATE-APPOINTMENT-NOT-FOUND", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.NoConnectionException.class)
    public void testMCABResponseHasTimedOut() throws Exception {
        ReflectionTestUtils.setField(mcabConfiguration, "mcabTimeOutSeconds", 1);
        ReflectionTestUtils.setField(mcabConfiguration, "mcabSyncClientRestTemplate", new MCABSyncClientRestTemplate(mcabConfiguration));
        updateAppointmentLifeCycle = new UpdateAppointmentLifeCycle(mcabConfiguration, new ResponseHandler(), new UpdateAppointmentTransformer());

        String jsonRequest = format("{\"appointmentIdentifier\":\"%s\", \"apptLifeCycleState\":\"%s\"}", APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());
        String jsonResponse = format("{\"reasons\":[],\"extension\":{},\"appointmentIdentifier\":\"%s\"}", APPOINTMENT_ID);

        stubFor(post(urlPathEqualTo("/mcabBaseUri/updateAppointmentLifeCycle"))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withFixedDelay(1100) //over timeout
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        try {
            updateAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        } catch (Exceptions.NoConnectionException e) {
            assertEquals("ABP-UPDATE-APPOINTMENT-NO-CONNECTION", e.getErrorCode().code);
            throw e;
        }
    }



}
