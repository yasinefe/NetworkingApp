/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.config;

import com.hsbc.rbwm.ted.rest.error.ErrorCode;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by 44027117 on 21/06/2017.
 */
public class ControllerExceptionHandlerTest {
    ControllerExceptionHandler controllerExceptionHandler;

    @Before
    public void setUp() {
        controllerExceptionHandler = new ControllerExceptionHandler();
    }

    @Test
    public void testServerException() {
        ErrorCode errorCode = new ErrorCode("ErrorCode", "This is a test");
        Exceptions.NotFoundException notFoundException = new Exceptions.NotFoundException(errorCode, new RuntimeException(), "/test");
        ResponseEntity responseEntity = controllerExceptionHandler.serverException(notFoundException);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        Map body = (Map) responseEntity.getBody();
        ErrorCode errorCodeResponse = (ErrorCode) body.get("error");
        assertEquals("ErrorCode", errorCodeResponse.code);
        assertEquals("This is a test", errorCodeResponse.message);
    }

    @Test
    public void testUncheckedException() {
        Exceptions.UnexpectedException notFoundException = new Exceptions.UnexpectedException(null, new RuntimeException(), "/test");
        ResponseEntity responseEntity = controllerExceptionHandler.throwable(notFoundException);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        Map body = (Map) responseEntity.getBody();
        ErrorCode errorCodeResponse = (ErrorCode) body.get("error");
        assertEquals("ErrorCode", errorCodeResponse.code);
        assertEquals("Unchecked Exception" ,errorCodeResponse.message);
    }
}
