/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.api.MeetingStatsServiceApi;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.appointment.model.MeetingStats;
import com.hsbc.rbwm.ted.appointment.model.StatData;
import org.junit.Test;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static java.util.Arrays.asList;
import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Flux.empty;
import static reactor.core.publisher.Flux.fromIterable;

/**
 * Created by 44052007 on 22/05/2018.
 */
public class MeetingStatsServiceTest {

    public static final String BRANCH_ID = "400296";
    private ZonedDateTime time = LocalDateTime.of(2018, 5, 1, 11, 23, 45, 175).atZone(ZoneId.of("UTC"));
    private ClockProvider clockProvider = new ClockProvider(Clock.fixed(time.toInstant(), ZoneId.of("UTC")));
    private AppointmentService mockAppointmentService = mock(AppointmentService.class);

    private MeetingStatsServiceApi meetingStatsServiceApi = new MeetingStatsService(mockAppointmentService, clockProvider);

    @Test
    public void shouldReturnMeetingStatsWithZeroWhenThereIsNoAppointments() throws Exception {
        when(mockAppointmentService.getAppointments(BRANCH_ID, Collections.emptySet())).thenReturn(empty());
        when(mockAppointmentService.getYesterdayAppointments(BRANCH_ID, Collections.emptySet())).thenReturn(empty());

        MeetingStats expectedMeetingStats = new MeetingStats(
                new StatData(0, 0L),
                new StatData(0, 0L),
                new StatData(0, 0L),
                0);
        MeetingStats meetingStats = meetingStatsServiceApi.getMeetingStats(BRANCH_ID).block();

        assertEquals(expectedMeetingStats, meetingStats);
    }

    @Test
    public void shouldReturnMeetingStats() throws Exception {
        // Waiting time 1 min so far, meeting length is not available
        Map<String, Object> checkedInAppointment = createAppointment(AppointmentStatus.CHECKED_IN, minsBefore(1), minsAfter(4), null, null);
        // Waiting time 10 mins so far, meeting length is not available
        Map<String, Object> overdueAppointment = createAppointment(AppointmentStatus.CHECKED_IN, minsBefore(10), minsBefore(5), null, null);
        // Waiting time was 7 mins, meeting length is not available
        Map<String, Object> inMeetingAppointment = createAppointment(AppointmentStatus.IN_MEETING, minsBefore(20), minsBefore(15), minsBefore(13), null);
        // Waiting time was 9 mins, meeting length 18 mins
        Map<String, Object> completedAppointment = createAppointment(AppointmentStatus.COMPLETED, minsBefore(30), minsBefore(25), minsBefore(21), minsBefore(3));
        // Waiting time is not available, meeting length is not available
        Map<String, Object> completedAppointmentWithoutCheckedInAtAndStartedAt = createAppointment(AppointmentStatus.COMPLETED, null, minsBefore(25), null, minsBefore(2));
        // Waiting time is not available, meeting length is not available
        Map<String, Object> completedAppointmentWithoutCheckedInAtAndEndedAt = createAppointment(AppointmentStatus.COMPLETED, null, minsBefore(25), minsBefore(21), null);
        // Waiting time was 3 mins, meeting length is not available
        Map<String, Object> cancelledAppointment = createAppointment(AppointmentStatus.CANCELLED, minsBefore(10), minsBefore(5), null, minsBefore(7));

        MeetingStats expectedMeetingStats = new MeetingStats(
                new StatData(5, TimeUnit.MINUTES.toMillis(30)),
                new StatData(5, TimeUnit.MINUTES.toMillis(30)),
                new StatData(1, TimeUnit.MINUTES.toMillis(18)),
                1);

        when(mockAppointmentService.getAppointments(BRANCH_ID, Collections.emptySet()))
                .thenReturn(fromIterable(asList(checkedInAppointment, overdueAppointment, inMeetingAppointment, completedAppointment,
                        completedAppointmentWithoutCheckedInAtAndStartedAt, completedAppointmentWithoutCheckedInAtAndEndedAt,
                        cancelledAppointment)));
        when(mockAppointmentService.getYesterdayAppointments(BRANCH_ID, Collections.emptySet()))
                .thenReturn(fromIterable(asList(checkedInAppointment, overdueAppointment, inMeetingAppointment, completedAppointment,
                        completedAppointmentWithoutCheckedInAtAndStartedAt, completedAppointmentWithoutCheckedInAtAndEndedAt,
                        cancelledAppointment)));

        MeetingStats meetingStats = meetingStatsServiceApi.getMeetingStats(BRANCH_ID).block();

        assertEquals(expectedMeetingStats, meetingStats);
    }

    private Long minsBefore(int min) {
        return minsAfter(-1 * min);
    }

    private Long minsAfter(int min) {
        return time.toInstant().plus(min, ChronoUnit.MINUTES).toEpochMilli();
    }

    private Map<String, Object> createAppointment(AppointmentStatus appointmentStatus, Long checkedInAt,
                                     Long dateTime, Long startedAt, Long endedAt) {
        Map<String, Object> appointment = new HashMap<>();

        appointment.put("appointmentStatus", appointmentStatus);
        appointment.put("checkedInAt", checkedInAt);
        appointment.put("dateTime", dateTime);
        appointment.put("startedAt", startedAt);
        appointment.put("endedAt", endedAt);

        return appointment;
    }

}