/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment

import java.util

import com.hsbc.rbwm.ted.appointment.model._
import org.mockito.Mockito._
import org.springframework.http.HttpStatus
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import reactor.core.publisher.{Flux, Mono}

/**
  * Created by 44052007 on 02/05/2018.
  */
class MeetingControllerTest  extends ControllerTest {

  def meetingResponse =
    """
      {
        "status": "IN_MEETING",
        "group": "IN_MEETING",
        "meetingId": "meetingId",
        "topicId": "topicId",
        "topicName": "topicName",
        "topicCategoryId": "topicCategoryId",
        "topicCategoryName": "topicCategoryName",
        "conductor": {
          "employeeId": "employeeId",
          "fullName": "fullName"
        },
        "bookedFor": "2018-05-01T12:20:45.000+0100",
        "checkedInAt": "2018-05-01T12:20:45.000+0100",
        "startedAt": "2018-05-01T12:20:45.000+0100",
        "endedAt": "2018-05-01T12:20:45.000+0100",
        "duration": 15,
        "isOverdue": true,
        "isOverdueCritical": true,
        "isOverrun": true,
        "isOverrunCritical": true,
        "attendee": {
          "firstName": "firstName",
          "lastName": "lastName",
          "email": "email",
          "phoneNumber": "pnoneNumber",
          "mobileNumber": "mobileNumber",
          "gender": "gender"
        },
        "comments": "comments",
        "proofOfId": true,
        "endedBy": "USER",
        "checklist": ["proofOfId", "proofOfIncome"],
        "timezone": "Europe/London"
      }
    """.stripMargin

  def meetingsResponse = "[" + meetingResponse + "]"


  val person = new Person("firstName", "lastName", "email", "pnoneNumber", "mobileNumber", "gender")
  val employee = new Employee("employeeId", "fullName")
  val checklist = new util.LinkedHashSet[String]()
  checklist.add("proofOfId")
  checklist.add("proofOfIncome")

  val meeting = new Meeting(MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING, "meetingId", "topicId", "topicName",
    "topicCategoryId", "topicCategoryName", employee, "2018-05-01T12:20:45.000+0100",
    "2018-05-01T12:20:45.000+0100", "2018-05-01T12:20:45.000+0100", "2018-05-01T12:20:45.000+0100", 15, true, true,
    true, true, person, "comments", true, ModifierType.USER, checklist, "Europe/London")

  val meetings = new java.util.ArrayList[Meeting]
  meetings.add(meeting)

  it should " return all meetings " in {
    when(meetingService.getMeetings("400123", null, null)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return meetings filtered by meeting status " in {
    when(meetingService.getMeetings("400123", MeetingStatus.IN_MEETING, null)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123?meetingStatus=IN_MEETING", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return meetings filtered by meeting group " in {
    when(meetingService.getMeetings("400123", null, MeetingGroup.IN_MEETING)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123?meetingGroup=IN_MEETING", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return next working day meetings " in {
    when(meetingService.getNextWorkingDayMeetings("400123", null, null)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123/nextWorkingDay", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return next working day meetings filtered by meeting status " in {
    when(meetingService.getNextWorkingDayMeetings("400123", MeetingStatus.IN_MEETING, null)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123/nextWorkingDay?meetingStatus=IN_MEETING", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return next working day meetings filtered by meeting group " in {
    when(meetingService.getNextWorkingDayMeetings("400123", null, MeetingGroup.IN_MEETING)).thenReturn(Flux.fromIterable(meetings))
    doGetAsync("/meetings/branchId/400123/nextWorkingDay?meetingGroup=IN_MEETING", HttpStatus.OK)
      .andExpect(content.json(meetingsResponse))
  }

  it should " return meeting " in {
    when(meetingService.getMeeting("meetingId")).thenReturn(Mono.just(meeting))
    doGetAsync("/meetings/meetingId", HttpStatus.OK)
      .andExpect(content.json(meetingResponse))
  }

  it should " update meeting status with proof of id " in {
    val updateMeetingStatusInput = new UpdateMeetingStatusInput(MeetingStatus.CHECKED_IN, true)
    when(meetingService.updateMeetingStatus("meetingId", updateMeetingStatusInput)).thenReturn(Mono.just(meeting))

    val request =
      """
      {
        "meetingStatus": "CHECKED_IN",
        "proofOfId": true
      }
      """.stripMargin


    doPutAsync("/meetings/meetingId", HttpStatus.OK, request)
      .andExpect(content.json(meetingResponse))
  }

  it should " update meeting status without proof of id " in {
    val updateMeetingStatusInput = new UpdateMeetingStatusInput(MeetingStatus.IN_MEETING, null)
    when(meetingService.updateMeetingStatus("meetingId", updateMeetingStatusInput)).thenReturn(Mono.just(meeting))

    val request =
      """
      {
        "meetingStatus": "IN_MEETING"
      }
      """.stripMargin


    doPutAsync("/meetings/meetingId", HttpStatus.OK, request)
      .andExpect(content.json(meetingResponse))
  }

  it should " return meeting stats " in {
    def statsResponse =
      """
      {
        "waitingTime": {
          "count": 1,
          "sum": 2
        },
        "waitingTimeLastWorkingDay": {
           "count": 3,
           "sum": 4
        },
        "meetingLength": {
           "count": 5,
           "sum": 6
        },
        "inNextHour": 7
      }
      """.stripMargin

    when(meetingStatsService.getMeetingStats("400123")).thenReturn(Mono.just(new MeetingStats(new StatData(1, 2L), new StatData(3, 4L), new StatData(5, 6L), 7)))
    doGetAsync("/meetings/stats/branchId/400123", HttpStatus.OK)
      .andExpect(content.json(statsResponse))
  }
}
