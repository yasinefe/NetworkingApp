/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.rbwm.ted.appointment.model.CheckListContainer;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.Collections;
import java.util.Set;

import static org.junit.Assert.*;

/**
 * Created by 44027117 on 31/07/2017.
 */
public class CheckListServiceTest {
    AppointmentMetaService checkListService;

    @Before
    public void setTup() throws IOException {
        checkListService = new AppointmentMetaService(new CheckListContainer(new ObjectMapper()));
    }

    @Test
    public void testFindChecklist() {
        Set<String> checkList =
                checkListService.findChecklist("mortgages", "purchase_a_property_decision_in_principle");

        assertEquals(8, checkList.size());
        assertTrue(checkList.contains("Proof of ID"));
        assertTrue(checkList.contains("3 months bank statements"));
        assertTrue(checkList.contains("3 months payslips"));
        assertTrue(checkList.contains("details of any unsecured lending"));
        assertTrue(checkList.contains("Evidence of deposit amount"));
        assertTrue(checkList.contains("Details of monthly outgoings"));
        assertTrue(checkList.contains("Property details"));
    }

    @Test
    public void testFindChecklistNotFound() {
        assertEquals(Collections.emptySet(), checkListService.findChecklist("mortgages", "notFound"));
        assertEquals(Collections.emptySet(), checkListService.findChecklist("notFound", "purchase_a_property_decision_in_principle"));
        assertEquals(Collections.emptySet(), checkListService.findChecklist("notFound", "notFound"));
    }
}