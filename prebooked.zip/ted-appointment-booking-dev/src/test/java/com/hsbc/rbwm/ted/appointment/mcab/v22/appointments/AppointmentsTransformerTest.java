/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.service.AppointmentFunctions;
import com.hsbc.rbwm.ted.appointment.service.ClockProvider;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import reactor.core.publisher.Flux;

import java.io.File;
import java.io.FileReader;
import java.util.Map;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.*;
import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by 43578876 on 15/06/2017.
 */
public class AppointmentsTransformerTest {

    private AppointmentsTransformer appointmentTransformer;

    private ResponseHandler<Map<String,Object>> responseHandler = new ResponseHandler<>();

    private AddCustomFields addCustomFields;

    private AppointmentFunctions functions = new AppointmentFunctions(new ClockProvider(), new AppointmentConfiguration());

    @Mock
    private AppointmentConfiguration config;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
        when(config.getNoShowDuration()).thenReturn(30);
        when(config.getCriticalOverdueOffset()).thenReturn(10);
        addCustomFields = new AddCustomFields(config, functions);
        appointmentTransformer = new AppointmentsTransformer(addCustomFields);
    }

    private Flux<Map<String,Object>> getAppointmentsFromFile() throws Exception {
        String fileName = "mock-data/mcab/2.3.1/retrieve-appointments-response.json";
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(fileName).getFile());
        FileReader reader = new FileReader(file);

        return appointmentTransformer.parseListResponse(
                responseHandler.extractBody(reader));

    }

    @Test
    public void parseListResponse() throws Exception {

        Flux<Map<String,Object>> allAppointments = getAppointmentsFromFile();

        Map<String,Object> appointment = allAppointments.blockFirst();

        assertEquals(1498118400000L ,appointment.get("dateTime"));

        assertEquals("Europe/London" ,appointment.get("timezone"));
        assertEquals(30L, appointment.get("duration"));
        assertEquals("VK8D4198" ,appointment.get(APPOINTMENT_ID.val()));
        assertEquals("CHECKED_IN" ,appointment.get(APPOINTMENT_STATUS.val()));

        assertEquals("404519" ,appointment.get("locationId"));
        assertEquals("insurance" ,appointment.get("topicId"));
        assertEquals("home_insurance_standalone" ,appointment.get("topicCategoryId"));
        assertEquals("10" ,appointment.get(CRITICAL_OVERDUE_OFFSET.val()));
        //assertEquals("8",appointment.get(OVERRUN_OFFSET.val()));
        assertEquals("30" ,appointment.get(NO_SHOW_DURATION.val()));

        //assert on attendee
        Map<String,Object> attendee = (Map<String,Object>) appointment.get("attendee");
        assertEquals("Narendra" ,attendee.get("firstName"));
        assertEquals("Bangal" ,attendee.get("lastName"));
        assertEquals("ravindrapowar1@gmail.com" ,attendee.get("email"));
        assertEquals("+44 7400 123456" ,attendee.get(PHONE_NUMBER.val()));

        Map<String,Object> appointmentContact = (Map<String,Object>) attendee.get("appointmentContact");
        assertFalse(appointmentContact.containsKey("email"));

        //assert on conductor
        Map<String,Object> conductor = (Map<String,Object>) appointment.get("conductor");
        assertEquals("04942752" ,conductor.get("employeeId"));
        assertEquals("LAURA EGGLESTON" ,conductor.get("fullName"));

        //12 appontments in total 5 upcoming / 7 past
        //12 are current day in both buckets
        assertEquals(new Long(12), allAppointments.count().block());
    }

    @Test
    public void parseListResponseRunAsNextDay() throws Exception {

        Flux<Map<String,Object>> allAppointments = getAppointmentsFromFile();
        assertEquals(new Long(12), allAppointments.count().block());
    }
}