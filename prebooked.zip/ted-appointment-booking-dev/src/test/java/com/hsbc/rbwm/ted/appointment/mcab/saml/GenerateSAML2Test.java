package com.hsbc.rbwm.ted.appointment.mcab.saml;

import com.hsbc.rbwm.ted.appointment.config.SamlConfiguration;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.opensaml.Configuration;
import org.opensaml.saml2.core.Response;
import org.opensaml.xml.parse.ParserPool;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by 44052007 on 06/09/2017.
 */
public class GenerateSAML2Test {

    private GenerateSAML2 generateSAML2;

    private SamlConfiguration samlConfiguration = new SamlConfiguration();

    @Before
    public void setUp() throws Exception {
        ReflectionTestUtils.setField(samlConfiguration, "channelId", "TED");
        ReflectionTestUtils.setField(samlConfiguration, "camLevel", "40");
        ReflectionTestUtils.setField(samlConfiguration, "ipId", "192.167.12.2");
        ReflectionTestUtils.setField(samlConfiguration, "secondaryUserId", "hsbc");
        ReflectionTestUtils.setField(samlConfiguration, "issuer", "ted");
        ReflectionTestUtils.setField(samlConfiguration, "subject", "mcab");
        ReflectionTestUtils.setField(samlConfiguration, "keyStorePassword", "changeit");
        ReflectionTestUtils.setField(samlConfiguration, "expiration", 432000);
        ReflectionTestUtils.setField(samlConfiguration, "certFile", "tedmcab.cert");
        ReflectionTestUtils.setField(samlConfiguration, "keyStoreFile", "tedmcab.jks");
        ReflectionTestUtils.setField(samlConfiguration, "keyAlias", "ted-mcab");

        CertManager certManager = new CertManager(samlConfiguration);
        SamlAssertionProducer samlAssertionProducer = new SamlAssertionProducer(samlConfiguration, certManager);
        generateSAML2 = new GenerateSAML2(samlAssertionProducer, samlConfiguration);

    }

    @Test
    public void generateSaml2() throws Exception {
        String samlToken = generateSAML2.generate();
        assertNotNull(samlToken);
        assertTrue(samlToken.contains("<saml2:AttributeValue xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"xs:string\">TED</saml2:AttributeValue>"));
    }

    @Test(expected = RuntimeException.class)
    public void testMarshallerExceptionWillNotBeThrown() throws Exception {
        Configuration.setParserPool(mock(ParserPool.class));
        SamlAssertionProducer samlAssertionProducer = mock(SamlAssertionProducer.class);
        generateSAML2 = new GenerateSAML2(samlAssertionProducer, samlConfiguration);
        when(samlAssertionProducer.createSAMLResponse(any(DateTime.class), anyMap())).thenReturn(mock(Response.class));
        generateSAML2.generate();
    }
}