/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.V23.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.config.SamlConfiguration;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.MCABHttpHeaderProvider;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.MCABSyncClientRestTemplate;
import org.springframework.test.util.ReflectionTestUtils;

/**
 * Created by 43578876 on 08/11/2017.
 */
public class MCABConfigurationTestBuilder {

    private SamlConfiguration samlConfiguration = new SamlConfiguration();
    private final MCABConfiguration mcabConfiguration = new MCABConfiguration();

    public MCABConfiguration build(WireMockRule wireMockRule) {
        ReflectionTestUtils.setField(mcabConfiguration, "mcabHostName", "http://localhost:" + wireMockRule.port());
        ReflectionTestUtils.setField(mcabConfiguration, "mcabBaseUri", "/mcabBaseUri");
        ReflectionTestUtils.setField(mcabConfiguration, "mcabRetrieveAppointments", "/retrieveAppointments");
        ReflectionTestUtils.setField(mcabConfiguration, "mcabUpdateStatus", "/changeAppointmentLifeCycleStatus");
        ReflectionTestUtils.setField(mcabConfiguration, "mcabRetrieveAppointment", "/retrieveAppointment");
        ReflectionTestUtils.setField(mcabConfiguration, "mcabCreateAppointment", "/createAppointment");
        ReflectionTestUtils.setField(mcabConfiguration, "samlEnabled", Boolean.FALSE);
        ReflectionTestUtils.setField(mcabConfiguration, "headerChannelCC", "GB");
        ReflectionTestUtils.setField(mcabConfiguration, "mcabTimeOutSeconds", 5);
        ReflectionTestUtils.setField(mcabConfiguration, "mcabHttpHeaderProvider", new MCABHttpHeaderProvider(null, mcabConfiguration, samlConfiguration));
        ReflectionTestUtils.setField(mcabConfiguration, "mcabSyncClientRestTemplate", new MCABSyncClientRestTemplate(mcabConfiguration));
        return mcabConfiguration;
    }
}
