/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.V23.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.mcab.v231.appointments.ChangeAppointmentLifeCycle;
import com.hsbc.rbwm.ted.appointment.mcab.v231.appointments.ChangeAppointmentStatusTransformer;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static com.hsbc.rbwm.ted.appointment.mcab.v231.appointments.ChangeAppointmentLifeCycle.UPDATE_APPOINTMENT_LIFECYCLE_REQUEST;
import static java.lang.String.format;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by 44052007 on 23/06/2017.
 */
public class ChangeAppointmentLifeCycleTest {

    private static final String APPOINTMENT_ID = "VC8L4N63";
    private static final AppointmentStatus APPOINTMENT_STATUS = AppointmentStatus.CHECKED_IN;
    private ChangeAppointmentLifeCycle changeAppointmentLifeCycle;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private final static String TEST_URI = "/mcabBaseUri/changeAppointmentLifeCycleStatus";
    @Before
    public void setUp() {

        MCABConfiguration mcabConfiguration = new MCABConfigurationTestBuilder()
                .build(wireMockRule);
        changeAppointmentLifeCycle = new ChangeAppointmentLifeCycle(mcabConfiguration, new ResponseHandler(), new ChangeAppointmentStatusTransformer());

        CorrelationIdContainer.setId("test-correlation-id");
    }

    @Test
    public void testUpdateAppointments() throws Exception {
        String jsonRequest = format(UPDATE_APPOINTMENT_LIFECYCLE_REQUEST, APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());
        String jsonResponse = format("{\"reasons\":[],\"extension\":{},\"confirmationNumberListType\":[{\"confirmationNumber\":\"%s\",\"ttStatus\":{\"result\":\"%s\",\"status\":\"0\"}}]}", APPOINTMENT_ID, APPOINTMENT_ID);

        stubFor(post(urlPathEqualTo(TEST_URI))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        Map<String, Object> updateResponse = changeAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        assertTrue(updateResponse != null);
        assertEquals(APPOINTMENT_ID, updateResponse.get("appointmentId"));
    }

    @Test(expected = Exceptions.APIException.class)
    public void testUpdateAppointmentsWhenMcabThrowsApiException() throws Exception {
        String jsonRequest = format(UPDATE_APPOINTMENT_LIFECYCLE_REQUEST, APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());
        String jsonResponse = "{\n" +
                "  \"reasons\": [\n" +
                "    {\n" +
                "      \"code\": \"8\",\n" +
                "      \"description\": \"Given appointment status is wrong,Appointment status should not be updated\",\n" +
                "      \"trace\": [],\n" +
                "      \"keys\": [],\n" +
                "      \"values\": []\n" +
                "    }\n" +
                "  ],\n" +
                "  \"responseCode\": \"500\"\n" +
                "}";

        stubFor(post(urlPathEqualTo(TEST_URI))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(500)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        try {
            changeAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        } catch (Exceptions.APIException e) {
            assertEquals("ABP-UPDATE-APPOINTMENT-API", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.UnexpectedException.class)
    public void testUpdateAppointmentsWhenMcabThrowsUnexpectedException() throws Exception {
        String jsonRequest = format(UPDATE_APPOINTMENT_LIFECYCLE_REQUEST, APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());

        stubFor(post(urlPathEqualTo(TEST_URI))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(400)
                        .withBody("<html>Bad Request</html>")));

        try {
            changeAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        } catch (Exceptions.UnexpectedException e) {
            assertEquals("ABP-UPDATE-APPOINTMENT-UNEXPECTED", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void testUpdateAppointmentsWhenMcabThrowsNotFoundException() throws Exception {
        String jsonRequest = format(UPDATE_APPOINTMENT_LIFECYCLE_REQUEST, APPOINTMENT_ID, APPOINTMENT_STATUS.getMcabCode());
        String jsonResponse = format("{\n" +
                "  \"reasons\": [],\n" +
                "  \"extension\": {},\n" +
                "  \"confirmationNumberListType\": [\n" +
                "    {\n" +
                "      \"confirmationNumber\": \"%s\",\n" +
                "      \"ttStatus\": {\n" +
                "        \"cause\": \"Appointment confirmation does not exist \",\n" +
                "        \"result\": \"FAILED\",\n" +
                "        \"status\": \"-4001\"\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}", APPOINTMENT_ID);

        stubFor(post(urlPathEqualTo(TEST_URI))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        try {
            changeAppointmentLifeCycle.update(APPOINTMENT_ID, APPOINTMENT_STATUS).block();
        } catch (Exceptions.NotFoundException e) {
            assertEquals("ABP-UPDATE-APPOINTMENT-NOT-FOUND", e.getErrorCode().code);
            throw e;
        }
    }
}
