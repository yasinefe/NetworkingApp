/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment

import java.util

import com.hsbc.rbwm.ted.appointment.model.{AppointmentInput, AppointmentStatus}
import com.hsbc.rbwm.ted.appointment.model.Appointments.Appointment
import org.mockito.Mockito
import org.mockito.Mockito.when
import org.springframework.http.HttpStatus
import org.springframework.test.context.web.WebAppConfiguration
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.{request => _}
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import reactor.core.publisher.{Flux, Mono}


/**
  * Created by 44052007 on 19/06/2017.
  */
class AppointmentControllerTest extends ControllerTest {

  val appointment: util.Map[String, Object] = createAppointment()
  val appointments = new java.util.ArrayList[java.util.Map[String, Object]]()
  appointments.add(appointment)

  import collection.JavaConverters._
  import collection.mutable._

  val statuses: java.util.Set[AppointmentStatus] = HashSet(AppointmentStatus.CHECKED_IN, AppointmentStatus.UPCOMING).asJava

  it should " return a list of CHECKED_IN and UPCOMING appointments " in {

    when(appointmentService.getAppointments("400706", HashSet(AppointmentStatus.CHECKED_IN, AppointmentStatus.UPCOMING).asJava))
      .thenReturn(Flux.fromIterable(appointments))

    val response = appointmentListResponse()


    doGetAsync("/appointments/branch/400706?status=CHECKED_IN&status=UPCOMING", HttpStatus.OK)
      .andExpect(content.json(response))
  }

  it should " return appointment by appointment id " in {
    Mockito.when(appointmentService.getAppointment("NK8L170W")).thenReturn(Mono.just(appointments.get(0)))

    val response = appointmentResponse()

    doGetAsync("/appointments/NK8L170W", HttpStatus.OK).andExpect(content.json(response))
  }

  it should " update appointment status" in {
    val updateStatusResponse: java.util.Map[String, Object] = new java.util.HashMap[String, Object]
    updateStatusResponse.put("appointmentId", "NK8L170W")

    Mockito.when(appointmentService.updateAppointmentStatus("NK8L170W", AppointmentStatus.CHECKED_IN))
      .thenReturn(Mono.just(updateStatusResponse))

    val request =
      """
        |{
        |  "appointmentStatus": "CHECKED_IN"
        |}
      """.stripMargin

    val response =
      """
        |{
        |  "appointmentId": "NK8L170W"
        |}
      """.stripMargin


    doPutAsync("/appointments/NK8L170W", HttpStatus.OK, request)
      .andExpect(content.json(response))
  }

  it should " return a summary of appointmentStatus counts for CHECKED_IN and UPCOMING" in {

    val statusMap: java.util.Map[AppointmentStatus, java.lang.Long] = Map(
      AppointmentStatus.CHECKED_IN -> new java.lang.Long(2),
      AppointmentStatus.UPCOMING -> new java.lang.Long(1)).asJava

    Mockito.when(appointmentService.getAppointmentSummary("400706", statuses)).thenReturn(Mono.just(statusMap))

    val response =
      """
        |{
        |  "UPCOMING": 1,
        |  "CHECKED_IN": 2
        |}
      """.stripMargin

    doGetAsync("/appointments/summary/branch/400706?status=CHECKED_IN&status=UPCOMING", HttpStatus.OK)
      .andExpect(content.json(response))
  }

  it should " return a appointments and summary combined of for CHECKED_IN and UPCOMING" in {

    val statusMap: java.util.Map[AppointmentStatus, java.lang.Long] = Map(
      AppointmentStatus.CHECKED_IN -> new java.lang.Long(2),
      AppointmentStatus.UPCOMING -> new java.lang.Long(1)).asJava

    val statsMap: java.util.Map[String, java.lang.Integer] = Map("inNextHour" -> new Integer(3)).asJava


    val appointmentListMap: java.util.Map[String, Object] = Map(
      "appointments" -> appointments,
      "summary" -> statusMap,
      "stats" -> statsMap
    ).asJava

    Mockito.when(appointmentService.getAppointmentList("400706", HashSet(AppointmentStatus.CHECKED_IN, AppointmentStatus.UPCOMING).asJava))
      .thenReturn(Mono.just(appointmentListMap))

    val appointmentResponse = appointmentListResponse()
    val statusResponse =
      """
        |{
        |  "UPCOMING": 1,
        |  "CHECKED_IN": 2
        |}
      """.stripMargin
    val statsResponse =
      """
        |{
        |  "inNextHour": 3
        |}
      """.stripMargin


    val response = "{ \"appointments\" : " + appointmentResponse +
      ", \"summary\" : " + statusResponse +
      ", \"stats\": " + statsResponse + " }"

    doGetAsync("/appointments/list/400706?status=CHECKED_IN&status=UPCOMING", HttpStatus.OK)
      .andExpect(content.json(response))
  }

  it should " return a bad request when no passing the status when getting appointment summary " in {
    doGet("/appointments/summary/branch/400706", HttpStatus.BAD_REQUEST)
  }

  def appointmentListResponse(): String = {
    val response =
      "[" + appointmentResponse + "]".stripMargin

    response
  }

  def appointmentResponse(): String = {
    val response =
      """
        |  {
        |    "dateTime": 1477465200000,
        |    "timezone": "Europe/London",
        |    "duration": 90,
        |    "appointmentId": "NK8L170W",
        |    "appointmentStatus": "UPCOMING",
        |    "locationId": "590003",
        |    "topicId": "business_banking_direct",
        |    "topicCategoryId": "business_account_application",
        |    "proofOfId": true,
        |    "attendee": {
        |      "firstName": "Mary",
        |      "lastName": "Jacksonville",
        |      "email": "mjack@email.com"
        |    },
        |    "conductor": {
        |      "employeeId": "43664583",
        |      "fullName": "KYLE HAGGERTY"
        |    },
        |    "topicName": "Business Banking",
        |    "topicCategoryName": "Business Account"
        |  }
      """.stripMargin

    response
  }

  def createAppointment(): java.util.Map[String, Object] = {
    val appointment = new java.util.HashMap[String, Object]

    appointment.put("dateTime", java.lang.Long.valueOf("1477465200000"))
    appointment.put("timezone", "Europe/London")
    appointment.put("duration", java.lang.Integer.valueOf(90))
    appointment.put("appointmentId", "NK8L170W")
    appointment.put("appointmentStatus", "UPCOMING")
    appointment.put("locationId", "590003")
    appointment.put("topicId", "business_banking_direct")
    appointment.put("topicCategoryId", "business_account_application")
    appointment.put("topicName", "Business Banking")
    appointment.put("topicCategoryName", "Business Account")
    appointment.put("proofOfId", java.lang.Boolean.TRUE)

    val attendee = new java.util.HashMap[String, Object]
    attendee.put("firstName", "Mary")
    attendee.put("lastName", "Jacksonville")
    attendee.put("email", "mjack@email.com")

    appointment.put("attendee", attendee)

    val conductor = new java.util.HashMap[String, Object]
    conductor.put("employeeId", "43664583")
    conductor.put("fullName", "KYLE HAGGERTY")

    appointment.put("conductor", conductor)

    appointment
  }

  it should " update proofOfId for an appointment" in {
    Mockito.when(appointmentService.updateProofOfId("NK8L170W", true)).thenReturn(Mono.just(new Appointment("NK8L170W", true, 123456L, null, null, null)))

    val request =
      """
        |{
        |  "proofOfId": true
        |}
      """.stripMargin

    val response =
      """
        |{
        |  "appointmentId": "NK8L170W",
        |  "proofOfId": true,
        |  "createdAt": 123456
        |}
      """.stripMargin

    doPutAsync("/appointments/NK8L170W/proofOfId", HttpStatus.OK, request)
      .andExpect(content.json(response))
  }

  it should " create appointment " in {
    val appointmentInput = new AppointmentInput("aCustomerId", "400246", 12345L, "business_banking_direct", "business_account_application", 30, "GB", "Europe/London")
    Mockito.when(appointmentService.createAppointment(appointmentInput)).thenReturn(Mono.just(createAppointment()))

    val request =
      """
        |{
        |  "customerId": "aCustomerId",
        |  "branchId": "400246",
        |  "dateTime": 12345,
        |  "topicId": "business_banking_direct",
        |  "topicCategoryId": "business_account_application",
        |  "duration": 30
        |}
      """.stripMargin


    doPostAsync("/appointments/", HttpStatus.OK, request)
      .andExpect(content.json(appointmentResponse()))
  }

}
