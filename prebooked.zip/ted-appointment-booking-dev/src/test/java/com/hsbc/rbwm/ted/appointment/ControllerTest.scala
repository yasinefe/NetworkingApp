/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment

import com.hsbc.rbwm.ted.appointment.api.{AppointmentServiceApi, MeetingServiceApi, MeetingStatsServiceApi}
import com.hsbc.rbwm.ted.appointment.config.CryptConfigurationTest
import com.hsbc.rbwm.ted.appointment.filter.{CorrelationIdFilter, LoggingFilter}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.mockito.MockitoSugar
import org.scalatest.{BeforeAndAfter, FlatSpec, GivenWhenThen, Matchers}
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment
import org.springframework.test.context.{ActiveProfiles, ContextConfiguration, TestContextManager, TestPropertySource}
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.setup.{AbstractMockMvcBuilder, MockMvcBuilders, StandaloneMockMvcBuilder}
import org.springframework.web.context.WebApplicationContext

/**
  * Created by 44052007 on 19/06/2017.
  */
@RunWith(classOf[JUnitRunner])
@ActiveProfiles(profiles = Array("int-be-test"))
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = Array(classOf[Application], classOf[CryptConfigurationTest.Config]))
@TestPropertySource(properties = Array[String]{"spring.config.location = classpath:config/ted-appointment-booking.yaml"})
abstract class ControllerTest extends FlatSpec
  with Matchers
  with MockitoSugar
  with BeforeAndAfter
  with GivenWhenThen
  with RestTestPack {

  var mvc: MockMvc = _

  @Autowired
  val appointmentController : AppointmentController = null

  @Autowired
  val meetingController : MeetingController = null

  @Autowired
  val webApplicationContext : WebApplicationContext = null

  var appointmentService: AppointmentServiceApi = _

  var meetingService: MeetingServiceApi = _

  var meetingStatsService: MeetingStatsServiceApi = _

  before {
    new TestContextManager(this.getClass).prepareTestInstance(this)
    val mvcBuilder: AbstractMockMvcBuilder[_ <: AbstractMockMvcBuilder[StandaloneMockMvcBuilder]] = MockMvcBuilders
      .webAppContextSetup(webApplicationContext)
      .addFilters(new CorrelationIdFilter, new LoggingFilter)

    mvc = mvcBuilder.build

    appointmentService = mock[AppointmentServiceApi]
    meetingService = mock[MeetingServiceApi]
    meetingStatsService = mock[MeetingStatsServiceApi]

    ReflectionTestUtils.setField(appointmentController, "appointmentService", appointmentService)
    ReflectionTestUtils.setField(meetingController, "meetingService", meetingService)
    ReflectionTestUtils.setField(meetingController, "meetingStatsService", meetingStatsService)
  }
}
