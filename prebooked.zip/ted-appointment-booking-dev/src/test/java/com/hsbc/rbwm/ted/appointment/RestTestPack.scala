/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment

import com.rbwm.ted.telemetry.correlation.CorrelationIdGenerator.CORRELATION_ID_HEADER
import org.springframework.http.{HttpHeaders, HttpStatus, MediaType}
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.{request => _, _}
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._

/**
  * Created by 44052007 on 19/06/2017.
  */
trait RestTestPack {

  var mvc: MockMvc

  def doGet(url: String, httpStatus : HttpStatus, headers: HttpHeaders = new HttpHeaders) = {
    if (!headers.containsKey(CORRELATION_ID_HEADER)) {
      headers.add(CORRELATION_ID_HEADER, "test-correlation-id")
    }

    mvc.perform(get(url)
      .contentType(MediaType.APPLICATION_JSON).headers(headers))
      .andExpect(status().is(httpStatus.value()))
  }

  def doGetAsync(url: String, httpStatus : HttpStatus, headers: HttpHeaders = new HttpHeaders) = {
    if (!headers.containsKey(CORRELATION_ID_HEADER)) {
      headers.add(CORRELATION_ID_HEADER, "test-correlation-id")
    }

    val mvcResult = mvc.perform(get(url)
      .contentType(MediaType.APPLICATION_JSON).headers(headers))
      .andExpect(request().asyncStarted())
      .andReturn()

    mvc.perform(asyncDispatch(mvcResult))
      .andExpect(status().is(httpStatus.value()))

  }

  def doPutAsync(url: String, httpStatus : HttpStatus, body: String, headers: HttpHeaders = new HttpHeaders) = {
    if (!headers.containsKey(CORRELATION_ID_HEADER)) {
      headers.add(CORRELATION_ID_HEADER, "test-correlation-id")
    }

    val mvcResult = mvc.perform(put(url)
      .contentType(MediaType.APPLICATION_JSON).headers(headers)
      .content(body))
      .andExpect(request().asyncStarted())
      .andReturn()

    mvc.perform(asyncDispatch(mvcResult))
      .andExpect(status().is(httpStatus.value()))
  }

  def doPostAsync(url: String, httpStatus : HttpStatus, body: String, headers: HttpHeaders = new HttpHeaders) = {
    if (!headers.containsKey(CORRELATION_ID_HEADER)) {
      headers.add(CORRELATION_ID_HEADER, "test-correlation-id")
    }

    val mvcResult = mvc.perform(post(url)
      .contentType(MediaType.APPLICATION_JSON)
      .content(body))
      .andExpect(request().asyncStarted())
      .andReturn()

    mvc.perform(asyncDispatch(mvcResult))
      .andExpect(status().is(httpStatus.value()))
  }
}
