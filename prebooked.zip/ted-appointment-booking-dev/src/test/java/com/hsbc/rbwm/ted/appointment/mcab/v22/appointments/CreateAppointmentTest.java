/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.mcab.V23.appointments.MCABConfigurationTestBuilder;
import com.hsbc.rbwm.ted.appointment.model.AppointmentInput;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static junit.framework.Assert.assertNotNull;

/**
 * Created by 44052007 on 23/06/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class CreateAppointmentTest {

    private CreateAppointment createAppointment;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    @Before
    public void setUp() throws IOException {

        MCABConfiguration mcabConfiguration = new MCABConfigurationTestBuilder()
                .build(wireMockRule);
        createAppointment = new CreateAppointment(mcabConfiguration, new ResponseHandler());

        CorrelationIdContainer.setId("test-correlation-id");
    }

    @Test
    public void testCreateAppointment() throws Exception {

        AppointmentInput appointmentInput = new AppointmentInput();
        appointmentInput.setBranchId("404519");
        appointmentInput.setCustomerId("NEWCUST00031");
        appointmentInput.setDateTime(1505988000000L);
        appointmentInput.setDuration(60);
        appointmentInput.setTopicCategoryId("savings");
        appointmentInput.setTopicId("savings_review");
        appointmentInput.setCountryCode("GB");
        appointmentInput.setTimezone("Europe/London");

        ClassLoader classLoader = getClass().getClassLoader();
        URL pathForRequest = classLoader.getResource("mock-data/mcab/2.2/create-appointment-request.json");
        String jsonRequest = new String(Files.readAllBytes(Paths.get(pathForRequest.toURI())));
        URL pathForResponse = classLoader.getResource("mock-data/mcab/2.2/create-appointment-response.json");
        String jsonResponse = new String(Files.readAllBytes(Paths.get(pathForResponse.toURI())));

        stubFor(post(urlPathEqualTo("/mcabBaseUri/createAppointment"))
                .withRequestBody(equalToJson(jsonRequest,true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        Map<String, Object> appointmentResponse = createAppointment.createAppointment(appointmentInput).block();
        assertNotNull(appointmentResponse);
        assertNotNull(appointmentResponse.get("appointmentDetails"));
    }

}
