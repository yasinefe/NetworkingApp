/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.api.AppointmentServiceApi;
import com.hsbc.rbwm.ted.appointment.api.MeetingServiceApi;
import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.model.*;
import org.junit.Before;
import org.junit.Test;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

import static com.hsbc.rbwm.ted.appointment.model.ModifierType.USER;
import static java.util.Arrays.asList;
import static java.util.Collections.emptySet;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Flux.fromIterable;

/**
 * Created by 44052007 on 03/05/2018.
 */
public class MeetingServiceTest {
    private ZonedDateTime time = LocalDateTime.of(2018, 5, 1, 11, 23, 45, 175).atZone(ZoneId.of("UTC"));
    private ClockProvider clockProvider = new ClockProvider(Clock.fixed(time.toInstant(), ZoneId.of("UTC")));
    private AppointmentServiceApi mockAppointmentService = mock(AppointmentServiceApi.class);
    private AppointmentConfiguration mockAppointmentConfiguration = mock(AppointmentConfiguration.class);

    private MeetingServiceApi meetingService = new MeetingService(mockAppointmentService, mockAppointmentConfiguration, clockProvider);

    private Meeting upcomingMeeting;
    private Meeting checkedInMeeting;
    private Meeting inMeetingMeeting;
    private Meeting completedMeeting;
    private Meeting cancelledMeeting;
    private Meeting overdueMeeting;
    private Meeting noShowMeeting;
    private Meeting noShowButUpComingMeeting;
    private Meeting criticalOverdueMeeting;
    private Meeting overRunMeeting;
    private Meeting criticalOverRunMeeting;
    private Meeting nextDayMeeting;

    @Before
    public void setUp() throws Exception {
        when(mockAppointmentConfiguration.getOverdueOffset()).thenReturn(5);
        when(mockAppointmentConfiguration.getCriticalOverdueOffset()).thenReturn(15);
        when(mockAppointmentConfiguration.getCriticalOverRunOffset()).thenReturn(10);

        Map<String, Object> upcomingAppointment = createAppointment("1234000", AppointmentStatus.UPCOMING, null,
                minsAfter(2), null, null, false);
        upcomingMeeting = createMeeting("1234000", MeetingStatus.UPCOMING, MeetingGroup.UPCOMING,
                null, minsAfter(2), null, null, null, false,
                false, false, false);

        Map<String, Object> checkedInAppointment = createAppointment("1234001", AppointmentStatus.CHECKED_IN, minsBefore(7),
                minsAfter(2), null, null, false);
        checkedInMeeting = createMeeting("1234001", MeetingStatus.CHECKED_IN, MeetingGroup.CHECKED_IN,
                minsBefore(7), minsAfter(2), null, null, null, false,
                false, false, false);

        Map<String, Object> inMeetingAppointment = createAppointment("1234002", AppointmentStatus.IN_MEETING, minsBefore(16),
                minsBefore(11), minsBefore(11), null, false);
        inMeetingMeeting = createMeeting("1234002", MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING,
                minsBefore(16), minsBefore(11), minsBefore(11), null, null,
                false, false, false, false);

        Map<String, Object> completedAppointment = createAppointment("1234003", AppointmentStatus.COMPLETED, minsBefore(30),
                minsBefore(25), minsBefore(25), minsBefore(10), false);
        completedMeeting = createMeeting("1234003", MeetingStatus.COMPLETED, MeetingGroup.COMPLETED,
                minsBefore(30), minsBefore(25), minsBefore(25), minsBefore(10), USER,
                false, false, false, false);

        Map<String, Object> cancelledAppointment = createAppointment("1234004", AppointmentStatus.CANCELLED, null,
                minsBefore(25), null, minsBefore(28), false);
        cancelledMeeting = createMeeting("1234004", MeetingStatus.CANCELLED, MeetingGroup.COMPLETED,
                null, minsBefore(25), null, minsBefore(28), USER,
                false, false, false, false);

        Map<String, Object> overdueAppointment = createAppointment("1234005", AppointmentStatus.CHECKED_IN, minsBefore(15),
                minsBefore(10), null, null, false);
        overdueMeeting = createMeeting("1234005", MeetingStatus.CHECKED_IN, MeetingGroup.CHECKED_IN,
                minsBefore(15), minsBefore(10), null, null, null,
                true, false, false, false);

        Map<String, Object> criticalOverdueAppointment = createAppointment("1234006", AppointmentStatus.CHECKED_IN, minsBefore(21),
                minsBefore(16), null, null, false);
        criticalOverdueMeeting = createMeeting("1234006", MeetingStatus.CHECKED_IN, MeetingGroup.CHECKED_IN,
                minsBefore(21), minsBefore(16), null, null, null,
                true, true, false, false);

        Map<String, Object> noShowAppointment = createAppointment("1234007", AppointmentStatus.UPCOMING, null,
                minsBefore(23), null, null, true);
        noShowMeeting = createMeeting("1234007", MeetingStatus.NOSHOW, MeetingGroup.COMPLETED,
                null, minsBefore(23), null, null, ModifierType.SYSTEM,
                false, false, false, false);

        // This is for MCAB "no show". It is different for us we have 20 mins to consider an appointment is NO_SHOW.
        Map<String, Object> noShowButUpComingAppointment = createAppointment("1234008", AppointmentStatus.NOSHOW, null,
                minsBefore(6), null, null, false);
        noShowButUpComingMeeting = createMeeting("1234008", MeetingStatus.UPCOMING, MeetingGroup.UPCOMING,
                null, minsBefore(6), null, null, null,
                false, false, false, false);

        Map<String, Object> overRunAppointment = createAppointment("1234009", AppointmentStatus.IN_MEETING, minsBefore(21),
                minsBefore(16), minsBefore(16), null, false);
        overRunMeeting = createMeeting("1234009", MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING,
                minsBefore(21), minsBefore(16), minsBefore(16), null, null,
                false, false, true, false);

        Map<String, Object> criticalOverRunAppointment = createAppointment("1234010", AppointmentStatus.IN_MEETING, minsBefore(36),
                minsBefore(31), minsBefore(31), null, false);
        criticalOverRunMeeting = createMeeting("1234010", MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING,
                minsBefore(36), minsBefore(31), minsBefore(31), null, null,
                false, false, true, true);

        Map<String, Object> unmappedAppointment = createAppointment("1234011", AppointmentStatus.UNMAPPED, null,
                null, null, null, false);

        Flux<Map<String, Object>> appointmentFlux = fromIterable(asList(upcomingAppointment, checkedInAppointment,
                inMeetingAppointment, completedAppointment, cancelledAppointment, overdueAppointment,
                criticalOverdueAppointment, noShowAppointment, noShowButUpComingAppointment, overRunAppointment,
                criticalOverRunAppointment, unmappedAppointment));

        when(mockAppointmentService.getAppointments("400706", emptySet())).thenReturn(appointmentFlux);

        Map<String, Object> nextDayAppointment = createAppointment("1234012", AppointmentStatus.NEXT_DAY, null,
                minsAfter(60 * 25), null, null, false);
        nextDayMeeting = createMeeting("1234012", MeetingStatus.UPCOMING, MeetingGroup.UPCOMING,
                null, minsAfter(60 * 25), null, null, null,
                false, false, false, false);


        Flux<Map<String, Object>> nextWorkingDayAppointmentFlux = fromIterable(asList(nextDayAppointment));

        when(mockAppointmentService.getNextWorkingDayAppointments("400706")).thenReturn(nextWorkingDayAppointmentFlux);
        when(mockAppointmentService.getAppointment("1234000")).thenReturn(Mono.just(upcomingAppointment));
    }

    @Test
    public void shouldReturnAllMeetings() throws Exception {
        List<Meeting> actualMeetings = meetingService.getMeetings("400706", null, null).collectList().block();
        List<Meeting> expectedMeetings = asList(upcomingMeeting, checkedInMeeting, inMeetingMeeting, completedMeeting,
                cancelledMeeting, overdueMeeting, criticalOverdueMeeting, noShowMeeting, noShowButUpComingMeeting,
                overRunMeeting, criticalOverRunMeeting);

        assertEquals(expectedMeetings, actualMeetings);
    }

    @Test
    public void shouldReturnMeetingsFilteredByMeetingStatus() throws Exception {
        List<Meeting> actualMeetings = meetingService.getMeetings("400706", MeetingStatus.IN_MEETING, null).collectList().block();
        List<Meeting> expectedMeetings = asList(inMeetingMeeting, overRunMeeting, criticalOverRunMeeting);

        assertEquals(expectedMeetings, actualMeetings);
    }

    @Test
    public void shouldReturnMeetingsFilteredByMeetingGroup() throws Exception {
        List<Meeting> actualMeetings = meetingService.getMeetings("400706", null, MeetingGroup.CHECKED_IN).collectList().block();
        List<Meeting> expectedMeetings = asList(checkedInMeeting, overdueMeeting, criticalOverdueMeeting);

        assertEquals(expectedMeetings, actualMeetings);
    }

    @Test
    public void shouldReturnNextDayMeetings() throws Exception {
        List<Meeting> actualMeetings = meetingService.getNextWorkingDayMeetings("400706", null, null).collectList().block();
        List<Meeting> expectedMeetings = asList(nextDayMeeting);

        assertEquals(expectedMeetings, actualMeetings);
    }

    @Test
    public void shouldReturnMeeting() throws Exception {
        Meeting actualMeeting = meetingService.getMeeting("1234000").block();
        assertEquals(upcomingMeeting, actualMeeting);
    }

    @Test
    public void shouldReturnAsOverdueWhenProgressedPassedCheckedIn() {
        //Given
        Map<String, Object> overdueCheckedInAppointment = createAppointment("GBTEST1", AppointmentStatus.IN_MEETING, minsAfter(0), minsAfter(0), minsAfter(7), null, false);
        Map<String, Object> criticallyOverdueCompletedInAppointment = createAppointment("GBTEST2", AppointmentStatus.COMPLETED, minsAfter(0), minsAfter(0), minsAfter(16), minsAfter(16), false);
        when(mockAppointmentService.getAppointments(eq("400672"), eq(emptySet()))).thenReturn(Flux.just(overdueCheckedInAppointment, criticallyOverdueCompletedInAppointment));

        //When
        List<Meeting> actual = meetingService.getMeetings("400672", null, null).collectList().block();

        //Then
        Meeting expectedMeeting1 = createMeeting("GBTEST1", MeetingStatus.IN_MEETING, MeetingGroup.IN_MEETING,
                minsAfter(0), minsAfter(0), minsAfter(7), null, null,
                true, false, false, false);
        Meeting expectedMeeting2 = createMeeting("GBTEST2", MeetingStatus.COMPLETED, MeetingGroup.COMPLETED,
                minsAfter(0), minsAfter(0), minsAfter(16), minsAfter(16), USER,
                true, true, false, false);

        List<Meeting> expected = asList(expectedMeeting1, expectedMeeting2);
        assertEquals(expected, actual);
    }

    @Test
    public void shouldReturnAsOverrunWhenProgressedPassedInMeeting() {
        //Given
        Map<String, Object> overrunCompletedAppointment = createAppointment("GBTEST1", AppointmentStatus.COMPLETED, minsAfter(0), minsAfter(0), minsAfter(0), minsAfter(16), false);
        Map<String, Object> criticalOverrunCompletedAppointment = createAppointment("GBTEST2", AppointmentStatus.COMPLETED, minsAfter(0), minsAfter(0), minsAfter(0), minsAfter(31), false);
        when(mockAppointmentService.getAppointments(eq("440672"), eq(emptySet()))).thenReturn(Flux.just(overrunCompletedAppointment, criticalOverrunCompletedAppointment));

        //When
        List<Meeting> actual = meetingService.getMeetings("440672", null, null).collectList().block();

        //Then
        Meeting expectedMeeting1 = createMeeting("GBTEST1", MeetingStatus.COMPLETED, MeetingGroup.COMPLETED,
                minsAfter(0), minsAfter(0), minsAfter(0), minsAfter(16), USER,
                false, false, true, false);
        Meeting expectedMeeting2 = createMeeting("GBTEST2", MeetingStatus.COMPLETED, MeetingGroup.COMPLETED,
                minsAfter(0), minsAfter(0), minsAfter(0), minsAfter(31), USER,
                false, false, true, true);

        List<Meeting> expected = asList(expectedMeeting1, expectedMeeting2);
        assertEquals(expected, actual);
    }

    @Test
    public void shouldUpdateMeetingStatusWithProofOfId() throws Exception {
        when(mockAppointmentService.updateAppointmentStatus("1234000", AppointmentStatus.CHECKED_IN))
                .thenReturn(Mono.just(Collections.emptyMap()));
        when(mockAppointmentService.updateProofOfId("1234000", true))
                .thenReturn(Mono.just(new Appointments.Appointment("1234000", true, null, null, null, null)));

        Meeting actualMeeting = meetingService.updateMeetingStatus("1234000", new UpdateMeetingStatusInput(MeetingStatus.CHECKED_IN, true)).block();

        assertEquals(upcomingMeeting, actualMeeting);
    }

    @Test
    public void shouldUpdateMeetingStatusWithoutProofOfId() throws Exception {
        when(mockAppointmentService.updateAppointmentStatus("1234000", AppointmentStatus.IN_MEETING))
                .thenReturn(Mono.just(Collections.emptyMap()));

        Meeting actualMeeting = meetingService.updateMeetingStatus("1234000", new UpdateMeetingStatusInput(MeetingStatus.IN_MEETING, null)).block();

        assertEquals(upcomingMeeting, actualMeeting);
    }


    private Long minsBefore(int min) {
        return minsAfter(-1 * min);
    }

    private Long minsAfter(int min) {
        return time.toInstant().plus(min, ChronoUnit.MINUTES).toEpochMilli();
    }

    private Map<String, Object> createAppointment(String appointmentId, AppointmentStatus appointmentStatus, Long checkedInAt,
                                                  Long dateTime, Long startedAt, Long endedAt, Boolean isNoShow) {
        Map<String, Object> person = new HashMap<>();
        person.put("firstName", "firstName");
        person.put("lastName", "lastName");
        person.put("email", "email");
        person.put("phoneNumber", "phoneNumber");
        person.put("mobileNumber", "mobileNumber");

        Map<String, Object> employee = new HashMap<>();
        employee.put("employeeId", "employeeId");
        employee.put("fullName", "fullName");

        Set<String> checklist = new LinkedHashSet<>();
        checklist.add("proofOfId");
        checklist.add("proofOfIncome");

        Map<String, Object> appointment = new HashMap<>();
        appointment.put("appointmentId", appointmentId);
        appointment.put("appointmentStatus", appointmentStatus.name());
        appointment.put("topicId", "topicId");
        appointment.put("topicName", "topicName");
        appointment.put("topicCategoryId", "topicCategoryId");
        appointment.put("topicCategoryName", "topicCategoryName");
        appointment.put("conductor", employee);
        appointment.put("dateTime", dateTime);
        appointment.put("checkedInAt", checkedInAt);
        appointment.put("startedAt", startedAt);
        appointment.put("endedAt", endedAt);
        appointment.put("duration", 15L);
        appointment.put("attendee", person);
        appointment.put("comments", "comments");
        appointment.put("proofOfId", true);
        appointment.put("timezone", "Europe/London");
        appointment.put("isNoShow", isNoShow);
        appointment.put("checklist", checklist);

        return appointment;
    }

    private Meeting createMeeting(String meetingId, MeetingStatus meetingStatus, MeetingGroup meetingGroup, Long checkedInAt,
                                  Long bookedFor, Long startedAt, Long endedAt, ModifierType endedBy,
                                  Boolean isOverDue, Boolean isOverDueCritical, Boolean isOverRun,
                                  Boolean isOverRunCritical) {
        Person person = new Person("firstName", "lastName", "email", "phoneNumber",
                "mobileNumber", null);
        Employee employee = new Employee("employeeId", "fullName");
        Set<String> checklist = new LinkedHashSet<>();
        checklist.add("proofOfId");
        checklist.add("proofOfIncome");
        return new Meeting(meetingStatus, meetingGroup, meetingId, "topicId", "topicName",
                "topicCategoryId", "topicCategoryName", employee, formatDate(bookedFor), formatDate(checkedInAt),
                formatDate(startedAt), formatDate(endedAt), 15, isOverDue, isOverDueCritical, isOverRun,
                isOverRunCritical, person, "comments", true, endedBy, checklist, "Europe/London");
    }

    private String formatDate(Long datetime) {
        if (datetime == null) {
            return null;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Europe/London"));
        return simpleDateFormat.format(new Date(datetime));
    }
}