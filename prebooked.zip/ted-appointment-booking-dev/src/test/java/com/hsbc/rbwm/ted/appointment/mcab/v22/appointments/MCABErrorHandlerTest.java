/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.v22.appointments;

import com.hsbc.rbwm.ted.rest.api.ClientRestTemplate;
import com.hsbc.rbwm.ted.rest.error.ErrorResponse;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.hsbc.rbwm.ted.rest.http.HttpErrorResponseBuilder;
import com.hsbc.rbwm.ted.rest.http.HttpRequestValues;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;

import javax.net.ssl.SSLHandshakeException;
import java.net.ConnectException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Created by 44027117 on 19/06/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class MCABErrorHandlerTest {

    private MCABErrorHandler mcabErrorHandler;

    @Mock
    ClientRestTemplate clientRestTemplate;

    @Before
    public void setUp() {
        ErrorResponse errorsResponse =
                new HttpErrorResponseBuilder()
                        .withApplicationErrorCodePrefix("ABP")
                        .withFeatureErrorCodePrefix("TEST")
                        .build();

        mcabErrorHandler = new MCABErrorHandler(errorsResponse);
    }

    @Test
    public void testExtractErrorMessage() throws Exception {
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource("mock-data/mcab/2.2/retrieve-appointments-internal-server-error-response.json");
        String errorMessage = mcabErrorHandler.extractErrorMessage(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
                "Status", Files.readAllBytes(Paths.get(path.toURI())), Charset.defaultCharset()));
        assertEquals("com.hsbc.group.common.segments.model.v1.bean.TechnicalException", errorMessage);
    }

    @Test(expected = Exceptions.NoConnectionException.class)
    public void testHandlerConnectionException() throws Exception {
        when(clientRestTemplate.doExchange(anyString(), anyMap(), anyMap(), anyString(), anyString()))
                .thenThrow(new RestClientException("error", new ConnectException()));
        try {
            mcabErrorHandler.handler(clientRestTemplate, new HttpRequestValues("url", Collections.emptyMap(), Collections.emptyMap(), "", "POST"));
        } catch (Exceptions.NoConnectionException e) {
            assertEquals("ABP-TEST-NO-CONNECTION", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.NoConnectionException.class)
    public void testHandlerUnknownHostException() throws Exception {
        when(clientRestTemplate.doExchange(anyString(), anyMap(), anyMap(), anyString(), anyString()))
                .thenThrow(new RestClientException("error", new UnknownHostException()));
        try {
            mcabErrorHandler.handler(clientRestTemplate, new HttpRequestValues("url", Collections.emptyMap(), Collections.emptyMap(), "", "POST"));
        } catch (Exceptions.NoConnectionException e) {
            assertEquals("ABP-TEST-NO-CONNECTION", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.NoConnectionException.class)
    public void testHandlerSSLHandshakeException() throws Exception {
        when(clientRestTemplate.doExchange(anyString(), anyMap(), anyMap(), anyString(), anyString()))
                .thenThrow(new RestClientException("error", new SSLHandshakeException("SSL Validation error")));
        try {
            mcabErrorHandler.handler(clientRestTemplate, new HttpRequestValues("url", Collections.emptyMap(), Collections.emptyMap(), "", "POST"));
        } catch (Exceptions.NoConnectionException e) {
            assertEquals("ABP-TEST-NO-CONNECTION", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.APIException.class)
    public void testHandlerMcabInternalServerError() throws Exception {
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource("mock-data/mcab/2.2/retrieve-appointments-internal-server-error-response.json");
        byte[] fileContent = Files.readAllBytes(Paths.get(path.toURI()));

        when(clientRestTemplate.doExchange(anyString(), anyMap(), anyMap(), anyString(), anyString()))
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Test", fileContent, Charset.defaultCharset()));

        try {
            mcabErrorHandler.handler(clientRestTemplate, new HttpRequestValues("url", Collections.emptyMap(), Collections.emptyMap(), "", "POST"));
        } catch (Exceptions.APIException e) {
            assertEquals("ABP-TEST-API", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.NotFoundException.class)
    public void testHandlerNotFound() throws Exception {
        when(clientRestTemplate.doExchange(anyString(), anyMap(), anyMap(), anyString(), anyString()))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

        try {
            mcabErrorHandler.handler(clientRestTemplate, new HttpRequestValues("url", Collections.emptyMap(), Collections.emptyMap(), "", "POST"));
        } catch (Exceptions.NoConnectionException e) {
            assertEquals("ABP-TEST-NOT-FOUND", e.getErrorCode().code);
            throw e;
        }
    }
}
