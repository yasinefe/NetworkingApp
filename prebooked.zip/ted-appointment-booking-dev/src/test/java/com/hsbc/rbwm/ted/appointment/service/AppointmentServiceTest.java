/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.CreateAppointment;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.RetrieveAppointment;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.RetrieveAppointments;
import com.hsbc.rbwm.ted.appointment.mcab.v231.appointments.ChangeAppointmentLifeCycle;
import com.hsbc.rbwm.ted.appointment.model.AppointmentFields;
import com.hsbc.rbwm.ted.appointment.model.AppointmentInput;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import com.hsbc.rbwm.ted.appointment.model.Appointments.Appointment;
import com.hsbc.rbwm.ted.appointment.repository.AppointmentRepository;
import com.hsbc.rbwm.ted.rest.error.ErrorCode;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.AdditionalAnswers;
import org.mockito.ArgumentMatcher;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.client.RestClientException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.*;
import static com.hsbc.rbwm.ted.appointment.model.AppointmentStatus.*;
import static java.util.Collections.singletonList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.*;

/**
 * Created by 43578876 on 23/06/2017.
 */
public class AppointmentServiceTest {

    private static final String APPOINTMENT_ID = "1234";
    private static final String BRANCH_CODE = "404519";

    private AppointmentService appointmentService;

    @Mock
    private RetrieveAppointments retrieveAppointments;

    @Mock
    private ChangeAppointmentLifeCycle updateAppointmentLifeCycle;

    @Mock
    private RetrieveAppointment retrieveAppointment;

    @Mock
    private AppointmentRepository appointmentRepository;

    @Mock
    private CreateAppointment createAppointment;

    @Mock
    private AppointmentConfiguration appointmentConfiguration;

    private ClockProvider clockProvider = new ClockProvider(Clock.fixed(Instant.ofEpochMilli(123456L), ZoneId.of("UTC")));

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        appointmentService = new AppointmentService(
                retrieveAppointments,
                updateAppointmentLifeCycle,
                retrieveAppointment,
                createAppointment,
                new Filters(new AppointmentFunctions(new ClockProvider(), appointmentConfiguration)),
                appointmentRepository,
                clockProvider
        );
        List<Map<String,Object>> appointments = Arrays.asList(
                createAppointment("1111", UPCOMING, false, LocalDateTime.now().plusMinutes(5)),
                createAppointment("2222", UPCOMING, true, LocalDateTime.now().minusMinutes(5)),
                createAppointment("3333", NOSHOW, true, LocalDateTime.now().minusMinutes(5)),
                createAppointment("4444", NOSHOW, false, LocalDateTime.now().minusMinutes(1)),
                createAppointment("5555", NOSHOW, false, LocalDateTime.now().minusMinutes(2)),
                createAppointment("6666", CHECKED_IN, false, LocalDateTime.now().plusMinutes(5)),
                createAppointment("7777", CHECKED_IN, false, LocalDateTime.now().minusMinutes(10)),// Overdue
                createAppointment("8888", UPCOMING, false, LocalDateTime.now().plusHours(25)), //NEXT DAY
                createAppointment("9999", IN_MEETING, false, LocalDateTime.now().plusMinutes(5)),
                createAppointment("2111", IN_MEETING, false, LocalDateTime.now().minusHours(2)), //OVERRUN
                createAppointment("2222", COMPLETED, false, LocalDateTime.now().minusDays(1)) //YESTERDAY
        );

        Map<String, Object> appointment = createAppointment(APPOINTMENT_ID, UPCOMING, false, LocalDateTime.now().plusMinutes(5));

        Flux<Map<String,Object>> fluxAppointments = Flux.fromIterable(appointments);
        when(retrieveAppointments.getAppointments(BRANCH_CODE)).thenReturn(fluxAppointments);
        when(retrieveAppointment.getAppointment(APPOINTMENT_ID)).thenReturn(Mono.just(appointment));
        when(appointmentRepository.findById(APPOINTMENT_ID)).thenReturn(Mono.just(new Appointment(APPOINTMENT_ID, true, null, null, null, null)));
        when(appointmentRepository.findByIds(anyListOf(String.class))).thenReturn(Flux.empty());
        when(appointmentRepository.save(any(Mono.class))).then(AdditionalAnswers.returnsArgAt(0));
        when(appointmentConfiguration.getOverdueOffset()).thenReturn(5);
    }

    @Test
    public void getAppointmentsUpcomingIncludeIsNoShowEqualsFalse() throws Exception {

        Flux<Map<String,Object>> results = appointmentService.getAppointments(BRANCH_CODE, new HashSet<>(singletonList(UPCOMING)));
        //should include the STATUS = NOSHOW iwth isNoShow=false property
        assertEquals(new Long(3), results.count().block());
    }

    @Test
    public void getAppointmentsNoShowsExcludeIsNoShowEqualsFalse() throws Exception {

        Flux<Map<String,Object>> results = appointmentService.getAppointments(BRANCH_CODE, new HashSet<>(singletonList(NOSHOW)));
        //should exclude the STATUS = NOSHOW where isNoShow=false property
        assertEquals(new Long(2), results.count().block());
    }

    @Test
    public void getAppointmentsCheckedIn() throws Exception {

        Flux<Map<String,Object>> results = appointmentService.getAppointments(BRANCH_CODE, new HashSet<>(singletonList(CHECKED_IN)));
        assertEquals(new Long(2), results.count().block());
    }

    @Test
    public void getAppointmentsOverdue() throws Exception {

        Flux<Map<String,Object>> results = appointmentService.getAppointments(BRANCH_CODE, new HashSet<>(singletonList(OVERDUE)));
        assertEquals(new Long(1), results.count().block());
    }

    @Test
    public void getAppointmentsInMeeting() throws Exception {

        Flux<Map<String,Object>> results = appointmentService.getAppointments(BRANCH_CODE, new HashSet<>(singletonList(IN_MEETING)));
        assertEquals(new Long(2), results.count().block());
    }

    @Test
    public void getAppointmentsOverRun() throws Exception {

        Flux<Map<String,Object>> results = appointmentService.getAppointments(BRANCH_CODE, new HashSet<>(singletonList(OVERRUN)));
        assertEquals(new Long(1), results.count().block());
    }

    @Test
    public void getAppointmentsForAllStatus() throws Exception {
        Flux<Map<String,Object>> results = appointmentService.getAppointments(BRANCH_CODE, Collections.emptySet());
        assertEquals(new Long(9), results.count().block());
    }

    @Test
    public void shouldUpdateAppointmentStatus() throws Exception {
        Map<String, Object> expectedResult = new HashMap<>();
        expectedResult.put(AppointmentFields.APPOINTMENT_ID.val(), APPOINTMENT_ID);

        when(updateAppointmentLifeCycle.update(APPOINTMENT_ID, CHECKED_IN)).thenReturn(Mono.just(expectedResult));
        Map<String, Object> actualResult = appointmentService.updateAppointmentStatus(APPOINTMENT_ID, CHECKED_IN).block();

        assertEquals(expectedResult, actualResult);
    }

    @Test
    public void updatedCheckedInAtWhenAppointmentIsCheckedIn() throws Exception {
        when(updateAppointmentLifeCycle.update(APPOINTMENT_ID, CHECKED_IN)).thenReturn(Mono.just(Collections.emptyMap()));
        when(appointmentRepository.findById(APPOINTMENT_ID)).thenReturn(Mono.just(new Appointment(APPOINTMENT_ID, true, 90000L, null, null, null)));
        appointmentService.updateAppointmentStatus(APPOINTMENT_ID, CHECKED_IN).subscribe();

        verify(updateAppointmentLifeCycle).update(APPOINTMENT_ID, CHECKED_IN);
        verify(appointmentRepository).save(argThat(new ArgumentMatcher<Mono<Appointment>>(){

            @Override
            public boolean matches(Object o) {
                Appointment arg = ((Mono<Appointment>) o).block();
                Appointment expected = new Appointment(APPOINTMENT_ID, true, 90000L, clockProvider.getUTCInstant().toEpochMilli(), null, null);
                return arg.equals(expected);
            }
        }));
    }

    @Test
    public void updatedStateToInMeetingShouldUpdateStartedAt() {
        when(updateAppointmentLifeCycle.update(APPOINTMENT_ID, IN_MEETING)).thenReturn(Mono.just(Collections.emptyMap()));
        when(appointmentRepository.findById(APPOINTMENT_ID)).thenReturn(Mono.just(new Appointment(APPOINTMENT_ID, true, 90000L, null, null, null)));
        appointmentService.updateAppointmentStatus(APPOINTMENT_ID, IN_MEETING).subscribe();

        verify(updateAppointmentLifeCycle).update(APPOINTMENT_ID, IN_MEETING);
        verify(appointmentRepository).save(argThat(new ArgumentMatcher<Mono<Appointment>>(){

            @Override
            public boolean matches(Object o) {
                Appointment arg = ((Mono<Appointment>) o).block();
                Appointment expected = new Appointment(APPOINTMENT_ID, true, 90000L, null, clockProvider.getUTCInstant().toEpochMilli(), null);
                return arg.equals(expected);
            }
        }));
    }

    @Test
    public void updatedStateToCompletedShouldUpdateEndedAt() {
        when(updateAppointmentLifeCycle.update(APPOINTMENT_ID, COMPLETED)).thenReturn(Mono.just(Collections.emptyMap()));
        when(appointmentRepository.findById(APPOINTMENT_ID)).thenReturn(Mono.just(new Appointment(APPOINTMENT_ID, true, 90000L, null, 10000L, null)));
        appointmentService.updateAppointmentStatus(APPOINTMENT_ID, COMPLETED).subscribe();

        verify(updateAppointmentLifeCycle).update(APPOINTMENT_ID, COMPLETED);
        verify(appointmentRepository).save(argThat(new ArgumentMatcher<Mono<Appointment>>(){

            @Override
            public boolean matches(Object o) {
                Appointment arg = ((Mono<Appointment>) o).block();
                Appointment expected = new Appointment(APPOINTMENT_ID, true, 90000L, null, 10000L, clockProvider.getUTCInstant().toEpochMilli());
                return arg.equals(expected);
            }
        }));
    }

    @Test
    public void updatedStateToCancelledShouldUpdateEndedAt() {
        when(updateAppointmentLifeCycle.update(APPOINTMENT_ID, CANCELLED)).thenReturn(Mono.just(Collections.emptyMap()));
        when(appointmentRepository.findById(APPOINTMENT_ID)).thenReturn(Mono.just(new Appointment(APPOINTMENT_ID, true, 80000L, null, 90000L, null)));
        appointmentService.updateAppointmentStatus(APPOINTMENT_ID, CANCELLED).subscribe();

        verify(updateAppointmentLifeCycle).update(APPOINTMENT_ID, CANCELLED);
        verify(appointmentRepository).save(argThat(new ArgumentMatcher<Mono<Appointment>>(){

            @Override
            public boolean matches(Object o) {
                Appointment arg = ((Mono<Appointment>) o).block();
                Appointment expected = new Appointment(APPOINTMENT_ID, true, 80000L, null, 90000L, clockProvider.getUTCInstant().toEpochMilli());
                return arg.equals(expected);
            }
        }));
    }

    @Test
    public void whenUpdateStateThrowsExceptionSaveShouldNotBeCalled() {
        when(updateAppointmentLifeCycle.update(APPOINTMENT_ID, CANCELLED)).thenThrow(new Exceptions.ServerException(new ErrorCode("500"), new RestClientException("could not cancel appointment in MCAB."), ""));

        try {
            appointmentService.updateAppointmentStatus(APPOINTMENT_ID, CANCELLED);
        } catch (Exceptions.ServerException ignored) {}

        verify(updateAppointmentLifeCycle).update(APPOINTMENT_ID, CANCELLED);
        verify(appointmentRepository, times(0)).save(any());
    }

    @Test
    public void shouldReturnAppointment() throws Exception {
        Mono<Map<String, Object>> appointment = appointmentService.getAppointment(APPOINTMENT_ID);
        verify(retrieveAppointment).getAppointment(APPOINTMENT_ID);
        assertTrue((Boolean)appointment.block().get("proofOfId"));
    }

    @Test
    public void getAppointmentSummary() throws Exception {

        Mono<Map<AppointmentStatus, Integer>> result = appointmentService.getAppointmentSummary(BRANCH_CODE, new HashSet(
                        Arrays.asList(
                                CHECKED_IN, UPCOMING, NOSHOW, COMPLETED, NEXT_DAY, IN_MEETING, OVERRUN
                        )
                )
        );

        Map<AppointmentStatus, Integer> monoResult = result.block();

        assertEquals(7, monoResult.size());
        assertEquals(new Long(2), monoResult.get(CHECKED_IN));
        assertEquals(new Long(2), monoResult.get(NOSHOW));
        assertEquals(new Long(3), monoResult.get(UPCOMING));
        assertEquals(new Long(2), monoResult.get(COMPLETED));
        assertEquals(new Long(1), monoResult.get(NEXT_DAY));
        assertEquals(new Long(2), monoResult.get(IN_MEETING));
        assertEquals(new Long(1), monoResult.get(OVERRUN));
    }

    @Test
    public void getAppointmentList() throws Exception {

        Mono<Map<String, Object>> result = appointmentService.getAppointmentList(BRANCH_CODE, new HashSet<>(singletonList(CHECKED_IN)));

        Map<String, Object> appointmentList = result.block();
        List<Map<String, Object>> appointments = (List<Map<String, Object>>)appointmentList.get("appointments");
        Map<AppointmentStatus, Long> summary = (Map<AppointmentStatus, Long>)appointmentList.get("summary");

        assertEquals(2, appointments.size());
        assertEquals(10, summary.size());
        assertEquals(new Long(2), summary.get(CHECKED_IN));
        assertEquals(new Long(2), summary.get(NOSHOW));
        assertEquals(new Long(3), summary.get(UPCOMING));
        assertEquals(new Long(2), summary.get(COMPLETED));
        assertEquals(new Long(1), summary.get(NEXT_DAY));
        assertEquals(new Long(2), summary.get(IN_MEETING));
        assertEquals(new Long(1), summary.get(OVERRUN));
        assertEquals(new Long(0), summary.get(UNMAPPED));
        assertEquals(new Long(0), summary.get(CANCELLED));
        assertEquals(new Long(1), summary.get(OVERDUE));
    }

    private Map<String,Object> createAppointment(String appointmentId, AppointmentStatus status, Boolean isNoShow, LocalDateTime dateTime) {

        Map<String, Object> appointment = new HashMap<String, Object>();
        appointment.put("appointmentId", appointmentId);
        appointment.put("locationId", BRANCH_CODE);
        appointment.put(APPOINTMENT_STATUS.val(), status.getCode());
        appointment.put(DURATION.val(), 60L);
        appointment.put(IS_NOSHOW.val(), isNoShow);
        appointment.put(DATE_TIME.val(), dateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
        appointment.put(TIMEZONE.val(), "Europe/London");

        return appointment;
    }

    @Test
    public void testUpdateProofOfId() throws Exception {
        Mono<Appointment> appointmentMono = Mono.just(new Appointment(APPOINTMENT_ID, true, 123456L, null, null, null));
        when(appointmentRepository.save(argThat(new ArgumentMatcher<Mono<Appointment>>(){
            @Override
            public boolean matches(Object o) {
                return appointmentMono.block().equals(((Mono<Appointment>)o).block()) ;
            }
        }))).thenReturn(appointmentMono);

        Mono<Appointment> appointmentMonoActual = appointmentService.updateProofOfId(APPOINTMENT_ID, true);

        assertEquals(appointmentMono, appointmentMonoActual);
    }

    @Test
    public void createAppointment() throws Exception {
        AppointmentInput appointmentInput = new AppointmentInput("aCustomerId", "400246", 12345L, "business_banking_direct", "business_account_application", 30, "GB", "Europe/London");
        Mono mockMono = mock(Mono.class);
        when(createAppointment.createAppointment(appointmentInput)).thenReturn(mockMono);
        Mono<Map<String, Object>> mapMono = appointmentService.createAppointment(appointmentInput);
        assertEquals(mockMono, mapMono);
        verify(createAppointment).createAppointment(appointmentInput);
    }

    @Test
    public void getNextWorkingDayAppointments() throws Exception {
        Flux<Map<String,Object>> results = appointmentService.getNextWorkingDayAppointments(BRANCH_CODE);
        assertEquals(new Long(1), results.count().block());
    }

    @Test
    public void getYesterdayAppointments() throws Exception {
        List<Map<String,Object>> results = appointmentService.getYesterdayAppointments(BRANCH_CODE, Collections.emptySet()).collectList().block();
        assertEquals(1L, results.size());
        assertEquals("2222", results.get(0).get("appointmentId"));
    }
}