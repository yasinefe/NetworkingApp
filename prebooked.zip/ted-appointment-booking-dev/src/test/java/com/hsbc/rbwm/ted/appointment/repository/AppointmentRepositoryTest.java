/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.repository;

import com.hsbc.rbwm.ted.appointment.config.MongoConfig;
import com.hsbc.rbwm.ted.appointment.model.Appointments.Appointment;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import reactor.core.publisher.Mono;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

/**
 * Created by 44052007 on 08/09/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class AppointmentRepositoryTest {

    private AppointmentRepository appointmentRepository;

    @Mock
    private MongoConfig mongoConfig;
    @Mock
    private ReactiveMongoTemplate mongoTemplate;

    private Appointment appointment = new Appointment("appointmentId", Boolean.TRUE, 123456L, null, null, null);
    private Mono<Appointment> appointmentMono = Mono.just(appointment);

    @Before
    public void setUp() throws Exception {
        when(mongoConfig.getAppointmentsCollection()).thenReturn("appointments");
        appointmentRepository = new AppointmentRepository(mongoTemplate, mongoConfig);
    }

    @Test
    public void testSave() throws Exception {
        when(mongoTemplate.save(appointmentMono, "appointments")).thenReturn(appointmentMono);

        Mono<Appointment> appointmentMonoActual = appointmentRepository.save(appointmentMono);

        assertEquals(appointmentMono, appointmentMonoActual);
    }

    @Test
    public void testFindById() throws Exception {
        when(mongoTemplate.findById(appointment.appointmentId, Appointment.class, "appointments")).thenReturn(appointmentMono);

        Mono<Appointment> appointmentMonoActual = appointmentRepository.findById(appointment.appointmentId);

        assertEquals(appointmentMono, appointmentMonoActual);
    }

    @Test
    public void testFindByIdWhenNotFound() throws Exception {
        when(mongoTemplate.findById(appointment.appointmentId, Appointment.class, "appointments")).thenReturn(Mono.empty());

        Mono<Appointment> appointmentMonoActual = appointmentRepository.findById(appointment.appointmentId);

        Appointment appointmentActual = appointmentMonoActual.block();
        assertEquals(this.appointment.appointmentId, appointmentActual.appointmentId);
        assertNull(appointmentActual.proofOfId);
        assertNull(appointmentActual.createdAt);
    }

}