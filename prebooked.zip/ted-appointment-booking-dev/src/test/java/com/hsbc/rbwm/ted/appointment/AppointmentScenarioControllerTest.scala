/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment

import java.net.URL
import java.nio.file.{Files, Paths}
import java.time._
import java.util.Collections

import com.github.tomakehurst.wiremock.client.WireMock
import com.github.tomakehurst.wiremock.client.WireMock._
import com.hsbc.rbwm.ted.appointment.config.{CryptConfigurationTest, MCABConfiguration}
import com.hsbc.rbwm.ted.appointment.filter.CorrelationIdFilter
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.RetrieveAppointments
import com.hsbc.rbwm.ted.appointment.model.Appointments.Appointment
import com.hsbc.rbwm.ted.appointment.repository.AppointmentRepository
import com.hsbc.rbwm.ted.appointment.service.{AppointmentFunctions, AppointmentService, ClockProvider}
import org.junit.runner.RunWith
import org.mockito.Matchers.anyListOf
import org.mockito.Mockito.when
import org.scalatest.junit.JUnitRunner
import org.scalatest.mockito.MockitoSugar
import org.scalatest.{BeforeAndAfter, FlatSpec, GivenWhenThen, Matchers}
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock
import org.springframework.http.HttpStatus
import org.springframework.test.context.{ActiveProfiles, TestContextManager, TestPropertySource}
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.result.MockMvcResultMatchers._
import org.springframework.test.web.servlet.setup.{AbstractMockMvcBuilder, MockMvcBuilders, StandaloneMockMvcBuilder}
import org.springframework.web.context.WebApplicationContext
import reactor.core.publisher.Flux

/**
  * Created by 43578876 on 19/06/2017.
  */
@RunWith(classOf[JUnitRunner])
@ActiveProfiles(profiles = Array("int-be-test"))
@TestPropertySource(properties = Array[String] {
  "spring.config.location = classpath:config/ted-appointment-booking.yaml"
})
@AutoConfigureWireMock(port = 9999)
@SpringBootTest(webEnvironment = WebEnvironment.MOCK, classes = Array(classOf[Application], classOf[CryptConfigurationTest.Config]))
class AppointmentScenarioControllerTest extends FlatSpec
  with Matchers
  with MockitoSugar
  with BeforeAndAfter
  with GivenWhenThen
  with RestTestPack {

  var mvc: MockMvc = _

  @Autowired
  val webApplicationContext: WebApplicationContext = null

  @Autowired
  var mcabConfiguration: MCABConfiguration = _

  @Autowired
  var retrieveAppointments: RetrieveAppointments = _

  @Autowired
  var appointmentFunctions: AppointmentFunctions = _

  @Autowired
  var appointmentService: AppointmentService = _

  var appointmentRepository: AppointmentRepository = _

  before {
    WireMock.configureFor(9999)
    new TestContextManager(this.getClass).prepareTestInstance(this)

    val mvcBuilder: AbstractMockMvcBuilder[_ <: AbstractMockMvcBuilder[StandaloneMockMvcBuilder]] = MockMvcBuilders
      .webAppContextSetup(webApplicationContext)
      .addFilters(new CorrelationIdFilter)

    mvc = mvcBuilder.build()

    //set scenario datetime via clock provider for java8, NOTE DATETIMES are offset around this time in the scenario file.
    val dateTime = LocalDateTime.of(2017, 6, 22, 12, 2, 0, 0).atZone(ZoneId.of("UTC")).toInstant
    val asOfClock = Clock.fixed(dateTime, ZoneId.systemDefault())
    val clockProvider = new ClockProvider(asOfClock)

    ReflectionTestUtils.setField(appointmentFunctions, "clockProvider", clockProvider)

    appointmentRepository = mock[AppointmentRepository]
    when(appointmentRepository.findByIds(anyListOf(classOf[String]))).thenReturn(Flux.just(
      new Appointment("VR8S1702", null, null, null, null, null),
      new Appointment("VR8S1703", null, null, null, null, null)))
    ReflectionTestUtils.setField(appointmentService, "appointmentRepository", appointmentRepository)
  }

  it should " return a list of UPCOMING appointments " in {

    setUpMCABRequestAndResponse

    val response =
      """
        |[
        |  {
        |    "appointmentId": "VR8S1702",
        |    "appointmentStatus": "NOSHOW",
        |    "isNoShow": false
        |  },
        |  {
        |    "appointmentId": "VR8S1703",
        |    "appointmentStatus": "UPCOMING",
        |    "isNoShow": false
        |  }
        |]
      """.stripMargin

    doGetAsync("/appointments/branch/404519?status=UPCOMING", HttpStatus.OK)
      .andExpect(content.json(response, false))
  }

  it should " return a list of NOSHOW appointments " in {

    setUpMCABRequestAndResponse

    val response =
      """
        |[
        |  {
        |    "appointmentId": "VR8S1708",
        |    "appointmentStatus": "UPCOMING",
        |    "isNoShow": true
        |  },
        |  {
        |    "appointmentId": "VR8S1709",
        |    "appointmentStatus": "NOSHOW",
        |    "isNoShow": true
        |  }
        |]
      """.stripMargin

    doGetAsync("/appointments/branch/404519?status=NOSHOW", HttpStatus.OK)
      .andExpect(content.json(response, false))
  }

  it should " return a list of CHECKED_IN appointments WHICH includes OVERDUE" in {
    when(appointmentRepository.findByIds(anyListOf(classOf[String]))).thenReturn(Flux.just(
      new Appointment("VR8S1704", false, null, 123560000L, null, null),
      new Appointment("VR8S1710", true, null, 123560000L, null, null))
    )

    setUpMCABRequestAndResponse

    val response =
      """
        |[
        |  {
        |    "appointmentId": "VR8S1704",
        |    "appointmentStatus": "CHECKED_IN",
        |    "proofOfId": false,
        |    "checkedInAt": 123560000
        |  },
        |  {
        |    "appointmentId": "VR8S1710",
        |    "appointmentStatus": "CHECKED_IN",
        |    "proofOfId": true,
        |    "checkedInAt": 123560000
        |  }
        |]
      """.stripMargin

    doGetAsync("/appointments/branch/404519?status=CHECKED_IN", HttpStatus.OK)
      .andExpect(content.json(response, false))
  }

  it should " return a list of OVERDUE appointments" in {
    when(appointmentRepository.findByIds(anyListOf(classOf[String]))).thenReturn(Flux.fromIterable(
      Collections.singletonList(new Appointment("VR8S1710", true, null, 123560000L, null, null))
    ))

    setUpMCABRequestAndResponse

    val response =
      """
        |[
        |  {
        |    "appointmentId": "VR8S1710",
        |    "appointmentStatus": "CHECKED_IN",
        |    "proofOfId": true,
        |    "checkedInAt": 123560000
        |  }
        |]
      """.stripMargin

    doGetAsync("/appointments/branch/404519?status=OVERDUE", HttpStatus.OK)
      .andExpect(content.json(response, false))
  }

  it should " return a list of COMPLETED appointments which includes NOSHOWS " in {
    when(appointmentRepository.findByIds(anyListOf(classOf[String]))).thenReturn(Flux.just(
      new Appointment("VR8S1712", false, null, 123560000L, 123570000L, 123580000L),
      new Appointment("VR8S1706", true, null, 123560000L, 123570000L, 123580000L))
    )

    setUpMCABRequestAndResponse

    val response =
      """
        |[
        |  {
        |    "appointmentId": "VR8S1712",
        |    "appointmentStatus": "COMPLETED",
        |    "isNoShow": false,
        |    "proofOfId": false,
        |    "checkedInAt": 123560000,
        |    "startedAt": 123570000,
        |    "endedAt": 123580000
        |  },
        |  {
        |    "appointmentId": "VR8S1708",
        |    "appointmentStatus": "UPCOMING",
        |    "isNoShow": true
        |  },
        |  {
        |    "appointmentId": "VR8S1709",
        |    "appointmentStatus": "NOSHOW",
        |    "isNoShow": true
        |  },
        |  {
        |    "appointmentId": "VR8S1706",
        |    "appointmentStatus": "COMPLETED",
        |    "isNoShow": false,
        |    "proofOfId": true,
        |    "checkedInAt": 123560000,
        |    "startedAt": 123570000,
        |    "endedAt": 123580000
        |  }
        |]
      """.stripMargin

    doGetAsync("/appointments/branch/404519?status=COMPLETED", HttpStatus.OK)
      .andExpect(content.json(response, false))
  }

  it should "should return a list of all appointments when status is not passed" in {
    when(appointmentRepository.findByIds(anyListOf(classOf[String]))).thenReturn(Flux.just(
      new Appointment("VR8S1704", true, null, 123560000L, null, null),
      new Appointment("VR8S1705", true, null, 123560000L, 123570000L, null),
      new Appointment("VR8S1706", true, null, 123560000L, 123570000L, 123580000L),
      new Appointment("VR8S1710", true, null, 123560000L, null, null),
      new Appointment("VR8S1711", true, null, 123560000L, 123570000L, null),
      new Appointment("VR8S1712", true, null, 123560000L, 123570000L, 123580000L),
      new Appointment("VR8S1714", true, null, 123560000L, 123570000L, null)
    ))

    setUpMCABRequestAndResponse

    val response =
      """
        |[
        |   {
        |      "appointmentId": "VR8S1702",
        |      "appointmentStatus": "NOSHOW",
        |      "isNoShow": false
        |    },
        |    {
        |      "appointmentId": "VR8S1703",
        |      "appointmentStatus": "UPCOMING",
        |      "isNoShow": false
        |    },
        |    {
        |      "appointmentId": "VR8S1704",
        |      "appointmentStatus": "CHECKED_IN",
        |      "proofOfId": true,
        |      "checkedInAt": 123560000
        |    },
        |    {
        |      "appointmentId": "VR8S1705",
        |      "appointmentStatus": "IN_MEETING",
        |      "proofOfId": true,
        |      "checkedInAt": 123560000,
        |      "startedAt": 123570000
        |    },
        |    {
        |      "appointmentId": "VR8S1706",
        |      "appointmentStatus": "COMPLETED",
        |      "isNoShow": false,
        |      "proofOfId": true,
        |      "checkedInAt": 123560000,
        |      "startedAt": 123570000,
        |      "endedAt": 123580000
        |    },
        |    {
        |      "appointmentId": "VR8S1708",
        |      "appointmentStatus": "UPCOMING",
        |      "isNoShow": true
        |    },
        |    {
        |      "appointmentId": "VR8S1709",
        |      "appointmentStatus": "NOSHOW",
        |      "isNoShow": true
        |    },
        |    {
        |      "appointmentId": "VR8S1710",
        |      "appointmentStatus": "CHECKED_IN",
        |      "proofOfId": true,
        |      "checkedInAt": 123560000
        |    },
        |    {
        |      "appointmentId": "VR8S1711",
        |      "appointmentStatus": "IN_MEETING",
        |      "proofOfId": true,
        |      "checkedInAt": 123560000,
        |      "startedAt": 123570000
        |    },
        |    {
        |      "appointmentId": "VR8S1712",
        |      "appointmentStatus": "COMPLETED",
        |      "isNoShow": false,
        |      "proofOfId": true,
        |      "checkedInAt": 123560000,
        |      "startedAt": 123570000,
        |      "endedAt": 123580000
        |    },
        |    {
        |      "appointmentId": "VR8S1714",
        |      "appointmentStatus": "IN_MEETING",
        |      "proofOfId": true,
        |      "checkedInAt": 123560000,
        |      "startedAt": 123570000
        |    }
        |]
      """.stripMargin

    doGetAsync("/appointments/branch/404519", HttpStatus.OK)
      .andExpect(content.json(response, false))

  }

  it should " return a list of OVERRUN appointments" in {

    setUpMCABRequestAndResponse

    val response =
      """
        |[
        |  {
        |    "appointmentId": "VR8S1714",
        |    "appointmentStatus": "IN_MEETING"
        |  }
        |]
      """.stripMargin

    doGetAsync("/appointments/branch/404519?status=OVERRUN", HttpStatus.OK)
      .andExpect(content.json(response, false))
  }

  it should " return a count of NEXT_DAY appointments" in {

    setUpMCABRequestAndResponse

    val response =
      """
        |{
        |  "NEXT_DAY": 1
        |}
      """.stripMargin

    doGetAsync("/appointments/summary/branch/404519?status=NEXT_DAY", HttpStatus.OK)
      .andExpect(content.json(response, false))
  }

  def setUpMCABRequestAndResponse(): Unit = {

    /* FOLLOWING STATUES / DATE TIMES ARE IMPLEMENTED IN THE scenario-response.json
     * VAPP ID		lifeCycleState		dateTime
     + VR8S1701	Scheduled			now + 36h
     + VR8S1702	NoShow				now - 1m
     + VR8S1703	Scheduled			now + 1h
     + VR8S1704	CheckedIn			now + 15m
     + VR8S1705	InProgress			now - 5m
     + VR8S1706	Completed   		now - 10m
     +
     + VR8S1708	Scheduled			now - 30m
     + VR8S1709	NoShow				now - 25m
     + VR8S1710	CheckedIn			now - 1h
     + VR8S1711	InProgress			now - 15m
     + VR8S1712	Completed   		now - 3h
     + VR8S1713	Completed   		now - 32h
     + VR8S1714	InProgress			now - 2h		duration: 30
     */

    //ONE TIME SETUP FOR ALL TESTS
    val mcabRequest =
      """
        |{
        |  "customerIdentifier": {
        |  },
        |  "resourceIdentifier": {
        |  },
        |  "locationType": {
        |    "locationId": "404519"  },
        |  "spanInDays": "2"
        |}
      """.stripMargin

    val path: URL = getClass.getClassLoader.getResource("mock-data/mcab/2.3.1/retrieve-appointments-scenario-response.json")
    val mcabResponse: String = new String(Files.readAllBytes(Paths.get(path.toURI)))

    stubFor(post(urlPathEqualTo("/group-chnlsvc-salesmanagement-appointmentbooking-svc/retrieveAppointments"))
      .withRequestBody(equalToJson(mcabRequest, true, true))
      .withHeader("X-HDR-Channel-CC", equalTo("GB"))
      .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
      .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
      .withHeader("X-HDR-Channel-Locale", equalTo("en"))
      .withHeader("Content-Type", equalTo("application/json"))
      .willReturn(aResponse
        .withStatus(200)
        .withHeader("Content-Type", "application/json")
        .withBody(mcabResponse)))
  }
}
