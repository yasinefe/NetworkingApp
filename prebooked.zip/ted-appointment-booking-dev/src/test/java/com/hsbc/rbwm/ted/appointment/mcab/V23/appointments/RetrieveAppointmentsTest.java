/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.V23.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.appointment.api.AppointmentMetaServiceApi;
import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.AddCustomFields;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.AppointmentsTransformer;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.RetrieveAppointments;
import com.hsbc.rbwm.ted.appointment.service.AppointmentFunctions;
import com.hsbc.rbwm.ted.appointment.service.ClockProvider;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Map;
import java.util.Optional;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static java.lang.String.format;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Created by 44027117 on 19/06/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class RetrieveAppointmentsTest {

    public static final String BRANCH_CODE = "branchCode";
    private RetrieveAppointments retrieveAppointments;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    private AppointmentsTransformer appointmentTransformer;

    private MCABConfiguration mcabConfiguration;

    @Mock
    private AppointmentConfiguration appointmentConfig;

    @Mock
    private AppointmentMetaServiceApi appointmentMetaService;

    @Before
    public void setUp() throws IOException {
        // 8th September 2017 Friday
        Instant dateTime = LocalDateTime.of(2017, 9, 8, 12, 2, 0, 0).atZone(ZoneId.of("UTC")).toInstant();
        Clock asOfClock = Clock.fixed(dateTime, ZoneId.systemDefault());
        ClockProvider clockProvider = new ClockProvider(asOfClock);

        mcabConfiguration = new MCABConfigurationTestBuilder()
                .build(wireMockRule);

        appointmentTransformer = new AppointmentsTransformer(
                new AddCustomFields(appointmentConfig, new AppointmentFunctions(clockProvider, appointmentConfig))
        );

        when(appointmentMetaService.getCategoryName(anyString())).thenReturn(Optional.of("Insurance"));
        when(appointmentMetaService.getTopicName(anyString())).thenReturn(Optional.of("Home Insurance (Standalone)"));

        retrieveAppointments = new RetrieveAppointments(mcabConfiguration, new ResponseHandler(), appointmentTransformer, appointmentMetaService, clockProvider);

        CorrelationIdContainer.setId("test-correlation-id");
    }

    @Test
    public void testGetAppointments() throws Exception {
        String jsonRequest = createRequest(2);
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource("mock-data/mcab/2.3.1/retrieve-appointments-response.json");
        String fileContent = new String(Files.readAllBytes(Paths.get(path.toURI())));

        stubWiremock(jsonRequest, fileContent);

        Flux result = retrieveAppointments.getAppointments("branchCode");
        Map<String, Object> appointments = (Map) result.blockFirst();
        assertTrue(appointments != null);
        assertEquals("Insurance", appointments.get("topicName"));
        assertEquals("Home Insurance (Standalone)", appointments.get("topicCategoryName"));
    }


    @Test
    public void testGetAppointmentsEmpty() throws Exception {
        String jsonRequest = createRequest(2);

        stubWiremock(jsonRequest, "{\n" +
                "  \"reasons\": [],\n" +
                "  \"extension\": {}," +
                "  \"upcomingAppointments\": []," +
                "  \"pastAppointments\": []," +
                "  \"canceledAppointments\": []" +
                "}");

        Flux result = retrieveAppointments.getAppointments("branchCode");
        assertTrue(result.blockFirst() == null);
    }

    @Test
    public void testGetAppointmentsForSaturday() throws Exception {
        // 9th September 2017 Saturday
        Instant dateTime = LocalDateTime.of(2017, 9, 9, 12, 2, 0, 0).atZone(ZoneId.of("UTC")).toInstant();
        Clock asOfClock = Clock.fixed(dateTime, ZoneId.systemDefault());
        ClockProvider clockProvider = new ClockProvider(asOfClock);
        retrieveAppointments = new RetrieveAppointments(mcabConfiguration, new ResponseHandler(), appointmentTransformer, appointmentMetaService, clockProvider);

        String jsonRequest = createRequest(3);
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource("mock-data/mcab/2.2/retrieve-appointments-response.json");
        String fileContent = new String(Files.readAllBytes(Paths.get(path.toURI())));

        stubWiremock(jsonRequest, fileContent);

        Flux result = retrieveAppointments.getAppointments("branchCode");
        Map<String, Object> appointments = (Map) result.blockFirst();
        assertTrue(appointments != null);
        assertEquals("Insurance", appointments.get("topicName"));
        assertEquals("Home Insurance (Standalone)", appointments.get("topicCategoryName"));
    }

    private void stubWiremock(String jsonRequest, String fileContent) {
        stubFor(post(urlPathEqualTo("/mcabBaseUri/retrieveAppointments"))
                .withRequestBody(equalToJson(jsonRequest, true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(fileContent)));
    }

    private String createRequest(int spanInDays) {
        return format("{\n" +
                "  \"customerIdentifier\": {\n" +
                "  },\n" +
                "  \"resourceIdentifier\": {\n" +
                "  },\n" +
                "  \"locationType\": {\n" +
                "    \"locationId\": \"%s\"" +
                "  },\n" +
                "  \"spanInDays\": \"" + spanInDays + "\",\n" +
                "  \"platformIndicator\": \"ted\"" +
                "}", BRANCH_CODE);
    }
}
