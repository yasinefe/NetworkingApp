/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment;

import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import static com.hsbc.rbwm.ted.appointment.model.AppointmentFields.*;

/**
 * Created by 43578876 on 27/06/2017.
 */
public class AppointmentTestData {

    private String branchCode;

    public AppointmentTestData(String branchCode) {
        this.branchCode = branchCode;
    }

    public Map<String,Object> createAppointment(AppointmentStatus status, Boolean isNoShow, ZonedDateTime dateTime) {

        Map<String, Object> appointment = new HashMap<String, Object>();
        appointment.put("appointmentId", "1234");
        appointment.put("locationId", branchCode);
        appointment.put(APPOINTMENT_STATUS.val(), status.getCode());
        appointment.put(DURATION.val(), "60");
        appointment.put(IS_NOSHOW.val(), isNoShow);
        appointment.put(DATE_TIME.val(), dateTime.toInstant().toEpochMilli());

        return appointment;
    }
}
