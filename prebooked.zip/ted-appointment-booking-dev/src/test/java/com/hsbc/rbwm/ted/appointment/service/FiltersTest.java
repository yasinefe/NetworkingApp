/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import org.junit.Test;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by 44052007 on 26/01/2017.
 */
public class FiltersTest {

    private Filters filters;

    private ZonedDateTime yesterday23pm = LocalDateTime.of(2018, 1, 24, 23, 0, 0, 0).atZone(ZoneId.of("UTC"));
    private ZonedDateTime today1am = LocalDateTime.of(2018, 1, 25, 1, 0, 0, 0).atZone(ZoneId.of("UTC"));

    private ClockProvider clockYesterday23pm = new ClockProvider(Clock.fixed(yesterday23pm.toInstant(), ZoneId.of("UTC")));
    private ClockProvider clockToday1am = new ClockProvider(Clock.fixed(today1am.toInstant(), ZoneId.of("UTC")));

    // |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
    // 8   9   10  11  12  13  14  15  16  17  18  19  20  21  22  23  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18  19  20  21  22  23  0
    //
    //                                                                 |--------------------------------- 25/01/2018 Europe London ------------------------------------|
    //
    //                         Clock Samples       (yesterday23pm) *       * (today1am)
    //
    // |-------------------------- 25/01/2018 America Los Angeles -------------------------------------|
    //
    // 0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18  19  20  21  22  23  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16
    // |---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

    @Test
    public void isSameDayWhenTimeZoneIsEuropeLondon() throws Exception {
        setTime(clockYesterday23pm);

        Map<String, Object> appointment = new HashMap<>();
        ZonedDateTime yesterday17pm = LocalDateTime.of(2018, 1, 24, 17, 0, 0, 0).atZone(ZoneId.of("Europe/London"));
        appointment.put("dateTime", yesterday17pm.toInstant().toEpochMilli());
        appointment.put("timezone", "Europe/London");

        assertTrue(filters.isSameDay.test(appointment));
    }

    @Test
    public void isNotSameDayWhenTimeZoneIsEuropeLondon() throws Exception {
        setTime(clockToday1am);

        Map<String, Object> appointment = new HashMap<>();
        ZonedDateTime yesterday17pm = LocalDateTime.of(2018, 1, 24, 17, 0, 0, 0).atZone(ZoneId.of("Europe/London"));
        appointment.put("dateTime", yesterday17pm.toInstant().toEpochMilli());
        appointment.put("timezone", "Europe/London");

        assertFalse(filters.isSameDay.test(appointment));
    }

    @Test
    public void isStillSameDayWhenTimeZoneIsAmericaLosAngeles() throws Exception {
        setTime(clockToday1am);

        Map<String, Object> appointment = new HashMap<>();
        ZonedDateTime yesterday17pm = LocalDateTime.of(2018, 1, 24, 17, 0, 0, 0).atZone(ZoneId.of("America/Los_Angeles"));
        appointment.put("dateTime", yesterday17pm.toInstant().toEpochMilli());
        appointment.put("timezone", "America/Los_Angeles");

        assertTrue(filters.isSameDay.test(appointment));
    }

    @Test
    public void isNextDayWhenTimeZoneIsEuropeLondon() throws Exception {
        setTime(clockYesterday23pm);

        Map<String, Object> appointment = new HashMap<>();
        ZonedDateTime yesterday17pm = LocalDateTime.of(2018, 1, 24, 17, 0, 0, 0).atZone(ZoneId.of("Europe/London"));
        appointment.put("dateTime", yesterday17pm.plusDays(1).toInstant().toEpochMilli());
        appointment.put("timezone", "Europe/London");

        assertTrue(filters.isNextDay.test(appointment));
    }

    @Test
    public void isNotNextDayWhenTimeZoneIsEuropeLondon() throws Exception {
        setTime(clockToday1am);

        Map<String, Object> appointment = new HashMap<>();
        ZonedDateTime yesterday17pm = LocalDateTime.of(2018, 1, 24, 17, 0, 0, 0).atZone(ZoneId.of("Europe/London"));
        appointment.put("dateTime", yesterday17pm.plusDays(1).toInstant().toEpochMilli());
        appointment.put("timezone", "Europe/London");

        assertFalse(filters.isNextDay.test(appointment));
    }

    @Test
    public void isStillNextDayWhenTimeZoneIsAmericaLosAngeles() throws Exception {
        setTime(clockToday1am);

        Map<String, Object> appointment = new HashMap<>();
        ZonedDateTime yesterday17pm = LocalDateTime.of(2018, 1, 24, 17, 0, 0, 0).atZone(ZoneId.of("America/Los_Angeles"));
        appointment.put("dateTime", yesterday17pm.plusDays(1).toInstant().toEpochMilli());
        appointment.put("timezone", "America/Los_Angeles");

        assertTrue(filters.isNextDay.test(appointment));
    }

    @Test
    public void isYesterday() throws Exception {
        setTime(clockToday1am);

        Map<String, Object> appointment = new HashMap<>();
        ZonedDateTime yesterday17pm = LocalDateTime.of(2018, 1, 24, 17, 0, 0, 0).atZone(ZoneId.of("Europe/London"));
        appointment.put("dateTime", yesterday17pm.toInstant().toEpochMilli());
        appointment.put("timezone", "Europe/London");

        assertTrue(filters.isYesterday.test(appointment));
    }

    private void setTime(ClockProvider clockProvider) {
        AppointmentFunctions appointmentFunctions = new AppointmentFunctions(clockProvider, new AppointmentConfiguration());
        filters = new Filters(appointmentFunctions);
    }

}
