/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.mcab.V23.appointments;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.config.MCABConfiguration;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.AddCustomFields;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.AppointmentsTransformer;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.MCABSyncClientRestTemplate;
import com.hsbc.rbwm.ted.appointment.mcab.v22.appointments.RetrieveAppointment;
import com.hsbc.rbwm.ted.appointment.service.AppointmentFunctions;
import com.hsbc.rbwm.ted.appointment.service.AppointmentMetaService;
import com.hsbc.rbwm.ted.appointment.service.ClockProvider;
import com.hsbc.rbwm.ted.rest.api.ResponseHandler;
import com.hsbc.rbwm.ted.rest.error.Exceptions;
import com.rbwm.ted.telemetry.correlation.CorrelationIdContainer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static java.lang.String.format;
import static java.util.stream.Collectors.toSet;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.mockito.Mockito.when;

/**
 * Created by 44052007 on 23/06/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class RetrieveAppointmentTest {

    private static final String APPOINTMENT_ID = "VC8L4N63";
    private RetrieveAppointment retrieveAppointment;
    private MCABConfiguration mcabConfiguration;
    private AppointmentsTransformer appointmentsTransformer;

    @Rule
    public WireMockRule wireMockRule = new WireMockRule(wireMockConfig().dynamicPort());

    @Mock
    AppointmentMetaService appointmentMetaService;

    private static final String APPOINTMENT_REQUEST = "{\"customerIdentifier\": {}, \"appointmentIdentifier\": {\"appointmentIdentifier\": \"%s\"},\"platformIndicator\": \"ted\"}";

    @Before
    public void setUp() throws IOException {
        AppointmentConfiguration appointmentConfiguration = new AppointmentConfiguration();

        ReflectionTestUtils.setField(appointmentConfiguration, "noShowDuration", 10);
        ReflectionTestUtils.setField(appointmentConfiguration, "criticalOverdueOffset", 20);

        mcabConfiguration = new MCABConfigurationTestBuilder()
                .build(wireMockRule);
        AppointmentFunctions appointmentFunctions = new AppointmentFunctions(new ClockProvider(), appointmentConfiguration);
        AddCustomFields addCustomFields = new AddCustomFields(appointmentConfiguration, appointmentFunctions);
        appointmentsTransformer = new AppointmentsTransformer(addCustomFields);
        when(appointmentMetaService.findChecklist("mortgages", "homeowner_loan"))
                .thenReturn(Stream.of("proofOfId", "proofOfAddress").collect(toSet()));

        when(appointmentMetaService.getCategoryName("mortgages")).thenReturn(Optional.of("Mortgages"));
        when(appointmentMetaService.getTopicName("homeowner_loan")).thenReturn(Optional.of("Arrange a homeowner loan"));

        retrieveAppointment = new RetrieveAppointment(mcabConfiguration, new ResponseHandler(), appointmentsTransformer, appointmentMetaService);

        CorrelationIdContainer.setId("test-correlation-id");
    }

    @Test
    public void testRetrieveAppointment() throws Exception {
        String jsonRequest = format(APPOINTMENT_REQUEST, APPOINTMENT_ID);
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource("mock-data/mcab/2.3.1/retrieve-appointment-response.json");
        String jsonResponse = new String(Files.readAllBytes(Paths.get(path.toURI())));

        stubFor(post(urlPathEqualTo("/mcabBaseUri/retrieveAppointment"))
                .withRequestBody(equalToJson(jsonRequest, true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        Map<String, Object> appointmentResponse = retrieveAppointment.getAppointment(APPOINTMENT_ID).block();
        assertTrue(appointmentResponse != null);
        assertEquals(APPOINTMENT_ID, appointmentResponse.get("appointmentId"));
        assertTrue(((Set<String>) appointmentResponse.get("checklist")).contains("proofOfId"));
        assertTrue(((Set<String>) appointmentResponse.get("checklist")).contains("proofOfAddress"));
        assertEquals("Mortgages", appointmentResponse.get("topicName"));
        assertEquals("Arrange a homeowner loan", appointmentResponse.get("topicCategoryName"));
        assertEquals("mjack@email.com", ((Map<String, Object>) appointmentResponse.get("attendee")).get("email"));
        assertEquals("This is a note", appointmentResponse.get("comments"));
    }

    @Test
    public void testRetrieveAppointmentEmptyFieldsRemoved() throws Exception {
        String jsonRequest = format(APPOINTMENT_REQUEST, APPOINTMENT_ID);
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource("mock-data/mcab/2.3.1/retrieve-appointment-response_emptyFields.json");
        String jsonResponse = new String(Files.readAllBytes(Paths.get(path.toURI())));

        stubFor(post(urlPathEqualTo("/mcabBaseUri/retrieveAppointment"))
                .withRequestBody(equalToJson(jsonRequest, true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        Map<String, Object> appointmentResponse = retrieveAppointment.getAppointment(APPOINTMENT_ID).block();
        assertTrue(appointmentResponse != null);
        assertEquals(APPOINTMENT_ID, appointmentResponse.get("appointmentId"));
        assertTrue(((Set<String>) appointmentResponse.get("checklist")).contains("proofOfId"));
        assertTrue(((Set<String>) appointmentResponse.get("checklist")).contains("proofOfAddress"));
        assertEquals("Mortgages", appointmentResponse.get("topicName"));
        assertEquals("Arrange a homeowner loan", appointmentResponse.get("topicCategoryName"));
        assertEquals(null, ((Map<String, Object>) appointmentResponse.get("attendee")).get("email"));
    }


    @Test(expected = Exceptions.NotFoundException.class)
    public void testGetAppointmentInCaseMcabReturnsConflict() throws Exception {
        String jsonRequest = format(APPOINTMENT_REQUEST, APPOINTMENT_ID);
        String jsonResponse = "{ \"reasons\": [], \"responseCode\": \"409\" }";

        stubFor(post(urlPathEqualTo("/mcabBaseUri/retrieveAppointment"))
                .withRequestBody(equalToJson(jsonRequest, true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withStatus(409)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        try {
            retrieveAppointment.getAppointment(APPOINTMENT_ID).block();
        } catch (Exceptions.UnexpectedException e) {
            assertEquals("ABP-GET-APPOINTMENT-UNEXPECTED", e.getErrorCode().code);
            throw e;
        }
    }

    @Test(expected = Exceptions.NoConnectionException.class)
    public void testTimeoutWhenRetrievingAppointment() throws Exception {
        ReflectionTestUtils.setField(mcabConfiguration, "mcabTimeOutSeconds", 1);
        ReflectionTestUtils.setField(mcabConfiguration, "mcabSyncClientRestTemplate", new MCABSyncClientRestTemplate(mcabConfiguration));
        retrieveAppointment = new RetrieveAppointment(mcabConfiguration, new ResponseHandler(), appointmentsTransformer, appointmentMetaService);

        String jsonRequest = format(APPOINTMENT_REQUEST, APPOINTMENT_ID);
        ClassLoader classLoader = getClass().getClassLoader();
        URL path = classLoader.getResource("mock-data/mcab/2.3.1/retrieve-appointment-response.json");
        String jsonResponse = new String(Files.readAllBytes(Paths.get(path.toURI())));

        stubFor(post(urlPathEqualTo("/mcabBaseUri/retrieveAppointment"))
                .withRequestBody(equalToJson(jsonRequest, true, false))
                .withHeader("X-HDR-Channel-CC", equalTo("GB"))
                .withHeader("X-HDR-Channel-CorrelationId", equalTo("test-correlation-id"))
                .withHeader("X-HDR-Channel-GMC", equalTo("HBEU"))
                .withHeader("X-HDR-Channel-Locale", equalTo("en"))
                .willReturn(aResponse()
                        .withFixedDelay(1100)
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(jsonResponse)));

        try {
            retrieveAppointment.getAppointment(APPOINTMENT_ID).block();
        } catch (Exceptions.NoConnectionException e) {
            assertEquals("ABP-GET-APPOINTMENT-NO-CONNECTION", e.getErrorCode().code);
            throw e;
        }
    }
}
