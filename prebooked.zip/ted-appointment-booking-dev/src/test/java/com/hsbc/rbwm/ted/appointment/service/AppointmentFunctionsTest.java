/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.hsbc.rbwm.ted.appointment.service;

import com.hsbc.rbwm.ted.appointment.AppointmentTestData;
import com.hsbc.rbwm.ted.appointment.config.AppointmentConfiguration;
import com.hsbc.rbwm.ted.appointment.model.AppointmentFields;
import com.hsbc.rbwm.ted.appointment.model.AppointmentStatus;
import org.joda.time.DateTimeUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by 43578876 on 27/06/2017.
 */
public class AppointmentFunctionsTest {


    private AppointmentTestData testData = new AppointmentTestData("400734");
    private ClockProvider clockProvider = new ClockProvider();
    private AppointmentConfiguration appointmentConfiguration = new AppointmentConfiguration();
    private AppointmentFunctions appointmentFunctions = new AppointmentFunctions(clockProvider, appointmentConfiguration);

    @Before
    public void setUp() {
        DateTimeUtils.setCurrentMillisSystem();
        ReflectionTestUtils.setField(appointmentConfiguration, "overdueOffset", 5);
    }

    @Test
    public void testIsNoShowDerivedfromUpcomingOK() {

        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC).minusMinutes(6);

        Map<String, Object> upcomingNoShow = testData.createAppointment(AppointmentStatus.UPCOMING, false, utc);
        upcomingNoShow.put(AppointmentFields.NO_SHOW_DURATION.val(), "5");

        assertTrue(appointmentFunctions.isNoShow(upcomingNoShow,utc.toInstant().toEpochMilli()));
    }

    @Test
    public void testIsNoShowDerivedfromNoShowOK() {

        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC).minusMinutes(6);

        Map<String, Object> upcomingNoShow = testData.createAppointment(AppointmentStatus.NOSHOW, false, utc);
        upcomingNoShow.put(AppointmentFields.NO_SHOW_DURATION.val(), "5");

        assertTrue(appointmentFunctions.isNoShow(upcomingNoShow,utc.toInstant().toEpochMilli()));
    }

    @Test
    public void testIsNotNoShowDerivedfromUpcomingOK() {

        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC).minusMinutes(4);

        Map<String, Object> upcomingNoShow = testData.createAppointment(AppointmentStatus.UPCOMING, true, utc);
        upcomingNoShow.put(AppointmentFields.NO_SHOW_DURATION.val(), "5");

        assertTrue(!appointmentFunctions.isNoShow(upcomingNoShow,utc.toInstant().toEpochMilli()));
    }

    @Test
    public void testIsNotNoShowDerivedfromNoShowOK() {

        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC).minusMinutes(4);

        Map<String, Object> upcomingNoShow = testData.createAppointment(AppointmentStatus.NOSHOW, false, utc);
        upcomingNoShow.put(AppointmentFields.NO_SHOW_DURATION.val(), "5");

        assertTrue(!appointmentFunctions.isNoShow(upcomingNoShow,utc.toInstant().toEpochMilli()));
    }

    @Test
    public void testOverdue() {
        long dateTime = Instant.now().minus(10, ChronoUnit.MINUTES).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli();
        assertTrue(appointmentFunctions.isOverDue(dateTime));
    }

    @Test
    public void testNextWorkingDay() throws Exception {
        ZonedDateTime saturday = LocalDateTime.of(2017, 9, 9, 12, 2, 0, 0).atZone(ZoneId.of("UTC"));
        ZonedDateTime nextWorkingDayMonday = LocalDateTime.of(2017, 9, 11, 12, 2, 0, 0).atZone(ZoneId.of("UTC"));
        ClockProvider clockProvider = new ClockProvider(Clock.fixed(saturday.toInstant(), ZoneId.of("UTC")));
        appointmentFunctions = new AppointmentFunctions(clockProvider, new AppointmentConfiguration());
        LocalDate nextWorkingDay = appointmentFunctions.getNextWorkingDay(1, "UTC");
        assertEquals(nextWorkingDayMonday.toLocalDate(), nextWorkingDay);
    }

    @Test
    public void testGetYesterday() throws Exception {
        ZonedDateTime saturday = LocalDateTime.of(2017, 9, 9, 12, 2, 0, 0).atZone(ZoneId.of("UTC"));
        ZonedDateTime friday = LocalDateTime.of(2017, 9, 8, 12, 2, 0, 0).atZone(ZoneId.of("UTC"));
        ClockProvider clockProvider = new ClockProvider(Clock.fixed(saturday.toInstant(), ZoneId.of("UTC")));
        appointmentFunctions = new AppointmentFunctions(clockProvider, new AppointmentConfiguration());
        LocalDate yesterday = appointmentFunctions.getYesterday("UTC");
        assertEquals(friday.toLocalDate(), yesterday);
    }

    @Test
    public void testGetYesterdayAndSkipSundays() throws Exception {
        ZonedDateTime monday = LocalDateTime.of(2017, 9, 11, 12, 2, 0, 0).atZone(ZoneId.of("UTC"));
        ZonedDateTime saturday = LocalDateTime.of(2017, 9, 9, 12, 2, 0, 0).atZone(ZoneId.of("UTC"));
        ClockProvider clockProvider = new ClockProvider(Clock.fixed(monday.toInstant(), ZoneId.of("UTC")));
        appointmentFunctions = new AppointmentFunctions(clockProvider, new AppointmentConfiguration());
        LocalDate yesterday = appointmentFunctions.getYesterday("UTC");
        assertEquals(saturday.toLocalDate(), yesterday);
    }
}