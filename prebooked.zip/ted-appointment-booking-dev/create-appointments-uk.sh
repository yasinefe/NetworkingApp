timestamp() {
  date -v+$1M +%s
}

# GBHBEU507000100 BIkXX6ebhhuPWm6GwzVkuza5G0gZdSA8kRAuhUewuqg=             Yasin Efe                     yasin.efe@hsbc.com
# GBHBEU507000101 BIkXX6ebhhuPWm6GwzVku2St4ATnGR0vzI3LSk9EXjE=             Adam Lee Edwards              adam.l.edwards@hsbc.com
# GBHBEU507000102 BIkXX6ebhhuPWm6GwzVku4T_plus_3mJHQaNWJ35Js_plus_flHNc=   Gerrone Richard Matticks      gerrone.r.matticks@hsbc.com
# GBHBEU507000103 BIkXX6ebhhuPWm6GwzVku_plus_QVPkymQah3lWvtujIETM0=        Oliver Relph                  oliver.relph@hsbc.com
# GBHBEU507000104 BIkXX6ebhhuPWm6GwzVku2WC5xjq_plus_0yHMYgSGS_plus_KU0w=   Ozgul Ozeli                   ozgul.ozeli@hsbc.com
# GBHBEU507000105 BIkXX6ebhhuPWm6GwzVku77hP1pLaOu6i_plus_rUpZhZ1Mo=        Daniel John Costin            daniel.j.costin@hsbc.com
# GBHBEU507000106 BIkXX6ebhhuPWm6GwzVku5qpsi9oG9n6SYPGnV_plus_fLOI=        Daryl Michael Sobers Browne   daryl.m.browne@hsbc.com
# GBHBEU507000107 BIkXX6ebhhuPWm6GwzVku8_plus_gsgqmagleLJAzZSA6Ze4=        Yann Vallery-Radot            yann.vallery-radot@hsbc.com
# GBHBEU507000108 BIkXX6ebhhuPWm6GwzVku0vG4z_plus_8dxqg_slash_9MCWxNnH24=  Tipu Ali                      tipu.ali@hsbc.com
# GBHBEU507000109 BIkXX6ebhhuPWm6GwzVku9S2N_plus_hLDxpwRXTFps2CmAE=        Angela M Iglio                angela.m.iglio@hsbc.com

declare -a customers=("BIkXX6ebhhuPWm6GwzVkuza5G0gZdSA8kRAuhUewuqg=" "BIkXX6ebhhuPWm6GwzVku2St4ATnGR0vzI3LSk9EXjE=" "BIkXX6ebhhuPWm6GwzVku4T_plus_3mJHQaNWJ35Js_plus_flHNc=" "BIkXX6ebhhuPWm6GwzVku_plus_QVPkymQah3lWvtujIETM0=" "BIkXX6ebhhuPWm6GwzVku2WC5xjq_plus_0yHMYgSGS_plus_KU0w=" "BIkXX6ebhhuPWm6GwzVku77hP1pLaOu6i_plus_rUpZhZ1Mo=" "BIkXX6ebhhuPWm6GwzVku5qpsi9oG9n6SYPGnV_plus_fLOI=" "BIkXX6ebhhuPWm6GwzVku8_plus_gsgqmagleLJAzZSA6Ze4=" "BIkXX6ebhhuPWm6GwzVku0vG4z_plus_8dxqg_slash_9MCWxNnH24=" "BIkXX6ebhhuPWm6GwzVku9S2N_plus_hLDxpwRXTFps2CmAE=")

for i in {1..100}
do

min=$(($i * 6))
t=$(timestamp $min)000
customer=${customers[($i % 10)]}

echo $t
echo $customer

curl -X POST -H "Content-Type: application/json" -H "Cache-Control: no-cache" -H "Postman-Token: a3a001e7-c2b0-53c5-2c0e-424240020451" -d '{
     "customerId": "'$customer'",
     "branchId": "404519",
     "dateTime": '$t',
     "topicId": "savings_review",
     "topicCategoryId": "savings",
     "duration": 5,
     "countryCode": "GB",
     "timezone": "Europe/London"
}' "http://ted-appointment-booking-dev.cf.wgdc-drn-01.cloud.uk.hsbc/appointments/"

done