package com.vocalink.validation.framework.service;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.streamer.ContentStreamer;
import com.vocalink.validation.framework.streamer.ContentStreamerFactory;

import java.io.InputStream;
import java.util.Collections;
import java.util.List;

public class StructuralValidatorService {

    private ContentStreamerFactory<String> contentStreamerFactory;

    public List<ValidationResponse> validate(InputStream content, FileFormat fileFormat, ValidationContext validationContext) {
        ContentStreamer<String> contentStreamer = contentStreamerFactory.getContentParser(fileFormat);

        // Stream through file and implement structural validation
        // Add invalid lines to validationContext
        contentStreamer.stream(
                content,
                fileFormat,
                (String beginRecord) -> validateBeginRecord(beginRecord, fileFormat, validationContext),
                (List<String> innerRecords) -> validateInnerRecord(innerRecords, fileFormat, validationContext),
                (String endRecord) -> validateEndRecord(endRecord, fileFormat, validationContext));

        return Collections.emptyList();
    }

    private void validateBeginRecord(String beginRecord, FileFormat fileFormat, ValidationContext validationContext) {

    }

    private void validateInnerRecord(List<String> innerRecords, FileFormat fileFormat, ValidationContext validationContext) {

    }

    private void validateEndRecord(String endRecord, FileFormat fileFormat, ValidationContext validationContext) {

    }


}
