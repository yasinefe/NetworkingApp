package com.vocalink.validation.framework.parser;

import com.vocalink.validation.framework.domain.FileFormat;

import java.util.Map;

public class ContentParserFactory {

    private Map<FileFormat, ContentParser> contentParserMap;

    public ContentParser getContentParser(FileFormat fileFormat) {
        return contentParserMap.get(fileFormat);
    }

}
