package com.vocalink.validation.framework.validator;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.streamer.ContentStreamer;

import java.util.Map;

public class StructuralValidatorFactory {

    private Map<FileFormat, StructuralValidator> structuralValidatorMap;

    public StructuralValidator getContentParser(FileFormat fileFormat) {
        return structuralValidatorMap.get(fileFormat);
    }

}
