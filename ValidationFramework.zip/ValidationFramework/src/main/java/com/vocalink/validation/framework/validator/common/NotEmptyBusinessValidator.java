package com.vocalink.validation.framework.validator.common;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.validator.BusinessValidator;

import java.util.Map;

public class NotEmptyBusinessValidator implements BusinessValidator {


    @Override
    public ValidationResponse execute(Map<String, String> attributes, FileFormat fileFormat, ValidationContext validationContext) {
        return null;
    }
}
