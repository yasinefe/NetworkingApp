package com.vocalink.validation.framework.validator.nacham;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.validator.StructuralValidator;

import java.io.InputStream;

public class NachamStructuralValidator implements StructuralValidator {
    @Override
    public ValidationResponse execute(InputStream content, FileFormat fileFormat, ValidationContext validationContext) {
        return null;
    }
}
