package com.vocalink.validation.framework.parser.nacham;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.parser.ContentParser;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

// This class can be in a different library and can be injected
public class NachamContentParser implements ContentParser {


    @Override
    public List<String> nextRecord(InputStream content, FileFormat fileFormat) {
        return null;
    }

    @Override
    public Map<String, String> parseRecord(String record, FileFormat fileFormat) {
        return null;
    }

    @Override
    public Map<String, String> parseRecords(List<String> records, FileFormat fileFormat) {
        return null;
    }
}
