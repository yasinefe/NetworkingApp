package com.vocalink.validation.framework.streamer.nacham;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.streamer.ContentStreamer;
import com.vocalink.validation.framework.validator.StructuralValidator;

import java.io.InputStream;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

// This class can be in a different library and can be injected
public class NachamContentStreamer implements ContentStreamer<String> {

    @Override
    public void stream(InputStream content, FileFormat fileFormat, Consumer beginRecordConsumer, Consumer innerRecordsConsumer, Consumer postRecordConsumer) {

    }
}
