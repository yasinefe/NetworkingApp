package com.vocalink.validation.framework.domain;

public enum FileFormat {

    NACHAM, ISO20022, XXX, YYY, ZZZ

}
