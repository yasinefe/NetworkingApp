package com.vocalink.validation.framework.validator.common;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.validator.Validator;

import java.util.Map;

public class NotEmptyValidator implements Validator {

    @Override
    public ValidationResponse execute(Map<String, Object> attributes, FileFormat fileFormat, ValidationContext validationContext) {
        return null;
    }

}
