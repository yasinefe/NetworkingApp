package com.vocalink.validation.framework.service;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.validator.BusinessValidator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class BusinessValidatorService {

    private ExecutorService executorService;
    private ReferenceDataService referenceDataService;

    public List<ValidationResponse> validateRecord(Map<String, String> attributes, FileFormat fileFormat, ValidationContext validationContext) {
        List<BusinessValidator> businessValidators = referenceDataService.getListOfValidator(attributes.get("recordType"), fileFormat);

        List<Future> futures = new ArrayList<>();
        List<ValidationResponse> allValidationResponses = new ArrayList<>();

        businessValidators.forEach(validator -> {
            futures.add(executorService.submit(() -> validator.execute(attributes, fileFormat, validationContext)));
        });

        futures.forEach(future -> {
            try {
                allValidationResponses.addAll((List<ValidationResponse>) future.get());
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        });

        return allValidationResponses;
    }

}
