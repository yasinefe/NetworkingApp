package com.vocalink.validation.framework.validator;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;

import java.util.Map;

public interface Validator {

    ValidationResponse execute(Map<String, String> attributes, FileFormat fileFormat, ValidationContext validationContext);

}
