package com.vocalink.validation.framework.service;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.validator.BusinessValidator;

import java.util.List;


public interface ReferenceDataService {

    // We can map a record type to a payment group for example:
    // For NACHAM
    // if recordType is 1 which is a logical file payment group
    // For ISO20022
    // if recordType is xxx which is a logical file payment group
    Boolean isPaymentGroup(String recordType, FileFormat fileFormat);

    // We can map a record type to rule set for example:
    // For NACHAM
    // if recordType is 1 which is a Logical Header then return related list of validators
    // For ISO20022
    // if recordType is yyy which is a yyy then return related list of validators
    List<BusinessValidator> getListOfValidator(String recordType, FileFormat fileFormat);

    // ... getListOfParticipant, getListOfAllowedXXXFieldValues, getListOfTransactionTypes, getListOfAllowedLogicalRecordCodes

}
