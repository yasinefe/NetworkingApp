package com.vocalink.validation.framework.service;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.validator.Validator;

import java.util.List;


public interface ReferenceDataService {

    // We can map a record type to a payment group for example:
    // For NACHAM
    // if recordType is 1 which is a logical file payment group
    // For ISO20022
    // if recordType is xxx which is a logical file payment group
    Boolean isPaymentGroup(String recordType, FileFormat fileFormat);

    // We can map a record type to rule set for example:
    // For NACHAM
    // if recordType is 1 which is a Logical Header then return related list of validators
    // For ISO20022
    // if recordType is yyy which is a yyy then return related list of validators
    List<Validator> getListOfValidator(String recordType, FileFormat fileFormat);

    // We can map structural validators per fileFormat:
    // For NACHAM
    // Return a list of structural validator specific to NACHAM
    // For ISO20022
    // Return a list of structural validator specific to ISO20022
    List<Validator> getListOfStructuralValidator(FileFormat fileFormat);


    // ... getListOfParticipant, getListOfAllowedXXXFieldValues, getListOfTransactionTypes, getListOfAllowedLogicalRecordCodes

}
