package com.vocalink.validation.framework.streamer;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationResponse;

import java.util.Map;

public class ContentStreamerFactory<T> {

    private Map<FileFormat, ContentStreamer<T>> contentStreamerMap;

    public ContentStreamer<T> getContentParser(FileFormat fileFormat) {
        return contentStreamerMap.get(fileFormat);
    }

}
