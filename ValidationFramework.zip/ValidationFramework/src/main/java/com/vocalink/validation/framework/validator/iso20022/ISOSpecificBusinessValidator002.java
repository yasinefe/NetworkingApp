package com.vocalink.validation.framework.validator.iso20022;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.validator.BusinessValidator;

import java.util.Map;

// This class can be in a different library and can be injected
public class ISOSpecificBusinessValidator002 implements BusinessValidator {

    private Integer maxLength;

    @Override
    public ValidationResponse execute(Map<String, String> attributes, FileFormat fileFormat, ValidationContext validationContext) {
        return null;
    }
}
