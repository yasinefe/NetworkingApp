package com.vocalink.validation.framework.domain;

import java.util.List;
import java.util.concurrent.Future;

public class ExecutorContext<T> {

    private Future<List<T>> beginRecordFuture;
    private List<Future<List<T>>> innerRecordsFuture;

    public Future<List<T>> getBeginRecordFuture() {
        return beginRecordFuture;
    }

    public void setBeginRecordFuture(Future<List<T>> beginRecordFuture) {
        this.beginRecordFuture = beginRecordFuture;
    }

    public List<Future<List<T>>> getInnerRecordsFuture() {
        return innerRecordsFuture;
    }

    public void setInnerRecordsFuture(List<Future<List<T>>> innerRecordsFuture) {
        this.innerRecordsFuture = innerRecordsFuture;
    }
}

