package com.vocalink.validation.framework.service;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.parser.ContentParser;
import com.vocalink.validation.framework.parser.ContentParserFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class ValidationExecutorService {

    // This must be a ThreadPoolExecutor
    private ExecutorService executorService;
    private StructuralValidatorService structuralValidatorService;
    private BusinessValidatorService businessValidatorService;
    private ContentParserFactory contentParserFactory;
    private ReferenceDataService referenceDataService;

    public List<ValidationResponse> execute(List<String> parts, FileFormat fileFormat, ValidationContext validationContext) {

        // This can be used to skip the part of
        List<ValidationResponse> structoralValidationResponses = structuralValidatorService.validate(parts, fileFormat, validationContext);

        ContentParser contentParser = contentParserFactory.getContentParser(fileFormat);

        List<ValidationResponse> allValidationResponses = new ArrayList<>();

        allValidationResponses.addAll(executePreValidations(parts.get(0), fileFormat, validationContext, contentParser));
        allValidationResponses.addAll(executeValidationForInnerParts(parts, fileFormat, validationContext, contentParser));
        allValidationResponses.addAll(executePostValidations(parts.get(parts.size() - 1), fileFormat, validationContext, contentParser));

        return allValidationResponses;
    }

    private List<ValidationResponse> executePreValidations(String part, FileFormat fileFormat, ValidationContext validationContext, ContentParser contentParser) {
        // Executes a preValidations for a paymentGroup eg. Logical or Batch
        Map<String, String> attributes = contentParser.parsePart(part, fileFormat);
        if (referenceDataService.isPaymentGroup(attributes.get("recordType"), fileFormat)) {
            return businessValidatorService.validateRecord(attributes, fileFormat, validationContext);
        }
        return Collections.emptyList();
    }

    private List<ValidationResponse> executeValidationForInnerParts(List<String> parts, FileFormat fileFormat, ValidationContext validationContext, ContentParser contentParser) {
        List<String> innerParts = parts.subList(1, parts.size() - 1);

        List<Future> futures = new ArrayList<>();
        List<ValidationResponse> allValidationResponses = new ArrayList<>();

        if (parts.size() > 0) {
            Map<String, String> attributesForFirstPart = contentParser.parsePart(innerParts.get(0), fileFormat);
            if (referenceDataService.isPaymentGroup(attributesForFirstPart.get("recordType"), fileFormat)) {
                futures.add(executorService.submit(() -> execute(innerParts, fileFormat, validationContext)));
            } else {
                innerParts.forEach(part -> {
                    Map<String, String> attributes = contentParser.parsePart(part, fileFormat);
                    futures.add(executorService.submit(() -> businessValidatorService.validateRecord(attributes, fileFormat, validationContext)));
                });
            }
        }

        futures.forEach(future -> {
            try {
                allValidationResponses.addAll((List<ValidationResponse>) future.get());
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        });

        return allValidationResponses;
    }

    private List<ValidationResponse> executePostValidations(String part, FileFormat fileFormat, ValidationContext validationContext, ContentParser contentParser) {
        // Executes a postValidations for a paymentGroup eg. Logical or Batch
        Map<String, String> attributes = contentParser.parsePart(part, fileFormat);
        if (referenceDataService.isPaymentGroup(attributes.get("recordType"), fileFormat)) {
            return businessValidatorService.validateRecord(attributes, fileFormat, validationContext);
        }
        return Collections.emptyList();
    }

}
