package com.vocalink.validation.framework.service;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.parser.ContentParser;
import com.vocalink.validation.framework.parser.ContentParserFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

// This is responsible to execute begin record and innerRecords and endRecord using ExecutorService
public class ValidationExecutorService {

    // This must be a ThreadPoolExecutor
    private ExecutorService executorService;
    private BusinessValidatorService businessValidatorService;
    private ContentParserFactory contentParserFactory;

    public Future<List<ValidationResponse>> executePreValidations(String record, FileFormat fileFormat, ValidationContext validationContext, ContentParser contentParser) {
        // Executes a preValidations for a paymentGroup eg. Logical or Batch
        Map<String, String> attributes = contentParser.parseRecord(record, fileFormat);
        return executorService.submit(() -> businessValidatorService.validateRecord(attributes, fileFormat, validationContext));
    }

    public List<Future<List<ValidationResponse>>> executeValidation(List<String> records, FileFormat fileFormat, ValidationContext validationContext, ContentParser contentParser) {
        List<Future<List<ValidationResponse>>> futures = new ArrayList<>();

        Map<String, String> attributes = contentParser.parseRecords(records, fileFormat);
        futures.add(executorService.submit(() -> businessValidatorService.validateRecord(attributes, fileFormat, validationContext)));

        return futures;
    }

    public Future<List<ValidationResponse>> executePostValidations(String record, FileFormat fileFormat, ValidationContext validationContext, ContentParser contentParser) {
        // Executes a postValidations for a paymentGroup eg. Logical or Batch
        Map<String, String> attributes = contentParser.parseRecord(record, fileFormat);
        return executorService.submit(() -> businessValidatorService.validateRecord(attributes, fileFormat, validationContext));
    }

}
