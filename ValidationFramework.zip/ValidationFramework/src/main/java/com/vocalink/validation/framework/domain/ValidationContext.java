package com.vocalink.validation.framework.domain;

import java.util.HashMap;
import java.util.Map;

public class ValidationContext {

    // This will keep the data which will be used for post validations
    // Total numbers of batch count in a logical file
    // Total numbers of payment count in a batch file
    // Or total amounts to validate logical file total amount matches with total batches amount
    // IMPORTANT:
    // This validation context will be shared by multiple thread.
    // So what ever we put here must be thread safe, must have synchronised methods
    // synchronised addAmount(BigDecimal amountOfBatch)
    private Map<String, Object> context = new HashMap<>();

    public void addAttribute(String key, Object value) {
        context.put(key, value);
    }

    public <T> T getAttribute(String key) {
        return (T)context.get(key);
    }


}
