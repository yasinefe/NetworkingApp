package com.vocalink.validation.framework.parser;

import com.vocalink.validation.framework.domain.FileFormat;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

// There will be implementation per file format such as NachaContentParser, ISO20022ContentParser etc.
public interface ContentParser {


    // Get next record while streaming
    // For NACHAM each record contains 200 chars string.
    // NachaContentParser will know how to split records
    // For IS2O022 each record contains <sometag ..... > start tag, or sibling begin or text or end tag
    // ISO20022ContentParser will know how to split xml to individual record
    List<String> nextRecord(InputStream content, FileFormat fileFormat);

    // Split records to individual fields
    // For NACHAM each record contains 200 chars string.
    // NachaContentParser will know how to parse a record
    // For IS2O022 each record contains <sometag ..... > start tag, or sibling begin or text or end tag
    // ISO20022ContentParser will know how to parse an xml record
    Map<String, String> parseRecord(String record, FileFormat fileFormat);

    // Split records to individual fields
    // For NACHAM each record contains 200 chars string.
    // NachaContentParser will know how to multiple records
    // For IS2O022 each record contains <sometag ..... > start tag, or sibling begin or text or end tag
    // ISO20022ContentParser will know how to parse multiple xml records
    Map<String, String> parseRecords(List<String> records, FileFormat fileFormat);
}
