package com.vocalink.validation.framework.parser;

import com.vocalink.validation.framework.domain.FileFormat;

import java.util.List;
import java.util.Map;

public interface ContentParser {

    // Split parts of the file
    // For NACHAM each part contains 200 chars string. NachaContentParser will now how to split the parts
    // For ISO0122 each part contains <logical ..... > beginning of the tag, or text, or end of the tag ISO20022ContentParser will now how to split xml to individual parts
    List<String> splitToPart(String content, FileFormat fileFormat);

    // Split a part to individual fields
    // For NACHAM each part contains 200 chars string. NachaContentParser will know how to split a part
    // For ISO0122 each part contains <logical ..... > beginning of the tag, or text, or end of the tag ISO20022ContentParser will know how to split an xml part
    Map<String, String> parsePart(String part, FileFormat fileFormat);

}
