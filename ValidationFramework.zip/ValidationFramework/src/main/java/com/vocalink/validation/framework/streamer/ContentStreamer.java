package com.vocalink.validation.framework.streamer;

import com.vocalink.validation.framework.domain.FileFormat;

import java.io.InputStream;
import java.util.List;
import java.util.function.Consumer;

// There will be implementation per file format such as NachaContentStreamer, ISO20022ContentStreamer etc.
public interface ContentStreamer<T> {

    void stream(InputStream content,
                FileFormat fileFormat,
                Consumer<T> beginRecordConsumer,
                Consumer<List<T>> innerRecordsConsumer,
                Consumer<T> postRecordConsumer);

}
