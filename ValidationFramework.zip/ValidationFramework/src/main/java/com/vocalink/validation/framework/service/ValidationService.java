package com.vocalink.validation.framework.service;

import com.vocalink.validation.framework.domain.ExecutorContext;
import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.parser.ContentParser;
import com.vocalink.validation.framework.parser.ContentParserFactory;
import com.vocalink.validation.framework.streamer.ContentStreamer;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

// Responsible to execute validation using ValidationExecutorService which runs concurrently and returns java Future objects
// Also responsible to make sure to run post validation after inner validation is completed
// For example to validate logical control record (end of logical file) we have to make sure we completed all batch validations
public class ValidationService {

    private ValidationExecutorService validationExecutorService;
    private ContentStreamer<String> contentStreamer;
    private ContentParserFactory contentParserFactory;

    public List<ValidationResponse> validate(InputStream content, FileFormat fileFormat) {
        ContentParser contentParser = contentParserFactory.getContentParser(fileFormat);
        ValidationContext validationContext = new ValidationContext();

        // I called it record because it can be line for text file, it can be multiple line for xml format
        // It can be a row for cvs format.
        // Even we can use an Object called ContentPart to wrap it so executor service will be abstracted
        List<ValidationResponse> validationResponses = new ArrayList<>();
        ExecutorContext<ValidationResponse> executorContext = new ExecutorContext<>();
        contentStreamer.stream(
                content,
                fileFormat,
                (String beginRecord) -> executePreValidation(beginRecord, fileFormat, validationContext, executorContext, contentParser),
                (List<String> innerRecords) -> executeValidationForInnerRecords(innerRecords, fileFormat, validationContext, executorContext, contentParser),
                (String endRecord) -> executePostValidation(endRecord, fileFormat, validationContext, executorContext, validationResponses, contentParser)
        );

        return validationResponses;
    }

    private void executePreValidation(String beginRecord,
                                      FileFormat fileFormat,
                                      ValidationContext validationContext,
                                      ExecutorContext<ValidationResponse> executorContext,
                                      ContentParser contentParser) {
        Future<List<ValidationResponse>> future = validationExecutorService.executePreValidations(beginRecord, fileFormat, validationContext, contentParser);
        executorContext.setBeginRecordFuture(future);
    }

    private void executeValidationForInnerRecords(List<String> innerRecords,
                                                  FileFormat fileFormat,
                                                  ValidationContext validationContext,
                                                  ExecutorContext<ValidationResponse> executorContext,
                                                  ContentParser contentParser) {
        List<Future<List<ValidationResponse>>> futures = validationExecutorService.executeValidation(innerRecords, fileFormat, validationContext, contentParser);
        executorContext.setInnerRecordsFuture(futures);
    }

    private void executePostValidation(String endRecord,
                                       FileFormat fileFormat,
                                       ValidationContext validationContext,
                                       ExecutorContext<ValidationResponse> executorContext,
                                       List<ValidationResponse> validationResponses,
                                       ContentParser contentParser) {

        try {
            // To execute post validation we have to wait inner validation to be completed
            validationResponses.addAll(executorContext.getBeginRecordFuture().get());
            executorContext.getInnerRecordsFuture().forEach(future -> {
                try {
                    validationResponses.addAll(future.get());
                } catch (InterruptedException | ExecutionException e) {
                    // This must be handled gracefully
                    throw new RuntimeException(e);
                }
            });

            Future<List<ValidationResponse>> future = validationExecutorService.executePostValidations(endRecord, fileFormat, validationContext, contentParser);
            validationResponses.addAll(future.get());
        } catch (InterruptedException | ExecutionException e) {
            // This must be handled gracefully
            throw new RuntimeException(e);
        }
    }
}
