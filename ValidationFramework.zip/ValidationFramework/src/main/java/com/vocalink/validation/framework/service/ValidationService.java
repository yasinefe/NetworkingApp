package com.vocalink.validation.framework.service;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.domain.ValidationContext;
import com.vocalink.validation.framework.domain.ValidationResponse;
import com.vocalink.validation.framework.parser.ContentParser;
import com.vocalink.validation.framework.parser.ContentParserFactory;

import java.util.List;

public class ValidationService {

    private ValidationExecutorService validationExecutorService;
    private ContentParserFactory contentParserFactory;

    List<ValidationResponse> validate(String content, FileFormat fileFormat) {
        ContentParser contentParser = contentParserFactory.getContentParser(fileFormat);
        // I called it part because it can be line for text file, it can be multiple line for xml format
        // It can be a row for cvs format.
        // Even we can use an Object called ContentPart to wrap it so executor service will abstracted
        List<String> parts = contentParser.splitToPart(content, fileFormat);
        return validationExecutorService.execute(parts, fileFormat, new ValidationContext());
    }

}
