package com.vocalink.validation.framework.parser.iso20022;

import com.vocalink.validation.framework.domain.FileFormat;
import com.vocalink.validation.framework.parser.ContentParser;

import java.util.List;
import java.util.Map;

// This class can be in a different library and can be injected
public class ISO20022ContentParser implements ContentParser {


    @Override
    public List<String> splitToPart(String content, FileFormat fileFormat) {
        return null;
    }

    @Override
    public Map<String, String> parsePart(String part, FileFormat fileFormat) {
        return null;
    }
}
