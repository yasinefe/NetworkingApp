package com.vocalink.validation.framework.domain;

public class ValidationResponse {

    private Long recordNumber;
    private String errorCode;
    private String errorMessage;

}
