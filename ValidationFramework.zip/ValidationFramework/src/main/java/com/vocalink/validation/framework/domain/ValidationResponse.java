package com.vocalink.validation.framework.domain;

public class ValidationResponse {

    private Long partNumber;
    private String errorCode;
    private String errorMessage;

}
