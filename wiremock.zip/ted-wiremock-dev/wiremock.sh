#!/usr/bin/env bash

java -jar wiremock-standalone-2.6.0.jar