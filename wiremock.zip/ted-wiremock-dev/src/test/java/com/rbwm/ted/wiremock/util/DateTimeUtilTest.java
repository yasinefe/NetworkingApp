package com.rbwm.ted.wiremock.util;

import org.junit.Test;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

import static org.junit.Assert.assertEquals;

/**
 * Created by 44052007 on 23/06/2017.
 */
public class DateTimeUtilTest {

    @Test
    public void shouldReturnGivenTimeIfPatternIs0() throws Exception {
        long time = Instant.now().toEpochMilli();
        assertEquals(time, DateTimeUtil.adjustTime("${now}", time));
    }

    @Test
    public void shouldReturnGivenTimeIfPatternHas5SecondsBefore() throws Exception {
        Instant now = Instant.now();
        assertEquals(now.plus(-5, ChronoUnit.SECONDS).toEpochMilli(), DateTimeUtil.adjustTime("${now-5s}", now.toEpochMilli()));
    }

    @Test
    public void shouldReturnGivenTimeIfPatternHas5MinutesAfter() throws Exception {
        Instant now = Instant.now();
        assertEquals(now.plus(5, ChronoUnit.MINUTES).toEpochMilli(), DateTimeUtil.adjustTime("${now+5m}", now.toEpochMilli()));
    }

    @Test
    public void shouldReturnGivenTimeIfPatternHas10HoursBefore() throws Exception {
        Instant now = Instant.now();
        assertEquals(now.plus(-10, ChronoUnit.HOURS).toEpochMilli(), DateTimeUtil.adjustTime("${now-10h}", now.toEpochMilli()));
    }

    @Test
    public void shouldReturnGivenTimeIfPatternHas1DayBefore() throws Exception {
        Instant now = Instant.now();
        assertEquals(now.plus(-1, ChronoUnit.DAYS).toEpochMilli(), DateTimeUtil.adjustTime("${now-1d}", now.toEpochMilli()));
    }

    @Test
    public void shouldReturnGivenTimeIfPatternHas1DayBeforePlus5Minutes() throws Exception {
        Instant now = Instant.now();
        assertEquals(now.plus(-1, ChronoUnit.DAYS).plus(5, ChronoUnit.MINUTES).toEpochMilli(), DateTimeUtil.adjustTime("${now-1d+5m}", now.toEpochMilli()));
    }

    @Test
    public void shouldReturnGivenTimeIfPatternHas1DayBeforePlus5MinutesMinus3Seconds() throws Exception {
        Instant now = Instant.now();
        assertEquals(
                now.plus(-1, ChronoUnit.DAYS).plus(5, ChronoUnit.MINUTES).plus(-3, ChronoUnit.SECONDS).toEpochMilli(),
                DateTimeUtil.adjustTime("${now-1d+5m-3s}", now.toEpochMilli()));
    }
}