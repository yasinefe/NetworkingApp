/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.rbwm.ted.wiremock.util;

import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by 44052007 on 23/06/2017.
 */
public class DateTimeUtil {


    public static final DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("YYYY-MM-dd hh:mm aa 'UTC'")
            .withZone(DateTimeZone.UTC);


    public static long adjustTime(String pattern, long time) {
        if (pattern.equals("${now}")) return time;
        if (pattern.equals("${lwd}")) return getLastWorkingDay(time);

        String allDuration;
        if (pattern.startsWith("${now")) {
            allDuration = pattern.replace("${now", "").replace("}", "");
        } else {
            time = getLastWorkingDay(time);
            allDuration = pattern.replace("${lwd", "").replace("}", "");
        }


        List<String> durations = splitDurations(allDuration);
        for (String duration: durations) {
            time = calculateTime(duration, time);
        }
        return time;
    }

    private static long getLastWorkingDay(long time) {
        LocalDateTime yesterday = LocalDateTime.now(Clock.fixed(Instant.ofEpochMilli(time), ZoneId.of("UTC"))).minus(1, ChronoUnit.DAYS);
        if (yesterday.getDayOfWeek() == DayOfWeek.SUNDAY) {
            return time - TimeUnit.DAYS.toMillis(2);
        }
        return time - TimeUnit.DAYS.toMillis(1);
    }

    // Sample : -1d+5m-3s will be splited as ['-1d', '+5m', '-3s']
    private static List<String> splitDurations(String allDuration) {
        List<String> durations = new ArrayList<>();
        StringBuilder durationPart = new StringBuilder();
        allDuration.chars().forEach(ch -> {
            durationPart.append((char) ch);
            if (ch == 's' || ch == 'm' || ch == 'h' || ch == 'd') {
                durations.add(durationPart.toString());
                durationPart.delete(0, durationPart.length());
            }
        });
        return durations;
    }

    private static long calculateTime(String duration, long time) {
        int amount = Integer.valueOf(duration.substring(0, duration.length() - 1));
        String unitStr = duration.substring(duration.length() - 1, duration.length());

        ChronoUnit unit = ChronoUnit.SECONDS;
        if (unitStr.equals("s")) {
            unit = ChronoUnit.SECONDS;
        } else if (unitStr.equals("m")) {
            unit = ChronoUnit.MINUTES;
        } else if (unitStr.equals("h")) {
            unit = ChronoUnit.HOURS;
        } else if (unitStr.equals("d")) {
            unit = ChronoUnit.DAYS;
        }

        Instant instant = Instant.ofEpochMilli(time);

        return instant.plus(amount, unit).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli();
    }

}
