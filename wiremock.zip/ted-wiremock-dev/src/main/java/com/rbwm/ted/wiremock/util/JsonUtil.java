/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.rbwm.ted.wiremock.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;

/**
 * Created by 44052007 on 23/06/2017.
 */
public class JsonUtil<T> {

    private ObjectMapper objectMapper = new ObjectMapper();

    public T convertToObject(String body) {
        TypeReference<T> typeRef = new TypeReference<T>() {};

        try {
            return objectMapper.readValue(body, typeRef);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String convertToString(T object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Map<String, Object> iterateAndApply(Map<String, Object> body, BiFunction<String, Object, Object> biFunction) {
        for (String key:body.keySet()) {
            if (body.get(key) instanceof List) {
                for (Object map: (List<Object>)body.get(key)) {
                    if (map instanceof Map) {
                        iterateAndApply((Map<String, Object>)map, biFunction);
                    }
                }
            } else if (body.get(key) instanceof Map) {
                iterateAndApply((Map<String, Object>)body.get(key), biFunction);
            } else {
                body.put(key, biFunction.apply(key, body.get(key)));
            }
        }

        return body;
    }

}
