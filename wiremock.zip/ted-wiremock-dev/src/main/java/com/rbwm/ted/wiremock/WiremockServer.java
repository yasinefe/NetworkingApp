/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */

package com.rbwm.ted.wiremock;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.rbwm.ted.wiremock.transformer.AppointmentsDateTimeTransformer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;

@SpringBootApplication
public class WiremockServer {

	public static void main(String[] args) {
		SpringApplication.run(WiremockServer.class, args);
	}

	@Bean(initMethod = "start", destroyMethod = "stop")
	public WireMockServer wireMockServer(Environment env) {
		return new WireMockServer(wireMockConfig()
				.port(env.getProperty("server.wiremock.port", Integer.class))
				.extensions(new AppointmentsDateTimeTransformer())
				.usingFilesUnderClasspath(env.getProperty("server.wiremock.scenarios.classpath","scenarios")
				)
		);
	}

}
