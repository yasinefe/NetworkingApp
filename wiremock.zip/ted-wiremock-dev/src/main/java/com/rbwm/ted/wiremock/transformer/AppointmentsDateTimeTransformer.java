/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.rbwm.ted.wiremock.transformer;

import com.github.tomakehurst.wiremock.common.FileSource;
import com.github.tomakehurst.wiremock.extension.Parameters;
import com.github.tomakehurst.wiremock.extension.ResponseTransformer;
import com.github.tomakehurst.wiremock.http.Request;
import com.github.tomakehurst.wiremock.http.Response;
import com.rbwm.ted.wiremock.util.DateTimeUtil;
import com.rbwm.ted.wiremock.util.JsonUtil;

import java.time.Instant;
import java.time.ZoneId;
import java.util.Map;

/**
 * Created by 44052007 on 22/06/2017.
 */
public class AppointmentsDateTimeTransformer extends ResponseTransformer {

    private JsonUtil<Map<String, Object>> jsonUtil = new JsonUtil<>();

    @Override
    public Response transform(Request request, Response response, FileSource fileSource, Parameters parameters) {
        return Response.Builder.like(response)
                .but().body(convertResponseBody(response.getBodyAsString())).build();
    }

    @Override
    public boolean applyGlobally() {
        return false;
    }

    @Override
    public String getName() {
        return "appointments-datetime-transformer";
    }

    private String convertResponseBody(String body) {
        Map<String, Object> map = jsonUtil.convertToObject(body);
        return jsonUtil.convertToString(transformResponseBody(map));
    }

    private Map<String, Object> transformResponseBody(Map<String, Object> body) {
        jsonUtil.iterateAndApply(body, (key, value) -> {
            if (key.equals("dateTime")) {
                long time = DateTimeUtil.adjustTime((String) value, Instant.now().atZone(ZoneId.of("UTC")).toInstant().toEpochMilli());
                return DateTimeUtil.dateTimeFormatter.print(time);
            }
            return value;
        });
        return body;
    }
}
