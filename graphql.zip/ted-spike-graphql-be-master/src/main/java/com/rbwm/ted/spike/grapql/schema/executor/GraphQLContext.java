package com.rbwm.ted.spike.grapql.schema.executor;

/**
 * Created by 44052007 on 25/04/2017.
 */
public class GraphQLContext {

}
