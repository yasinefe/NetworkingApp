package com.rbwm.ted.spike.grapql.model;

/**
 * Created by 44052007 on 13/10/2017.
 */
public class Appointment {
    public final String id;
    public final String name;
    public final String categoryId;
    public final Integer revision;

    public Appointment(String id, String name, String categoryId, Integer revision) {
        this.id = id;
        this.name = name;
        this.categoryId = categoryId;
        this.revision = revision;
    }
}
