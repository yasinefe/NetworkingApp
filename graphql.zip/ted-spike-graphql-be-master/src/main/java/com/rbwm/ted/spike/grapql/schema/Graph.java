package com.rbwm.ted.spike.grapql.schema;

import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;

import static graphql.schema.idl.TypeRuntimeWiring.newTypeWiring;

/**
 * Created by 43578876 on 28/10/2016.
 */
@Component
public class Graph {

    private final GraphQLSchema schema;

    private final NodeInterfaceHandler nodeInterfaceHandler;
    private final DataFetchers dataFetchers;

    @Autowired
    public Graph(NodeInterfaceHandler nodeInterfaceHandler, DataFetchers dataFetchers) {
        this.nodeInterfaceHandler = nodeInterfaceHandler;
        this.dataFetchers = dataFetchers;

        this.schema = createSchema();
    }

    private GraphQLSchema createSchema() {
        SchemaParser schemaParser = new SchemaParser();
        SchemaGenerator schemaGenerator = new SchemaGenerator();

        File schemaFile = new File(Graph.class.getClassLoader().getResource("schema.idl").getPath());

        TypeDefinitionRegistry typeRegistry = schemaParser.parse(schemaFile);
        RuntimeWiring wiring = buildRuntimeWiring();
        return schemaGenerator.makeExecutableSchema(typeRegistry, wiring);
    }

    private RuntimeWiring buildRuntimeWiring() {
        return RuntimeWiring.newRuntimeWiring()
                .type(newTypeWiring("Root")
                        .dataFetcher("viewer", dataFetchers.viewerFetcher)
                        .dataFetcher("node", nodeInterfaceHandler.nodeDataFetcher)
                ).type(newTypeWiring("Node")
                        .typeResolver(nodeInterfaceHandler.typeResolverProxy)
                ).type(newTypeWiring("Viewer")
                        .dataFetcher("id", dataFetchers.viewerIdFetcher)
                        .dataFetcher("allAppointments", dataFetchers.allAppointments)
                        .dataFetcher("allCategories", dataFetchers.allCategories)
                        .dataFetcher("allCategoryAppointments", dataFetchers.allCategoryAppointments)
                ).type(newTypeWiring("Appointment")
                        .dataFetcher("id", dataFetchers.appointmentIdFetcher)
                        .dataFetcher("categoryId", dataFetchers.appointmentCategoryIdFetcher)
                        .dataFetcher("category", dataFetchers.categoryFetcher)
                ).type(newTypeWiring("AppointmentConnection")
                        .dataFetcher("count", dataFetchers.edgeCountFetcher)
                ).type(newTypeWiring("Category")
                        .dataFetcher("id", dataFetchers.categoryIdFetcher)
                        .dataFetcher("appointments", dataFetchers.appointmentsFetcher)
                ).type(newTypeWiring("CategoryConnection")
                        .dataFetcher("count", dataFetchers.edgeCountFetcher)
                ).type(newTypeWiring("CategoryAppointment")
                        .dataFetcher("id", dataFetchers.categoryAppointmentIdFetcher)
                ).type(newTypeWiring("CategoryAppointmentConnection")
                        .dataFetcher("count", dataFetchers.edgeCountFetcher)
                ).type(newTypeWiring("Mutation")
                        .dataFetcher("updateAppointment", dataFetchers.appointmentUpdater)
                        .dataFetcher("createAppointment", dataFetchers.appointmentCreator)
                        .dataFetcher("deleteAppointment", dataFetchers.appointmentRemover)
                ).type(newTypeWiring("UpdateAppointmentPayload")
                        .dataFetcher("viewer", dataFetchers.viewerFetcher)
                ).type(newTypeWiring("CreateAppointmentPayload")
                        .dataFetcher("viewer", dataFetchers.viewerFetcher)
                ).type(newTypeWiring("DeleteAppointmentPayload")
                        .dataFetcher("viewer", dataFetchers.viewerFetcher)
                )
                .build();
    }

    public GraphQLSchema getSchema() {
        return schema;
    }

}
