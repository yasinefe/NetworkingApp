package com.rbwm.ted.spike.grapql.schema.executor;

import com.fasterxml.jackson.annotation.JsonValue;
import com.rbwm.ted.spike.grapql.exception.ConflictException;
import com.rbwm.ted.spike.grapql.exception.ErrorCodeException;
import com.rbwm.ted.spike.grapql.exception.ValidationException;
import graphql.*;
import org.springframework.http.HttpStatus;

import java.util.*;
import java.util.concurrent.CompletionException;
import java.util.stream.Collectors;

import static graphql.ExecutionInput.newExecutionInput;

/**
 * Created by javierbracerotorres on 16/11/2016.
 */
public class GraphQLHttpResponse {
    private static final String ERRORS = "errors";
    private static final String DATA = "data";

    private List<GraphQLError> errors = new LinkedList<>();
    private Map<String, Object> response = new HashMap<>();
    private HttpStatus httpStatus = HttpStatus.OK;

    public GraphQLHttpResponse(GraphQL graphql, String query, GraphQLContext context, Map<String, Object> arguments) {
            ExecutionResult result = graphql.execute(newExecutionInput().context(context).query(query).variables(arguments));
            errors = extractErrors(result);
            response = buildResponse(result, errors);
    }

    private Map<String, Object> buildResponse(ExecutionResult result, List<GraphQLError> errors) {
        Map<String, Object> response = new HashMap<>();
        response.put(DATA, result.getData());
        if (!errors.isEmpty()) {
            response.put(ERRORS, errors.stream().map(error -> toSpecification(error)).collect(Collectors.toList()));
            response.put(DATA, null);
        }

        return response;
    }

    private Map<String, Object> toSpecification(GraphQLError error) {
        Map<String, Object> errorMap = error.toSpecification();
        if (error.getErrorType() == ErrorType.DataFetchingException) {
            ExceptionWhileDataFetching exceptionWhileDataFetching = (ExceptionWhileDataFetching) error;
            Throwable cause = getCause(exceptionWhileDataFetching);
            if (cause instanceof ErrorCodeException) {
                ErrorCodeException errorCodeException = (ErrorCodeException) cause;
                errorMap.put("detail", errorMap.get("message"));
                errorMap.put("message", errorCodeException.getMessage());
                errorMap.put("code", errorCodeException.code);
            }
            if (cause instanceof ConflictException) {
                httpStatus = HttpStatus.CONFLICT;
            }
            if (cause instanceof ValidationException) {
                ValidationException validationException = (ValidationException) cause;
                List<String> path = (List<String>) errorMap.get("path");
                path.add("input");
                path.add(validationException.field);
            }
        }
        return errorMap;
    }

    private Throwable getCause(ExceptionWhileDataFetching exceptionWhileDataFetching) {
        Throwable cause;
        if (exceptionWhileDataFetching.getException() instanceof CompletionException) {
            CompletionException completionException = (CompletionException) exceptionWhileDataFetching.getException();
            cause = completionException.getCause();
        } else {
            cause = exceptionWhileDataFetching.getException();
        }
        return cause;
    }

    private List<GraphQLError> extractErrors(ExecutionResult result) {
        return result==null || result.getErrors().isEmpty()?
                Collections.EMPTY_LIST:
                result.getErrors();
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    @JsonValue
    public Map<String, Object> getResponse() {
        return response;
    }

}
