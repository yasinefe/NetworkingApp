package com.rbwm.ted.spike.grapql.service;

import com.rbwm.ted.spike.grapql.exception.NotFoundException;
import com.rbwm.ted.spike.grapql.exception.ValidationException;
import com.rbwm.ted.spike.grapql.model.Appointment;
import com.rbwm.ted.spike.grapql.repository.InMemoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by 44052007 on 16/10/2017.
 */
@Service
public class AppointmentService {

    private InMemoryRepository repository;

    private Function<Map<String, Object>, Appointment> mapAppointmentFunction;

    @Autowired
    public AppointmentService(InMemoryRepository repository) {
        this.repository = repository;
        mapAppointmentFunction = appointment -> new Appointment((String)appointment.get("appointmentId"), (String) appointment.get("name"), (String) appointment.get("categoryId"), (Integer) appointment.get("revision"));
    }

    public List<Appointment> getAllAppointments() {
        return repository.getAppointments().stream()
                .map(mapAppointmentFunction)
                .collect(Collectors.toList());
    }

    public Appointment getAppointment(String appointmentId) {
        return mapAppointmentFunction.apply(repository.getAppointment(appointmentId));
    }

    public List<Appointment> getAppointments(String categoryId) {
        return repository.getAppointmentsByCategoryId(categoryId).stream()
                .map(mapAppointmentFunction)
                .collect(Collectors.toList());
    }

    public Appointment updateAppointment(String appointmentId, String name, String categoryId, Integer revision) {
        return mapAppointmentFunction.apply(repository.updateAppointment(appointmentId, name, categoryId, revision));
    }

    public Appointment createAppointment(String name, String categoryId) {
        try {
            Integer.valueOf(name.substring(0, 1));
            throw new ValidationException("name", "APPOINTMENT_STARTS_WITH_NUMBER", "Appointment name should not start with number");
        } catch (NumberFormatException e) {

        }
        try {
            repository.getCategory(categoryId);
        } catch (NotFoundException e) {
            throw new ValidationException("categoryId", e.code, e.getMessage());
        }

        return mapAppointmentFunction.apply(repository.createAppointment(name, categoryId));
    }

    public void removeAppointment(String appointmentId) {
        repository.removeAppointment(appointmentId);
    }
}
