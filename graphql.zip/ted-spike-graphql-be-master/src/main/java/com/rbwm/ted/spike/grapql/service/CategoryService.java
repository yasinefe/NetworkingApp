package com.rbwm.ted.spike.grapql.service;

import com.rbwm.ted.spike.grapql.model.Category;
import com.rbwm.ted.spike.grapql.model.CategoryAppointment;
import com.rbwm.ted.spike.grapql.repository.InMemoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by 44052007 on 16/10/2017.
 */
@Service
public class CategoryService {

    private InMemoryRepository repository;

    private Function<Map<String, Object>, Category> mapCategoryFunction;
    private BiFunction<Map<String, Object>, Integer, CategoryAppointment> mapCategoryAppointmentFunction;

    @Autowired
    public CategoryService(InMemoryRepository repository) {
        this.repository = repository;
        mapCategoryFunction = category -> new Category((String)category.get("categoryId"), (String) category.get("name"));
        mapCategoryAppointmentFunction = (category, count) -> new CategoryAppointment((String)category.get("categoryId"), mapCategoryFunction.apply(category), count);
    }

    public List<Category> getAllCategories() {
        return repository.getCategories().stream()
                .map(mapCategoryFunction)
                .collect(Collectors.toList());
    }

    public List<CategoryAppointment> getAllCategoryAppointments() {
        List<Map<String, Object>> categories = repository.getCategories();
        List<CategoryAppointment> categoryAppointments = new LinkedList<>();
        categories.forEach(category -> categoryAppointments.add(mapCategoryAppointmentFunction.apply(category, repository.getAppointmentsByCategoryId((String)category.get("categoryId")).size())));
        return categoryAppointments;
    }

    public Category getCategory(String categoryId) {
        Map<String, Object> category = repository.getCategory(categoryId);
        return mapCategoryFunction.apply(category);
    }

    public CategoryAppointment getCategoryAppointment(String categoryId) {
        Map<String, Object> category = repository.getCategory(categoryId);
        return mapCategoryAppointmentFunction.apply(category, repository.getAppointmentsByCategoryId((String) category.get("categoryId")).size());
    }
}
