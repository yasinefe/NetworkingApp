package com.rbwm.ted.spike.grapql.schema;

import com.rbwm.ted.spike.grapql.model.Appointment;
import com.rbwm.ted.spike.grapql.model.Category;
import com.rbwm.ted.spike.grapql.model.CategoryAppointment;
import com.rbwm.ted.spike.grapql.schema.filter.FilteredConnection;
import com.rbwm.ted.spike.grapql.service.AppointmentService;
import com.rbwm.ted.spike.grapql.service.CategoryService;
import graphql.relay.Connection;
import graphql.relay.Relay;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.StaticDataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

/**
 * Created by 44052007 on 13/10/2017.
 */
@Component
public class DataFetchers {

    public final DataFetcher<CompletableFuture<Connection<Appointment>>> allAppointments;
    public final DataFetcher<CompletableFuture<Connection<Category>>> allCategories;
    public final DataFetcher<CompletableFuture<Connection<CategoryAppointment>>> allCategoryAppointments;

    public final DataFetcher<CompletableFuture<List<Appointment>>> appointmentsFetcher;
    public final DataFetcher<CompletableFuture<Appointment>> appointmentNodeFetcher;

    public final DataFetcher<CompletableFuture<Category>> categoryFetcher;
    public final DataFetcher<CompletableFuture<Category>> categoryNodeFetcher;

    public final DataFetcher<CompletableFuture<CategoryAppointment>> categoryAppointmentNodeFetcher;

    public final DataFetcher appointmentUpdater;
    public final DataFetcher appointmentCreator;
    public final DataFetcher appointmentRemover;

    public final DataFetcher appointmentIdFetcher;
    public final DataFetcher categoryIdFetcher;
    public final DataFetcher appointmentCategoryIdFetcher;
    public final DataFetcher categoryAppointmentIdFetcher;
    public final DataFetcher edgeCountFetcher;
    public final DataFetcher viewerFetcher;
    public final DataFetcher viewerIdFetcher;

    @Autowired
    public DataFetchers(NodeInterfaceHandler nodeInterfaceHandler, AsyncDataFetcher asyncDataFetcher, AppointmentService appointmentService, CategoryService categoryService) {
        Relay relay = nodeInterfaceHandler.relay;

        Function<DataFetchingEnvironment, String> resolveId = env -> relay.fromGlobalId(env.getArgument("id")).getId();

        // Query Fetchers
        allAppointments = env -> asyncDataFetcher.fetchAsync(() -> new FilteredConnection(appointmentService.getAllAppointments()).get(env));
        allCategories = env -> asyncDataFetcher.fetchAsync(() ->  new FilteredConnection(categoryService.getAllCategories()).get(env));
        allCategoryAppointments = env ->  asyncDataFetcher.fetchAsync(() -> new FilteredConnection(categoryService.getAllCategoryAppointments()).get(env));

        // Object Fetchers
        appointmentsFetcher = env -> asyncDataFetcher.fetchAsync(() -> {
            Category category = env.getSource();
            return appointmentService.getAppointments(category.id);
        });
        categoryFetcher = env -> asyncDataFetcher.fetchAsync(() -> {
            Appointment appointment = env.getSource();
            return categoryService.getCategory(appointment.categoryId);
        });

        // Node Fetchers
        appointmentNodeFetcher = env -> asyncDataFetcher.fetchAsync(() -> appointmentService.getAppointment(resolveId.apply(env)));
        categoryNodeFetcher = env -> asyncDataFetcher.fetchAsync(() -> categoryService.getCategory(resolveId.apply(env)));
        categoryAppointmentNodeFetcher = env -> asyncDataFetcher.fetchAsync(() -> categoryService.getCategoryAppointment(resolveId.apply(env)));

        // Mutation Fetchers
        appointmentUpdater = env -> {
            Map<String, Object> input = (Map<String, Object>) env.getArguments().get("input");
            String appointmentId = relay.fromGlobalId((String) input.get("id")).getId();
            String name = (String)input.get("name");
            String categoryId = relay.fromGlobalId((String) input.get("categoryId")).getId();
            Integer revision = (Integer) input.get("revision");

            Appointment appointment = appointmentService.updateAppointment(appointmentId, name, categoryId, revision);

            return new HashMap<String, Object>(){{
                put("appointment", appointment);
                put("clientMutationId", input.get("clientMutationId"));
            }};
        };

        appointmentCreator = env -> {
            Map<String, Object> input = (Map<String, Object>) env.getArguments().get("input");
            String name = (String)input.get("name");
            String categoryId = relay.fromGlobalId((String) input.get("categoryId")).getId();
            Appointment appointment = appointmentService.createAppointment(name, categoryId);

            return new HashMap<String, Object>(){{
                put("appointment", appointment);
                put("clientMutationId", input.get("clientMutationId"));
            }};
        };

        appointmentRemover = env -> {
            Map<String, Object> input = (Map<String, Object>) env.getArguments().get("input");
            String appointmentId = relay.fromGlobalId((String) input.get("id")).getId();
            appointmentService.removeAppointment(appointmentId);

            return new HashMap<String, Object>(){{
                put("clientMutationId", input.get("clientMutationId"));
            }};
        };

        appointmentIdFetcher = env -> {
            Appointment appointment = env.getSource();
            return relay.toGlobalId("Appointment", appointment.id);
        };

        categoryIdFetcher = env -> {
            Category category = env.getSource();
            return relay.toGlobalId("Category", category.id);
        };

        appointmentCategoryIdFetcher = env -> {
            Appointment appointment = env.getSource();
            return relay.toGlobalId("Category", appointment.categoryId);
        };

        categoryAppointmentIdFetcher = env -> {
            CategoryAppointment categoryAppointment = env.getSource();
            return nodeInterfaceHandler.relay.toGlobalId("CategoryAppointment", categoryAppointment.id);
        };

        edgeCountFetcher = environment -> {
            Connection connection = environment.getSource();
            return connection.getEdges().size();
        };

        viewerFetcher = new StaticDataFetcher("Viewer");

        viewerIdFetcher = env -> nodeInterfaceHandler.relay.toGlobalId("Viewer", "1");
    }

}
