package com.rbwm.ted.spike.grapql.schema.filter;

import graphql.GraphQLException;
import graphql.Scalars;
import graphql.relay.Connection;
import graphql.relay.Relay;
import graphql.relay.SimpleListConnection;
import graphql.schema.*;

import java.lang.reflect.Field;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by 44052007 on 17/10/2017.
 */
public class FilteredConnection<T> implements DataFetcher<Connection<T>> {

    private List<T> data;

    public FilteredConnection(List<T> data) {
        this.data = data;
    }

    @Override
    public Connection<T> get(DataFetchingEnvironment environment) {
        List<T> filteredData = applyFilters(environment);
        return new SimpleListConnection<T>(filteredData).get(environment);
    }

    private List<T> applyFilters(DataFetchingEnvironment environment) {
        List<T> filteredData = new LinkedList<>(data);
        Map<String, Object> filter = environment.getArgument("filter");
        if (filter == null) {
            return filteredData;
        }

        GraphQLObjectType connectionType = (GraphQLObjectType) environment.getFieldType();
        GraphQLList edgeType = (GraphQLList) connectionType.getFieldDefinition("edges").getType();
        GraphQLObjectType edgeObjectType = (GraphQLObjectType) edgeType.getWrappedType();
        GraphQLObjectType outputObjectType = (GraphQLObjectType) edgeObjectType.getFieldDefinition("node").getType();
        List<GraphQLFieldDefinition> fieldDefinitions = outputObjectType.getFieldDefinitions();


        for (GraphQLFieldDefinition graphQLFieldDefinition : fieldDefinitions) {
            if (getType(graphQLFieldDefinition.getType()) == Scalars.GraphQLString) {
                filteredData = applyStringFilters(filteredData, graphQLFieldDefinition.getName(), filter);
            }
            if (getType(graphQLFieldDefinition.getType()) == Scalars.GraphQLID) {
                filteredData = applyIdFilters(filteredData, graphQLFieldDefinition.getName(), filter);
            }
        }

        return filteredData;
    }

    private static GraphQLOutputType getType(GraphQLOutputType graphQLOutputType) {
        if (graphQLOutputType instanceof GraphQLModifiedType) {
            return (GraphQLOutputType) ((GraphQLModifiedType) graphQLOutputType).getWrappedType();
        }
        return graphQLOutputType;
    }

    private List<T> applyStringFilters(List<T> data, String fieldName, Map<String, Object> filter) {
        List<T> filteredData = new LinkedList<>();
        for (T obj : data) {
            if (applyStringEqualFilter(obj, fieldName, (String) filter.get(fieldName)) &&
                    applyStringNotEqualFilter(obj, fieldName, (String) filter.get(fieldName + "_not")) &&
                    applyStringContainsFilter(obj, fieldName, (String) filter.get(fieldName + "_contains")) &&
                    applyStringNotContainsFilter(obj, fieldName, (String) filter.get(fieldName + "_not_contains")) &&
                    applyStringStartsWithFilter(obj, fieldName, (String) filter.get(fieldName + "_starts_with")) &&
                    applyStringNotStartsWithFilter(obj, fieldName, (String) filter.get(fieldName + "_not_starts_with"))
                    ) {
                filteredData.add(obj);
            }
        }
        return filteredData;
    }

    private List<T> applyIdFilters(List<T> data, String fieldName, Map<String, Object> filter) {
        List<T> filteredData = new LinkedList<>();
        for (T obj : data) {
            if (applyIdEqualFilter(obj, fieldName, (String) filter.get(fieldName)) &&
                    applyIdNotEqualFilter(obj, fieldName, (String) filter.get(fieldName + "_not"))
                    ) {
                filteredData.add(obj);
            }
        }
        return filteredData;
    }

    private boolean applyIdEqualFilter(T obj, String fieldName, String value) {
        return value == null || getFieldValue(obj, fieldName).equals(new Relay().fromGlobalId(value).getId());
    }

    private boolean applyIdNotEqualFilter(T obj, String fieldName, String value) {
        return value == null || !getFieldValue(obj, fieldName).equals(new Relay().fromGlobalId(value).getId());
    }

    private boolean applyStringEqualFilter(T obj, String fieldName, String value) {
        return value == null || getFieldValue(obj, fieldName).equals(value);
    }

    private boolean applyStringNotEqualFilter(T obj, String fieldName, String value) {
        return value == null || !getFieldValue(obj, fieldName).equals(value);
    }

    private boolean applyStringContainsFilter(T obj, String fieldName, String value) {
        return value == null || ((String) getFieldValue(obj, fieldName)).contains(value);
    }

    private boolean applyStringNotContainsFilter(T obj, String fieldName, String value) {
        return value == null || !((String) getFieldValue(obj, fieldName)).contains(value);
    }

    private boolean applyStringStartsWithFilter(T obj, String fieldName, String value) {
        return value == null || ((String) getFieldValue(obj, fieldName)).startsWith(value);
    }

    private boolean applyStringNotStartsWithFilter(T obj, String fieldName, String value) {
        return value == null || !((String) getFieldValue(obj, fieldName)).startsWith(value);
    }

    private <R> R getFieldValue(T obj, String fieldName) {
        try {
            Field field = obj.getClass().getField(fieldName);
            return (R) field.get(obj);
        } catch (NoSuchFieldException e) {
            throw new GraphQLException("field " + fieldName + " not found");
        } catch (IllegalAccessException e) {
            throw new GraphQLException("illegal access to field " + fieldName);
        }
    }
}
