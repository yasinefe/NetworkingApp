package com.rbwm.ted.spike.grapql.schema;

import com.rbwm.ted.spike.grapql.model.Appointment;
import com.rbwm.ted.spike.grapql.model.Category;
import com.rbwm.ted.spike.grapql.model.CategoryAppointment;
import graphql.schema.GraphQLObjectType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by 44052007 on 13/10/2017.
 */
@Component
public class NodeQueries {

    @Autowired
    public NodeQueries(NodeInterfaceHandler nodeInterfaceHandler, DataFetchers dataFetchers, Graph graph) {
        nodeInterfaceHandler.nodeFetcherResolver.put("Appointment", dataFetchers.appointmentNodeFetcher);
        nodeInterfaceHandler.nodeFetcherResolver.put("Category", dataFetchers.categoryNodeFetcher);
        nodeInterfaceHandler.nodeFetcherResolver.put("CategoryAppointment", dataFetchers.categoryAppointmentNodeFetcher);

        nodeInterfaceHandler.typeResolverProxy.setTypeResolver(
                typeResolver -> {
                    if (typeResolver.getObject() instanceof Appointment) {
                        return (GraphQLObjectType)graph.getSchema().getType("Appointment");
                    } else if (typeResolver.getObject() instanceof Category) {
                        return (GraphQLObjectType)graph.getSchema().getType("Category");
                    } else if (typeResolver.getObject() instanceof CategoryAppointment) {
                        return (GraphQLObjectType)graph.getSchema().getType("CategoryAppointment");
                    }
                    return null;
                }
        );
    }

}
