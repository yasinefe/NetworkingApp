package com.rbwm.ted.spike.grapql.schema.filter;

import graphql.Scalars;
import graphql.schema.*;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by 44052007 on 17/10/2017.
 */
public class FilterBuilder {


    public static GraphQLArgument createFilter(GraphQLObjectType appointmentConnection) {
        GraphQLList edgeType = (GraphQLList) appointmentConnection.getFieldDefinition("edges").getType();
        GraphQLObjectType edgeObjectType = (GraphQLObjectType)edgeType.getWrappedType();
        GraphQLObjectType outputObjectType = (GraphQLObjectType)edgeObjectType.getFieldDefinition("node").getType();
        List<GraphQLFieldDefinition> fieldDefinitions = outputObjectType.getFieldDefinitions();

        List<GraphQLInputObjectField> inputObjectFields = new LinkedList<>();

        fieldDefinitions.forEach(graphQLFieldDefinition -> {
            if (getType(graphQLFieldDefinition.getType()) == Scalars.GraphQLString) {
                inputObjectFields.addAll(createStringFilterInputFields(graphQLFieldDefinition.getName()));
            }
            if (getType(graphQLFieldDefinition.getType()) == Scalars.GraphQLID) {
                inputObjectFields.addAll(createIdFilterInputFields(graphQLFieldDefinition.getName()));
            }
        });

        return GraphQLArgument.newArgument().name("filter").description("filter argument").type(GraphQLInputObjectType.newInputObject().name(outputObjectType.getName() + "Filter").fields(inputObjectFields).build()).build();
    }

    private static GraphQLOutputType getType(GraphQLOutputType graphQLOutputType){
        if (graphQLOutputType instanceof GraphQLModifiedType) {
            return (GraphQLOutputType)((GraphQLModifiedType)graphQLOutputType).getWrappedType();
        }
        return graphQLOutputType;
    }

    private static List<GraphQLInputObjectField> createStringFilterInputFields(String name) {
        return Arrays.asList(
                GraphQLInputObjectField.newInputObjectField().name(name).description("filter equal to").type(Scalars.GraphQLString).build(),
                GraphQLInputObjectField.newInputObjectField().name(name + "_not").description("filter not equal to").type(Scalars.GraphQLString).build(),
                GraphQLInputObjectField.newInputObjectField().name(name + "_contains").description("filter contains").type(Scalars.GraphQLString).build(),
                GraphQLInputObjectField.newInputObjectField().name(name + "_not_contains").description("filter not contains").type(Scalars.GraphQLString).build(),
                GraphQLInputObjectField.newInputObjectField().name(name + "_starts_with").description("filter starts with").type(Scalars.GraphQLString).build(),
                GraphQLInputObjectField.newInputObjectField().name(name + "_not_starts_with").description("filter not starts with").type(Scalars.GraphQLString).build()
        );
    }

    private static List<GraphQLInputObjectField> createIdFilterInputFields(String name) {
        return Arrays.asList(
                GraphQLInputObjectField.newInputObjectField().name(name).description("filter equal to").type(Scalars.GraphQLID).build(),
                GraphQLInputObjectField.newInputObjectField().name(name + "_not").description("filter not equal to").type(Scalars.GraphQLID).build()
        );
    }
}
