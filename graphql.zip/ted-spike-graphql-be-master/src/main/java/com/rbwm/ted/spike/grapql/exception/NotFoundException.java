package com.rbwm.ted.spike.grapql.exception;

/**
 * Created by 44052007 on 23/10/2017.
 */
public class NotFoundException extends ErrorCodeException {

    public NotFoundException(String code, String message) {
        super(code, message);
    }
}
