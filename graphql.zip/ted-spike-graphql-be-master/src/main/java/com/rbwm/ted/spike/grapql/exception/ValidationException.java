package com.rbwm.ted.spike.grapql.exception;

/**
 * Created by 44052007 on 23/10/2017.
 */
public class ValidationException extends ErrorCodeException {

    public final String field;

    public ValidationException(String field, String code, String message) {
        super(code, message);
        this.field = field;
    }


}
