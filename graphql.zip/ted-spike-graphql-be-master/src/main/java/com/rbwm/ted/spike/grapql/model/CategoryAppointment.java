package com.rbwm.ted.spike.grapql.model;

/**
 * Created by 44052007 on 13/10/2017.
 */
public class CategoryAppointment {

    public final String id;
    public final Category category;
    public final int count;

    public CategoryAppointment(String id, Category category, int count) {
        this.id = id;
        this.category = category;
        this.count = count;
    }
}
