package com.rbwm.ted.spike.grapql.model;

/**
 * Created by 44052007 on 13/10/2017.
 */
public class Category {

    public final String id;
    public final String name;

    public Category(String id, String name) {
        this.id = id;
        this.name = name;
    }
}
