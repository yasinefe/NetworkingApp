package com.rbwm.ted.spike.grapql;

import com.rbwm.ted.spike.grapql.repository.InMemoryRepository;
import com.rbwm.ted.spike.grapql.schema.Graph;
import com.rbwm.ted.spike.grapql.schema.executor.GraphQLContext;
import com.rbwm.ted.spike.grapql.schema.executor.GraphQLHttpResponse;
import graphql.ExecutionResult;
import graphql.GraphQL;
import graphql.introspection.IntrospectionQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


/**
 * Created by 43578876 on 28/10/2016.
 */
@Controller
public class GraphQLController {

    private final GraphQL graphql;
    private final InMemoryRepository repository;

    @Autowired
    public GraphQLController(Graph graph, InMemoryRepository repository) {
        this.graphql = GraphQL.newGraphQL(graph.getSchema()).build();
        this.repository = repository;
    }

    @RequestMapping(value = "/schema", method = RequestMethod.GET)
    @ResponseBody
    @CrossOrigin
    public Map<String,Object> getSchema() {
        Map<String, Object> result = new LinkedHashMap<>();
        ExecutionResult executionResult =  graphql.execute(IntrospectionQuery.INTROSPECTION_QUERY);
        result.put("data", executionResult.getData());
        return result;
    }

    @RequestMapping(value = "/reset", method = RequestMethod.GET)
    @ResponseBody
    @CrossOrigin
    public Map<String,Object> reset() {
        repository.primeData();
        return new HashMap<String, Object>(){{
            put("result", "Data has been reset");
        }};
    }

    @RequestMapping(value = "/graphql", method = RequestMethod.POST)
    @ResponseBody
    @CrossOrigin
    public ResponseEntity<?> executeOperation(@RequestBody Map<String,Object> body) {
        String query = (String) body.get("query");
        Map<String, Object> variables = (Map<String, Object>) body.get("variables");

        GraphQLHttpResponse response = new GraphQLHttpResponse(graphql, query, new GraphQLContext(), variables);

        return new ResponseEntity<>(response, response.getHttpStatus());
    }
}
