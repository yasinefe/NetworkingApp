package com.rbwm.ted.spike.grapql.exception;

/**
 * Created by 44052007 on 23/10/2017.
 */
public class ErrorCodeException extends RuntimeException {

    public final String code;

    public ErrorCodeException(String code, String message) {
        super(message);
        this.code = code;
    }
}
