package com.rbwm.ted.spike.grapql.schema;

import graphql.relay.Relay;
import graphql.schema.DataFetcher;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLInterfaceType;
import graphql.schema.TypeResolverProxy;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 44052007 on 13/10/2017.
 */
@Component
public class NodeInterfaceHandler {

    public final Relay relay;
    public final TypeResolverProxy typeResolverProxy;
    public final Map<String, DataFetcher> nodeFetcherResolver = new HashMap();
    public final DataFetcher nodeDataFetcher;
    public final GraphQLInterfaceType nodeInterface;
    public final GraphQLFieldDefinition nodeField;

    public NodeInterfaceHandler() {
        this.relay = new Relay();
        this.typeResolverProxy = new TypeResolverProxy();
        this.nodeInterface = relay.nodeInterface(typeResolverProxy);

        this.nodeDataFetcher = env -> {
            Relay.ResolvedGlobalId globalId = relay.fromGlobalId(env.getArgument("id"));
            return nodeFetcherResolver.get(globalId.getType()).get(env);
        };

        nodeField = relay.nodeField(nodeInterface, nodeDataFetcher);
    }

}
