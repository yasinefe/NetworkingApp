package com.rbwm.ted.spike.grapql.repository;

import com.rbwm.ted.spike.grapql.exception.ConflictException;
import com.rbwm.ted.spike.grapql.exception.NotFoundException;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by 44052007 on 16/10/2017.
 */
@Repository
public class InMemoryRepository {

    private List<Map<String, Object>> appointments;

    private List<Map<String, Object>> categories;

    private int appointmentId;

    public InMemoryRepository() {
        appointmentId = 1000100;
        primeData();
    }

    private String generateAppointmentId() {
        return String.valueOf(appointmentId++);
    }

    public void primeData() {
        appointments = new LinkedList<>();
        appointments.add(createAppointmentMap(generateAppointmentId(), "Daniel Costin", "111"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Yasin Efe", "111"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Oliver Relph", "222"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Adam Edwards", "222"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Daryl Browne", "222"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Joseph Chang", "222"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Andrew Wyld", "333"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Stuart Law", "333"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Optimus Prime", "444"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Sentinel Prime", "444"));
        appointments.add(createAppointmentMap(generateAppointmentId(), "Rodimus Prime", "444"));

        categories = new LinkedList<>();
        categories.add(createCategory("111", "Backend"));
        categories.add(createCategory("222", "Frontend"));
        categories.add(createCategory("333", "Architect"));
        categories.add(createCategory("444", "Transformer"));
    }

    private Map<String,Object> createAppointmentMap(String appointmentId, String name, String categoryId) {
        return new HashMap<String, Object>() {{
            put("appointmentId", appointmentId);
            put("name", name);
            put("categoryId", categoryId);
            put("revision", 1);
        }};
    }

    private Map<String,Object> createCategory(String categoryId, String name) {
        return new HashMap<String, Object>() {{
            put("categoryId", categoryId);
            put("name", name);
        }};
    }

    public List<Map<String, Object>> getAppointments() {
        return appointments;
    }

    public Map<String, Object> getAppointment(String appointmentId) {
        return appointments.stream()
                .filter(appointment -> appointment.get("appointmentId").equals(appointmentId))
                .findFirst().orElseThrow(() -> new NotFoundException("APPOINTMENT_NOT_FOUND", "Appointment not found"));
    }

    public List<Map<String, Object>> getCategories() {
        return categories;
    }

    public Map<String, Object> getCategory(String categoryId) {
        return categories.stream()
                .filter(category -> category.get("categoryId").equals(categoryId))
                .findFirst().orElseThrow(() -> new NotFoundException("CATEGORY_NOT_FOUND", "Category not found"));
    }

    public List<Map<String, Object>> getAppointmentsByCategoryId(String categoryId) {
        return appointments.stream()
                .filter(appointment -> appointment.get("categoryId").equals(categoryId))
                .collect(Collectors.toList());
    }

    public Map<String, Object> updateAppointment(String appointmentId, String name, String categoryId, Integer revision) {
        Map<String, Object> appointment = getAppointment(appointmentId);

        if (revision < (Integer) appointment.get("revision")) {
            throw new ConflictException("APPOINTMENT_HAS_ALREADY_BEEN_UPDATED", "Appointment has already been updated, revision: " + appointment.get("revision"));
        }

        appointment.put("name", name);
        appointment.put("categoryId", categoryId);
        appointment.put("revision", (Integer)appointment.get("revision") + 1);
        return appointment;
    }

    public Map<String, Object> createAppointment(String name, String categoryId) {
        Map<String, Object> category = getCategory(categoryId);
        Map<String, Object> appointmentMap = createAppointmentMap(generateAppointmentId(), name, (String)category.get("categoryId"));
        appointments.add(appointmentMap);
        return appointmentMap;
    }

    public void removeAppointment(String appointmentId) {
        appointments.remove(getAppointment(appointmentId));
    }
}
