# ted-spike-graphql-be
Back end service to spike graphql

## GraphQL URL

POST https://ted-spike-graphql-be.cf.wgdc-drn-01.cloud.uk.hsbc/graphql

## URL to Get Schema

GET https://ted-spike-graphql-be.cf.wgdc-drn-01.cloud.uk.hsbc/schema

## URL to Reset In Memory Data

GET https://ted-spike-graphql-be.cf.wgdc-drn-01.cloud.uk.hsbc/reset

## Query All Appointments

```
{
	"query":"{ viewer { allAppointments { count pageInfo { hasNextPage } edges { node { id name revision category { id name appointments { id name category { id name } } } } } } } }"
}
```

## Query All Categories

```
{
	"query":"{ viewer { allCategories { count pageInfo { hasNextPage } edges { node { id name appointments { id name category { id name } } } } } } }"
}
```

## Query All CategoryAppointment

```
{
	"query":"{ viewer { allCategoryAppointments { count pageInfo { hasNextPage } edges { node { id category { id name appointments { id name } } count } } } } }"
}
```

## Mutation to Update Appointment

```
{
	"query":"mutation UpdateAppointmentMutation($input:UpdateAppointmentInput!) { updateAppointment(input:$input) { clientMutationId appointment { id name category { id name } } viewer { allCategories { count pageInfo { hasNextPage } edges { node { id name appointments { id name category { id name } } } } } } } }",
	"variables": {
		"input":{
			"id":"QXBwb2ludG1lbnQ6MTAwMDEwMA==",
			"name": "Daniel Costin",
			"categoryId": "Q2F0ZWdvcnk6MzMz",
			"clientMutationId":"10",
			"revision": 1
		}
	}
}
```

## Mutation to Create Appointment

```
{
	"query":"mutation CreateAppointmentMutation($input:CreateAppointmentInput!) { createAppointment(input:$input) { clientMutationId appointment { id name category { id name } } viewer { allCategories { count pageInfo { hasNextPage } edges { node { id name appointments { id name category { id name } } } } } } } }",
	"variables": {
		"input":{
			"name": "Daniel Costin",
			"categoryId": "Q2F0ZWdvcnk6MzMz",
			"clientMutationId":"10"
		}
	}
}
```

## Mutation to Delete Appointment

```
{
	"query":"mutation DeleteAppointmentMutation($input:DeleteAppointmentInput!) { deleteAppointment(input:$input) { clientMutationId viewer { allCategories { count pageInfo { hasNextPage } edges { node { id name appointments { id name category { id name } } } } } } } }",
	"variables": {
		"input":{
			"id":"QXBwb2ludG1lbnQ6MTAwMDEwMA==",
			"clientMutationId":"10"
		}
	}
}
```

## Node Query for Appointment

```
{
	"query":"{node (id:\"QXBwb2ludG1lbnQ6MTAwMDEwMA==\") { id ... on Appointment { id name }}}"
}
```

## Node Query for Category

```
{
	"query":"{node (id:\"Q2F0ZWdvcnk6MTEx\") { id ... on Category { id name }}}"
}
```

## Node Query for CategoryAppointment

```
{
	"query":"{node (id:\"Q2F0ZWdvcnlBcHBvaW50bWVudDoxMTE=\") { id ... on CategoryAppointment { id category {id name} count }}}"
}
```